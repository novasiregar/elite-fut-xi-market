"use client"

import { useEffect, useState } from "react"

type HapticType = "light" | "medium" | "heavy" | "success" | "warning" | "error" | "notification"

export function useHapticFeedback() {
  const [hapticAvailable, setHapticAvailable] = useState(false)

  useEffect(() => {
    // Check if the navigator.vibrate API is available
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      setHapticAvailable(true)
    }
  }, [])

  const triggerHaptic = (type: HapticType) => {
    if (!hapticAvailable) return

    switch (type) {
      case "light":
        navigator.vibrate(10)
        break
      case "medium":
        navigator.vibrate(25)
        break
      case "heavy":
        navigator.vibrate(50)
        break
      case "success":
        navigator.vibrate([10, 30, 50])
        break
      case "warning":
        navigator.vibrate([50, 30, 50])
        break
      case "error":
        navigator.vibrate([100, 30, 100])
        break
      case "notification":
        navigator.vibrate([10, 20, 10])
        break
      default:
        navigator.vibrate(25)
    }
  }

  return { triggerHaptic, hapticAvailable }
}
