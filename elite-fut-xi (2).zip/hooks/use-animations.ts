"use client"

import { useState, useEffect, useRef } from "react"
import { useInView } from "react-intersection-observer"

// Fade in animation hook
export function useFadeIn(delay = 0, duration = 0.5, threshold = 0.1) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold,
  })

  return {
    ref,
    style: {
      opacity: inView ? 1 : 0,
      transform: inView ? "translateY(0)" : "translateY(20px)",
      transition: `opacity ${duration}s ease-out, transform ${duration}s ease-out`,
      transitionDelay: `${delay}s`,
    },
  }
}

// Pixel reveal animation hook
export function usePixelReveal(delay = 0, duration = 0.8, threshold = 0.1) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold,
  })

  return {
    ref,
    className: inView ? "pixel-reveal-active" : "pixel-reveal",
    style: {
      animationDelay: `${delay}s`,
      animationDuration: `${duration}s`,
    },
  }
}

// Glitch text animation hook
export function useGlitchText(text: string, interval = 100, duration = 2000) {
  const [displayText, setDisplayText] = useState(text)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const originalText = useRef(text)
  const isAnimating = useRef(false)

  const glitchChars = "!<>-_\\/[]{}—=+*^?#________"

  const getRandomChar = () => {
    return glitchChars[Math.floor(Math.random() * glitchChars.length)]
  }

  const glitch = () => {
    if (isAnimating.current) return

    isAnimating.current = true
    let iterations = 0
    const maxIterations = 10

    intervalRef.current = setInterval(() => {
      setDisplayText((prevText) => {
        const randomIndex = Math.floor(Math.random() * originalText.current.length)
        const randomChar = getRandomChar()
        const newText = prevText.substring(0, randomIndex) + randomChar + prevText.substring(randomIndex + 1)
        return newText
      })

      iterations++
      if (iterations >= maxIterations) {
        if (intervalRef.current) clearInterval(intervalRef.current)
        setDisplayText(originalText.current)
        isAnimating.current = false
      }
    }, interval)

    timeoutRef.current = setTimeout(() => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      setDisplayText(originalText.current)
      isAnimating.current = false
    }, duration)
  }

  useEffect(() => {
    originalText.current = text
    setDisplayText(text)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [text])

  return { displayText, glitch }
}

// Counter animation hook
export function useCounter(end: number, duration = 2000, start = 0) {
  const [count, setCount] = useState(start)
  const countRef = useRef(start)
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  useEffect(() => {
    if (!inView) return

    countRef.current = start
    const step = (end - start) / (duration / 16)
    let animationFrame: number

    const updateCount = () => {
      if (countRef.current < end) {
        countRef.current += step
        if (countRef.current > end) countRef.current = end
        setCount(Math.floor(countRef.current))
        animationFrame = requestAnimationFrame(updateCount)
      }
    }

    animationFrame = requestAnimationFrame(updateCount)

    return () => {
      cancelAnimationFrame(animationFrame)
    }
  }, [inView, end, duration, start])

  return { count, ref }
}
