"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import { MessageService } from "@/client/services/messages"
import { Send, Shield, ImageIcon, Smile, Paperclip, MoreVertical, Check, CheckCheck, Clock } from "lucide-react"
import { motion } from "framer-motion"

interface EnhancedMessagingProps {
  conversationId?: string
  recipientId?: string
  listingId?: string
}

export function EnhancedMessaging({ conversationId, recipientId, listingId }: EnhancedMessagingProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [conversation, setConversation] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSending, setIsSending] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Fetch conversation and messages
  useEffect(() => {
    if (!user) return

    const fetchData = async () => {
      try {
        setIsLoading(true)

        if (conversationId) {
          // Fetch existing conversation
          const data = await MessageService.getMessages(conversationId)
          setConversation(data)
          setMessages(data.messages || [])
        } else if (recipientId) {
          // Check if conversation exists
          const conversations = await MessageService.getConversations()
          const existingConversation = conversations.find((conv: any) => conv.otherParticipant.id === recipientId)

          if (existingConversation) {
            const data = await MessageService.getMessages(existingConversation.id)
            setConversation(data)
            setMessages(data.messages || [])
          } else {
            // New conversation
            setConversation({
              newConversation: true,
              otherParticipant: {
                id: recipientId,
              },
              listingId,
            })
            setMessages([])
          }
        }
      } catch (error) {
        console.error("Error fetching messages:", error)
        toast({
          title: "Error",
          description: "Failed to load messages",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()

    // Set up polling for new messages
    const interval = setInterval(fetchData, 10000)
    return () => clearInterval(interval)
  }, [user, conversationId, recipientId, listingId, toast])

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Simulate typing indicator
  const simulateTyping = () => {
    // Clear any existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current)
    }

    // Show typing indicator
    setIsTyping(true)

    // Hide typing indicator after random time (1-3 seconds)
    const randomTime = Math.floor(Math.random() * 2000) + 1000
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false)
    }, randomTime)
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    try {
      setIsSending(true)

      if (conversation.newConversation) {
        // Create new conversation
        const response = await MessageService.createConversation(
          conversation.otherParticipant.id,
          newMessage,
          conversation.listingId,
        )

        // Refresh conversation
        const data = await MessageService.getMessages(response.conversationId)
        setConversation(data)
        setMessages(data.messages || [])
      } else {
        // Send message to existing conversation
        await MessageService.sendMessage(conversation.id, newMessage)

        // Add message to UI immediately
        const newMsg = {
          id: Date.now().toString(),
          senderId: user?.uid,
          content: newMessage,
          createdAt: new Date().toISOString(),
          read: false,
          status: "sending",
        }

        setMessages((prev) => [...prev, newMsg])

        // Simulate message being delivered
        setTimeout(() => {
          setMessages((prev) => prev.map((msg) => (msg.id === newMsg.id ? { ...msg, status: "sent" } : msg)))

          // Simulate message being read after another delay
          setTimeout(() => {
            setMessages((prev) =>
              prev.map((msg) => (msg.id === newMsg.id ? { ...msg, status: "read", read: true } : msg)),
            )

            // Simulate typing response
            simulateTyping()
          }, 2000)
        }, 1000)
      }

      // Clear new message
      setNewMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  if (isLoading) {
    return (
      <Card className="h-[70vh] bg-card/50 backdrop-blur-sm">
        <CardContent className="p-0 h-full flex flex-col">
          <div className="p-3 border-b border-border animate-pulse">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-muted"></div>
              <div className="space-y-2">
                <div className="h-4 w-24 bg-muted rounded"></div>
                <div className="h-3 w-16 bg-muted rounded"></div>
              </div>
            </div>
          </div>

          <div className="flex-1 p-4 space-y-4">
            <div className="w-3/4 h-10 bg-muted rounded-lg ml-auto"></div>
            <div className="w-2/3 h-10 bg-muted rounded-lg"></div>
            <div className="w-3/4 h-10 bg-muted rounded-lg ml-auto"></div>
          </div>

          <div className="p-3 border-t border-border">
            <div className="flex gap-2">
              <div className="flex-1 h-10 bg-muted rounded-md"></div>
              <div className="w-10 h-10 bg-muted rounded-md"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!conversation) {
    return (
      <Card className="h-[70vh] bg-card/50 backdrop-blur-sm">
        <CardContent className="p-6 h-full flex flex-col items-center justify-center">
          <div className="text-center">
            <h3 className="font-futuristic text-lg mb-2 glow-text">No Conversation Selected</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Select a conversation from the list or start a new one.
            </p>
            <Button onClick={() => router.push("/marketplace")}>Browse Marketplace</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="h-[70vh] bg-card/50 backdrop-blur-sm neon-card">
      <CardContent className="p-0 h-full flex flex-col">
        {/* Conversation Header */}
        <div className="p-3 border-b border-border flex items-center justify-between bg-gradient-to-r from-background to-muted/30">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={conversation.otherParticipant?.avatar || "/placeholder.svg"} />
              <AvatarFallback className="bg-primary/20 text-primary">
                {conversation.otherParticipant?.displayName?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>

            <div>
              <div className="flex items-center">
                <p className="font-futuristic text-sm">{conversation.otherParticipant?.displayName || "User"}</p>
                {conversation.otherParticipant?.isVerified && <Shield className="h-3 w-3 text-primary ml-1" />}
              </div>

              <div className="flex items-center">
                {isTyping ? (
                  <Badge variant="outline" className="h-5 px-2 text-[10px] bg-primary/10">
                    typing...
                  </Badge>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    {conversation.newConversation
                      ? "New conversation"
                      : "Last active: " +
                        new Date(conversation.lastMessageTimestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                  </p>
                )}
              </div>
            </div>
          </div>

          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 p-4 overflow-y-auto scrollbar-hide bg-gradient-to-b from-background/50 to-background/80">
          <div className="space-y-4">
            {conversation.newConversation ? (
              <div className="text-center py-8">
                <Badge variant="outline" className="mb-2 bg-primary/10">
                  New Conversation
                </Badge>
                <p className="text-sm text-muted-foreground">Send a message to start chatting with this user.</p>
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground">No messages yet. Start the conversation!</p>
              </div>
            ) : (
              messages.map((message, index) => (
                <EnhancedMessageBubble
                  key={message.id}
                  message={message}
                  isOwn={message.senderId === user?.uid}
                  showAvatar={
                    index === 0 ||
                    messages[index - 1].senderId !== message.senderId ||
                    new Date(message.createdAt).getTime() - new Date(messages[index - 1].createdAt).getTime() > 300000
                  }
                />
              ))
            )}

            {isTyping && (
              <div className="flex items-end gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={conversation.otherParticipant?.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="bg-primary/20 text-primary">
                    {conversation.otherParticipant?.displayName?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>

                <div className="bg-muted rounded-lg px-3 py-2 max-w-[80%]">
                  <div className="flex gap-1">
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    ></div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Message Input */}
        <div className="p-3 border-t border-border bg-gradient-to-r from-background to-muted/30">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <div className="flex gap-2">
              <Button type="button" variant="ghost" size="icon" className="text-muted-foreground">
                <Paperclip className="h-5 w-5" />
              </Button>
              <Button type="button" variant="ghost" size="icon" className="text-muted-foreground">
                <ImageIcon className="h-5 w-5" />
              </Button>
              <Button type="button" variant="ghost" size="icon" className="text-muted-foreground">
                <Smile className="h-5 w-5" />
              </Button>
            </div>

            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              disabled={isSending}
              className="flex-1 bg-muted/30"
            />

            <Button
              type="submit"
              size="icon"
              disabled={isSending || !newMessage.trim()}
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>

        {/* Scanline effect */}
        <div className="scanline absolute inset-0 pointer-events-none opacity-10"></div>
      </CardContent>
    </Card>
  )
}

function EnhancedMessageBubble({
  message,
  isOwn,
  showAvatar = true,
}: {
  message: any
  isOwn: boolean
  showAvatar?: boolean
}) {
  // Get message status icon
  const getStatusIcon = () => {
    switch (message.status) {
      case "sending":
        return <Clock className="h-3 w-3 text-muted-foreground" />
      case "sent":
        return <Check className="h-3 w-3 text-muted-foreground" />
      case "read":
        return <CheckCheck className="h-3 w-3 text-primary" />
      default:
        return null
    }
  }

  return (
    <div className={`flex ${isOwn ? "justify-end" : "justify-start"} items-end gap-2`}>
      {!isOwn && showAvatar ? (
        <Avatar className="h-8 w-8">
          <AvatarImage src="/placeholder.svg" />
          <AvatarFallback className="bg-primary/20 text-primary">U</AvatarFallback>
        </Avatar>
      ) : !isOwn ? (
        <div className="w-8" />
      ) : null}

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className={`max-w-[80%] rounded-lg px-3 py-2 ${
          isOwn
            ? "bg-gradient-to-r from-primary/80 to-secondary/80 text-primary-foreground rounded-br-none"
            : "bg-muted rounded-bl-none"
        }`}
      >
        <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
        <div className="flex items-center justify-end gap-1 mt-1">
          <p className="text-xs opacity-70">
            {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
          {isOwn && getStatusIcon()}
        </div>
      </motion.div>
    </div>
  )
}
