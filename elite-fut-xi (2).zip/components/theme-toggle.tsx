"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Sun, Moon, Monitor } from "lucide-react"
import { motion } from "framer-motion"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="flex items-center justify-center gap-2 p-2 rounded-lg bg-muted/30">
      <ThemeButton
        theme="light"
        icon={<Sun className="h-4 w-4" />}
        isActive={theme === "light"}
        onClick={() => setTheme("light")}
      />
      <ThemeButton
        theme="dark"
        icon={<Moon className="h-4 w-4" />}
        isActive={theme === "dark"}
        onClick={() => setTheme("dark")}
      />
      <ThemeButton
        theme="system"
        icon={<Monitor className="h-4 w-4" />}
        isActive={theme === "system"}
        onClick={() => setTheme("system")}
      />
    </div>
  )
}

function ThemeButton({
  theme,
  icon,
  isActive,
  onClick,
}: {
  theme: string
  icon: React.ReactNode
  isActive: boolean
  onClick: () => void
}) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className={`relative h-8 w-8 ${isActive ? "text-primary" : "text-muted-foreground"}`}
      onClick={onClick}
      aria-label={`Switch to ${theme} theme`}
    >
      {icon}
      {isActive && (
        <motion.div
          layoutId="theme-indicator"
          className="absolute inset-0 rounded-md border border-primary"
          transition={{ type: "spring", duration: 0.2 }}
        />
      )}
    </Button>
  )
}
