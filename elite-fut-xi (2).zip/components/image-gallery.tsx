"use client"

import { useState } from "react"
import { ProgressiveImage } from "@/components/progressive-image"
import { Button } from "@/components/ui/button"
import { useHaptic, HapticType } from "@/utils/haptic"
import { ChevronLeft, ChevronRight, Maximize, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface ImageGalleryProps {
  images: string[]
  alt: string
}

export function ImageGallery({ images, alt }: ImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [fullscreen, setFullscreen] = useState(false)
  const { trigger } = useHaptic()

  const nextImage = () => {
    trigger(HapticType.LIGHT)
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1))
  }

  const prevImage = () => {
    trigger(HapticType.LIGHT)
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1))
  }

  const toggleFullscreen = () => {
    trigger(HapticType.MEDIUM)
    setFullscreen((prev) => !prev)
  }

  return (
    <div className="relative">
      {/* Main image */}
      <div className="relative overflow-hidden rounded-md">
        <ProgressiveImage
          src={images[currentIndex]}
          alt={`${alt} - Image ${currentIndex + 1}`}
          className="w-full"
          aspectRatio="16/9"
          priority={currentIndex === 0}
        />

        {/* Navigation arrows */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8"
          onClick={prevImage}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8"
          onClick={nextImage}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>

        {/* Fullscreen button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-2 top-2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8"
          onClick={toggleFullscreen}
        >
          <Maximize className="h-5 w-5" />
        </Button>

        {/* Image counter */}
        <div className="absolute left-2 bottom-2 bg-background/70 backdrop-blur-sm rounded-md px-2 py-1 text-xs font-futuristic">
          {currentIndex + 1} / {images.length}
        </div>
      </div>

      {/* Thumbnail strip */}
      <div className="flex gap-2 mt-2 overflow-x-auto pb-2 scrollbar-hide">
        {images.map((image, index) => (
          <button
            key={index}
            className={cn(
              "flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-all",
              index === currentIndex ? "border-primary" : "border-transparent",
            )}
            onClick={() => {
              trigger(HapticType.LIGHT)
              setCurrentIndex(index)
            }}
          >
            <ProgressiveImage src={image} alt={`Thumbnail ${index + 1}`} className="w-full h-full" aspectRatio="1/1" />
          </button>
        ))}
      </div>

      {/* Fullscreen modal */}
      {fullscreen && (
        <div className="fixed inset-0 z-50 bg-background/90 backdrop-blur-md flex items-center justify-center">
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4 bg-background/50 backdrop-blur-sm rounded-full h-10 w-10 z-10"
            onClick={toggleFullscreen}
          >
            <X className="h-6 w-6" />
          </Button>

          <div className="relative w-full max-w-4xl">
            <ProgressiveImage
              src={images[currentIndex]}
              alt={`${alt} - Image ${currentIndex + 1} (Fullscreen)`}
              className="w-full"
              aspectRatio="16/9"
              priority
            />

            <Button
              variant="ghost"
              size="icon"
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-12 w-12"
              onClick={prevImage}
            >
              <ChevronLeft className="h-8 w-8" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-12 w-12"
              onClick={nextImage}
            >
              <ChevronRight className="h-8 w-8" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
