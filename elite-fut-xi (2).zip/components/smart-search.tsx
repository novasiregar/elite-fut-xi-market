"use client"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Filter, X, Star, DollarSign, Shield, Clock, Zap } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface SmartSearchProps {
  onSearch: (filters: any) => void
}

export function SmartSearch({ onSearch }: SmartSearchProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [priceRange, setPriceRange] = useState([500000, 5000000])
  const [ratingFilter, setRatingFilter] = useState(0)
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [filterCount, setFilterCount] = useState(0)
  const searchInputRef = useRef<HTMLInputElement>(null)

  const filters = [
    { id: "verified", label: "Verified Sellers", icon: <Shield className="h-4 w-4" /> },
    { id: "featured", label: "Featured", icon: <Star className="h-4 w-4" /> },
    { id: "new", label: "New Listings", icon: <Clock className="h-4 w-4" /> },
    { id: "premium", label: "Premium", icon: <DollarSign className="h-4 w-4" /> },
    { id: "video", label: "With Video", icon: <Zap className="h-4 w-4" /> },
  ]

  // Focus search input on mount
  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [])

  // Count active filters
  useEffect(() => {
    let count = activeFilters.length
    if (priceRange[0] > 500000 || priceRange[1] < 5000000) count++
    if (ratingFilter > 0) count++
    setFilterCount(count)
  }, [activeFilters, priceRange, ratingFilter])

  const toggleFilter = (filterId: string) => {
    setActiveFilters((prev) => (prev.includes(filterId) ? prev.filter((id) => id !== filterId) : [...prev, filterId]))
  }

  const clearFilters = () => {
    setActiveFilters([])
    setPriceRange([500000, 5000000])
    setRatingFilter(0)
  }

  const handleSearch = () => {
    onSearch({
      searchTerm,
      priceRange,
      ratingFilter,
      filters: activeFilters,
    })
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID").format(price)
  }

  return (
    <div className="mb-4">
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          ref={searchInputRef}
          type="text"
          placeholder="Search accounts, players, teams..."
          className="pl-10 pr-20"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
        />
        <Button
          variant="ghost"
          size="sm"
          className="absolute right-1 top-1 px-2 h-8 flex items-center gap-1"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="h-4 w-4" />
          <span className="text-xs">Filters</span>
          {filterCount > 0 && (
            <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center">
              {filterCount}
            </Badge>
          )}
        </Button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <Card className="mt-2 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-futuristic">ADVANCED FILTERS</h3>
                  {filterCount > 0 && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={clearFilters}>
                      Clear All
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">PRICE RANGE</Label>
                    <span className="text-xs">
                      Rp {formatPrice(priceRange[0])} - Rp {formatPrice(priceRange[1])}
                    </span>
                  </div>
                  <Slider
                    defaultValue={[500000, 5000000]}
                    min={0}
                    max={10000000}
                    step={100000}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="my-4"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">MINIMUM RATING</Label>
                    <span className="text-xs">{ratingFilter.toFixed(1)} ★</span>
                  </div>
                  <Slider
                    defaultValue={[0]}
                    min={0}
                    max={5}
                    step={0.5}
                    value={[ratingFilter]}
                    onValueChange={(value) => setRatingFilter(value[0])}
                    className="my-4"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">ACCOUNT TYPE</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {filters.map((filter) => (
                      <div
                        key={filter.id}
                        className={`flex items-center gap-2 border border-border rounded-md p-2 cursor-pointer transition-colors ${
                          activeFilters.includes(filter.id) ? "bg-primary/10 border-primary" : ""
                        }`}
                        onClick={() => toggleFilter(filter.id)}
                      >
                        <Checkbox
                          id={filter.id}
                          checked={activeFilters.includes(filter.id)}
                          onCheckedChange={() => toggleFilter(filter.id)}
                          className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                        />
                        <div className="flex items-center gap-1">
                          {filter.icon}
                          <Label htmlFor={filter.id} className="text-xs cursor-pointer">
                            {filter.label}
                          </Label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full text-xs font-futuristic" onClick={handleSearch}>
                  APPLY FILTERS
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active filters display */}
      {filterCount > 0 && (
        <div className="flex gap-2 mt-2 overflow-x-auto scrollbar-hide pb-2">
          {priceRange[0] > 500000 || priceRange[1] < 5000000 ? (
            <Badge variant="outline" className="flex items-center gap-1 h-6">
              <DollarSign className="h-3 w-3" />
              <span className="text-xs">
                Rp {formatPrice(priceRange[0])} - Rp {formatPrice(priceRange[1])}
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 ml-1 p-0"
                onClick={() => setPriceRange([500000, 5000000])}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ) : null}

          {ratingFilter > 0 && (
            <Badge variant="outline" className="flex items-center gap-1 h-6">
              <Star className="h-3 w-3" />
              <span className="text-xs">{ratingFilter.toFixed(1)}+ Rating</span>
              <Button variant="ghost" size="icon" className="h-4 w-4 ml-1 p-0" onClick={() => setRatingFilter(0)}>
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}

          {activeFilters.map((filterId) => {
            const filter = filters.find((f) => f.id === filterId)
            if (!filter) return null

            return (
              <Badge key={filterId} variant="outline" className="flex items-center gap-1 h-6">
                {filter.icon}
                <span className="text-xs">{filter.label}</span>
                <Button variant="ghost" size="icon" className="h-4 w-4 ml-1 p-0" onClick={() => toggleFilter(filterId)}>
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            )
          })}
        </div>
      )}
    </div>
  )
}
