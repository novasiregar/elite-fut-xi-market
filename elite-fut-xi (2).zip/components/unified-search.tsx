"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Filter, X, Star, DollarSign, Shield, Clock, Zap, Camera } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { debounce } from "lodash"
import { SearchService, type SearchSuggestion } from "@/client/services/search"
import { useToast } from "@/hooks/use-toast"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface UnifiedSearchProps {
  onSearch: (filters: any) => void
  initialFilters?: any
  enableVisualSearch?: boolean
}

export function UnifiedSearch({ onSearch, initialFilters = {}, enableVisualSearch = false }: UnifiedSearchProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [priceRange, setPriceRange] = useState([500000, 5000000])
  const [ratingFilter, setRatingFilter] = useState(0)
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [filterCount, setFilterCount] = useState(0)
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isSearching, setIsSearching] = useState(false)
  const [visualSearchFile, setVisualSearchFile] = useState<File | null>(null)
  const [visualSearchPreview, setVisualSearchPreview] = useState<string | null>(null)

  const searchInputRef = useRef<HTMLInputElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const suggestionsRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { triggerHaptic } = useHapticFeedback()

  const filters = [
    { id: "verified", label: "Verified Sellers", icon: <Shield className="h-4 w-4" /> },
    { id: "featured", label: "Featured", icon: <Star className="h-4 w-4" /> },
    { id: "new", label: "New Listings", icon: <Clock className="h-4 w-4" /> },
    { id: "premium", label: "Premium", icon: <DollarSign className="h-4 w-4" /> },
    { id: "video", label: "With Video", icon: <Zap className="h-4 w-4" /> },
  ]

  // Initialize search term from URL
  useEffect(() => {
    const query = searchParams.get("q")
    if (query) {
      setSearchTerm(query)
    }
  }, [searchParams])

  // Focus search input on mount
  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [])

  // Count active filters
  useEffect(() => {
    let count = activeFilters.length
    if (priceRange[0] > 500000 || priceRange[1] < 5000000) count++
    if (ratingFilter > 0) count++
    setFilterCount(count)
  }, [activeFilters, priceRange, ratingFilter])

  // Handle click outside suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current &&
        !suggestionsRef.current.contains(event.target as Node) &&
        !searchInputRef.current?.contains(event.target as Node)
      ) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Fetch suggestions as user types
  const fetchSuggestions = useCallback(
    debounce(async (query: string) => {
      if (query.length < 2) {
        setSuggestions([])
        return
      }

      try {
        const results = await SearchService.getSuggestions(query)
        setSuggestions(results)
      } catch (error) {
        console.error("Error fetching suggestions:", error)
      }
    }, 300),
    [],
  )

  useEffect(() => {
    if (searchTerm) {
      fetchSuggestions(searchTerm)
    } else {
      setSuggestions([])
    }
  }, [searchTerm, fetchSuggestions])

  const toggleFilter = (filterId: string) => {
    setActiveFilters((prev) => (prev.includes(filterId) ? prev.filter((id) => id !== filterId) : [...prev, filterId]))
    triggerHaptic("light")
  }

  const clearFilters = () => {
    setActiveFilters([])
    setPriceRange([500000, 5000000])
    setRatingFilter(0)
    triggerHaptic("medium")
  }

  const handleSearch = async () => {
    setShowSuggestions(false)
    setIsSearching(true)
    triggerHaptic("light")

    try {
      if (visualSearchFile && enableVisualSearch) {
        await handleVisualSearch()
      } else {
        // Update URL
        const params = new URLSearchParams(searchParams.toString())
        if (searchTerm) {
          params.set("q", searchTerm)
        } else {
          params.delete("q")
        }

        // Add filters to URL
        if (activeFilters.length > 0) {
          params.set("filters", activeFilters.join(","))
        } else {
          params.delete("filters")
        }

        router.push(`/marketplace?${params.toString()}`)

        // Call parent onSearch
        onSearch({
          searchTerm,
          priceRange,
          ratingFilter,
          filters: {
            ...initialFilters,
            tags: activeFilters,
          },
        })
      }
    } finally {
      setIsSearching(false)
    }
  }

  // Handle visual search
  const handleVisualSearch = async () => {
    if (!visualSearchFile || !enableVisualSearch) return

    setIsSearching(true)
    triggerHaptic("medium")

    try {
      const formData = new FormData()
      formData.append("image", visualSearchFile)

      const response = await fetch("/api/search/visual", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Visual search failed")
      }

      const data = await response.json()

      // Call parent onSearch with results
      onSearch({
        visualSearchResults: data.results,
        detectedObjects: data.detectedObjects,
        searchImage: visualSearchPreview,
      })

      // Show success toast
      toast({
        title: "Visual search complete",
        description: `Found ${data.results.length} matching listings`,
        variant: "default",
      })

      // Reset visual search
      setVisualSearchFile(null)
      setVisualSearchPreview(null)
    } catch (error) {
      console.error("Visual search error:", error)
      toast({
        title: "Visual search failed",
        description: "Please try again with a different image",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  // Handle suggestion click
  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    triggerHaptic("light")

    if (suggestion.type === "query") {
      setSearchTerm(suggestion.text)
      handleSearch()
    } else if (suggestion.type === "category") {
      // Navigate to category
      router.push(`/marketplace/category/${encodeURIComponent(suggestion.text)}`)
    } else if (suggestion.type === "tag") {
      // Add tag as filter
      setActiveFilters((prev) => {
        if (prev.includes(suggestion.text)) return prev
        return [...prev, suggestion.text]
      })
      setSearchTerm("")
    } else if (suggestion.type === "player") {
      setSearchTerm(suggestion.text)
      handleSearch()
    }

    setShowSuggestions(false)
  }

  // Handle file selection for visual search
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setVisualSearchFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setVisualSearchPreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)

    triggerHaptic("medium")
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID").format(price)
  }

  return (
    <div className="mb-4">
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          ref={searchInputRef}
          type="text"
          placeholder="Search accounts, players, teams..."
          className="pl-10 pr-20"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value)
            setShowSuggestions(true)
          }}
          onFocus={() => {
            if (searchTerm.length >= 2) {
              setShowSuggestions(true)
            }
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              handleSearch()
            } else if (e.key === "Escape") {
              setShowSuggestions(false)
            }
          }}
        />
        <div className="absolute right-1 top-1 flex items-center gap-1">
          {enableVisualSearch && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => {
                triggerHaptic("medium")
                fileInputRef.current?.click()
              }}
              title="Visual Search"
            >
              <Camera className="h-4 w-4" />
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-2 flex items-center gap-1"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4" />
            <span className="text-xs">Filters</span>
            {filterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center">
                {filterCount}
              </Badge>
            )}
          </Button>
        </div>
      </div>

      {/* Visual search preview */}
      {visualSearchPreview && (
        <div className="mt-2 relative rounded-md overflow-hidden border border-border">
          <div className="aspect-[3/1] relative">
            <img
              src={visualSearchPreview || "/placeholder.svg"}
              alt="Visual search"
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 bg-background/80 rounded-full h-8 w-8"
            onClick={() => {
              setVisualSearchFile(null)
              setVisualSearchPreview(null)
              triggerHaptic("light")
            }}
          >
            <X className="h-4 w-4" />
          </Button>
          <Button
            className="absolute bottom-2 right-2 bg-primary"
            size="sm"
            onClick={handleVisualSearch}
            disabled={isSearching}
          >
            {isSearching ? "Searching..." : "Search by Image"}
          </Button>
        </div>
      )}

      {/* Search suggestions */}
      <AnimatePresence>
        {showSuggestions && suggestions.length > 0 && (
          <motion.div
            ref={suggestionsRef}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute z-50 mt-1 w-full bg-card rounded-md border border-border shadow-lg overflow-hidden"
          >
            <div className="max-h-60 overflow-y-auto">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="px-3 py-2 hover:bg-accent cursor-pointer flex items-center gap-2"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  {suggestion.type === "query" && <Search className="h-4 w-4 text-muted-foreground" />}
                  {suggestion.type === "category" && <Filter className="h-4 w-4 text-muted-foreground" />}
                  {suggestion.type === "tag" && <Star className="h-4 w-4 text-muted-foreground" />}
                  {suggestion.type === "player" && <Shield className="h-4 w-4 text-muted-foreground" />}

                  <span>{suggestion.text}</span>

                  <span className="ml-auto text-xs text-muted-foreground">{suggestion.count} results</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <Card className="mt-2 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-futuristic">ADVANCED FILTERS</h3>
                  {filterCount > 0 && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={clearFilters}>
                      Clear All
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">PRICE RANGE</Label>
                    <span className="text-xs">
                      Rp {formatPrice(priceRange[0])} - Rp {formatPrice(priceRange[1])}
                    </span>
                  </div>
                  <Slider
                    defaultValue={[500000, 5000000]}
                    min={0}
                    max={10000000}
                    step={100000}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="my-4"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">MINIMUM RATING</Label>
                    <span className="text-xs">{ratingFilter.toFixed(1)} ★</span>
                  </div>
                  <Slider
                    defaultValue={[0]}
                    min={0}
                    max={5}
                    step={0.5}
                    value={[ratingFilter]}
                    onValueChange={(value) => setRatingFilter(value[0])}
                    className="my-4"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">ACCOUNT TYPE</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {filters.map((filter) => (
                      <div
                        key={filter.id}
                        className={`flex items-center gap-2 border border-border rounded-md p-2 cursor-pointer transition-colors ${
                          activeFilters.includes(filter.id) ? "bg-primary/10 border-primary" : ""
                        }`}
                        onClick={() => toggleFilter(filter.id)}
                      >
                        <Checkbox
                          id={filter.id}
                          checked={activeFilters.includes(filter.id)}
                          onCheckedChange={() => toggleFilter(filter.id)}
                          className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                        />
                        <div className="flex items-center gap-1">
                          {filter.icon}
                          <Label htmlFor={filter.id} className="text-xs cursor-pointer">
                            {filter.label}
                          </Label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full text-xs font-futuristic" onClick={handleSearch}>
                  APPLY FILTERS
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active filters display */}
      {filterCount > 0 && (
        <div className="flex gap-2 mt-2 overflow-x-auto scrollbar-hide pb-2">
          {priceRange[0] > 500000 || priceRange[1] < 5000000 ? (
            <Badge variant="outline" className="flex items-center gap-1 h-6">
              <DollarSign className="h-3 w-3" />
              <span className="text-xs">
                Rp {formatPrice(priceRange[0])} - Rp {formatPrice(priceRange[1])}
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 ml-1 p-0"
                onClick={() => setPriceRange([500000, 5000000])}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ) : null}

          {ratingFilter > 0 && (
            <Badge variant="outline" className="flex items-center gap-1 h-6">
              <Star className="h-3 w-3" />
              <span className="text-xs">{ratingFilter.toFixed(1)}+ Rating</span>
              <Button variant="ghost" size="icon" className="h-4 w-4 ml-1 p-0" onClick={() => setRatingFilter(0)}>
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          )}

          {activeFilters.map((filterId) => {
            const filter = filters.find((f) => f.id === filterId)
            if (!filter) return null

            return (
              <Badge key={filterId} variant="outline" className="flex items-center gap-1 h-6">
                {filter.icon}
                <span className="text-xs">{filter.label}</span>
                <Button variant="ghost" size="icon" className="h-4 w-4 ml-1 p-0" onClick={() => toggleFilter(filterId)}>
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            )
          })}
        </div>
      )}
    </div>
  )
}
