"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { shareWithDeepLink, generateDeepLink } from "@/utils/deep-linking"
import { Share2, Copy, MessageCircle, Facebook, Twitter, PhoneIcon as WhatsApp } from "lucide-react"
import QRCode from "react-qr-code"

interface ShareListingProps {
  listing: {
    id: string
    title: string
    price: number
    image?: string
  }
  variant?: "icon" | "button"
  size?: "sm" | "md" | "lg"
}

export function ShareListing({ listing, variant = "icon", size = "md" }: ShareListingProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("link")
  const { toast } = useToast()

  const deepLink = generateDeepLink({
    route: `/listings/${listing.id}`,
    params: { ref: "share" },
  })

  const shareMessage = `Check out this listing on ELITE FUT XI Market: ${listing.title} - Rp ${listing.price.toLocaleString()}`

  const handleShare = async () => {
    const success = await shareWithDeepLink(
      {
        route: `/listings/${listing.id}`,
        params: { ref: "share" },
      },
      listing.title,
      shareMessage,
    )

    if (success) {
      toast({
        title: "Shared Successfully",
        description: "The listing has been shared",
      })
      setIsOpen(false)
    } else {
      toast({
        title: "Share Failed",
        description: "Unable to share the listing",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(deepLink)
      toast({
        title: "Link Copied",
        description: "The link has been copied to your clipboard",
      })
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy the link",
        variant: "destructive",
      })
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {variant === "icon" ? (
          <Button variant="outline" size="icon">
            <Share2 className="h-5 w-5" />
          </Button>
        ) : (
          <Button variant="outline" size={size === "sm" ? "sm" : "default"}>
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share Listing</DialogTitle>
        </DialogHeader>

        <div className="py-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="link" className="font-futuristic">
                LINK
              </TabsTrigger>
              <TabsTrigger value="social" className="font-futuristic">
                SOCIAL
              </TabsTrigger>
              <TabsTrigger value="qr" className="font-futuristic">
                QR CODE
              </TabsTrigger>
            </TabsList>

            <TabsContent value="link">
              <div className="flex items-center space-x-2">
                <Input value={deepLink} readOnly className="flex-1" />
                <Button variant="outline" size="icon" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>

              <div className="mt-4">
                <Button className="w-full" onClick={handleShare}>
                  <Share2 className="h-4 w-4 mr-2" />
                  Share Listing
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="social">
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                  <Facebook className="h-8 w-8 mb-2 text-blue-600" />
                  <span className="text-xs">Facebook</span>
                </Button>

                <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                  <Twitter className="h-8 w-8 mb-2 text-sky-500" />
                  <span className="text-xs">Twitter</span>
                </Button>

                <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                  <WhatsApp className="h-8 w-8 mb-2 text-green-500" />
                  <span className="text-xs">WhatsApp</span>
                </Button>

                <Button variant="outline" className="h-20 flex flex-col items-center justify-center">
                  <MessageCircle className="h-8 w-8 mb-2 text-purple-500" />
                  <span className="text-xs">Message</span>
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="qr" className="flex flex-col items-center">
              <div className="bg-white p-4 rounded-md">
                <QRCode value={deepLink} size={200} />
              </div>
              <p className="text-xs text-muted-foreground mt-4 text-center">
                Scan this QR code to open the listing on another device
              </p>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
