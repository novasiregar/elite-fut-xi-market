"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Camera, Upload, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"
import { useRouter } from "next/navigation"

export function VisualSearchButton() {
  const [open, setOpen] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const { toast } = useToast()
  const { triggerHaptic } = useHapticFeedback()
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (!selectedFile) return

    // Check file type
    if (!selectedFile.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (selectedFile.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setFile(selectedFile)

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string)
    }
    reader.readAsDataURL(selectedFile)

    triggerHaptic("light")
  }

  const handleSearch = async () => {
    if (!file) {
      toast({
        title: "No image selected",
        description: "Please select an image to search",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    triggerHaptic("medium")

    try {
      const formData = new FormData()
      formData.append("image", file)

      const response = await fetch("/api/search/visual", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Visual search failed")
      }

      const data = await response.json()

      // Navigate to visual search results page
      router.push(`/visual-search-results?id=${data.searchId}`)

      // Close dialog
      setOpen(false)
    } catch (error) {
      console.error("Visual search error:", error)
      toast({
        title: "Search failed",
        description: "Please try again with a different image",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleClear = () => {
    setFile(null)
    setImagePreview(null)
    triggerHaptic("light")
  }

  return (
    <>
      <Button
        variant="outline"
        size="icon"
        className="rounded-full"
        onClick={() => {
          setOpen(true)
          triggerHaptic("light")
        }}
        title="Visual Search"
      >
        <Camera className="h-4 w-4" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Visual Search</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {imagePreview ? (
              <div className="relative rounded-md overflow-hidden border border-border">
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Search preview"
                  className="w-full aspect-video object-cover"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 bg-background/80 rounded-full h-8 w-8"
                  onClick={handleClear}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="border border-dashed border-border rounded-md p-8 text-center">
                <Camera className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-4">Upload an image to search for similar listings</p>
                <div className="flex flex-col gap-2">
                  <Button variant="outline" onClick={() => document.getElementById("visual-search-input")?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Select Image
                  </Button>
                  <input
                    id="visual-search-input"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </div>
              </div>
            )}

            {imagePreview && (
              <Button className="w-full" onClick={handleSearch} disabled={isUploading}>
                {isUploading ? "Searching..." : "Search"}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
