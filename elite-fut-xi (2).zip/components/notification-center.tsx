"use client"

import { useState, useEffect } from "react"
import { Bell, X, Check, MessageSquare, DollarSign, ShoppingBag, Info } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useRouter } from "next/navigation"
import { triggerHaptic } from "@/utils/haptic"
import { useAuth } from "@/context/auth-context"

// Mock data for demonstration
const mockNotifications = [
  {
    id: "n1",
    type: "transaction",
    title: "Payment Received",
    message: "You have received a payment of Rp 2,500,000 for Messi 96 OVR Card",
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 minutes ago
    actionUrl: "/transactions/TX123456",
  },
  {
    id: "n2",
    type: "message",
    title: "New Message",
    message: "Sarah Williams sent you a message about Ronaldo 94 OVR Card",
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
    actionUrl: "/messages",
  },
  {
    id: "n3",
    type: "listing",
    title: "Listing Approved",
    message: "Your listing for Rare Gold Pack Bundle has been approved",
    read: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
    actionUrl: "/listings/3",
  },
  {
    id: "n4",
    type: "system",
    title: "System Maintenance",
    message: "The platform will be under maintenance on July 25th from 2:00 AM to 4:00 AM UTC",
    read: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    actionUrl: null,
  },
  {
    id: "n5",
    type: "transaction",
    title: "Transaction Disputed",
    message: "A transaction for Ultimate Team Coins - 1M has been disputed",
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 36).toISOString(), // 1.5 days ago
    actionUrl: "/transactions/TX123459",
  },
]

export function NotificationCenter() {
  const [open, setOpen] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()
  const { user } = useAuth()

  useEffect(() => {
    // In a real app, this would fetch notifications from an API
    setNotifications(mockNotifications)
    setUnreadCount(mockNotifications.filter((n) => !n.read).length)

    // In a real app, this would set up a WebSocket or SSE connection for real-time notifications
    const setupRealTimeNotifications = () => {
      // Mock a new notification coming in after 10 seconds
      const timer = setTimeout(() => {
        const newNotification = {
          id: `n${notifications.length + 1}`,
          type: "listing",
          title: "New Listing Alert",
          message: "A new listing matching your watchlist criteria has been posted",
          read: false,
          createdAt: new Date().toISOString(),
          actionUrl: "/marketplace",
        }

        setNotifications((prev) => [newNotification, ...prev])
        setUnreadCount((prev) => prev + 1)

        // Show a browser notification if permission is granted
        if (Notification.permission === "granted") {
          new Notification("ELITE FUT XI Market", {
            body: newNotification.message,
            icon: "/favicon.ico",
          })
        }
      }, 10000)

      return () => clearTimeout(timer)
    }

    if (user) {
      const cleanup = setupRealTimeNotifications()
      return cleanup
    }
  }, [user])

  const handleNotificationClick = (notification: any) => {
    // Mark as read
    if (!notification.read) {
      setNotifications(notifications.map((n) => (n.id === notification.id ? { ...n, read: true } : n)))
      setUnreadCount((prev) => Math.max(0, prev - 1))
    }

    // Navigate to the action URL if available
    if (notification.actionUrl) {
      setOpen(false)
      router.push(notification.actionUrl)
    }

    triggerHaptic("light")
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
    setUnreadCount(0)
    triggerHaptic("medium")
  }

  const clearAllNotifications = () => {
    setNotifications([])
    setUnreadCount(0)
    triggerHaptic("medium")
  }

  const getFilteredNotifications = () => {
    if (activeTab === "all") return notifications
    return notifications.filter((n) => n.type === activeTab)
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "transaction":
        return <DollarSign className="h-5 w-5 text-green-500" />
      case "message":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      case "listing":
        return <ShoppingBag className="h-5 w-5 text-purple-500" />
      case "system":
        return <Info className="h-5 w-5 text-yellow-500" />
      default:
        return <Bell className="h-5 w-5 text-muted-foreground" />
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSecs = Math.floor(diffMs / 1000)
    const diffMins = Math.floor(diffSecs / 60)
    const diffHours = Math.floor(diffMins / 60)
    const diffDays = Math.floor(diffHours / 24)

    if (diffSecs < 60) return `${diffSecs}s ago`
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return `${diffDays}d ago`
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" onClick={() => triggerHaptic("light")}>
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 px-1 min-w-[18px] h-[18px] flex items-center justify-center bg-primary text-[10px]">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="end">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-medium">Notifications</h3>
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={markAllAsRead}>
                <Check className="h-3.5 w-3.5 mr-1" />
                Mark all read
              </Button>
            )}
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={clearAllNotifications}>
              <X className="h-3.5 w-3.5 mr-1" />
              Clear all
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-5 p-1 m-1">
            <TabsTrigger value="all" className="text-xs">
              All
            </TabsTrigger>
            <TabsTrigger value="transaction" className="text-xs">
              Transactions
            </TabsTrigger>
            <TabsTrigger value="message" className="text-xs">
              Messages
            </TabsTrigger>
            <TabsTrigger value="listing" className="text-xs">
              Listings
            </TabsTrigger>
            <TabsTrigger value="system" className="text-xs">
              System
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-0">
            <ScrollArea className="h-[300px]">
              {getFilteredNotifications().length > 0 ? (
                <div className="divide-y">
                  {getFilteredNotifications().map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 hover:bg-muted/50 cursor-pointer transition-colors ${notification.read ? "" : "bg-muted/20"}`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-start justify-between">
                            <p className={`text-sm font-medium ${notification.read ? "" : "text-primary"}`}>
                              {notification.title}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {formatTimeAgo(notification.createdAt)}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground">{notification.message}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full p-4">
                  <Bell className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">No notifications</p>
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>

        <div className="p-2 border-t">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-xs"
            onClick={() => {
              setOpen(false)
              router.push("/notifications")
              triggerHaptic("light")
            }}
          >
            View all notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}
