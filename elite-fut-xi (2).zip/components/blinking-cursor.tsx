"use client"

import { useState, useEffect } from "react"

export function BlinkingCursor() {
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setVisible((v) => !v)
    }, 500)

    return () => clearInterval(interval)
  }, [])

  return (
    <span
      className={`inline-block w-2 h-4 ml-1 bg-primary ${visible ? "opacity-100" : "opacity-0"}`}
      style={{ transition: "opacity 0.1s ease" }}
    />
  )
}
