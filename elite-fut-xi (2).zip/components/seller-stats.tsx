"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { UserService } from "@/client/services/users"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { Clock, ShoppingBag, CheckCircle, AlertCircle, BarChart3 } from "lucide-react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

interface SellerStats {
  totalSales: number
  completionRate: number
  averageResponseTime: number
  disputeRate: number
  ratingBreakdown: {
    5: number
    4: number
    3: number
    2: number
    1: number
  }
  recentActivity: {
    date: string
    sales: number
  }[]
}

interface SellerStatsProps {
  sellerId: string
}

export function SellerStats({ sellerId }: SellerStatsProps) {
  const [stats, setStats] = useState<SellerStats | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  // Fetch seller stats
  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true)
        const data = await UserService.getSellerStats(sellerId)
        setStats(data)
      } catch (error) {
        console.error("Error fetching seller stats:", error)
        toast({
          title: "Error",
          description: "Failed to load seller statistics",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [sellerId, toast])

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    )
  }

  if (!stats) {
    return (
      <Card className="bg-muted/30">
        <CardContent className="p-6 text-center">
          <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm mb-4">No statistics available</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <h2 className="font-futuristic text-sm glow-text">SELLER STATISTICS</h2>

      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col items-center">
              <ShoppingBag className="h-8 w-8 text-primary mb-2" />
              <h3 className="text-sm font-medium">Total Sales</h3>
              <p className="text-2xl font-futuristic mt-1">{stats.totalSales}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col items-center">
              <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
              <h3 className="text-sm font-medium">Completion Rate</h3>
              <p className="text-2xl font-futuristic mt-1">{stats.completionRate}%</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col items-center">
              <Clock className="h-8 w-8 text-secondary mb-2" />
              <h3 className="text-sm font-medium">Avg. Response</h3>
              <p className="text-2xl font-futuristic mt-1">{stats.averageResponseTime}m</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col items-center">
              <AlertCircle className="h-8 w-8 text-orange-500 mb-2" />
              <h3 className="text-sm font-medium">Dispute Rate</h3>
              <p className="text-2xl font-futuristic mt-1">{stats.disputeRate}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Rating Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {[5, 4, 3, 2, 1].map((rating) => (
            <div key={rating} className="space-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-xs">{rating} Star</span>
                </div>
                <span className="text-xs">{stats.ratingBreakdown[rating as keyof typeof stats.ratingBreakdown]}%</span>
              </div>
              <Progress value={stats.ratingBreakdown[rating as keyof typeof stats.ratingBreakdown]} className="h-1" />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={stats.recentActivity}>
              <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(15, 15, 15, 0.9)",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  borderRadius: "4px",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="sales" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}
