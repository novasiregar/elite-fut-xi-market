"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { PaymentService, PaymentStatus } from "@/client/services/payments"
import { TransactionService, TransactionStatus } from "@/client/services/transactions"
import { CheckCircle, Clock, Copy, AlertCircle, ChevronRight, Smartphone, CreditCard, Wallet } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"

interface PaymentFlowProps {
  transactionId: string
  amount: number
  onComplete?: () => void
}

export function PaymentFlow({ transactionId, amount, onComplete }: PaymentFlowProps) {
  const [step, setStep] = useState(1)
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("")
  const [paymentReference, setPaymentReference] = useState("")
  const [paymentDetails, setPaymentDetails] = useState<any>(null)
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [countdown, setCountdown] = useState(0)
  const { toast } = useToast()
  const router = useRouter()

  // Payment methods with icons
  const paymentMethods = [
    { id: "gopay", name: "GoPay", icon: <Wallet className="h-5 w-5 text-blue-500" /> },
    { id: "ovo", name: "OVO", icon: <Wallet className="h-5 w-5 text-purple-500" /> },
    { id: "dana", name: "DANA", icon: <Wallet className="h-5 w-5 text-blue-400" /> },
    { id: "bank_transfer", name: "Bank Transfer", icon: <CreditCard className="h-5 w-5 text-green-500" /> },
  ]

  // Countdown timer for payment expiration
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1)
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [countdown])

  // Format countdown time
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Initialize payment
  const initializePayment = async () => {
    if (!selectedPaymentMethod) {
      setError("Please select a payment method")
      return
    }

    try {
      setIsLoading(true)
      setError("")

      const response = await PaymentService.initializePayment(transactionId, selectedPaymentMethod)

      setPaymentReference(response.paymentReference)
      setPaymentDetails(response.paymentDetails)
      setPaymentStatus(PaymentStatus.PENDING)

      // Set countdown timer based on payment details expiry
      if (response.paymentDetails?.expiresAt) {
        const expiryTime = new Date(response.paymentDetails.expiresAt).getTime()
        const currentTime = new Date().getTime()
        const timeLeft = Math.floor((expiryTime - currentTime) / 1000)

        if (timeLeft > 0) {
          setCountdown(timeLeft)
        }
      }

      setStep(2)
    } catch (error: any) {
      console.error("Initialize payment error:", error)
      setError(error.message || "Failed to initialize payment")
    } finally {
      setIsLoading(false)
    }
  }

  // Check payment status
  const checkPaymentStatus = async () => {
    if (!paymentReference) return

    try {
      setIsLoading(true)

      const paymentData = await PaymentService.checkPaymentStatus(paymentReference)
      setPaymentStatus(paymentData.status)

      // If payment is completed, move to next step
      if (paymentData.status === PaymentStatus.COMPLETED) {
        setStep(3)

        // Refresh transaction to get updated status
        const transaction = await TransactionService.getTransaction(transactionId)

        if (transaction.status === TransactionStatus.ESCROW_FUNDED) {
          toast({
            title: "Payment Successful",
            description: "Your payment has been processed and the escrow is funded.",
          })

          // Call onComplete callback if provided
          if (onComplete) {
            onComplete()
          }
        }
      } else if (paymentData.status === PaymentStatus.FAILED) {
        setError("Payment failed. Please try again.")
      } else if (paymentData.status === PaymentStatus.EXPIRED) {
        setError("Payment expired. Please try again.")
        setCountdown(0)
      }
    } catch (error) {
      console.error("Check payment status error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Copy text to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)

    toast({
      title: "Copied to clipboard",
      description: "The text has been copied to your clipboard.",
    })
  }

  return (
    <div className="space-y-4">
      {/* Step indicator */}
      <div className="flex items-center justify-between mb-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-center">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step === i
                  ? "bg-primary text-primary-foreground"
                  : step > i
                    ? "bg-primary/20 text-primary"
                    : "bg-muted text-muted-foreground"
              }`}
            >
              {step > i ? <CheckCircle className="h-5 w-5" /> : i}
            </div>

            {i < 3 && <div className={`w-full h-1 ${step > i ? "bg-primary" : "bg-muted"}`} />}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-futuristic text-lg mb-4 glow-text text-center">SELECT PAYMENT METHOD</h3>

                <div className="space-y-4">
                  <div className="text-center mb-6">
                    <p className="text-sm text-muted-foreground">Amount to Pay:</p>
                    <p className="text-2xl font-futuristic glow-text">Rp {amount.toLocaleString()}</p>
                  </div>

                  <RadioGroup value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                    <div className="space-y-2">
                      {paymentMethods.map((method) => (
                        <label
                          key={method.id}
                          className={`flex items-center justify-between p-3 rounded-md border cursor-pointer transition-colors ${
                            selectedPaymentMethod === method.id
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <RadioGroupItem value={method.id} id={method.id} />
                            {method.icon}
                            <span className="font-futuristic">{method.name}</span>
                          </div>
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </label>
                      ))}
                    </div>
                  </RadioGroup>

                  {error && (
                    <div className="bg-destructive/20 p-3 rounded-md flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-destructive" />
                      <p className="text-xs text-destructive">{error}</p>
                    </div>
                  )}

                  <Button
                    className="w-full font-futuristic bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
                    onClick={initializePayment}
                    disabled={!selectedPaymentMethod || isLoading}
                  >
                    {isLoading ? "Processing..." : "Continue to Payment"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 2 && paymentDetails && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="font-futuristic text-lg mb-4 glow-text text-center">COMPLETE PAYMENT</h3>

                <div className="space-y-4">
                  {countdown > 0 && (
                    <div className="bg-muted/30 p-3 rounded-md text-center">
                      <p className="text-xs text-muted-foreground mb-1">Payment expires in:</p>
                      <p className="font-futuristic text-lg glow-text">{formatTime(countdown)}</p>
                    </div>
                  )}

                  {selectedPaymentMethod === "gopay" && (
                    <div className="flex flex-col items-center">
                      {paymentDetails.qrCode && (
                        <div className="bg-white p-4 rounded-md mb-4 relative overflow-hidden">
                          <img
                            src={paymentDetails.qrCode || "/placeholder.svg"}
                            alt="GoPay QR Code"
                            className="w-48 h-48"
                          />
                          <div className="hologram absolute inset-0"></div>
                        </div>
                      )}
                      <p className="text-sm text-center mb-4">Scan this QR code with your GoPay app</p>
                      {paymentDetails.deepLink && (
                        <Button
                          className="w-full font-futuristic"
                          onClick={() => window.open(paymentDetails.deepLink, "_blank")}
                        >
                          <Smartphone className="mr-2 h-4 w-4" />
                          Open GoPay App
                        </Button>
                      )}
                    </div>
                  )}

                  {selectedPaymentMethod === "ovo" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Enter your OVO phone number:</Label>
                        <div className="flex">
                          <Input value={paymentDetails.phoneNumber || ""} readOnly className="flex-1" />
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => copyToClipboard(paymentDetails.phoneNumber)}
                            className="ml-2"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-3 rounded-md">
                        <p className="text-sm font-medium mb-1">Instructions:</p>
                        <ol className="text-xs space-y-1 list-decimal list-inside">
                          <li>Open your OVO app</li>
                          <li>Select "Pay"</li>
                          <li>Enter the amount: Rp {amount.toLocaleString()}</li>
                          <li>Confirm payment</li>
                        </ol>
                      </div>
                    </div>
                  )}

                  {selectedPaymentMethod === "dana" && (
                    <div className="flex flex-col items-center">
                      {paymentDetails.qrCode && (
                        <div className="bg-white p-4 rounded-md mb-4 relative overflow-hidden">
                          <img
                            src={paymentDetails.qrCode || "/placeholder.svg"}
                            alt="DANA QR Code"
                            className="w-48 h-48"
                          />
                          <div className="hologram absolute inset-0"></div>
                        </div>
                      )}
                      <p className="text-sm text-center mb-4">Scan this QR code with your DANA app</p>
                      {paymentDetails.deepLink && (
                        <Button
                          className="w-full font-futuristic"
                          onClick={() => window.open(paymentDetails.deepLink, "_blank")}
                        >
                          <Smartphone className="mr-2 h-4 w-4" />
                          Open DANA App
                        </Button>
                      )}
                    </div>
                  )}

                  {selectedPaymentMethod === "bank_transfer" && paymentDetails.bankAccounts && (
                    <div className="space-y-4">
                      {paymentDetails.bankAccounts.map((account: any, index: number) => (
                        <div key={index} className="bg-muted/30 p-3 rounded-md">
                          <p className="text-sm font-medium">{account.bank}</p>
                          <div className="flex items-center justify-between mt-1">
                            <p className="text-base font-mono">{account.accountNumber}</p>
                            <Button variant="ghost" size="sm" onClick={() => copyToClipboard(account.accountNumber)}>
                              <Copy className="h-3 w-3 mr-1" />
                              Copy
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">{account.accountName}</p>
                        </div>
                      ))}

                      <div className="bg-muted/30 p-3 rounded-md">
                        <div className="flex justify-between mb-1">
                          <p className="text-sm">Amount:</p>
                          <p className="text-sm font-medium">Rp {amount.toLocaleString()}</p>
                        </div>
                        <div className="flex justify-between">
                          <p className="text-sm">Reference:</p>
                          <div className="flex items-center">
                            <p className="text-sm font-medium mr-2">{paymentReference}</p>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => copyToClipboard(paymentReference)}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-3 rounded-md">
                        <p className="text-sm font-medium mb-1">Instructions:</p>
                        <ol className="text-xs space-y-1 list-decimal list-inside">
                          <li>Transfer the exact amount to one of the virtual accounts above</li>
                          <li>Include the reference number in the transfer description</li>
                          <li>Keep your transfer receipt until the transaction is completed</li>
                        </ol>
                      </div>
                    </div>
                  )}

                  {error && (
                    <div className="bg-destructive/20 p-3 rounded-md flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-destructive" />
                      <p className="text-xs text-destructive">{error}</p>
                    </div>
                  )}

                  <Button className="w-full font-futuristic" onClick={checkPaymentStatus} disabled={isLoading}>
                    {isLoading ? (
                      <span className="flex items-center">
                        <Clock className="animate-spin mr-2 h-4 w-4" />
                        Checking Payment Status...
                      </span>
                    ) : (
                      "I've Completed Payment"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-primary" />
                </div>

                <h3 className="font-futuristic text-lg mb-2 glow-text">PAYMENT SUCCESSFUL</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Your payment has been processed successfully. The funds are now held in escrow.
                </p>

                <div className="bg-muted/30 p-3 rounded-md text-left mb-6">
                  <p className="text-sm font-medium mb-1">What happens next?</p>
                  <ol className="text-xs space-y-1 list-decimal list-inside">
                    <li>The seller will be notified of your purchase</li>
                    <li>The seller will provide the account details</li>
                    <li>You'll receive a notification when the details are ready</li>
                    <li>Verify the account details and confirm receipt</li>
                    <li>Funds will be released to the seller after confirmation</li>
                  </ol>
                </div>

                <Button
                  className="w-full font-futuristic bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
                  onClick={() => router.push("/transactions")}
                >
                  View Transaction Details
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
