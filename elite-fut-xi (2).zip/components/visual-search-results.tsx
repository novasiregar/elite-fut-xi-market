"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { OptimizedImage } from "@/components/optimized-image"
import { Badge } from "@/components/ui/badge"
import { Camera, X } from "lucide-react"
import type { Listing } from "@/client/services/listings"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface DetectedObject {
  name: string
  score: number
  boundingBox: {
    x: number
    y: number
    width: number
    height: number
  }
}

interface VisualSearchResultsProps {
  results: Listing[]
  detectedObjects: DetectedObject[]
  searchImage: string
  onClose: () => void
}

export function VisualSearchResults({ results, detectedObjects, searchImage, onClose }: VisualSearchResultsProps) {
  const [selectedObject, setSelectedObject] = useState<string | null>(null)
  const [filteredResults, setFilteredResults] = useState<Listing[]>(results)
  const { triggerHaptic } = useHapticFeedback()

  // Filter results when a detected object is selected
  useEffect(() => {
    if (selectedObject) {
      // Simple filtering based on title and tags
      const filtered = results.filter(
        (listing) =>
          listing.title.toLowerCase().includes(selectedObject.toLowerCase()) ||
          listing.tags.some((tag) => tag.toLowerCase().includes(selectedObject.toLowerCase())) ||
          (listing.accountDetails?.topPlayers &&
            Array.isArray(listing.accountDetails.topPlayers) &&
            listing.accountDetails.topPlayers.some((player) =>
              player.toLowerCase().includes(selectedObject.toLowerCase()),
            )),
      )
      setFilteredResults(filtered.length > 0 ? filtered : results)
    } else {
      setFilteredResults(results)
    }
  }, [selectedObject, results])

  const handleObjectClick = (objectName: string) => {
    triggerHaptic("light")
    setSelectedObject((prev) => (prev === objectName ? null : objectName))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Camera className="h-4 w-4 text-primary" />
          Visual Search Results
        </h2>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => {
            triggerHaptic("medium")
            onClose()
          }}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="relative rounded-md overflow-hidden border border-border">
        <div className="aspect-[3/1] relative">
          <img src={searchImage || "/placeholder.svg"} alt="Visual search" className="w-full h-full object-cover" />

          {/* Detected object overlays */}
          {detectedObjects.map((obj, index) => (
            <div
              key={index}
              className={`absolute border-2 cursor-pointer transition-colors ${
                selectedObject === obj.name ? "border-primary" : "border-primary/50"
              }`}
              style={{
                left: `${obj.boundingBox.x * 100}%`,
                top: `${obj.boundingBox.y * 100}%`,
                width: `${obj.boundingBox.width * 100}%`,
                height: `${obj.boundingBox.height * 100}%`,
              }}
              onClick={() => handleObjectClick(obj.name)}
            >
              <span
                className={`absolute -top-6 left-0 text-xs px-1 py-0.5 rounded ${
                  selectedObject === obj.name
                    ? "bg-primary text-primary-foreground"
                    : "bg-primary/50 text-primary-foreground"
                }`}
              >
                {obj.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Detected objects as clickable tags */}
      {detectedObjects.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {detectedObjects
            .filter((obj) => obj.score > 0.6)
            .map((obj, index) => (
              <Badge
                key={index}
                variant={selectedObject === obj.name ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => handleObjectClick(obj.name)}
              >
                {obj.name}
              </Badge>
            ))}
        </div>
      )}

      {/* Results grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
        {filteredResults.map((listing) => (
          <Link
            href={`/listings/${listing.id}`}
            key={listing.id}
            className="bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="aspect-square relative">
              <OptimizedImage
                src={listing.media?.[0]?.url || "/placeholder.svg?height=200&width=200"}
                alt={listing.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 50vw, 33vw"
              />
              {listing.featured && (
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                  Featured
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="font-medium text-sm line-clamp-2">{listing.title}</h3>
              <p className="text-primary font-bold mt-1">Rp {listing.price.toLocaleString("id-ID")}</p>
              <div className="flex items-center mt-2 text-xs text-muted-foreground">
                <span>{listing.sellerName}</span>
                <span className="ml-auto flex items-center">★ {listing.rating || "N/A"}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {filteredResults.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No results found for this selection.</p>
          <Button variant="outline" className="mt-4" onClick={() => setSelectedObject(null)}>
            Show all results
          </Button>
        </div>
      )}
    </div>
  )
}
