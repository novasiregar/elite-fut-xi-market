"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { motion } from "framer-motion"
import { useAuth } from "@/context/auth-context"
import type { SearchResult } from "@/client/services/search"
import { triggerHaptic } from "@/utils/haptic"
import { useToast } from "@/hooks/use-toast"

export function RecommendationCarousel() {
  const [recommendations, setRecommendations] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [visibleCount, setVisibleCount] = useState(3)
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()

  // Determine visible count based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setVisibleCount(1)
      } else if (window.innerWidth < 768) {
        setVisibleCount(2)
      } else {
        setVisibleCount(3)
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Fetch recommendations
  useEffect(() => {
    const fetchRecommendations = async () => {
      setIsLoading(true)
      try {
        // Fetch personalized recommendations if user is logged in
        // Otherwise fetch trending listings
        const endpoint = user ? "/api/recommendations" : "/api/recommendations/trending"

        const response = await fetch(endpoint)

        if (!response.ok) {
          throw new Error("Failed to fetch recommendations")
        }

        const data = await response.json()
        setRecommendations(data.results || [])
      } catch (error) {
        console.error("Error fetching recommendations:", error)
        toast({
          title: "Error",
          description: "Failed to load recommendations",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchRecommendations()
  }, [user, toast])

  const handlePrevious = () => {
    setCurrentIndex((prev) => Math.max(0, prev - 1))
    triggerHaptic("light")
  }

  const handleNext = () => {
    setCurrentIndex((prev) => Math.min(recommendations.length - visibleCount, prev + 1))
    triggerHaptic("light")
  }

  const handleCardClick = (listing: SearchResult) => {
    triggerHaptic("light")
    router.push(`/listings/${listing.id}`)
  }

  if (isLoading) {
    return (
      <div className="relative">
        <div className="flex gap-4 overflow-hidden">
          {Array(visibleCount)
            .fill(0)
            .map((_, index) => (
              <div key={index} className="flex-shrink-0 w-full sm:w-1/2 md:w-1/3">
                <Card className="h-full">
                  <CardContent className="p-0">
                    <div className="aspect-[4/3] relative">
                      <Skeleton className="h-full w-full" />
                    </div>
                    <div className="p-4">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-6 w-1/2 mb-2" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
        </div>
      </div>
    )
  }

  if (recommendations.length === 0) {
    return null
  }

  return (
    <div className="relative">
      <div className="flex gap-4 overflow-hidden">
        {recommendations.slice(currentIndex, currentIndex + visibleCount).map((listing) => (
          <motion.div
            key={listing.id}
            className="flex-shrink-0 w-full sm:w-1/2 md:w-1/3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
            onClick={() => handleCardClick(listing)}
          >
            <Card className="h-full cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-0">
                <div className="aspect-[4/3] relative">
                  <img
                    src={listing.media?.[0]?.url || "/placeholder.svg?height=300&width=400"}
                    alt={listing.title}
                    className="h-full w-full object-cover rounded-t-md"
                  />
                  {listing.featured && (
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-md">
                      Featured
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-medium line-clamp-1">{listing.title}</h3>
                  <p className="text-lg font-bold mt-1">
                    {new Intl.NumberFormat("id-ID", {
                      style: "currency",
                      currency: "IDR",
                      minimumFractionDigits: 0,
                    }).format(listing.price)}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-muted overflow-hidden mr-2">
                        {listing.seller.avatar ? (
                          <img
                            src={listing.seller.avatar || "/placeholder.svg"}
                            alt={listing.seller.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-primary/20 flex items-center justify-center text-xs">
                            {listing.seller.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">{listing.seller.name}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-xs">{listing.seller.rating.toFixed(1)} ★</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Navigation buttons */}
      {currentIndex > 0 && (
        <Button
          variant="secondary"
          size="icon"
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 rounded-full h-10 w-10 opacity-80 hover:opacity-100"
          onClick={handlePrevious}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
      )}

      {currentIndex < recommendations.length - visibleCount && (
        <Button
          variant="secondary"
          size="icon"
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rounded-full h-10 w-10 opacity-80 hover:opacity-100"
          onClick={handleNext}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      )}
    </div>
  )
}
