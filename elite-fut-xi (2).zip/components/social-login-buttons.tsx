"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function SocialLoginButtons() {
  const { loginWithGoogle, loginWithFacebook, loginWithDiscord, loading } = useAuth()
  const [socialLoading, setSocialLoading] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  const handleSocialLogin = async (provider: "google" | "facebook" | "discord", loginFunction: () => Promise<any>) => {
    try {
      setSocialLoading(provider)
      await loginFunction()
      toast({
        title: "Login successful",
        description: "Welcome to ELITE FUT XI Market!",
      })
      router.push("/dashboard")
    } catch (error: any) {
      console.error(`${provider} login error:`, error)
      toast({
        title: "Login failed",
        description: error.message || `Failed to login with ${provider}.`,
        variant: "destructive",
      })
    } finally {
      setSocialLoading(null)
    }
  }

  return (
    <div className="space-y-3">
      <Button
        type="button"
        variant="outline"
        className="w-full font-futuristic relative pl-10"
        onClick={() => handleSocialLogin("google", loginWithGoogle)}
        disabled={loading || !!socialLoading}
      >
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
          <Image src="/icons/google.png" alt="Google" width={20} height={20} />
        </div>
        {socialLoading === "google" ? "CONNECTING..." : "CONTINUE WITH GOOGLE"}
      </Button>

      <Button
        type="button"
        variant="outline"
        className="w-full font-futuristic relative pl-10"
        onClick={() => handleSocialLogin("facebook", loginWithFacebook)}
        disabled={loading || !!socialLoading}
      >
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
          <Image src="/icons/facebook.png" alt="Facebook" width={20} height={20} />
        </div>
        {socialLoading === "facebook" ? "CONNECTING..." : "CONTINUE WITH FACEBOOK"}
      </Button>

      <Button
        type="button"
        variant="outline"
        className="w-full font-futuristic relative pl-10"
        onClick={() => handleSocialLogin("discord", loginWithDiscord)}
        disabled={loading || !!socialLoading}
      >
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
          <Image src="/icons/discord.png" alt="Discord" width={20} height={20} />
        </div>
        {socialLoading === "discord" ? "CONNECTING..." : "CONTINUE WITH DISCORD"}
      </Button>
    </div>
  )
}
