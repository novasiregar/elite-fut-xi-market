"use client"

import type React from "react"
import { useState, useRef, useEffect, type ReactNode } from "react"
import { useHaptic, HapticType } from "@/utils/haptic"

type GestureType = "swipe" | "tap" | "longPress" | "pinch" | "rotate" | "pan"

interface GestureHandlerProps {
  children: ReactNode
  onSwipeLeft?: () => void
  onSwipeRight?: () => void
  onSwipeUp?: () => void
  onSwipeDown?: () => void
  onTap?: () => void
  onDoubleTap?: () => void
  onLongPress?: () => void
  onPinchIn?: (scale: number) => void
  onPinchOut?: (scale: number) => void
  onRotate?: (angle: number) => void
  onPan?: (deltaX: number, deltaY: number) => void
  swipeThreshold?: number
  longPressDelay?: number
  doubleTapDelay?: number
  disableScroll?: boolean
  hapticFeedback?: boolean | { [key in GestureType]?: HapticType }
  className?: string
  style?: React.CSSProperties
}

export function GestureHandler({
  children,
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  onTap,
  onDoubleTap,
  onLongPress,
  onPinchIn,
  onPinchOut,
  onRotate,
  onPan,
  swipeThreshold = 50,
  longPressDelay = 500,
  doubleTapDelay = 300,
  disableScroll = false,
  hapticFeedback = true,
  className,
  style,
}: GestureHandlerProps) {
  const { trigger } = useHaptic()
  const elementRef = useRef<HTMLDivElement>(null)
  const touchStartRef = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 })
  const touchEndRef = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 })
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null)
  const lastTapTimeRef = useRef<number>(0)
  const initialTouchDistanceRef = useRef<number>(0)
  const initialTouchAngleRef = useRef<number>(0)
  const [isLongPressing, setIsLongPressing] = useState(false)
  const [isPinching, setIsPinching] = useState(false)
  const [isRotating, setIsRotating] = useState(false)
  const [isPanning, setIsPanning] = useState(false)

  // Helper function to get haptic feedback type
  const getHapticType = (gesture: GestureType): HapticType | null => {
    if (!hapticFeedback) return null

    if (typeof hapticFeedback === "object") {
      return hapticFeedback[gesture] || null
    }

    // Default haptic types for different gestures
    switch (gesture) {
      case "swipe":
        return HapticType.MEDIUM
      case "tap":
        return HapticType.LIGHT
      case "longPress":
        return HapticType.HEAVY
      case "pinch":
        return HapticType.MEDIUM
      case "rotate":
        return HapticType.MEDIUM
      case "pan":
        return HapticType.LIGHT
      default:
        return HapticType.LIGHT
    }
  }

  // Calculate distance between two touch points
  const getTouchDistance = (touches: TouchList): number => {
    if (touches.length < 2) return 0
    const dx = touches[0].clientX - touches[1].clientX
    const dy = touches[0].clientY - touches[1].clientY
    return Math.sqrt(dx * dx + dy * dy)
  }

  // Calculate angle between two touch points
  const getTouchAngle = (touches: TouchList): number => {
    if (touches.length < 2) return 0
    return (
      Math.atan2(touches[1].clientY - touches[0].clientY, touches[1].clientX - touches[0].clientX) * (180 / Math.PI)
    )
  }

  // Handle touch start
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0]
    touchStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    }

    // Start long press timer
    if (onLongPress) {
      longPressTimerRef.current = setTimeout(() => {
        setIsLongPressing(true)
        const hapticType = getHapticType("longPress")
        if (hapticType) trigger(hapticType)
        onLongPress()
      }, longPressDelay)
    }

    // Handle pinch start
    if ((onPinchIn || onPinchOut) && e.touches.length === 2) {
      initialTouchDistanceRef.current = getTouchDistance(e.touches)
      setIsPinching(true)
    }

    // Handle rotation start
    if (onRotate && e.touches.length === 2) {
      initialTouchAngleRef.current = getTouchAngle(e.touches)
      setIsRotating(true)
    }

    // Handle pan start
    if (onPan && e.touches.length === 1) {
      setIsPanning(true)
    }

    // Prevent default if scroll is disabled
    if (disableScroll) {
      e.preventDefault()
    }
  }

  // Handle touch move
  const handleTouchMove = (e: React.TouchEvent) => {
    // Cancel long press if finger moves too much
    if (longPressTimerRef.current && !isLongPressing) {
      const touch = e.touches[0]
      const deltaX = Math.abs(touch.clientX - touchStartRef.current.x)
      const deltaY = Math.abs(touch.clientY - touchStartRef.current.y)

      if (deltaX > 10 || deltaY > 10) {
        clearTimeout(longPressTimerRef.current)
        longPressTimerRef.current = null
      }
    }

    // Handle pinch
    if ((onPinchIn || onPinchOut) && e.touches.length === 2 && isPinching) {
      const currentDistance = getTouchDistance(e.touches)
      const scale = currentDistance / initialTouchDistanceRef.current

      if (scale > 1 && onPinchOut) {
        onPinchOut(scale)
        const hapticType = getHapticType("pinch")
        if (hapticType) trigger(hapticType)
      } else if (scale < 1 && onPinchIn) {
        onPinchIn(scale)
        const hapticType = getHapticType("pinch")
        if (hapticType) trigger(hapticType)
      }
    }

    // Handle rotation
    if (onRotate && e.touches.length === 2 && isRotating) {
      const currentAngle = getTouchAngle(e.touches)
      const rotation = currentAngle - initialTouchAngleRef.current
      onRotate(rotation)
      const hapticType = getHapticType("rotate")
      if (hapticType) trigger(hapticType)
    }

    // Handle pan
    if (onPan && e.touches.length === 1 && isPanning) {
      const touch = e.touches[0]
      const deltaX = touch.clientX - touchStartRef.current.x
      const deltaY = touch.clientY - touchStartRef.current.y
      onPan(deltaX, deltaY)
      const hapticType = getHapticType("pan")
      if (hapticType) trigger(hapticType)
    }

    // Prevent default if scroll is disabled
    if (disableScroll) {
      e.preventDefault()
    }
  }

  // Handle touch end
  const handleTouchEnd = (e: React.TouchEvent) => {
    const touch = e.changedTouches[0]
    touchEndRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    }

    // Clear long press timer
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current)
      longPressTimerRef.current = null
    }

    // Reset states
    setIsLongPressing(false)
    setIsPinching(false)
    setIsRotating(false)
    setIsPanning(false)

    // Calculate swipe
    const deltaX = touchEndRef.current.x - touchStartRef.current.x
    const deltaY = touchEndRef.current.y - touchStartRef.current.y
    const deltaTime = touchEndRef.current.time - touchStartRef.current.time

    // Check if it's a tap (small movement and short duration)
    if (Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10 && deltaTime < 300) {
      // Check if it's a double tap
      const now = Date.now()
      if (onDoubleTap && now - lastTapTimeRef.current < doubleTapDelay) {
        onDoubleTap()
        const hapticType = getHapticType("tap")
        if (hapticType) trigger(hapticType)
        lastTapTimeRef.current = 0 // Reset to prevent triple tap
      } else {
        // Single tap
        if (onTap) {
          onTap()
          const hapticType = getHapticType("tap")
          if (hapticType) trigger(hapticType)
        }
        lastTapTimeRef.current = now
      }
      return
    }

    // Check for swipes
    if (deltaTime < 300) {
      // Fast enough to be a swipe
      if (Math.abs(deltaX) > swipeThreshold) {
        if (deltaX > 0 && onSwipeRight) {
          onSwipeRight()
          const hapticType = getHapticType("swipe")
          if (hapticType) trigger(hapticType)
        } else if (deltaX < 0 && onSwipeLeft) {
          onSwipeLeft()
          const hapticType = getHapticType("swipe")
          if (hapticType) trigger(hapticType)
        }
      }

      if (Math.abs(deltaY) > swipeThreshold) {
        if (deltaY > 0 && onSwipeDown) {
          onSwipeDown()
          const hapticType = getHapticType("swipe")
          if (hapticType) trigger(hapticType)
        } else if (deltaY < 0 && onSwipeUp) {
          onSwipeUp()
          const hapticType = getHapticType("swipe")
          if (hapticType) trigger(hapticType)
        }
      }
    }
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current)
      }
    }
  }, [])

  return (
    <div
      ref={elementRef}
      className={className}
      style={style}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {children}
    </div>
  )
}
