"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Home,
  Search,
  MessageCircle,
  User,
  Menu,
  ShoppingBag,
  Bell,
  LogOut,
  LogIn,
  UserPlus,
  Settings,
  Heart,
  Clock,
} from "lucide-react"
import { useAuth } from "@/context/auth-context"
import { UserService } from "@/client/services/users"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { GestureHandler } from "@/components/gesture-handler"
import { useHaptic, HapticType } from "@/utils/haptic"
import { usePathname } from "next/navigation"

export function MobileNavbar() {
  const { user, userProfile, logout } = useAuth()
  const [notifications, setNotifications] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const { trigger } = useHaptic()
  const pathname = usePathname()

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Fetch notification count
  useEffect(() => {
    if (user) {
      const fetchNotifications = async () => {
        try {
          const notifs = await UserService.getNotifications(false)
          setNotifications(notifs.length)
        } catch (error) {
          console.error("Error fetching notifications:", error)
        }
      }

      fetchNotifications()

      // Refresh notifications every minute
      const interval = setInterval(fetchNotifications, 60000)
      return () => clearInterval(interval)
    }
  }, [user])

  const handleLogout = async () => {
    try {
      await logout()
      setIsMenuOpen(false)
      trigger(HapticType.MEDIUM)
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  const handleSwipeDown = () => {
    // Only trigger if we're at the top of the page
    if (window.scrollY < 10) {
      // Simulate pull-to-refresh
      trigger(HapticType.MEDIUM)
      window.location.reload()
    }
  }

  const handleSwipeLeft = () => {
    // Navigate forward in common navigation flows
    if (pathname === "/") {
      trigger(HapticType.LIGHT)
      window.location.href = "/marketplace"
    }
  }

  const handleSwipeRight = () => {
    // Navigate backward or open menu
    if (pathname !== "/") {
      trigger(HapticType.LIGHT)
      window.history.back()
    } else {
      trigger(HapticType.LIGHT)
      setIsMenuOpen(true)
    }
  }

  return (
    <GestureHandler onSwipeDown={handleSwipeDown} onSwipeLeft={handleSwipeLeft} onSwipeRight={handleSwipeRight}>
      {/* Top Navigation */}
      <div
        className={`fixed top-0 left-0 right-0 h-16 ${isScrolled ? "bg-background/80" : "bg-background/50"} backdrop-blur-md border-b border-border z-20 px-4 transition-colors duration-300`}
      >
        <div className="h-full max-w-md mx-auto flex items-center justify-between">
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="relative" onClick={() => trigger(HapticType.LIGHT)}>
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="gradient-bg border-r border-primary/20 w-[80%] max-w-[300px] p-0">
              <div className="p-6 border-b border-border">
                {user ? (
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 rounded-md">
                      <AvatarImage src={userProfile?.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-primary/20 text-primary">
                        {userProfile?.displayName?.charAt(0) || user.email?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-futuristic text-sm">{userProfile?.displayName || "PLAYER"}</p>
                      <p className="text-xs text-muted-foreground">
                        {userProfile?.isVerified ? "Verified Seller" : "Member"}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-md bg-primary/20 flex items-center justify-center">
                      <User className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-futuristic text-sm">GUEST</p>
                      <p className="text-xs text-muted-foreground">Not logged in</p>
                    </div>
                  </div>
                )}
              </div>

              <nav className="p-4">
                <ul className="space-y-2">
                  <NavItem
                    href="/"
                    icon={<Home className="h-4 w-4" />}
                    label="Home"
                    onClick={() => {
                      setIsMenuOpen(false)
                      trigger(HapticType.LIGHT)
                    }}
                  />
                  <NavItem
                    href="/marketplace"
                    icon={<ShoppingBag className="h-4 w-4" />}
                    label="Marketplace"
                    onClick={() => {
                      setIsMenuOpen(false)
                      trigger(HapticType.LIGHT)
                    }}
                  />

                  {user ? (
                    <>
                      <NavItem
                        href="/messages"
                        icon={<MessageCircle className="h-4 w-4" />}
                        label="Messages"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem
                        href="/favorites"
                        icon={<Heart className="h-4 w-4" />}
                        label="Favorites"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem
                        href="/transactions"
                        icon={<Clock className="h-4 w-4" />}
                        label="Transactions"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem
                        href="/profile"
                        icon={<User className="h-4 w-4" />}
                        label="Profile"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem
                        href="/settings"
                        icon={<Settings className="h-4 w-4" />}
                        label="Settings"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem href="#" icon={<LogOut className="h-4 w-4" />} label="Logout" onClick={handleLogout} />
                    </>
                  ) : (
                    <>
                      <NavItem
                        href="/login"
                        icon={<LogIn className="h-4 w-4" />}
                        label="Login"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                      <NavItem
                        href="/register"
                        icon={<UserPlus className="h-4 w-4" />}
                        label="Register"
                        onClick={() => {
                          setIsMenuOpen(false)
                          trigger(HapticType.LIGHT)
                        }}
                      />
                    </>
                  )}
                </ul>
              </nav>

              <div className="absolute bottom-8 left-4 right-4">
                <div className="pixel-border p-3 bg-muted/30">
                  <p className="text-xs mb-2 font-futuristic glow-text-accent">SECURE ESCROW</p>
                  <p className="text-xs text-muted-foreground">
                    All transactions are protected by our built-in escrow system.
                  </p>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <Link href="/" className="font-pixel text-sm glow-text" onClick={() => trigger(HapticType.LIGHT)}>
            ELITE FUT XI
          </Link>

          {user ? (
            <Link href="/notifications" className="relative" onClick={() => trigger(HapticType.LIGHT)}>
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
                {notifications > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center text-[10px] font-bold">
                    {notifications > 9 ? "9+" : notifications}
                  </span>
                )}
              </Button>
            </Link>
          ) : (
            <Link href="/login" onClick={() => trigger(HapticType.LIGHT)}>
              <Button variant="ghost" size="sm" className="font-futuristic text-xs">
                LOGIN
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 h-14 bg-background/80 backdrop-blur-md border-t border-border z-20">
        <div className="h-full max-w-md mx-auto grid grid-cols-4">
          <BottomNavItem href="/" icon={<Home className="h-5 w-5" />} label="Home" />
          <BottomNavItem href="/marketplace" icon={<Search className="h-5 w-5" />} label="Search" />
          {user ? (
            <>
              <BottomNavItem href="/messages" icon={<MessageCircle className="h-5 w-5" />} label="Chat" />
              <BottomNavItem href="/profile" icon={<User className="h-5 w-5" />} label="Profile" />
            </>
          ) : (
            <>
              <BottomNavItem href="/login" icon={<LogIn className="h-5 w-5" />} label="Login" />
              <BottomNavItem href="/register" icon={<UserPlus className="h-5 w-5" />} label="Register" />
            </>
          )}
        </div>
      </div>
    </GestureHandler>
  )
}

function NavItem({
  href,
  icon,
  label,
  onClick,
}: {
  href: string
  icon: React.ReactNode
  label: string
  onClick?: () => void
}) {
  return (
    <li>
      <Link
        href={href}
        className="flex items-center gap-3 px-2 py-2 rounded-md hover:bg-primary/10 transition-colors"
        onClick={onClick}
      >
        <span className="text-primary">{icon}</span>
        <span className="font-futuristic text-sm">{label}</span>
      </Link>
    </li>
  )
}

function BottomNavItem({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  const { trigger } = useHaptic()
  const pathname = usePathname()
  const isActive = pathname === href

  return (
    <Link
      href={href}
      className={`flex flex-col items-center justify-center ${isActive ? "text-primary" : "text-muted-foreground"}`}
      onClick={() => trigger(HapticType.LIGHT)}
    >
      <span>{icon}</span>
      <span className="text-[10px] mt-1 font-futuristic">{label}</span>
    </Link>
  )
}
