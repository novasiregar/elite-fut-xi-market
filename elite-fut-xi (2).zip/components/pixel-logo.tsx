"use client"

import { useEffect, useRef } from "react"

export function PixelLogo() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = 120
    canvas.height = 120

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw pixel art football
    const drawPixelBall = () => {
      // Ball outline
      ctx.fillStyle = "#ffffff"
      ctx.beginPath()
      ctx.arc(60, 60, 40, 0, Math.PI * 2)
      ctx.fill()

      // Ball pattern
      ctx.fillStyle = "#000000"

      // Hexagon pattern
      const hexPoints = [
        [60, 30], // top
        [85, 45], // top right
        [85, 75], // bottom right
        [60, 90], // bottom
        [35, 75], // bottom left
        [35, 45], // top left
      ]

      // Draw hexagon
      ctx.beginPath()
      ctx.moveTo(hexPoints[0][0], hexPoints[0][1])
      for (let i = 1; i < hexPoints.length; i++) {
        ctx.lineTo(hexPoints[i][0], hexPoints[i][1])
      }
      ctx.closePath()
      ctx.fill()

      // Draw pentagons
      const pentagonCenters = [
        [60, 20], // top
        [95, 50], // right
        [80, 95], // bottom right
        [40, 95], // bottom left
        [25, 50], // left
      ]

      pentagonCenters.forEach((center) => {
        ctx.beginPath()
        for (let i = 0; i < 5; i++) {
          const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2
          const x = center[0] + 10 * Math.cos(angle)
          const y = center[1] + 10 * Math.sin(angle)
          if (i === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        }
        ctx.closePath()
        ctx.fill()
      })

      // Add glow effect
      ctx.shadowColor = "#00ffff"
      ctx.shadowBlur = 15
      ctx.strokeStyle = "#00ffff"
      ctx.lineWidth = 2
      ctx.stroke()
    }

    // Add "XI" text
    const drawXI = () => {
      ctx.shadowColor = "#ff00ff"
      ctx.shadowBlur = 10
      ctx.fillStyle = "#ffffff"
      ctx.font = 'bold 24px "Press Start 2P", monospace'
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("XI", 60, 60)
    }

    drawPixelBall()
    drawXI()

    // Animation loop for glow effect
    let glowIntensity = 0
    let increasing = true

    const animate = () => {
      if (increasing) {
        glowIntensity += 0.5
        if (glowIntensity >= 20) increasing = false
      } else {
        glowIntensity -= 0.5
        if (glowIntensity <= 5) increasing = true
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      ctx.shadowBlur = glowIntensity
      drawPixelBall()
      drawXI()

      requestAnimationFrame(animate)
    }

    animate()
  }, [])

  return <canvas ref={canvasRef} width={120} height={120} className="pixel-border p-1" />
}
