"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { TrendingUp, Clock, Star, ArrowDownUp } from "lucide-react"
import { cn } from "@/lib/utils"

export function FilterBar() {
  const [activeFilter, setActiveFilter] = useState("trending")

  const handleFilterClick = (filter: string) => {
    setActiveFilter(filter)
  }

  return (
    <div className="flex gap-2 mb-2 overflow-x-auto pb-2 scrollbar-hide">
      <Button
        variant={activeFilter === "trending" ? "secondary" : "outline"}
        size="sm"
        className={cn("whitespace-nowrap", activeFilter === "trending" && "shadow-[0_0_10px_rgba(180,0,255,0.5)]")}
        onClick={() => handleFilterClick("trending")}
      >
        <TrendingUp className="h-3 w-3 mr-1" /> Trending
      </Button>

      <Button
        variant={activeFilter === "new" ? "secondary" : "outline"}
        size="sm"
        className={cn("whitespace-nowrap", activeFilter === "new" && "shadow-[0_0_10px_rgba(180,0,255,0.5)]")}
        onClick={() => handleFilterClick("new")}
      >
        <Clock className="h-3 w-3 mr-1" /> New Listings
      </Button>

      <Button
        variant={activeFilter === "rated" ? "secondary" : "outline"}
        size="sm"
        className={cn("whitespace-nowrap", activeFilter === "rated" && "shadow-[0_0_10px_rgba(180,0,255,0.5)]")}
        onClick={() => handleFilterClick("rated")}
      >
        <Star className="h-3 w-3 mr-1" /> Top Rated
      </Button>

      <Button
        variant={activeFilter === "price-low" ? "secondary" : "outline"}
        size="sm"
        className={cn("whitespace-nowrap", activeFilter === "price-low" && "shadow-[0_0_10px_rgba(180,0,255,0.5)]")}
        onClick={() => handleFilterClick("price-low")}
      >
        <ArrowDownUp className="h-3 w-3 mr-1" /> Price: Low to High
      </Button>

      <Button
        variant={activeFilter === "price-high" ? "secondary" : "outline"}
        size="sm"
        className={cn("whitespace-nowrap", activeFilter === "price-high" && "shadow-[0_0_10px_rgba(180,0,255,0.5)]")}
        onClick={() => handleFilterClick("price-high")}
      >
        <ArrowDownUp className="h-3 w-3 mr-1 rotate-180" /> Price: High to Low
      </Button>
    </div>
  )
}
