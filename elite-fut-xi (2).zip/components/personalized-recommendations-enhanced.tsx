"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { OptimizedImage } from "@/components/optimized-image"
import { Skeleton } from "@/components/ui/skeleton"
import { Sparkles, ChevronRight, ChevronLeft, RefreshCw } from "lucide-react"
import type { Listing } from "@/client/services/listings"
import { useAuth } from "@/context/auth-context"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"
import { useInView } from "react-intersection-observer"
import { motion, AnimatePresence } from "framer-motion"

interface PersonalizedRecommendationsProps {
  context?: "homepage" | "listing-detail" | "search-results" | "profile"
  title?: string
  limit?: number
  listingId?: string
  categories?: string[]
  priceRange?: { min: number; max: number }
  refreshInterval?: number // in milliseconds, if provided will auto-refresh
}

export function PersonalizedRecommendationsEnhanced({
  context = "homepage",
  title = "Recommended for You",
  limit = 10,
  listingId,
  categories,
  priceRange,
  refreshInterval,
}: PersonalizedRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<Listing[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [scrollPosition, setScrollPosition] = useState(0)
  const [refreshing, setRefreshing] = useState(false)
  const { user } = useAuth()
  const { triggerHaptic } = useHapticFeedback()

  // Use intersection observer to load recommendations when component is visible
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  // Fetch recommendations when component is in view
  useEffect(() => {
    if (inView) {
      fetchRecommendations()
    }
  }, [inView, user?.id, context, listingId, categories, priceRange])

  // Set up auto-refresh if interval is provided
  useEffect(() => {
    if (!refreshInterval) return

    const intervalId = setInterval(() => {
      if (inView && !loading) {
        handleRefresh()
      }
    }, refreshInterval)

    return () => clearInterval(intervalId)
  }, [refreshInterval, inView, loading])

  async function fetchRecommendations() {
    setLoading(true)
    setError(null)

    try {
      // Build query parameters
      const params = new URLSearchParams()
      params.append("limit", limit.toString())
      params.append("context", context)

      if (listingId) {
        params.append("listingId", listingId)
      }

      if (categories && categories.length > 0) {
        categories.forEach((category) => params.append("categories", category))
      }

      if (priceRange) {
        params.append("minPrice", priceRange.min.toString())
        params.append("maxPrice", priceRange.max.toString())
      }

      // Determine which API endpoint to use based on context and user state
      let endpoint = "/api/search/recommendations"

      if (context === "listing-detail" && listingId) {
        endpoint = `/api/search/similar/${listingId}`
      } else if (!user) {
        endpoint = "/api/listings/popular"
      }

      const response = await fetch(`${endpoint}?${params.toString()}`)

      if (!response.ok) {
        throw new Error("Failed to fetch recommendations")
      }

      const data = await response.json()
      setRecommendations(data.recommendations || data.listings || data.results || [])
    } catch (error) {
      console.error("Error fetching recommendations:", error)
      setError("Failed to load recommendations")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleScroll = (direction: "left" | "right") => {
    triggerHaptic("light")
    const container = document.getElementById("recommendations-container")
    if (!container) return

    const scrollAmount = direction === "left" ? -300 : 300
    const newPosition = scrollPosition + scrollAmount

    container.scrollTo({
      left: newPosition,
      behavior: "smooth",
    })

    setScrollPosition(newPosition)
  }

  const handleRefresh = () => {
    triggerHaptic("medium")
    setRefreshing(true)
    fetchRecommendations()
  }

  // Handle click on a recommendation
  const handleRecommendationClick = (listingId: string) => {
    // Record this click for improving future recommendations
    if (user) {
      fetch("/api/search/recommendation-click", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          listingId,
          context,
        }),
      }).catch((err) => console.error("Failed to record recommendation click:", err))
    }
  }

  if (loading && !refreshing) {
    return (
      <div ref={ref} className="space-y-3">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-8 w-20" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array(5)
            .fill(0)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="aspect-square w-full" />
                <CardContent className="p-3">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div ref={ref} className="p-4 border border-red-200 rounded-md bg-red-50 text-red-800">
        <p>{error}</p>
        <Button variant="outline" size="sm" className="mt-2" onClick={fetchRecommendations}>
          Try Again
        </Button>
      </div>
    )
  }

  if (recommendations.length === 0 && !loading) {
    return null
  }

  return (
    <div ref={ref} className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          {title}
        </h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleScroll("left")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleScroll("right")}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div id="recommendations-container" className="flex overflow-x-auto scrollbar-hide gap-4 pb-2">
        <AnimatePresence mode="popLayout">
          {recommendations.map((listing) => (
            <motion.div
              key={listing.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.2 }}
              className="min-w-[200px] max-w-[200px]"
            >
              <Link
                href={`/listings/${listing.id}`}
                onClick={() => handleRecommendationClick(listing.id)}
                className="block bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="aspect-square relative">
                  <OptimizedImage
                    src={listing.media?.[0]?.url || "/placeholder.svg?height=200&width=200"}
                    alt={listing.title}
                    fill
                    className="object-cover"
                    sizes="200px"
                  />
                  {listing.featured && (
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                      Featured
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm line-clamp-2">{listing.title}</h3>
                  <p className="text-primary font-bold mt-1">Rp {listing.price.toLocaleString("id-ID")}</p>
                  <div className="flex items-center mt-2 text-xs text-muted-foreground">
                    <span>{listing.sellerName}</span>
                    <span className="ml-auto flex items-center">★ {listing.rating || "N/A"}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}
