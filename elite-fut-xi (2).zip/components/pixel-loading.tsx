"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface PixelLoadingProps {
  size?: number
  color?: string
  className?: string
}

export function PixelLoading({ size = 64, color = "#00ffff", className }: PixelLoadingProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = size
    canvas.height = size

    // Pixel size
    const pixelSize = size / 8

    // Animation variables
    let frame = 0
    const totalFrames = 12
    const pixelStates: boolean[][] = Array(8)
      .fill(0)
      .map(() => Array(8).fill(false))

    // Animation patterns
    const patterns = [
      // Border pattern
      [
        [0, 0],
        [1, 0],
        [2, 0],
        [3, 0],
        [4, 0],
        [5, 0],
        [6, 0],
        [7, 0],
        [7, 1],
        [7, 2],
        [7, 3],
        [7, 4],
        [7, 5],
        [7, 6],
        [7, 7],
        [6, 7],
        [5, 7],
        [4, 7],
        [3, 7],
        [2, 7],
        [1, 7],
        [0, 7],
        [0, 6],
        [0, 5],
        [0, 4],
        [0, 3],
        [0, 2],
        [0, 1],
      ],
      // X pattern
      [
        [0, 0],
        [1, 1],
        [2, 2],
        [3, 3],
        [4, 4],
        [5, 5],
        [6, 6],
        [7, 7],
        [7, 0],
        [6, 1],
        [5, 2],
        [4, 3],
        [3, 4],
        [2, 5],
        [1, 6],
        [0, 7],
      ],
      // Plus pattern
      [
        [3, 0],
        [4, 0],
        [3, 1],
        [4, 1],
        [3, 2],
        [4, 2],
        [0, 3],
        [1, 3],
        [2, 3],
        [3, 3],
        [4, 3],
        [5, 3],
        [6, 3],
        [7, 3],
        [0, 4],
        [1, 4],
        [2, 4],
        [3, 4],
        [4, 4],
        [5, 4],
        [6, 4],
        [7, 4],
        [3, 5],
        [4, 5],
        [3, 6],
        [4, 6],
        [3, 7],
        [4, 7],
      ],
    ]

    // Animation function
    const animate = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Reset pixel states
      for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
          pixelStates[i][j] = false
        }
      }

      // Calculate current pattern
      const patternIndex = Math.floor(frame / (totalFrames / patterns.length))
      const pattern = patterns[patternIndex % patterns.length]

      // Calculate active pixels based on frame
      const activePixels = Math.floor(
        (pattern.length * (frame % (totalFrames / patterns.length))) / (totalFrames / patterns.length),
      )

      // Set active pixels
      for (let i = 0; i < activePixels; i++) {
        const [x, y] = pattern[i % pattern.length]
        pixelStates[x][y] = true
      }

      // Draw pixels
      for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
          if (pixelStates[i][j]) {
            ctx.fillStyle = color
            ctx.shadowColor = color
            ctx.shadowBlur = 8
            ctx.fillRect(i * pixelSize, j * pixelSize, pixelSize - 1, pixelSize - 1)
          } else {
            ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
            ctx.fillRect(i * pixelSize, j * pixelSize, pixelSize - 1, pixelSize - 1)
          }
        }
      }

      // Update frame
      frame = (frame + 1) % totalFrames

      requestAnimationFrame(animate)
    }

    // Start animation
    animate()
  }, [size, color])

  return <canvas ref={canvasRef} width={size} height={size} className={cn("pixel-border", className)} />
}
