"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShareListing } from "@/components/share-listing"
import { GestureHandler } from "@/components/gesture-handler"
import { Heart, MessageCircle, Shield, Star, ChevronLeft, ChevronRight, Play, Pause } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface ListingLandscapeLayoutProps {
  listing: any
  onContactSeller: () => void
  onBuyNow: () => void
  isContactingSeller: boolean
  isFavorited: boolean
  onToggleFavorite: () => void
}

export function ListingLandscapeLayout({
  listing,
  onContactSeller,
  onBuyNow,
  isContactingSeller,
  isFavorited,
  onToggleFavorite,
}: ListingLandscapeLayoutProps) {
  const [activeMediaIndex, setActiveMediaIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [activeTab, setActiveTab] = useState("details")
  const { toast } = useToast()

  const nextMedia = () => {
    if (!listing?.media) return
    setActiveMediaIndex((prev) => (prev + 1) % listing.media.length)
    setIsPlaying(false)
  }

  const prevMedia = () => {
    if (!listing?.media) return
    setActiveMediaIndex((prev) => (prev - 1 + listing.media.length) % listing.media.length)
    setIsPlaying(false)
  }

  const toggleVideo = () => {
    setIsPlaying(!isPlaying)
  }

  const activeMedia = listing.media[activeMediaIndex]
  const isVideo = activeMedia?.type === "video"

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden">
      {/* Left side - Media Gallery */}
      <div className="w-1/2 p-4 flex flex-col">
        <GestureHandler
          onSwipeLeft={nextMedia}
          onSwipeRight={prevMedia}
          className="relative flex-1 rounded-lg overflow-hidden pixel-border"
        >
          {isVideo ? (
            <>
              <video
                src={activeMedia.url}
                poster={listing.media[0]?.type === "image" ? listing.media[0].url : undefined}
                className="w-full h-full object-cover"
                loop
                muted
                playsInline
                autoPlay={isPlaying}
              />
              <button
                onClick={toggleVideo}
                className="absolute bottom-4 right-4 bg-black/50 rounded-full p-2 backdrop-blur-sm"
              >
                {isPlaying ? <Pause className="h-5 w-5 text-white" /> : <Play className="h-5 w-5 text-white" />}
              </button>
            </>
          ) : (
            <img
              src={activeMedia.url || "/placeholder.svg"}
              alt={listing.title}
              className="w-full h-full object-cover"
            />
          )}

          {/* Media navigation */}
          {listing.media.length > 1 && (
            <>
              <button
                onClick={prevMedia}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 rounded-full p-2 backdrop-blur-sm"
              >
                <ChevronLeft className="h-5 w-5 text-white" />
              </button>
              <button
                onClick={nextMedia}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 rounded-full p-2 backdrop-blur-sm"
              >
                <ChevronRight className="h-5 w-5 text-white" />
              </button>
            </>
          )}

          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-background/70 to-transparent pointer-events-none"></div>

          {/* Scanline effect */}
          <div className="scanline absolute inset-0 pointer-events-none opacity-10"></div>
        </GestureHandler>

        {/* Thumbnails */}
        {listing.media.length > 1 && (
          <div className="flex gap-2 mt-2 overflow-x-auto scrollbar-hide pb-2">
            {listing.media.map((media: any, index: number) => (
              <button
                key={index}
                className={`w-16 h-16 rounded-md overflow-hidden border-2 transition-colors ${
                  index === activeMediaIndex ? "border-primary" : "border-transparent"
                }`}
                onClick={() => setActiveMediaIndex(index)}
              >
                {media.type === "image" ? (
                  <img
                    src={media.url || "/placeholder.svg"}
                    alt={`Thumbnail ${index}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <Play className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Right side - Listing Details */}
      <div className="w-1/2 p-4 overflow-y-auto">
        <div className="mb-4">
          <h1 className="font-futuristic text-xl glow-text mb-2">{listing.title}</h1>

          <div className="flex items-center justify-between mb-4">
            <div>
              <Badge variant="outline" className="font-futuristic text-lg mb-1">
                Rp {listing.price.toLocaleString()}
              </Badge>
              <div className="flex items-center">
                <Star className="h-3 w-3 text-yellow-500 mr-1" />
                <span className="text-xs">{listing.rating?.toFixed(1) || "New"}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className={`${isFavorited ? "text-red-500" : "text-muted-foreground"}`}
                onClick={onToggleFavorite}
              >
                <Heart className="h-5 w-5" fill={isFavorited ? "currentColor" : "none"} />
              </Button>
              <ShareListing listing={listing} />
            </div>
          </div>

          <Card className="mb-4 bg-card/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center">
                      <p className="font-futuristic text-sm">{listing.sellerName}</p>
                      {listing.sellerVerified && <Shield className="h-3 w-3 text-primary ml-1" />}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Seller since {new Date(listing.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={onContactSeller}
                  disabled={isContactingSeller}
                >
                  <MessageCircle className="h-3 w-3 mr-1" />
                  {isContactingSeller ? "Sending..." : "Contact"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="details" className="font-futuristic">
                DETAILS
              </TabsTrigger>
              <TabsTrigger value="stats" className="font-futuristic">
                STATS
              </TabsTrigger>
              <TabsTrigger value="info" className="font-futuristic">
                INFO
              </TabsTrigger>
            </TabsList>

            <TabsContent value="details">
              <Card className="bg-card/50 backdrop-blur-sm">
                <CardContent className="p-4">
                  <h3 className="font-futuristic text-sm mb-2 glow-text">DESCRIPTION</h3>
                  <p className="text-sm whitespace-pre-wrap">{listing.description}</p>

                  {listing.tags && listing.tags.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-xs text-muted-foreground mb-2">Tags:</h4>
                      <div className="flex flex-wrap gap-2">
                        {listing.tags.map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stats">
              <Card className="bg-card/50 backdrop-blur-sm">
                <CardContent className="p-4">
                  <h3 className="font-futuristic text-sm mb-2 glow-text">ACCOUNT STATS</h3>
                  <p className="text-sm">Stats content would go here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="info">
              <Card className="bg-card/50 backdrop-blur-sm">
                <CardContent className="p-4">
                  <h3 className="font-futuristic text-sm mb-2 glow-text">LISTING INFORMATION</h3>
                  <p className="text-sm">Info content would go here</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Button
            className="w-full mt-4 font-futuristic bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
            onClick={onBuyNow}
          >
            BUY NOW
          </Button>
        </div>
      </div>
    </div>
  )
}
