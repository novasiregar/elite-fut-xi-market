"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { OptimizedImage } from "@/components/optimized-image"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Camera, Filter } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"
import type { Listing } from "@/client/services/listings"

interface DetectedObject {
  name: string
  score: number
  boundingBox: {
    x: number
    y: number
    width: number
    height: number
  }
}

interface VisualSearchResultsClientProps {
  searchId: string
}

export function VisualSearchResultsClient({ searchId }: VisualSearchResultsClientProps) {
  const [results, setResults] = useState<Listing[]>([])
  const [detectedObjects, setDetectedObjects] = useState<DetectedObject[]>([])
  const [searchTerms, setSearchTerms] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedObject, setSelectedObject] = useState<string | null>(null)
  const [filteredResults, setFilteredResults] = useState<Listing[]>([])
  const { toast } = useToast()
  const { triggerHaptic } = useHapticFeedback()

  useEffect(() => {
    fetchResults()
  }, [searchId])

  // Filter results when a detected object is selected
  useEffect(() => {
    if (selectedObject) {
      // Simple filtering based on title and tags
      const filtered = results.filter(
        (listing) =>
          listing.title.toLowerCase().includes(selectedObject.toLowerCase()) ||
          listing.tags.some((tag) => tag.toLowerCase().includes(selectedObject.toLowerCase())) ||
          (listing.accountDetails?.topPlayers &&
            Array.isArray(listing.accountDetails.topPlayers) &&
            listing.accountDetails.topPlayers.some((player) =>
              player.toLowerCase().includes(selectedObject.toLowerCase()),
            )),
      )
      setFilteredResults(filtered.length > 0 ? filtered : results)
    } else {
      setFilteredResults(results)
    }
  }, [selectedObject, results])

  const fetchResults = async () => {
    setLoading(true)
    setError(null)

    try {
      // Fetch visual search results
      const response = await fetch(`/api/search/visual-results?id=${searchId}`)

      if (!response.ok) {
        throw new Error("Failed to fetch visual search results")
      }

      const data = await response.json()

      setResults(data.results || [])
      setDetectedObjects(data.detectedObjects || [])
      setSearchTerms(data.searchTerms || [])
      setFilteredResults(data.results || [])
    } catch (error) {
      console.error("Error fetching visual search results:", error)
      setError("Failed to load visual search results")

      toast({
        title: "Error",
        description: "Failed to load visual search results",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleObjectClick = (objectName: string) => {
    triggerHaptic("light")
    setSelectedObject((prev) => (prev === objectName ? null : objectName))
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="relative rounded-md overflow-hidden border border-border">
          <Skeleton className="aspect-[3/1] w-full" />
        </div>

        <div className="flex flex-wrap gap-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-6 w-20" />
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="aspect-square w-full" />
              <div className="p-3">
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-4 border border-red-200 rounded-md bg-red-50 text-red-800">
        <p>{error}</p>
        <Button variant="outline" size="sm" className="mt-2" onClick={fetchResults}>
          Try Again
        </Button>
      </div>
    )
  }

  if (results.length === 0) {
    return (
      <div className="p-4 border border-border rounded-md bg-muted/20 text-muted-foreground">
        <p>No results found for this visual search.</p>
        <Button variant="outline" size="sm" className="mt-2" asChild>
          <Link href="/marketplace">Back to Marketplace</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Search terms */}
      <div className="flex flex-wrap gap-2 items-center">
        <Camera className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Search terms:</span>
        {searchTerms.map((term, index) => (
          <Badge key={index} variant="outline">
            {term}
          </Badge>
        ))}
      </div>

      {/* Detected objects as clickable tags */}
      {detectedObjects.length > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Filter by:</span>
          {detectedObjects
            .filter((obj) => obj.score > 0.6)
            .map((obj, index) => (
              <Badge
                key={index}
                variant={selectedObject === obj.name ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => handleObjectClick(obj.name)}
              >
                {obj.name}
              </Badge>
            ))}
        </div>
      )}

      {/* Results grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredResults.map((listing) => (
          <Link
            href={`/listings/${listing.id}`}
            key={listing.id}
            className="bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="aspect-square relative">
              <OptimizedImage
                src={listing.media?.[0]?.url || "/placeholder.svg?height=200&width=200"}
                alt={listing.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
              />
              {listing.featured && (
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                  Featured
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="font-medium text-sm line-clamp-2">{listing.title}</h3>
              <p className="text-primary font-bold mt-1">Rp {listing.price.toLocaleString("id-ID")}</p>
              <div className="flex items-center mt-2 text-xs text-muted-foreground">
                <span>{listing.sellerName}</span>
                <span className="ml-auto flex items-center">★ {listing.rating || "N/A"}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {filteredResults.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No results found for this selection.</p>
          <Button variant="outline" className="mt-4" onClick={() => setSelectedObject(null)}>
            Show all results
          </Button>
        </div>
      )}
    </div>
  )
}
