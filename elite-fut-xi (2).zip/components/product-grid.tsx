"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { OptimizedImage } from "@/components/optimized-image"
import { ProductGridSkeleton } from "@/components/product-grid-skeleton"

interface Listing {
  id: string
  title: string
  price: number
  image: string
  seller: {
    name: string
    rating: number
  }
  category: string
  featured: boolean
}

interface ProductGridProps {
  initialListings?: Listing[]
  category?: string
  searchTerm?: string
}

export function ProductGrid({ initialListings = [], category, searchTerm }: ProductGridProps) {
  const [listings, setListings] = useState<Listing[]>(initialListings)
  const [loading, setLoading] = useState(!initialListings.length)

  // If we don't have initial listings or filters change, fetch on client
  useEffect(() => {
    if (!initialListings.length || category || searchTerm) {
      fetchListings()
    }
  }, [category, searchTerm])

  async function fetchListings() {
    setLoading(true)
    try {
      // Build query params
      const params = new URLSearchParams()
      if (category) params.append("category", category)
      if (searchTerm) params.append("search", searchTerm)

      const response = await fetch(`/api/listings?${params.toString()}`)
      const data = await response.json()
      setListings(data)
    } catch (error) {
      console.error("Error fetching listings:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <ProductGridSkeleton />
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
      {listings.map((listing) => (
        <Link
          href={`/listings/${listing.id}`}
          key={listing.id}
          className="bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
        >
          <div className="aspect-square relative">
            <OptimizedImage
              src={listing.image}
              alt={listing.title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 50vw, 33vw"
            />
            {listing.featured && (
              <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                Featured
              </div>
            )}
          </div>
          <div className="p-3">
            <h3 className="font-medium text-sm line-clamp-2">{listing.title}</h3>
            <p className="text-primary font-bold mt-1">Rp {listing.price.toLocaleString("id-ID")}</p>
            <div className="flex items-center mt-2 text-xs text-muted-foreground">
              <span>{listing.seller.name}</span>
              <span className="ml-auto flex items-center">★ {listing.seller.rating}</span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}
