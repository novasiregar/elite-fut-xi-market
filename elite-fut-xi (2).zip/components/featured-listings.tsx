"use client"

import { useRef, useState, useEffect } from "react"
import { AccountCard } from "@/components/account-card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

// Sample featured data
const FEATURED_ACCOUNTS = [
  {
    id: 101,
    title: "Ultimate Team 94 OVR",
    price: "2,500,000",
    rating: 4.9,
    image: "/placeholder.svg?height=200&width=400",
    video: "/placeholder.svg?height=200&width=400",
    seller: "EliteTrader",
    verified: true,
    tags: ["featured", "trending"],
  },
  {
    id: 102,
    title: "Icon-Packed Squad",
    price: "4,500,000",
    rating: 4.8,
    image: "/placeholder.svg?height=200&width=400",
    video: "/placeholder.svg?height=200&width=400",
    seller: "IconCollector",
    verified: true,
    tags: ["premium", "featured"],
  },
  {
    id: 103,
    title: "All TOTY Players",
    price: "5,000,000",
    rating: 4.9,
    image: "/placeholder.svg?height=200&width=400",
    video: "/placeholder.svg?height=200&width=400",
    seller: "TOTYMaster",
    verified: true,
    tags: ["premium", "featured"],
  },
  {
    id: 104,
    title: "Ronaldo + Messi Account",
    price: "3,200,000",
    rating: 5.0,
    image: "/placeholder.svg?height=200&width=400",
    video: "/placeholder.svg?height=200&width=400",
    seller: "LegendaryAccounts",
    verified: false,
    tags: ["featured", "premium"],
  },
]

export function FeaturedListings() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(true)
  const [activeIndex, setActiveIndex] = useState(0)

  const checkScrollability = () => {
    const container = scrollContainerRef.current
    if (!container) return

    setCanScrollLeft(container.scrollLeft > 0)
    setCanScrollRight(container.scrollLeft < container.scrollWidth - container.clientWidth - 10)
  }

  useEffect(() => {
    const container = scrollContainerRef.current
    if (container) {
      container.addEventListener("scroll", checkScrollability)
      // Initial check
      checkScrollability()
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", checkScrollability)
      }
    }
  }, [])

  const scrollLeft = () => {
    if (!scrollContainerRef.current) return
    scrollContainerRef.current.scrollBy({ left: -300, behavior: "smooth" })
    setActiveIndex((prev) => Math.max(0, prev - 1))
  }

  const scrollRight = () => {
    if (!scrollContainerRef.current) return
    scrollContainerRef.current.scrollBy({ left: 300, behavior: "smooth" })
    setActiveIndex((prev) => Math.min(FEATURED_ACCOUNTS.length - 1, prev + 1))
  }

  return (
    <div className="relative">
      <div
        ref={scrollContainerRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-4"
        style={{ scrollSnapType: "x mandatory" }}
      >
        {FEATURED_ACCOUNTS.map((account, index) => (
          <div key={account.id} className="min-w-[280px] w-[280px] snap-center" style={{ scrollSnapAlign: "center" }}>
            <AccountCard account={account} />
          </div>
        ))}
      </div>

      <div className="absolute -bottom-2 left-0 right-0 flex justify-center gap-1 mt-2">
        {FEATURED_ACCOUNTS.map((_, index) => (
          <div
            key={index}
            className={cn(
              "w-2 h-2 rounded-full transition-all duration-300",
              activeIndex === index ? "bg-primary w-4" : "bg-muted",
            )}
          />
        ))}
      </div>

      {canScrollLeft && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-0 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8"
          onClick={scrollLeft}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
      )}

      {canScrollRight && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-0 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8"
          onClick={scrollRight}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      )}
    </div>
  )
}
