"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sparkles, Rocket, TrendingUp, Plus, Edit, Trash } from "lucide-react"

export function AdminPromotionManagement() {
  const [activeTab, setActiveTab] = useState("active")

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Promotion Management</CardTitle>
          <CardDescription>Manage featured listings, campaigns, and promotional offers</CardDescription>
        </div>
        <Button size="sm">
          <Plus className="mr-2 h-4 w-4" />
          New Promotion
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
            <TabsTrigger value="expired">Expired</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            <PromotionItem
              icon={<Sparkles className="h-4 w-4" />}
              title="Featured Listings Bundle"
              type="Featured"
              status="Active"
              startDate="2023-05-01"
              endDate="2023-05-31"
              listings={12}
            />
            <PromotionItem
              icon={<Rocket className="h-4 w-4" />}
              title="Summer Sale Campaign"
              type="Campaign"
              status="Active"
              startDate="2023-05-15"
              endDate="2023-06-15"
              listings={24}
            />
          </TabsContent>

          <TabsContent value="scheduled" className="space-y-4">
            <PromotionItem
              icon={<TrendingUp className="h-4 w-4" />}
              title="Weekend Flash Sale"
              type="Flash Sale"
              status="Scheduled"
              startDate="2023-05-20"
              endDate="2023-05-22"
              listings={8}
            />
          </TabsContent>

          <TabsContent value="expired" className="space-y-4">
            <PromotionItem
              icon={<Sparkles className="h-4 w-4" />}
              title="Spring Collection"
              type="Featured"
              status="Expired"
              startDate="2023-04-01"
              endDate="2023-04-30"
              listings={15}
            />
          </TabsContent>

          <TabsContent value="templates" className="space-y-4">
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="template-name">Template Name</Label>
                  <Input id="template-name" placeholder="Enter template name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="promotion-type">Promotion Type</Label>
                  <Select defaultValue="featured">
                    <SelectTrigger id="promotion-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="featured">Featured Listing</SelectItem>
                      <SelectItem value="campaign">Campaign</SelectItem>
                      <SelectItem value="flash">Flash Sale</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button>Save Template</Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function PromotionItem({ icon, title, type, status, startDate, endDate, listings }) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">{icon}</div>
        <div>
          <p className="font-medium">{title}</p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>
              {startDate} to {endDate}
            </span>
            <span>•</span>
            <span>{listings} listings</span>
          </div>
          <div className="flex gap-2 mt-1">
            <Badge variant="outline">{type}</Badge>
            <Badge
              variant="outline"
              className={
                status === "Active"
                  ? "text-green-500"
                  : status === "Scheduled"
                    ? "text-blue-500"
                    : "text-muted-foreground"
              }
            >
              {status}
            </Badge>
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <Edit className="h-4 w-4" />
          <span className="sr-only">Edit</span>
        </Button>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-destructive">
          <Trash className="h-4 w-4" />
          <span className="sr-only">Delete</span>
        </Button>
      </div>
    </div>
  )
}
