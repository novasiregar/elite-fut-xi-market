"use client"

import { useState, useEffect } from "react"
import { Users, ShoppingBag, CreditCard, TrendingUp, TrendingDown, DollarSign } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Skeleton } from "@/components/ui/skeleton"

// Mock data for demonstration
const mockData = {
  userGrowth: [
    { date: "Jan", users: 120 },
    { date: "Feb", users: 150 },
    { date: "Mar", users: 190 },
    { date: "Apr", users: 250 },
    { date: "May", users: 320 },
    { date: "Jun", users: 390 },
    { date: "Jul", users: 450 },
  ],
  transactionVolume: [
    { date: "Jan", volume: 5200 },
    { date: "Feb", volume: 6100 },
    { date: "Mar", volume: 8500 },
    { date: "Apr", volume: 9200 },
    { date: "May", volume: 12000 },
    { date: "Jun", volume: 13500 },
    { date: "Jul", volume: 15000 },
  ],
  listingGrowth: [
    { date: "Jan", listings: 320 },
    { date: "Feb", listings: 380 },
    { date: "Mar", listings: 450 },
    { date: "Apr", listings: 520 },
    { date: "May", listings: 590 },
    { date: "Jun", listings: 670 },
    { date: "Jul", listings: 750 },
  ],
  revenueGrowth: [
    { date: "Jan", revenue: 1200 },
    { date: "Feb", revenue: 1500 },
    { date: "Mar", revenue: 1800 },
    { date: "Apr", revenue: 2200 },
    { date: "May", revenue: 2600 },
    { date: "Jun", revenue: 3100 },
    { date: "Jul", revenue: 3500 },
  ],
}

interface AdminMetricsOverviewProps {
  detailed?: boolean
}

export function AdminMetricsOverview({ detailed = false }: AdminMetricsOverviewProps) {
  const [loading, setLoading] = useState(true)
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    activeListings: 0,
    totalTransactions: 0,
    totalRevenue: 0,
    userGrowth: 0,
    listingGrowth: 0,
    transactionGrowth: 0,
    revenueGrowth: 0,
  })

  useEffect(() => {
    // Simulate API call to fetch metrics
    const fetchMetrics = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setMetrics({
          totalUsers: 4521,
          activeListings: 2876,
          totalTransactions: 18432,
          totalRevenue: 253890,
          userGrowth: 12.5,
          listingGrowth: 8.3,
          transactionGrowth: 15.7,
          revenueGrowth: 18.2,
        })

        setLoading(false)
      } catch (error) {
        console.error("Error fetching metrics:", error)
        setLoading(false)
      }
    }

    fetchMetrics()
  }, [])

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card className="border border-green-500/20 bg-green-500/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          <Users className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-8 w-[100px]" />
          ) : (
            <>
              <div className="text-2xl font-bold">{metrics.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                {metrics.userGrowth > 0 ? (
                  <>
                    <TrendingUp className="h-3 w-3 text-green-500" />
                    <span className="text-green-500">+{metrics.userGrowth}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 text-red-500" />
                    <span className="text-red-500">{metrics.userGrowth}%</span>
                  </>
                )}
                <span>from last month</span>
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border border-blue-500/20 bg-blue-500/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
          <ShoppingBag className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-8 w-[100px]" />
          ) : (
            <>
              <div className="text-2xl font-bold">{metrics.activeListings.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                {metrics.listingGrowth > 0 ? (
                  <>
                    <TrendingUp className="h-3 w-3 text-green-500" />
                    <span className="text-green-500">+{metrics.listingGrowth}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 text-red-500" />
                    <span className="text-red-500">{metrics.listingGrowth}%</span>
                  </>
                )}
                <span>from last month</span>
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border border-purple-500/20 bg-purple-500/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
          <CreditCard className="h-4 w-4 text-purple-500" />
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-8 w-[100px]" />
          ) : (
            <>
              <div className="text-2xl font-bold">{metrics.totalTransactions.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                {metrics.transactionGrowth > 0 ? (
                  <>
                    <TrendingUp className="h-3 w-3 text-green-500" />
                    <span className="text-green-500">+{metrics.transactionGrowth}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 text-red-500" />
                    <span className="text-red-500">{metrics.transactionGrowth}%</span>
                  </>
                )}
                <span>from last month</span>
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border border-yellow-500/20 bg-yellow-500/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          <DollarSign className="h-4 w-4 text-yellow-500" />
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-8 w-[100px]" />
          ) : (
            <>
              <div className="text-2xl font-bold">${metrics.totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                {metrics.revenueGrowth > 0 ? (
                  <>
                    <TrendingUp className="h-3 w-3 text-green-500" />
                    <span className="text-green-500">+{metrics.revenueGrowth}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 text-red-500" />
                    <span className="text-red-500">{metrics.revenueGrowth}%</span>
                  </>
                )}
                <span>from last month</span>
              </p>
            </>
          )}
        </CardContent>
      </Card>

      {detailed && (
        <>
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>New user registrations over time</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <ChartContainer
                  config={{
                    users: {
                      label: "Users",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-[200px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.userGrowth}>
                      <XAxis dataKey="date" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="users"
                        stroke="var(--color-users)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Transaction Volume</CardTitle>
              <CardDescription>Total transaction volume over time</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <ChartContainer
                  config={{
                    volume: {
                      label: "Volume",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                  className="h-[200px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.transactionVolume}>
                      <XAxis dataKey="date" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="volume"
                        stroke="var(--color-volume)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Listing Growth</CardTitle>
              <CardDescription>Active listings over time</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <ChartContainer
                  config={{
                    listings: {
                      label: "Listings",
                      color: "hsl(var(--chart-3))",
                    },
                  }}
                  className="h-[200px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.listingGrowth}>
                      <XAxis dataKey="date" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="listings"
                        stroke="var(--color-listings)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Revenue Growth</CardTitle>
              <CardDescription>Platform revenue over time</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <ChartContainer
                  config={{
                    revenue: {
                      label: "Revenue",
                      color: "hsl(var(--chart-4))",
                    },
                  }}
                  className="h-[200px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockData.revenueGrowth}>
                      <XAxis dataKey="date" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="revenue"
                        stroke="var(--color-revenue)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
