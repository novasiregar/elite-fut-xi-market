"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Flag, MessageSquare, ShoppingBag, User, Check, X } from "lucide-react"

export function AdminFlaggedContent() {
  const [activeTab, setActiveTab] = useState("listings")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Flagged Content</CardTitle>
        <CardDescription>Review and moderate content that has been reported by users</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="listings">Listings</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="listings" className="space-y-4">
            <FlaggedItem
              icon={<ShoppingBag className="h-4 w-4" />}
              title="FIFA 25 Ultimate Team Account"
              reportedBy="user123"
              reason="Fraudulent listing"
              date="2023-05-15"
            />
            <FlaggedItem
              icon={<ShoppingBag className="h-4 w-4" />}
              title="eFootball 2025 Legend Account"
              reportedBy="user456"
              reason="Prohibited content"
              date="2023-05-14"
            />
          </TabsContent>

          <TabsContent value="messages" className="space-y-4">
            <FlaggedItem
              icon={<MessageSquare className="h-4 w-4" />}
              title="Message from user789"
              reportedBy="user321"
              reason="Harassment"
              date="2023-05-13"
            />
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <FlaggedItem
              icon={<User className="h-4 w-4" />}
              title="user567"
              reportedBy="user890"
              reason="Suspicious activity"
              date="2023-05-12"
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function FlaggedItem({ icon, title, reportedBy, reason, date }) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
          {icon || <Flag className="h-4 w-4" />}
        </div>
        <div>
          <p className="font-medium">{title}</p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Reported by: {reportedBy}</span>
            <span>•</span>
            <span>{date}</span>
          </div>
          <Badge variant="outline" className="mt-1">
            {reason}
          </Badge>
        </div>
      </div>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <Check className="h-4 w-4" />
          <span className="sr-only">Approve</span>
        </Button>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-destructive">
          <X className="h-4 w-4" />
          <span className="sr-only">Reject</span>
        </Button>
      </div>
    </div>
  )
}
