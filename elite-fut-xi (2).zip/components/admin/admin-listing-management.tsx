"use client"

import { useState, useEffect } from "react"
import {
  Check,
  X,
  MoreHorizontal,
  Search,
  Download,
  Eye,
  Edit,
  Trash2,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { ProgressiveImage } from "@/components/progressive-image"

// Mock data for demonstration
const mockListings = [
  {
    id: "1",
    title: "Ronaldo 94 OVR Card",
    price: 1250000,
    seller: "Alex Johnson",
    sellerId: "1",
    status: "active",
    featured: false,
    verified: true,
    category: "Players",
    createdAt: "2023-06-15",
    views: 1245,
    likes: 87,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "2",
    title: "Messi 96 OVR Card",
    price: 2500000,
    seller: "Sarah Williams",
    sellerId: "2",
    status: "active",
    featured: true,
    verified: true,
    category: "Players",
    createdAt: "2023-06-22",
    views: 3421,
    likes: 245,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "3",
    title: "Rare Gold Pack Bundle",
    price: 500000,
    seller: "James Wilson",
    sellerId: "5",
    status: "active",
    featured: false,
    verified: true,
    category: "Packs",
    createdAt: "2023-07-01",
    views: 876,
    likes: 42,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "4",
    title: "Haaland 92 OVR Card",
    price: 980000,
    seller: "Sarah Williams",
    sellerId: "2",
    status: "pending",
    featured: false,
    verified: false,
    category: "Players",
    createdAt: "2023-07-10",
    views: 532,
    likes: 28,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "5",
    title: "Ultimate Team Coins - 1M",
    price: 150000,
    seller: "James Wilson",
    sellerId: "5",
    status: "flagged",
    featured: false,
    verified: false,
    category: "Coins",
    createdAt: "2023-07-15",
    views: 1023,
    likes: 15,
    image: "/placeholder.svg?height=80&width=80",
  },
]

export function AdminListingManagement() {
  const [loading, setLoading] = useState(true)
  const [listings, setListings] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [viewListingId, setViewListingId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate API call to fetch listings
    const fetchListings = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setListings(mockListings)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching listings:", error)
        setLoading(false)
      }
    }

    fetchListings()
  }, [])

  const filteredListings = listings.filter((listing) => {
    const matchesSearch =
      listing.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      listing.seller.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || listing.status === statusFilter
    const matchesCategory = categoryFilter === "all" || listing.category === categoryFilter

    return matchesSearch && matchesStatus && matchesCategory
  })

  const handleStatusChange = (listingId: string, newStatus: string) => {
    setListings(listings.map((listing) => (listing.id === listingId ? { ...listing, status: newStatus } : listing)))

    toast({
      title: "Listing Status Updated",
      description: `Listing status has been changed to ${newStatus}.`,
    })
  }

  const handleFeatureToggle = (listingId: string) => {
    setListings(
      listings.map((listing) => (listing.id === listingId ? { ...listing, featured: !listing.featured } : listing)),
    )

    const listing = listings.find((l) => l.id === listingId)
    const newFeaturedStatus = !listing.featured

    toast({
      title: newFeaturedStatus ? "Listing Featured" : "Listing Unfeatured",
      description: newFeaturedStatus
        ? "Listing has been added to featured listings."
        : "Listing has been removed from featured listings.",
    })
  }

  const handleVerifyToggle = (listingId: string) => {
    setListings(
      listings.map((listing) => (listing.id === listingId ? { ...listing, verified: !listing.verified } : listing)),
    )

    const listing = listings.find((l) => l.id === listingId)
    const newVerifiedStatus = !listing.verified

    toast({
      title: newVerifiedStatus ? "Listing Verified" : "Listing Unverified",
      description: newVerifiedStatus
        ? "Listing has been marked as verified."
        : "Listing verification has been removed.",
    })
  }

  const handleDeleteListing = (listingId: string) => {
    setListings(listings.filter((listing) => listing.id !== listingId))

    toast({
      title: "Listing Deleted",
      description: "The listing has been permanently deleted.",
      variant: "destructive",
    })
  }

  const handleExportListings = () => {
    // In a real app, this would generate a CSV or Excel file
    toast({
      title: "Export Started",
      description: "Listing data export has been initiated.",
    })
  }

  const viewingListing = viewListingId ? listings.find((l) => l.id === viewListingId) : null

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-[300px]">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search listings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="flagged">Flagged</SelectItem>
              <SelectItem value="sold">Sold</SelectItem>
            </SelectContent>
          </Select>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="Players">Players</SelectItem>
              <SelectItem value="Packs">Packs</SelectItem>
              <SelectItem value="Coins">Coins</SelectItem>
              <SelectItem value="Accounts">Accounts</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button variant="outline" onClick={handleExportListings} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Listing</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Seller</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Featured</TableHead>
              <TableHead>Verified</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Stats</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array(5)
                .fill(0)
                .map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-6 w-[200px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[50px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[50px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                  </TableRow>
                ))
            ) : filteredListings.length > 0 ? (
              filteredListings.map((listing) => (
                <TableRow key={listing.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="h-10 w-10 rounded overflow-hidden">
                        <ProgressiveImage
                          src={listing.image}
                          alt={listing.title}
                          width={40}
                          height={40}
                          className="h-10 w-10 object-cover"
                        />
                      </div>
                      <span className="font-medium">{listing.title}</span>
                    </div>
                  </TableCell>
                  <TableCell>{listing.price.toLocaleString()} coins</TableCell>
                  <TableCell>{listing.seller}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        listing.status === "active"
                          ? "default"
                          : listing.status === "pending"
                            ? "secondary"
                            : listing.status === "flagged"
                              ? "destructive"
                              : "outline"
                      }
                    >
                      {listing.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleFeatureToggle(listing.id)}
                      className={listing.featured ? "text-yellow-500" : "text-muted-foreground"}
                    >
                      {listing.featured ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                    </Button>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleVerifyToggle(listing.id)}
                      className={listing.verified ? "text-green-500" : "text-muted-foreground"}
                    >
                      {listing.verified ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                    </Button>
                  </TableCell>
                  <TableCell>{new Date(listing.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="flex flex-col text-xs">
                      <span>{listing.views} views</span>
                      <span>{listing.likes} likes</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setViewListingId(listing.id)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Listing
                        </DropdownMenuItem>
                        {listing.status !== "flagged" ? (
                          <DropdownMenuItem onClick={() => handleStatusChange(listing.id, "flagged")}>
                            <ShieldAlert className="h-4 w-4 mr-2" />
                            Flag Listing
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={() => handleStatusChange(listing.id, "active")}>
                            <ShieldCheck className="h-4 w-4 mr-2" />
                            Approve Listing
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteListing(listing.id)}>
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Listing
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-4">
                  No listings found matching your filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {viewingListing && (
        <Dialog open={!!viewListingId} onOpenChange={(open) => !open && setViewListingId(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Listing Details</DialogTitle>
              <DialogDescription>Detailed information about the selected listing.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
              <div>
                <div className="rounded-md overflow-hidden mb-4">
                  <ProgressiveImage
                    src={viewingListing.image}
                    alt={viewingListing.title}
                    width={400}
                    height={300}
                    className="w-full h-auto object-cover"
                  />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">{viewingListing.title}</h3>
                  <p className="text-2xl font-semibold">{viewingListing.price.toLocaleString()} coins</p>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        viewingListing.status === "active"
                          ? "default"
                          : viewingListing.status === "pending"
                            ? "secondary"
                            : viewingListing.status === "flagged"
                              ? "destructive"
                              : "outline"
                      }
                    >
                      {viewingListing.status}
                    </Badge>
                    {viewingListing.featured && (
                      <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                        Featured
                      </Badge>
                    )}
                    {viewingListing.verified && (
                      <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                        Verified
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Seller Information</h4>
                  <p className="font-medium">{viewingListing.seller}</p>
                  <p className="text-sm text-muted-foreground">ID: {viewingListing.sellerId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Listing Details</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Category:</p>
                      <p>{viewingListing.category}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Created:</p>
                      <p>{new Date(viewingListing.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Views:</p>
                      <p>{viewingListing.views}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Likes:</p>
                      <p>{viewingListing.likes}</p>
                    </div>
                  </div>
                </div>
                <div className="pt-4">
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Admin Actions</h4>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={viewingListing.status === "active" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        handleStatusChange(viewingListing.id, "active")
                        setViewListingId(null)
                      }}
                    >
                      <Check className="h-4 w-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      variant={viewingListing.status === "flagged" ? "destructive" : "outline"}
                      size="sm"
                      onClick={() => {
                        handleStatusChange(viewingListing.id, "flagged")
                        setViewListingId(null)
                      }}
                    >
                      <ShieldAlert className="h-4 w-4 mr-2" />
                      Flag
                    </Button>
                    <Button
                      variant={viewingListing.featured ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        handleFeatureToggle(viewingListing.id)
                        setViewListingId(null)
                      }}
                    >
                      <TrendingUp className="h-4 w-4 mr-2" />
                      {viewingListing.featured ? "Unfeature" : "Feature"}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        handleDeleteListing(viewingListing.id)
                        setViewListingId(null)
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
