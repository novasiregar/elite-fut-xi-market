"use client"

import { useState, useEffect } from "react"
import { Save, RefreshCw, Bell, Shield, DollarSign, Percent, Clock, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/utils/haptic"

// Mock data for demonstration
const mockSettings = {
  general: {
    siteName: "ELITE FUT XI Market",
    siteDescription: "The premier marketplace for FIFA Ultimate Team trading",
    maintenanceMode: false,
    allowRegistration: true,
    allowListingCreation: true,
    requireEmailVerification: true,
  },
  fees: {
    transactionFeePercentage: 5,
    minimumTransactionFee: 5000,
    featuredListingFee: 50000,
    promotionBaseFee: 100000,
  },
  security: {
    maxLoginAttempts: 5,
    passwordExpiryDays: 90,
    sessionTimeoutMinutes: 60,
    twoFactorAuthRequired: false,
    requireIdVerificationForSellers: true,
  },
  notifications: {
    systemNotificationsEnabled: true,
    emailNotificationsEnabled: true,
    pushNotificationsEnabled: true,
    transactionNotificationsEnabled: true,
    marketingNotificationsEnabled: true,
    systemNotificationMessage:
      "Welcome to ELITE FUT XI Market! The premier marketplace for FIFA Ultimate Team trading.",
  },
}

export function AdminSettings() {
  const [loading, setLoading] = useState(true)
  const [settings, setSettings] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("general")
  const { toast } = useToast()

  useEffect(() => {
    // Simulate API call to fetch settings
    const fetchSettings = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setSettings(mockSettings)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching settings:", error)
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  const handleSaveSettings = () => {
    // In a real app, this would be an API call to save settings
    toast({
      title: "Settings Saved",
      description: "Your changes have been successfully saved.",
    })

    triggerHaptic("success")
  }

  const handleResetSettings = () => {
    // In a real app, this would reset settings to defaults
    setSettings(mockSettings)

    toast({
      title: "Settings Reset",
      description: "Settings have been reset to default values.",
    })

    triggerHaptic("medium")
  }

  const handleSettingChange = (category: string, setting: string, value: any) => {
    setSettings({
      ...settings,
      [category]: {
        ...settings[category],
        [setting]: value,
      },
    })

    triggerHaptic("light")
  }

  if (loading || !settings) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-[200px]" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Skeleton className="h-[300px] rounded-md" />
          <Skeleton className="h-[300px] rounded-md" />
          <Skeleton className="h-[300px] rounded-md" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Platform Settings</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleResetSettings} className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            Reset
          </Button>
          <Button onClick={handleSaveSettings} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Changes
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="fees" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Fees
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Manage basic platform settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    value={settings.general.siteName}
                    onChange={(e) => handleSettingChange("general", "siteName", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="siteDescription">Site Description</Label>
                  <Input
                    id="siteDescription"
                    value={settings.general.siteDescription}
                    onChange={(e) => handleSettingChange("general", "siteDescription", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="maintenanceMode" className="block">
                      Maintenance Mode
                    </Label>
                    <p className="text-sm text-muted-foreground">Take the platform offline for maintenance</p>
                  </div>
                  <Switch
                    id="maintenanceMode"
                    checked={settings.general.maintenanceMode}
                    onCheckedChange={(checked) => handleSettingChange("general", "maintenanceMode", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="allowRegistration" className="block">
                      Allow Registration
                    </Label>
                    <p className="text-sm text-muted-foreground">Allow new users to register on the platform</p>
                  </div>
                  <Switch
                    id="allowRegistration"
                    checked={settings.general.allowRegistration}
                    onCheckedChange={(checked) => handleSettingChange("general", "allowRegistration", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="allowListingCreation" className="block">
                      Allow Listing Creation
                    </Label>
                    <p className="text-sm text-muted-foreground">Allow users to create new listings</p>
                  </div>
                  <Switch
                    id="allowListingCreation"
                    checked={settings.general.allowListingCreation}
                    onCheckedChange={(checked) => handleSettingChange("general", "allowListingCreation", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="requireEmailVerification" className="block">
                      Require Email Verification
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Require users to verify their email before using the platform
                    </p>
                  </div>
                  <Switch
                    id="requireEmailVerification"
                    checked={settings.general.requireEmailVerification}
                    onCheckedChange={(checked) => handleSettingChange("general", "requireEmailVerification", checked)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={() => {
                  handleSaveSettings()
                  triggerHaptic("success")
                }}
              >
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="fees" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Fee Settings</CardTitle>
              <CardDescription>Manage platform fees and charges</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="transactionFeePercentage" className="flex items-center gap-1">
                    Transaction Fee Percentage
                    <Percent className="h-4 w-4" />
                  </Label>
                  <div className="flex items-center">
                    <Input
                      id="transactionFeePercentage"
                      type="number"
                      min="0"
                      max="100"
                      value={settings.fees.transactionFeePercentage}
                      onChange={(e) => handleSettingChange("fees", "transactionFeePercentage", Number(e.target.value))}
                    />
                    <span className="ml-2">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="minimumTransactionFee" className="flex items-center gap-1">
                    Minimum Transaction Fee
                    <DollarSign className="h-4 w-4" />
                  </Label>
                  <Input
                    id="minimumTransactionFee"
                    type="number"
                    min="0"
                    value={settings.fees.minimumTransactionFee}
                    onChange={(e) => handleSettingChange("fees", "minimumTransactionFee", Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="featuredListingFee" className="flex items-center gap-1">
                    Featured Listing Fee
                    <DollarSign className="h-4 w-4" />
                  </Label>
                  <Input
                    id="featuredListingFee"
                    type="number"
                    min="0"
                    value={settings.fees.featuredListingFee}
                    onChange={(e) => handleSettingChange("fees", "featuredListingFee", Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="promotionBaseFee" className="flex items-center gap-1">
                    Promotion Base Fee
                    <DollarSign className="h-4 w-4" />
                  </Label>
                  <Input
                    id="promotionBaseFee"
                    type="number"
                    min="0"
                    value={settings.fees.promotionBaseFee}
                    onChange={(e) => handleSettingChange("fees", "promotionBaseFee", Number(e.target.value))}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={() => {
                  handleSaveSettings()
                  triggerHaptic("success")
                }}
              >
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Manage platform security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="maxLoginAttempts" className="flex items-center gap-1">
                    Max Login Attempts
                    <Users className="h-4 w-4" />
                  </Label>
                  <Input
                    id="maxLoginAttempts"
                    type="number"
                    min="1"
                    value={settings.security.maxLoginAttempts}
                    onChange={(e) => handleSettingChange("security", "maxLoginAttempts", Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="passwordExpiryDays" className="flex items-center gap-1">
                    Password Expiry (Days)
                    <Clock className="h-4 w-4" />
                  </Label>
                  <Input
                    id="passwordExpiryDays"
                    type="number"
                    min="0"
                    value={settings.security.passwordExpiryDays}
                    onChange={(e) => handleSettingChange("security", "passwordExpiryDays", Number(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sessionTimeoutMinutes" className="flex items-center gap-1">
                    Session Timeout (Minutes)
                    <Clock className="h-4 w-4" />
                  </Label>
                  <Input
                    id="sessionTimeoutMinutes"
                    type="number"
                    min="1"
                    value={settings.security.sessionTimeoutMinutes}
                    onChange={(e) => handleSettingChange("security", "sessionTimeoutMinutes", Number(e.target.value))}
                  />
                </div>
              </div>

              <div className="space-y-4 mt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="twoFactorAuthRequired" className="block">
                      Require Two-Factor Authentication
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Require all users to set up two-factor authentication
                    </p>
                  </div>
                  <Switch
                    id="twoFactorAuthRequired"
                    checked={settings.security.twoFactorAuthRequired}
                    onCheckedChange={(checked) => handleSettingChange("security", "twoFactorAuthRequired", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="requireIdVerificationForSellers" className="block">
                      Require ID Verification for Sellers
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Require sellers to verify their identity before listing items
                    </p>
                  </div>
                  <Switch
                    id="requireIdVerificationForSellers"
                    checked={settings.security.requireIdVerificationForSellers}
                    onCheckedChange={(checked) =>
                      handleSettingChange("security", "requireIdVerificationForSellers", checked)
                    }
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={() => {
                  handleSaveSettings()
                  triggerHaptic("success")
                }}
              >
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Manage platform notification settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="systemNotificationsEnabled" className="block">
                      System Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">Enable system-wide notifications</p>
                  </div>
                  <Switch
                    id="systemNotificationsEnabled"
                    checked={settings.notifications.systemNotificationsEnabled}
                    onCheckedChange={(checked) =>
                      handleSettingChange("notifications", "systemNotificationsEnabled", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="emailNotificationsEnabled" className="block">
                      Email Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">Enable email notifications</p>
                  </div>
                  <Switch
                    id="emailNotificationsEnabled"
                    checked={settings.notifications.emailNotificationsEnabled}
                    onCheckedChange={(checked) =>
                      handleSettingChange("notifications", "emailNotificationsEnabled", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="pushNotificationsEnabled" className="block">
                      Push Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">Enable push notifications</p>
                  </div>
                  <Switch
                    id="pushNotificationsEnabled"
                    checked={settings.notifications.pushNotificationsEnabled}
                    onCheckedChange={(checked) =>
                      handleSettingChange("notifications", "pushNotificationsEnabled", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="transactionNotificationsEnabled" className="block">
                      Transaction Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">Send notifications for transaction updates</p>
                  </div>
                  <Switch
                    id="transactionNotificationsEnabled"
                    checked={settings.notifications.transactionNotificationsEnabled}
                    onCheckedChange={(checked) =>
                      handleSettingChange("notifications", "transactionNotificationsEnabled", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="marketingNotificationsEnabled" className="block">
                      Marketing Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">Send marketing and promotional notifications</p>
                  </div>
                  <Switch
                    id="marketingNotificationsEnabled"
                    checked={settings.notifications.marketingNotificationsEnabled}
                    onCheckedChange={(checked) =>
                      handleSettingChange("notifications", "marketingNotificationsEnabled", checked)
                    }
                  />
                </div>
              </div>

              <div className="space-y-2 mt-4">
                <Label htmlFor="systemNotificationMessage">System Notification Message</Label>
                <Textarea
                  id="systemNotificationMessage"
                  value={settings.notifications.systemNotificationMessage}
                  onChange={(e) => handleSettingChange("notifications", "systemNotificationMessage", e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={() => {
                  handleSaveSettings()
                  triggerHaptic("success")
                }}
              >
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
