"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { api } from "@/client/services/auth"
import { PixelLoading } from "@/components/pixel-loading"
import { DisputeStatus } from "@/server/services/dispute-service"

export function AdminDashboard() {
  const [isLoading, setIsLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("7")
  const [platformStats, setPlatformStats] = useState<any>(null)
  const [userStats, setUserStats] = useState<any>(null)
  const [listingStats, setListingStats] = useState<any>(null)
  const [transactionStats, setTransactionStats] = useState<any>(null)
  const [disputeStats, setDisputeStats] = useState<any>(null)
  const [revenueData, setRevenueData] = useState<any[]>([])
  const [openDisputes, setOpenDisputes] = useState<any[]>([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Fetch platform stats
        const platformResponse = await api.get(`/admin/stats/platform?days=${timeRange}`)
        setPlatformStats(platformResponse.data)

        // Fetch user stats
        const userResponse = await api.get(`/admin/stats/users?days=${timeRange}`)
        setUserStats(userResponse.data)

        // Fetch listing stats
        const listingResponse = await api.get(`/admin/stats/listings?days=${timeRange}`)
        setListingStats(listingResponse.data)

        // Fetch transaction stats
        const transactionResponse = await api.get(`/admin/stats/transactions?days=${timeRange}`)
        setTransactionStats(transactionResponse.data)

        // Fetch dispute stats
        const disputeResponse = await api.get(`/admin/stats/disputes`)
        setDisputeStats(disputeResponse.data)

        // Fetch revenue data
        const revenueResponse = await api.get(`/admin/stats/revenue?days=${timeRange}`)
        setRevenueData(revenueResponse.data.revenue)

        // Fetch open disputes
        const disputesResponse = await api.get(`/admin/disputes/open?limit=5`)
        setOpenDisputes(disputesResponse.data.disputes)
      } catch (error) {
        console.error("Error fetching admin data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [timeRange])

  if (isLoading) {
    return <PixelLoading text="Loading admin dashboard..." />
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <div className="mb-6">
        <Tabs defaultValue="7" onValueChange={setTimeRange}>
          <TabsList>
            <TabsTrigger value="1">Last 24 Hours</TabsTrigger>
            <TabsTrigger value="7">Last 7 Days</TabsTrigger>
            <TabsTrigger value="30">Last 30 Days</TabsTrigger>
            <TabsTrigger value="90">Last 90 Days</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${platformStats?.totalRevenue.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">
              {platformStats?.revenueGrowth > 0 ? "+" : ""}
              {platformStats?.revenueGrowth.toFixed(1)}% from previous period
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{userStats?.activeUsers.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">
              {userStats?.userGrowth > 0 ? "+" : ""}
              {userStats?.userGrowth.toFixed(1)}% from previous period
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{transactionStats?.totalTransactions.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">
              ${transactionStats?.averageValue.toLocaleString()} avg. value
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Active Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{listingStats?.activeListings.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">{listingStats?.newListings.toLocaleString()} new listings</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Daily revenue over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ChartContainer
                config={{
                  revenue: {
                    label: "Revenue",
                    color: "hsl(var(--chart-1))",
                  },
                  transactions: {
                    label: "Transactions",
                    color: "hsl(var(--chart-2))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={revenueData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="left" orientation="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="revenue"
                      stroke="var(--color-revenue)"
                      name="Revenue"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="transactions"
                      stroke="var(--color-transactions)"
                      name="Transactions"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Disputes by Reason</CardTitle>
            <CardDescription>Distribution of dispute reasons</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={Object.entries(disputeStats?.disputesByReason || {}).map(([key, value]) => ({
                      name: key,
                      value,
                    }))}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => {
                      const readableName = name
                        .split("_")
                        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                        .join(" ")
                      return `${readableName}: ${(percent * 100).toFixed(0)}%`
                    }}
                  >
                    {Object.keys(disputeStats?.disputesByReason || {}).map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Open Disputes</CardTitle>
            <CardDescription>Disputes requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            {openDisputes.length === 0 ? (
              <p className="text-center py-4">No open disputes</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">ID</th>
                      <th className="text-left py-2">Reason</th>
                      <th className="text-left py-2">Status</th>
                      <th className="text-left py-2">Created</th>
                      <th className="text-left py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {openDisputes.map((dispute) => (
                      <tr key={dispute.id} className="border-b">
                        <td className="py-2">{dispute.id.substring(0, 8)}...</td>
                        <td className="py-2">
                          {dispute.reason
                            .split("_")
                            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                            .join(" ")}
                        </td>
                        <td className="py-2">
                          <Badge variant={dispute.status === DisputeStatus.OPEN ? "default" : "secondary"}>
                            {dispute.status}
                          </Badge>
                        </td>
                        <td className="py-2">{new Date(dispute.createdAt).toLocaleDateString()}</td>
                        <td className="py-2">
                          <Button size="sm" variant="outline">
                            Review
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
