"use client"

import { useState, useEffect } from "react"
import { MoreHorizontal, Search, Flag, CheckCircle, XCircle, Eye, MessageSquare, User, ShoppingBag } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/utils/haptic"

// Mock data for demonstration
const mockReports = [
  {
    id: "R12345",
    reporterId: "1",
    reporter: "Alex Johnson",
    reportedItemType: "listing",
    reportedItemId: "5",
    reportedItemTitle: "Ultimate Team Coins - 1M",
    reportedUserId: "5",
    reportedUser: "James Wilson",
    reason: "Fraudulent listing",
    description: "This listing is offering coins at a suspiciously low price and may be a scam.",
    status: "pending",
    createdAt: "2023-07-15T14:30:00Z",
    resolvedAt: null,
    resolvedBy: null,
    resolution: null,
  },
  {
    id: "R12346",
    reporterId: "3",
    reporter: "Michael Brown",
    reportedItemType: "user",
    reportedItemId: "4",
    reportedItemTitle: null,
    reportedUserId: "4",
    reportedUser: "Emily Davis",
    reason: "Harassment",
    description: "This user has been sending threatening messages after a failed transaction.",
    status: "resolved",
    createdAt: "2023-07-10T09:15:00Z",
    resolvedAt: "2023-07-11T11:30:00Z",
    resolvedBy: "admin1",
    resolution: "User warned and messages deleted",
  },
  {
    id: "R12347",
    reporterId: "2",
    reporter: "Sarah Williams",
    reportedItemType: "message",
    reportedItemId: "M5432",
    reportedItemTitle: null,
    reportedUserId: "5",
    reportedUser: "James Wilson",
    reason: "Inappropriate content",
    description: "User sent messages containing offensive language and inappropriate offers.",
    status: "pending",
    createdAt: "2023-07-16T16:45:00Z",
    resolvedAt: null,
    resolvedBy: null,
    resolution: null,
  },
  {
    id: "R12348",
    reporterId: "5",
    reporter: "James Wilson",
    reportedItemType: "listing",
    reportedItemId: "3",
    reportedItemTitle: "Rare Gold Pack Bundle",
    reportedUserId: "5",
    reportedUser: "James Wilson",
    reason: "Counterfeit item",
    description: "This listing is offering counterfeit packs that don't match the official game content.",
    status: "investigating",
    createdAt: "2023-07-17T13:20:00Z",
    resolvedAt: null,
    resolvedBy: null,
    resolution: null,
  },
  {
    id: "R12349",
    reporterId: "4",
    reporter: "Emily Davis",
    reportedItemType: "transaction",
    reportedItemId: "TX123459",
    reportedItemTitle: null,
    reportedUserId: "5",
    reportedUser: "James Wilson",
    reason: "Failed delivery",
    description: "I paid for the coins but never received them. The seller is not responding to messages.",
    status: "resolved",
    createdAt: "2023-07-18T10:30:00Z",
    resolvedAt: "2023-07-19T14:15:00Z",
    resolvedBy: "admin2",
    resolution: "Refund issued to buyer",
  },
]

export function AdminReports() {
  const [loading, setLoading] = useState(true)
  const [reports, setReports] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [viewReportId, setViewReportId] = useState<string | null>(null)
  const [resolutionNote, setResolutionNote] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    // Simulate API call to fetch reports
    const fetchReports = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setReports(mockReports)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching reports:", error)
        setLoading(false)
      }
    }

    fetchReports()
  }, [])

  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.reporter.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.reportedUser.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (report.reportedItemTitle && report.reportedItemTitle.toLowerCase().includes(searchTerm.toLowerCase())) ||
      report.reason.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || report.status === statusFilter
    const matchesType = typeFilter === "all" || report.reportedItemType === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  const handleStatusChange = (reportId: string, newStatus: string, resolution = "") => {
    setReports(
      reports.map((report) =>
        report.id === reportId
          ? {
              ...report,
              status: newStatus,
              resolvedAt: newStatus === "resolved" ? new Date().toISOString() : report.resolvedAt,
              resolvedBy: newStatus === "resolved" ? "currentAdmin" : report.resolvedBy,
              resolution: newStatus === "resolved" ? resolution : report.resolution,
            }
          : report,
      ),
    )

    toast({
      title: "Report Status Updated",
      description: `Report status has been changed to ${newStatus}.`,
    })

    triggerHaptic("success")
  }

  const handleResolveReport = () => {
    if (!viewReportId) return

    handleStatusChange(viewReportId, "resolved", resolutionNote)
    setViewReportId(null)
    setResolutionNote("")
  }

  const viewingReport = viewReportId ? reports.find((r) => r.id === viewReportId) : null

  const getReportTypeIcon = (type: string) => {
    switch (type) {
      case "listing":
        return <ShoppingBag className="h-4 w-4 text-blue-500" />
      case "user":
        return <User className="h-4 w-4 text-green-500" />
      case "message":
        return <MessageSquare className="h-4 w-4 text-purple-500" />
      case "transaction":
        return <Flag className="h-4 w-4 text-orange-500" />
      default:
        return <Flag className="h-4 w-4 text-red-500" />
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "investigating":
        return "default"
      case "resolved":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-[300px]">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search reports..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="investigating">Investigating</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="listing">Listings</SelectItem>
              <SelectItem value="user">Users</SelectItem>
              <SelectItem value="message">Messages</SelectItem>
              <SelectItem value="transaction">Transactions</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Report ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead>Reporter</TableHead>
              <TableHead>Reported</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array(5)
                .fill(0)
                .map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[150px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[50px]" />
                    </TableCell>
                  </TableRow>
                ))
            ) : filteredReports.length > 0 ? (
              filteredReports.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="font-medium">{report.id}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getReportTypeIcon(report.reportedItemType)}
                      <span className="capitalize">{report.reportedItemType}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="truncate block max-w-[200px]">{report.reason}</span>
                  </TableCell>
                  <TableCell>{report.reporter}</TableCell>
                  <TableCell>{report.reportedUser}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(report.status)}>{report.status}</Badge>
                  </TableCell>
                  <TableCell>{new Date(report.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0" onClick={() => triggerHaptic("light")}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => {
                            setViewReportId(report.id)
                            triggerHaptic("light")
                          }}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        {report.status === "pending" && (
                          <DropdownMenuItem
                            onClick={() => {
                              handleStatusChange(report.id, "investigating")
                              triggerHaptic("medium")
                            }}
                          >
                            <Flag className="h-4 w-4 mr-2" />
                            Mark as Investigating
                          </DropdownMenuItem>
                        )}
                        {(report.status === "pending" || report.status === "investigating") && (
                          <DropdownMenuItem
                            onClick={() => {
                              setViewReportId(report.id)
                              triggerHaptic("light")
                            }}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Resolve Report
                          </DropdownMenuItem>
                        )}
                        {report.status === "resolved" && (
                          <DropdownMenuItem
                            onClick={() => {
                              handleStatusChange(report.id, "investigating")
                              triggerHaptic("medium")
                            }}
                          >
                            <Flag className="h-4 w-4 mr-2" />
                            Reopen Report
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4">
                  No reports found matching your filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {viewingReport && (
        <Dialog open={!!viewReportId} onOpenChange={(open) => !open && setViewReportId(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Report Details</DialogTitle>
              <DialogDescription>Detailed information about the selected report.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Report Information</h4>
                  <p className="font-medium text-lg">{viewingReport.id}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={getStatusBadgeVariant(viewingReport.status)}>{viewingReport.status}</Badge>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Reported Item</h4>
                  <div className="flex items-center gap-2">
                    {getReportTypeIcon(viewingReport.reportedItemType)}
                    <span className="capitalize font-medium">{viewingReport.reportedItemType}</span>
                  </div>
                  {viewingReport.reportedItemTitle && <p className="mt-1">{viewingReport.reportedItemTitle}</p>}
                  <p className="text-sm text-muted-foreground mt-1">ID: {viewingReport.reportedItemId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Reason</h4>
                  <p className="font-medium">{viewingReport.reason}</p>
                  <p className="text-sm mt-2">{viewingReport.description}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Reporter Information</h4>
                  <p className="font-medium">{viewingReport.reporter}</p>
                  <p className="text-sm text-muted-foreground">ID: {viewingReport.reporterId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Reported User</h4>
                  <p className="font-medium">{viewingReport.reportedUser}</p>
                  <p className="text-sm text-muted-foreground">ID: {viewingReport.reportedUserId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Timeline</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Created:</p>
                      <p className="font-medium">{new Date(viewingReport.createdAt).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Resolved:</p>
                      <p className="font-medium">
                        {viewingReport.resolvedAt ? new Date(viewingReport.resolvedAt).toLocaleString() : "Pending"}
                      </p>
                    </div>
                  </div>
                </div>
                {viewingReport.resolution && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Resolution</h4>
                    <p>{viewingReport.resolution}</p>
                  </div>
                )}
                {(viewingReport.status === "pending" || viewingReport.status === "investigating") && (
                  <div className="pt-4">
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Resolve Report</h4>
                    <Textarea
                      placeholder="Enter resolution details..."
                      value={resolutionNote}
                      onChange={(e) => setResolutionNote(e.target.value)}
                      className="mb-4"
                    />
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setViewReportId(null)
                          setResolutionNote("")
                          triggerHaptic("light")
                        }}
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => {
                          handleResolveReport()
                          triggerHaptic("success")
                        }}
                        disabled={!resolutionNote.trim()}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Resolve
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
