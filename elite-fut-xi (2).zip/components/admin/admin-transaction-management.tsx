"use client"

import { useState, useEffect } from "react"
import { MoreHorizontal, Search, Download, Eye, CheckCircle, XCircle, AlertTriangle, Clock } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/utils/haptic"

// Mock data for demonstration
const mockTransactions = [
  {
    id: "TX123456",
    buyerId: "1",
    buyer: "Alex Johnson",
    sellerId: "2",
    seller: "Sarah Williams",
    listingId: "2",
    listingTitle: "Messi 96 OVR Card",
    amount: 2500000,
    fee: 125000,
    status: "completed",
    paymentMethod: "Bank Transfer",
    createdAt: "2023-07-15T14:30:00Z",
    completedAt: "2023-07-15T15:45:00Z",
  },
  {
    id: "TX123457",
    buyerId: "3",
    buyer: "Michael Brown",
    sellerId: "5",
    seller: "James Wilson",
    listingId: "3",
    listingTitle: "Rare Gold Pack Bundle",
    amount: 500000,
    fee: 25000,
    status: "pending",
    paymentMethod: "GoPay",
    createdAt: "2023-07-16T10:15:00Z",
    completedAt: null,
  },
  {
    id: "TX123458",
    buyerId: "4",
    buyer: "Emily Davis",
    sellerId: "2",
    seller: "Sarah Williams",
    listingId: "4",
    listingTitle: "Haaland 92 OVR Card",
    amount: 980000,
    fee: 49000,
    status: "failed",
    paymentMethod: "OVO",
    createdAt: "2023-07-16T16:20:00Z",
    completedAt: "2023-07-16T16:35:00Z",
  },
  {
    id: "TX123459",
    buyerId: "1",
    buyer: "Alex Johnson",
    sellerId: "5",
    seller: "James Wilson",
    listingId: "5",
    listingTitle: "Ultimate Team Coins - 1M",
    amount: 150000,
    fee: 7500,
    status: "disputed",
    paymentMethod: "DANA",
    createdAt: "2023-07-17T09:45:00Z",
    completedAt: null,
  },
  {
    id: "TX123460",
    buyerId: "3",
    buyer: "Michael Brown",
    sellerId: "1",
    seller: "Alex Johnson",
    listingId: "1",
    listingTitle: "Ronaldo 94 OVR Card",
    amount: 1250000,
    fee: 62500,
    status: "completed",
    paymentMethod: "Bank Transfer",
    createdAt: "2023-07-18T11:30:00Z",
    completedAt: "2023-07-18T12:45:00Z",
  },
]

export function AdminTransactionManagement() {
  const [loading, setLoading] = useState(true)
  const [transactions, setTransactions] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [viewTransactionId, setViewTransactionId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Simulate API call to fetch transactions
    const fetchTransactions = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setTransactions(mockTransactions)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching transactions:", error)
        setLoading(false)
      }
    }

    fetchTransactions()
  }, [])

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.buyer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.seller.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.listingTitle.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || transaction.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleStatusChange = (transactionId: string, newStatus: string) => {
    setTransactions(
      transactions.map((transaction) =>
        transaction.id === transactionId ? { ...transaction, status: newStatus } : transaction,
      ),
    )

    toast({
      title: "Transaction Status Updated",
      description: `Transaction status has been changed to ${newStatus}.`,
    })

    triggerHaptic("success")
  }

  const handleExportTransactions = () => {
    // In a real app, this would generate a CSV or Excel file
    toast({
      title: "Export Started",
      description: "Transaction data export has been initiated.",
    })

    triggerHaptic("light")
  }

  const viewingTransaction = viewTransactionId ? transactions.find((t) => t.id === viewTransactionId) : null

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "disputed":
        return <AlertTriangle className="h-4 w-4 text-orange-500" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-[300px]">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="disputed">Disputed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button variant="outline" onClick={handleExportTransactions} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Transaction ID</TableHead>
              <TableHead>Listing</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Buyer</TableHead>
              <TableHead>Seller</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array(5)
                .fill(0)
                .map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[150px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[80px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[100px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[50px]" />
                    </TableCell>
                  </TableRow>
                ))
            ) : filteredTransactions.length > 0 ? (
              filteredTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="font-medium">{transaction.id}</TableCell>
                  <TableCell>{transaction.listingTitle}</TableCell>
                  <TableCell>{formatCurrency(transaction.amount)}</TableCell>
                  <TableCell>{transaction.buyer}</TableCell>
                  <TableCell>{transaction.seller}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(transaction.status)}
                      <Badge
                        variant={
                          transaction.status === "completed"
                            ? "default"
                            : transaction.status === "pending"
                              ? "secondary"
                              : transaction.status === "disputed"
                                ? "destructive"
                                : "outline"
                        }
                      >
                        {transaction.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>{new Date(transaction.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0" onClick={() => triggerHaptic("light")}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => {
                            setViewTransactionId(transaction.id)
                            triggerHaptic("light")
                          }}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        {transaction.status === "pending" && (
                          <DropdownMenuItem
                            onClick={() => {
                              handleStatusChange(transaction.id, "completed")
                              triggerHaptic("success")
                            }}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark as Completed
                          </DropdownMenuItem>
                        )}
                        {transaction.status === "disputed" && (
                          <>
                            <DropdownMenuItem
                              onClick={() => {
                                handleStatusChange(transaction.id, "completed")
                                triggerHaptic("success")
                              }}
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Resolve in Favor of Buyer
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                handleStatusChange(transaction.id, "failed")
                                triggerHaptic("error")
                              }}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Resolve in Favor of Seller
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4">
                  No transactions found matching your filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {viewingTransaction && (
        <Dialog open={!!viewTransactionId} onOpenChange={(open) => !open && setViewTransactionId(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
              <DialogDescription>Detailed information about the selected transaction.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Transaction Information</h4>
                  <p className="font-medium text-lg">{viewingTransaction.id}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {getStatusIcon(viewingTransaction.status)}
                    <Badge
                      variant={
                        viewingTransaction.status === "completed"
                          ? "default"
                          : viewingTransaction.status === "pending"
                            ? "secondary"
                            : viewingTransaction.status === "disputed"
                              ? "destructive"
                              : "outline"
                      }
                    >
                      {viewingTransaction.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Item</h4>
                  <p className="font-medium">{viewingTransaction.listingTitle}</p>
                  <p className="text-sm text-muted-foreground">Listing ID: {viewingTransaction.listingId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Financial Details</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Amount:</p>
                      <p className="font-medium">{formatCurrency(viewingTransaction.amount)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Platform Fee:</p>
                      <p className="font-medium">{formatCurrency(viewingTransaction.fee)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Net to Seller:</p>
                      <p className="font-medium">
                        {formatCurrency(viewingTransaction.amount - viewingTransaction.fee)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Payment Method:</p>
                      <p className="font-medium">{viewingTransaction.paymentMethod}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Buyer Information</h4>
                  <p className="font-medium">{viewingTransaction.buyer}</p>
                  <p className="text-sm text-muted-foreground">ID: {viewingTransaction.buyerId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Seller Information</h4>
                  <p className="font-medium">{viewingTransaction.seller}</p>
                  <p className="text-sm text-muted-foreground">ID: {viewingTransaction.sellerId}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Timeline</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Created:</p>
                      <p className="font-medium">{new Date(viewingTransaction.createdAt).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Completed:</p>
                      <p className="font-medium">
                        {viewingTransaction.completedAt
                          ? new Date(viewingTransaction.completedAt).toLocaleString()
                          : "Pending"}
                      </p>
                    </div>
                  </div>
                </div>
                {viewingTransaction.status === "disputed" && (
                  <div className="pt-4">
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Resolve Dispute</h4>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => {
                          handleStatusChange(viewingTransaction.id, "completed")
                          setViewTransactionId(null)
                        }}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Resolve for Buyer
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          handleStatusChange(viewingTransaction.id, "failed")
                          setViewTransactionId(null)
                        }}
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Resolve for Seller
                      </Button>
                    </div>
                  </div>
                )}
                {viewingTransaction.status === "pending" && (
                  <div className="pt-4">
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Actions</h4>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => {
                        handleStatusChange(viewingTransaction.id, "completed")
                        setViewTransactionId(null)
                      }}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Mark as Completed
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
