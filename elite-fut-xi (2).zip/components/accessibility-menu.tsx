"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Accessibility, ZoomIn, ZoomOut, Type, Eye } from "lucide-react"
import { useLanguage } from "@/context/language-context"
import { EnhancedThemeToggle } from "@/components/enhanced-theme-toggle"

export function AccessibilityMenu() {
  const { t } = useLanguage()
  const [fontSize, setFontSize] = useState(100)
  const [highContrast, setHighContrast] = useState(false)
  const [reducedMotion, setReducedMotion] = useState(false)
  const [readingMode, setReadingMode] = useState(false)

  const applyFontSize = (size: number) => {
    document.documentElement.style.fontSize = `${size}%`
    setFontSize(size)
  }

  const toggleHighContrast = (enabled: boolean) => {
    if (enabled) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }
    setHighContrast(enabled)
  }

  const toggleReducedMotion = (enabled: boolean) => {
    if (enabled) {
      document.documentElement.classList.add("reduced-motion")
    } else {
      document.documentElement.classList.remove("reduced-motion")
    }
    setReducedMotion(enabled)
  }

  const toggleReadingMode = (enabled: boolean) => {
    if (enabled) {
      document.documentElement.classList.add("reading-mode")
    } else {
      document.documentElement.classList.remove("reading-mode")
    }
    setReadingMode(enabled)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-8 w-8 text-muted-foreground hover:text-foreground"
          aria-label={t("accessibility.accessibilitySettings")}
        >
          <Accessibility className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t("accessibility.accessibilitySettings")}</DialogTitle>
          <DialogDescription>{t("accessibility.adjustSettingsForBetterExperience")}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <h3 className="text-sm font-medium">{t("common.appearance")}</h3>
            <EnhancedThemeToggle />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="font-size" className="flex items-center gap-2">
                <Type className="h-4 w-4" />
                {t("accessibility.textSize")}
              </Label>
              <span className="text-sm text-muted-foreground">{fontSize}%</span>
            </div>
            <div className="flex items-center gap-2">
              <ZoomOut className="h-4 w-4 text-muted-foreground" />
              <Slider
                id="font-size"
                min={75}
                max={150}
                step={5}
                value={[fontSize]}
                onValueChange={(value) => applyFontSize(value[0])}
                aria-label={t("accessibility.textSize")}
              />
              <ZoomIn className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="high-contrast"
              checked={highContrast}
              onCheckedChange={toggleHighContrast}
              aria-label={t("accessibility.highContrast")}
            />
            <Label htmlFor="high-contrast" className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              {t("accessibility.highContrast")}
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="reduced-motion"
              checked={reducedMotion}
              onCheckedChange={toggleReducedMotion}
              aria-label={t("accessibility.reducedMotion")}
            />
            <Label htmlFor="reduced-motion">{t("accessibility.reducedMotion")}</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="reading-mode"
              checked={readingMode}
              onCheckedChange={toggleReadingMode}
              aria-label={t("accessibility.readingMode")}
            />
            <Label htmlFor="reading-mode">{t("accessibility.readingMode")}</Label>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
