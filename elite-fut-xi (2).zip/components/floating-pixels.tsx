"use client"

import { useEffect, useRef } from "react"

interface Pixel {
  x: number
  y: number
  size: number
  color: string
  speedX: number
  speedY: number
  opacity: number
}

export function FloatingPixels({ count = 30 }: { count?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas to full screen
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Create pixels
    const pixels: Pixel[] = []
    const colors = ["#00ffff", "#ff00ff", "#4169e1"]

    for (let i = 0; i < count; i++) {
      pixels.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 4 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.5 + 0.2,
      })
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      pixels.forEach((pixel) => {
        // Update position
        pixel.x += pixel.speedX
        pixel.y += pixel.speedY

        // Wrap around screen
        if (pixel.x < 0) pixel.x = canvas.width
        if (pixel.x > canvas.width) pixel.x = 0
        if (pixel.y < 0) pixel.y = canvas.height
        if (pixel.y > canvas.height) pixel.y = 0

        // Draw pixel
        ctx.fillStyle = pixel.color
        ctx.globalAlpha = pixel.opacity
        ctx.shadowColor = pixel.color
        ctx.shadowBlur = 10
        ctx.fillRect(pixel.x, pixel.y, pixel.size, pixel.size)
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [count])

  return <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full pointer-events-none z-0" />
}
