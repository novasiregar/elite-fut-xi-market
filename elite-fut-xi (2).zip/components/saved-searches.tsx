"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Skeleton } from "@/components/ui/skeleton"
import { Bookmark, Clock, Search, Trash, Bell, BellOff } from "lucide-react"
import { SearchService, type SavedSearch } from "@/client/services/search"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/utils/haptic"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface SavedSearchesProps {
  onSelect: (searchParams: any) => void
}

export function SavedSearches({ onSelect }: SavedSearchesProps) {
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchToDelete, setSearchToDelete] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const fetchSavedSearches = async () => {
      setIsLoading(true)
      try {
        const searches = await SearchService.getSavedSearches()
        setSavedSearches(searches)
      } catch (error) {
        console.error("Error fetching saved searches:", error)
        toast({
          title: "Error",
          description: "Failed to load saved searches",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchSavedSearches()
  }, [toast])

  const handleSelect = (search: SavedSearch) => {
    triggerHaptic("light")
    onSelect({
      searchTerm: search.query,
      filters: search.filters,
    })
  }

  const handleDelete = async () => {
    if (!searchToDelete) return

    triggerHaptic("medium")
    try {
      await SearchService.deleteSavedSearch(searchToDelete)

      setSavedSearches((prev) => prev.filter((search) => search.id !== searchToDelete))

      toast({
        title: "Search deleted",
        description: "Your saved search has been deleted",
        variant: "default",
      })
    } catch (error) {
      console.error("Error deleting saved search:", error)
      toast({
        title: "Error",
        description: "Failed to delete saved search",
        variant: "destructive",
      })
    } finally {
      setSearchToDelete(null)
    }
  }

  const toggleNotifications = async (searchId: string, enabled: boolean) => {
    triggerHaptic("light")
    try {
      const result = await SearchService.updateSearchNotifications(searchId, enabled)

      setSavedSearches((prev) =>
        prev.map((search) =>
          search.id === searchId ? { ...search, notificationsEnabled: result.notificationsEnabled } : search,
        ),
      )

      toast({
        title: enabled ? "Notifications enabled" : "Notifications disabled",
        description: enabled
          ? "You'll be notified when new listings match your search"
          : "You won't receive notifications for this search",
        variant: "default",
      })
    } catch (error) {
      console.error("Error updating notifications:", error)
      toast({
        title: "Error",
        description: "Failed to update notification settings",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-4">
          <Bookmark className="h-4 w-4 text-primary" />
          <h2 className="text-lg font-medium">Saved Searches</h2>
        </div>

        {Array(3)
          .fill(0)
          .map((_, index) => (
            <Card key={index} className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-3">
                <Skeleton className="h-5 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-3" />
                <div className="flex justify-between">
                  <Skeleton className="h-8 w-20" />
                  <Skeleton className="h-8 w-20" />
                </div>
              </CardContent>
            </Card>
          ))}
      </div>
    )
  }

  if (savedSearches.length === 0) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-4">
          <Bookmark className="h-4 w-4 text-primary" />
          <h2 className="text-lg font-medium">Saved Searches</h2>
        </div>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4 text-center">
            <p className="text-muted-foreground">You don't have any saved searches yet.</p>
            <p className="text-sm text-muted-foreground mt-1">
              Save your searches to get notified when new listings match your criteria.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-4">
        <Bookmark className="h-4 w-4 text-primary" />
        <h2 className="text-lg font-medium">Saved Searches</h2>
      </div>

      {savedSearches.map((search) => (
        <Card key={search.id} className="bg-card/50 backdrop-blur-sm">
          <CardContent className="p-3">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-medium">{search.name}</h3>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => toggleNotifications(search.id, !search.notificationsEnabled)}
                  title={search.notificationsEnabled ? "Disable notifications" : "Enable notifications"}
                >
                  {search.notificationsEnabled ? (
                    <Bell className="h-4 w-4" />
                  ) : (
                    <BellOff className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>

                <AlertDialog
                  open={searchToDelete === search.id}
                  onOpenChange={(open) => !open && setSearchToDelete(null)}
                >
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-destructive"
                      onClick={() => {
                        triggerHaptic("light")
                        setSearchToDelete(search.id)
                      }}
                      title="Delete search"
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Saved Search</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete this saved search? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel onClick={() => triggerHaptic("light")}>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>

            <div className="text-xs text-muted-foreground mb-3 flex items-center gap-2">
              <Clock className="h-3 w-3" />
              <span>
                Last updated: {new Date(search.lastRunAt).toLocaleDateString()}
                {search.lastResultCount > 0 && ` • ${search.lastResultCount} results`}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="text-xs h-8" onClick={() => handleSelect(search)}>
                <Search className="h-3 w-3 mr-1" />
                Run Search
              </Button>

              <div className="flex items-center gap-1 ml-auto">
                <Switch
                  id={`notifications-${search.id}`}
                  checked={search.notificationsEnabled}
                  onCheckedChange={(checked) => toggleNotifications(search.id, checked)}
                  className="scale-75"
                />
                <span className="text-xs">Notifications</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
