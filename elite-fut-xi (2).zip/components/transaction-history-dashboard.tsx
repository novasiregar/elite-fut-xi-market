"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TransactionService, TransactionStatus } from "@/client/services/transactions"
import { useAuth } from "@/context/auth-context"
import { useState, useEffect } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { TransactionCard } from "@/app/profile/page"
import { useToast } from "@/components/ui/use-toast"

export function TransactionHistoryDashboard() {
  const { user, loading } = useAuth()
  const [transactions, setTransactions] = useState<any[]>([])
  const [loadingTransactions, setLoadingTransactions] = useState(true)
  const [activeTab, setActiveTab] = useState("all")
  const { toast } = useToast()

  useEffect(() => {
    if (user) {
      const fetchTransactions = async () => {
        try {
          setLoadingTransactions(true)
          const data = await TransactionService.getTransactions(undefined, "all")
          setTransactions(data)
        } catch (error) {
          console.error("Error fetching transactions:", error)
          toast({
            title: "Error",
            description: "Failed to load your transactions",
            variant: "destructive",
          })
        } finally {
          setLoadingTransactions(false)
        }
      }

      fetchTransactions()
    }
  }, [user, toast])

  if (loading || loadingTransactions) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 w-full rounded-md" />
        ))}
      </div>
    )
  }

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="grid grid-cols-3 mb-4">
        <TabsTrigger value="all">All</TabsTrigger>
        <TabsTrigger value="completed">Completed</TabsTrigger>
        <TabsTrigger value="pending">Pending</TabsTrigger>
        <TabsTrigger value="disputed">Disputed</TabsTrigger>
        <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
      </TabsList>

      <TabsContent value="all" className="space-y-4">
        {transactions.length > 0 ? (
          <div className="space-y-4">
            {transactions.map((transaction) => (
              <TransactionCard
                key={transaction.id}
                transaction={transaction}
                userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground">No transactions yet</p>
        )}
      </TabsContent>

      <TabsContent value="completed" className="space-y-4">
        {transactions
          .filter((t) => t.status === TransactionStatus.COMPLETED)
          .map((transaction) => (
            <TransactionCard
              key={transaction.id}
              transaction={transaction}
              userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
            />
          ))}
      </TabsContent>

      <TabsContent value="pending" className="space-y-4">
        {transactions
          .filter((t) => t.status === TransactionStatus.PENDING)
          .map((transaction) => (
            <TransactionCard
              key={transaction.id}
              transaction={transaction}
              userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
            />
          ))}
      </TabsContent>

      <TabsContent value="disputed" className="space-y-4">
        {transactions
          .filter((t) => t.status === TransactionStatus.DISPUTED)
          .map((transaction) => (
            <TransactionCard
              key={transaction.id}
              transaction={transaction}
              userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
            />
          ))}
      </TabsContent>

      <TabsContent value="cancelled" className="space-y-4">
        {transactions
          .filter((t) => t.status === TransactionStatus.CANCELLED)
          .map((transaction) => (
            <TransactionCard
              key={transaction.id}
              transaction={transaction}
              userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
            />
          ))}
      </TabsContent>
    </Tabs>
  )
}
