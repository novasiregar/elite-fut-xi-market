"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface ProgressiveImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  className?: string
  aspectRatio?: string
  priority?: boolean
  pixelEffect?: boolean
}

export function ProgressiveImage({
  src,
  alt,
  width,
  height,
  className,
  aspectRatio = "16/9",
  priority = false,
  pixelEffect = true,
}: ProgressiveImageProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [currentSrc, setCurrentSrc] = useState(src.startsWith("/placeholder") ? src : `${src}?quality=1&width=40`)

  useEffect(() => {
    // If it's a placeholder, don't try to load a high-res version
    if (src.startsWith("/placeholder")) {
      setIsLoading(false)
      return
    }

    // Create a new image to preload the high-quality version
    const img = new Image()
    img.src = src
    img.onload = () => {
      setCurrentSrc(src)
      setIsLoading(false)
    }
  }, [src])

  return (
    <div
      className={cn(
        "overflow-hidden relative bg-background/20",
        isLoading && pixelEffect && "pixel-loading",
        className,
      )}
      style={{ aspectRatio }}
    >
      <Image
        src={currentSrc || "/placeholder.svg"}
        alt={alt}
        width={width || 800}
        height={height || 450}
        className={cn(
          "object-cover w-full h-full transition-all duration-500",
          isLoading ? "scale-110 blur-sm" : "scale-100 blur-0",
        )}
        priority={priority}
        onLoad={() => {
          if (currentSrc === src) {
            setIsLoading(false)
          }
        }}
      />
    </div>
  )
}
