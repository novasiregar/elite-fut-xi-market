"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { ProgressiveImage } from "@/components/progressive-image"
import { useHaptic, HapticType } from "@/utils/haptic"
import { useFadeIn } from "@/hooks/use-animations"
import { Play, Star, ShoppingCart, Verified } from "lucide-react"
import { cn } from "@/lib/utils"

interface AccountCardProps {
  account: {
    id: number
    title: string
    price: string
    rating: number
    image: string
    video?: string
    seller: string
    verified: boolean
    tags?: string[]
  }
  className?: string
  priority?: boolean
}

export function AccountCard({ account, className, priority = false }: AccountCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const { trigger } = useHaptic()
  const fadeIn = useFadeIn(0.1, 0.5)

  const handleMouseEnter = () => {
    setIsHovered(true)
    trigger(HapticType.SELECTION)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
  }

  const handleBuyClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    trigger(HapticType.MEDIUM)
  }

  return (
    <Link href={`/listings/${account.id}`} passHref>
      <Card
        ref={fadeIn.ref}
        style={fadeIn.style}
        className={cn(
          "overflow-hidden border border-border bg-card/50 backdrop-blur-sm transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:-translate-y-1",
          className,
        )}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleMouseEnter}
        onTouchEnd={handleMouseLeave}
      >
        <div className="relative overflow-hidden aspect-video">
          <ProgressiveImage src={account.image} alt={account.title} className="w-full h-full" priority={priority} />

          {account.video && (
            <div
              className={cn(
                "absolute inset-0 flex items-center justify-center bg-black/50 transition-opacity duration-300",
                isHovered ? "opacity-100" : "opacity-0",
              )}
            >
              <Play className="w-12 h-12 text-white opacity-80" />
            </div>
          )}

          {account.tags && account.tags.length > 0 && (
            <div className="absolute top-2 left-2 flex flex-wrap gap-1">
              {account.tags.includes("featured") && (
                <Badge variant="secondary" className="bg-primary/80 text-xs font-pixel animate-pulse">
                  FEATURED
                </Badge>
              )}
              {account.tags.includes("trending") && (
                <Badge variant="outline" className="bg-secondary/80 text-xs font-pixel">
                  TRENDING
                </Badge>
              )}
              {account.tags.includes("new") && (
                <Badge variant="outline" className="bg-green-500/80 text-xs font-pixel">
                  NEW
                </Badge>
              )}
            </div>
          )}
        </div>

        <CardContent className="p-4">
          <h3 className="font-futuristic text-sm mb-2 line-clamp-1">{account.title}</h3>

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <Star className="h-3 w-3 text-yellow-500 mr-1" />
              <span className="text-xs">{account.rating.toFixed(1)}</span>
            </div>

            <div className="flex items-center">
              <span className="text-xs mr-1">{account.seller}</span>
              {account.verified && <Verified className="h-3 w-3 text-primary" />}
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant="default"
              size="sm"
              className={cn(
                "flex-1 font-pixel text-xs transition-all duration-300",
                isHovered && "bg-primary shadow-[0_0_10px_rgba(0,255,255,0.5)]",
              )}
              onClick={handleBuyClick}
            >
              <ShoppingCart className="h-3 w-3 mr-1" />
              Rp {account.price}
            </Button>

            <Button
              variant="outline"
              size="icon"
              className={cn("h-8 w-8 transition-all duration-300", isHovered && "border-primary text-primary")}
            >
              <Star className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
