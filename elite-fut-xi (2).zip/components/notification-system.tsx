"use client"

import { useState, useEffect } from "react"
import { Bell, X, CheckCircle, MessageCircle, DollarSign, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/context/auth-context"
import { UserService } from "@/client/services/users"
import { NotificationService } from "@/client/services/notifications"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface Notification {
  id: string
  type: "transaction" | "message" | "system" | "payment"
  title: string
  message: string
  read: boolean
  createdAt: string
  data?: any
}

export function NotificationSystem() {
  const { user } = useAuth()
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [showDropdown, setShowDropdown] = useState(false)
  const [showToast, setShowToast] = useState(false)
  const [currentToast, setCurrentToast] = useState<Notification | null>(null)
  const { triggerHaptic } = useHapticFeedback()

  // Initialize FCM
  useEffect(() => {
    if (!user) return

    const initFCM = async () => {
      try {
        await NotificationService.initialize()

        // Listen for foreground messages
        const unsubscribe = NotificationService.onForegroundMessage((payload) => {
          // Create notification from payload
          const notification = {
            id: payload.data?.notificationId || `fcm-${Date.now()}`,
            type: payload.data?.type || "system",
            title: payload.notification?.title || "New Notification",
            message: payload.notification?.body || "",
            read: false,
            createdAt: new Date().toISOString(),
            data: payload.data,
          }

          // Add to notifications list
          setNotifications((prev) => [notification, ...prev])
          setUnreadCount((prev) => prev + 1)

          // Show toast
          setCurrentToast(notification)
          setShowToast(true)

          // Trigger haptic feedback
          triggerHaptic("notification")

          // Hide toast after 5 seconds
          setTimeout(() => {
            setShowToast(false)
          }, 5000)
        })

        return unsubscribe
      } catch (error) {
        console.error("Error initializing FCM:", error)
      }
    }

    initFCM()
  }, [user, triggerHaptic])

  // Fetch notifications
  useEffect(() => {
    if (!user) return

    const fetchNotifications = async () => {
      try {
        const notifs = await UserService.getNotifications()
        setNotifications(notifs)
        setUnreadCount(notifs.filter((n: Notification) => !n.read).length)
      } catch (error) {
        console.error("Error fetching notifications:", error)
      }
    }

    fetchNotifications()

    // Set up polling for new notifications
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [user])

  const markAsRead = async (id: string) => {
    try {
      await UserService.markNotificationAsRead(id)

      // Update local state
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
      setUnreadCount((prev) => Math.max(0, prev - 1))
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  const markAllAsRead = async () => {
    try {
      await UserService.markAllNotificationsAsRead()

      // Update local state
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error("Error marking all notifications as read:", error)
    }
  }

  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    if (!notification.read) {
      markAsRead(notification.id)
    }

    // Navigate based on notification type
    switch (notification.type) {
      case "transaction":
        router.push(`/transactions/${notification.data?.transactionId || ""}`)
        break
      case "message":
        router.push(`/messages/${notification.data?.conversationId || ""}`)
        break
      case "payment":
        router.push(`/payments/${notification.data?.paymentId || ""}`)
        break
      default:
        // For system notifications, just close the dropdown
        break
    }

    // Close dropdown
    setShowDropdown(false)

    // Trigger haptic feedback
    triggerHaptic("light")
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "transaction":
        return <ShoppingBag className="h-5 w-5 text-primary" />
      case "message":
        return <MessageCircle className="h-5 w-5 text-secondary" />
      case "payment":
        return <DollarSign className="h-5 w-5 text-green-500" />
      case "system":
      default:
        return <CheckCircle className="h-5 w-5 text-accent" />
    }
  }

  return (
    <>
      {/* Notification Bell */}
      <div className="relative">
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          onClick={() => {
            setShowDropdown(!showDropdown)
            triggerHaptic("light")
          }}
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center text-[10px] font-bold">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>

        {/* Notification Dropdown */}
        <AnimatePresence>
          {showDropdown && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute right-0 mt-2 w-80 z-50"
            >
              <Card className="bg-card/90 backdrop-blur-sm border border-border shadow-lg">
                <CardContent className="p-0">
                  <div className="flex items-center justify-between p-3 border-b border-border">
                    <h3 className="font-futuristic text-sm">NOTIFICATIONS</h3>
                    {unreadCount > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => {
                          markAllAsRead()
                          triggerHaptic("medium")
                        }}
                      >
                        Mark all as read
                      </Button>
                    )}
                  </div>

                  <div className="max-h-[400px] overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">No notifications yet</p>
                      </div>
                    ) : (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b border-border hover:bg-muted/30 cursor-pointer transition-colors ${
                            !notification.read ? "bg-primary/5" : ""
                          }`}
                          onClick={() => handleNotificationClick(notification)}
                        >
                          <div className="flex gap-3">
                            <div className="mt-0.5">{getNotificationIcon(notification.type)}</div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="text-sm font-medium">{notification.title}</h4>
                                {!notification.read && <Badge variant="default" className="h-2 w-2 rounded-full p-0" />}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">{notification.message}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {new Date(notification.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="p-2 border-t border-border">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full text-xs"
                      onClick={() => {
                        router.push("/notifications")
                        setShowDropdown(false)
                        triggerHaptic("light")
                      }}
                    >
                      View All Notifications
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Toast Notification */}
      <AnimatePresence>
        {showToast && currentToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 50, x: "-50%" }}
            transition={{ type: "spring", damping: 15 }}
            className="fixed bottom-20 left-1/2 transform -translate-x-1/2 z-50 w-[90%] max-w-md"
          >
            <Card className="bg-card/90 backdrop-blur-sm border border-primary/30 shadow-lg shadow-primary/20">
              <CardContent className="p-3">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getNotificationIcon(currentToast.type)}</div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium">{currentToast.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{currentToast.message}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => {
                      setShowToast(false)
                      triggerHaptic("light")
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
