"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { generateSrcSet } from "@/utils/image-optimization"

interface OptimizedImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  priority?: boolean
  className?: string
  blurDataURL?: string
  sizes?: string
  fill?: boolean
  onLoad?: () => void
}

export function OptimizedImage({
  src,
  alt,
  width,
  height,
  priority = false,
  className = "",
  blurDataURL,
  sizes = "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
  fill = false,
  onLoad,
  ...props
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [srcSet, setSrcSet] = useState<string | undefined>(undefined)

  useEffect(() => {
    if (width && src) {
      setSrcSet(generateSrcSet(src, width))
    }
  }, [src, width])

  const handleLoad = () => {
    setIsLoaded(true)
    if (onLoad) onLoad()
  }

  // Determine placeholder strategy
  const placeholderStrategy = blurDataURL ? "blur" : "empty"

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      style={{ opacity: isLoaded ? 1 : 0.5, transition: "opacity 0.3s ease-in-out" }}
    >
      <Image
        src={src || "/placeholder.svg"}
        alt={alt}
        width={fill ? undefined : width}
        height={fill ? undefined : height}
        fill={fill}
        priority={priority}
        sizes={sizes}
        placeholder={placeholderStrategy as any}
        blurDataURL={blurDataURL}
        onLoad={handleLoad}
        loading={priority ? "eager" : "lazy"}
        {...props}
      />
    </div>
  )
}
