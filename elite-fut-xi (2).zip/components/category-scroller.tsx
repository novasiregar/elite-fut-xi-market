"use client"

import { useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Users, Star, Trophy, Zap, Gamepad, DollarSign } from "lucide-react"
import { cn } from "@/lib/utils"

const categories = [
  { name: "Featured", icon: <Star className="h-4 w-4" />, color: "from-yellow-500/20 to-yellow-500/5" },
  { name: "Top Rated", icon: <Trophy className="h-4 w-4" />, color: "from-purple-500/20 to-purple-500/5" },
  { name: "New Arrivals", icon: <Zap className="h-4 w-4" />, color: "from-blue-500/20 to-blue-500/5" },
  { name: "Budget", icon: <DollarSign className="h-4 w-4" />, color: "from-green-500/20 to-green-500/5" },
  { name: "Premium", icon: <Gamepad className="h-4 w-4" />, color: "from-red-500/20 to-red-500/5" },
  { name: "Verified", icon: <Users className="h-4 w-4" />, color: "from-primary/20 to-primary/5" },
]

export function CategoryScroller() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(true)
  const [activeCategory, setActiveCategory] = useState("Featured")

  const checkScrollability = () => {
    const container = scrollContainerRef.current
    if (!container) return

    setCanScrollLeft(container.scrollLeft > 0)
    setCanScrollRight(container.scrollLeft < container.scrollWidth - container.clientWidth - 10)
  }

  const scrollLeft = () => {
    if (!scrollContainerRef.current) return
    scrollContainerRef.current.scrollBy({ left: -200, behavior: "smooth" })
  }

  const scrollRight = () => {
    if (!scrollContainerRef.current) return
    scrollContainerRef.current.scrollBy({ left: 200, behavior: "smooth" })
  }

  return (
    <div className="relative">
      <div
        ref={scrollContainerRef}
        className="flex gap-3 overflow-x-auto scrollbar-hide pb-4 px-2"
        onScroll={checkScrollability}
      >
        {categories.map((category) => (
          <button
            key={category.name}
            className={cn(
              "flex flex-col items-center justify-center min-w-[100px] h-24 rounded-lg bg-gradient-to-b",
              category.color,
              "backdrop-blur-sm border border-border transition-all duration-300",
              activeCategory === category.name
                ? "border-primary shadow-[0_0_10px_rgba(0,255,255,0.3)]"
                : "hover:border-primary/50",
            )}
            onClick={() => setActiveCategory(category.name)}
          >
            <div
              className={cn(
                "rounded-full p-2 mb-2",
                activeCategory === category.name ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground",
              )}
            >
              {category.icon}
            </div>
            <span className="text-xs font-futuristic">{category.name}</span>
          </button>
        ))}
      </div>

      {canScrollLeft && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-0 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8 shadow-md"
          onClick={scrollLeft}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
      )}

      {canScrollRight && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-0 top-1/2 -translate-y-1/2 bg-background/50 backdrop-blur-sm rounded-full h-8 w-8 shadow-md"
          onClick={scrollRight}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      )}
    </div>
  )
}
