"use client"

import type React from "react"

import { forwardRef } from "react"
import { Button, type ButtonProps } from "@/components/ui/button"
import { useHaptic, HapticType } from "@/utils/haptic"
import { cn } from "@/lib/utils"

interface HapticButtonProps extends ButtonProps {
  hapticType?: HapticType
  withSound?: boolean
  glowEffect?: boolean
  pixelEffect?: boolean
}

export const HapticButton = forwardRef<HTMLButtonElement, HapticButtonProps>(
  (
    {
      children,
      hapticType = HapticType.MEDIUM,
      withSound = false,
      glowEffect = false,
      pixelEffect = false,
      className,
      onClick,
      ...props
    },
    ref,
  ) => {
    const { trigger, triggerWithSound } = useHaptic()

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (withSound) {
        triggerWithSound(hapticType)
      } else {
        trigger(hapticType)
      }

      if (onClick) {
        onClick(e)
      }
    }

    return (
      <Button
        ref={ref}
        className={cn(
          className,
          glowEffect && "hover:shadow-[0_0_15px_rgba(0,255,255,0.5)]",
          pixelEffect && "pixel-border",
        )}
        onClick={handleClick}
        {...props}
      >
        {children}
      </Button>
    )
  },
)

HapticButton.displayName = "HapticButton"
