"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { SearchService, type SearchResult } from "@/client/services/search"
import { triggerHaptic } from "@/utils/haptic"

interface SimilarListingsProps {
  listingId: string
  limit?: number
}

export function SimilarListings({ listingId, limit = 6 }: SimilarListingsProps) {
  const [listings, setListings] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchSimilarListings = async () => {
      if (!listingId) return

      setIsLoading(true)
      try {
        const results = await SearchService.getSimilarListings(listingId, limit)
        setListings(results)
      } catch (error) {
        console.error("Error fetching similar listings:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchSimilarListings()
  }, [listingId, limit])

  const handleCardClick = (listing: SearchResult) => {
    triggerHaptic("light")
    router.push(`/listings/${listing.id}`)
  }

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Array(limit)
          .fill(0)
          .map((_, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-0">
                <div className="aspect-[4/3] relative">
                  <Skeleton className="h-full w-full" />
                </div>
                <div className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-6 w-1/2 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </div>
              </CardContent>
            </Card>
          ))}
      </div>
    )
  }

  if (listings.length === 0) {
    return null
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {listings.map((listing) => (
        <Card
          key={listing.id}
          className="h-full cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => handleCardClick(listing)}
        >
          <CardContent className="p-0">
            <div className="aspect-[4/3] relative">
              <img
                src={listing.media?.[0]?.url || "/placeholder.svg?height=300&width=400"}
                alt={listing.title}
                className="h-full w-full object-cover rounded-t-md"
              />
            </div>
            <div className="p-4">
              <h3 className="font-medium line-clamp-1">{listing.title}</h3>
              <p className="text-lg font-bold mt-1">
                {new Intl.NumberFormat("id-ID", {
                  style: "currency",
                  currency: "IDR",
                  minimumFractionDigits: 0,
                }).format(listing.price)}
              </p>
              <div className="flex items-center mt-2">
                <div className="w-5 h-5 rounded-full bg-muted overflow-hidden mr-2">
                  {listing.seller.avatar ? (
                    <img
                      src={listing.seller.avatar || "/placeholder.svg"}
                      alt={listing.seller.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-primary/20 flex items-center justify-center text-xs">
                      {listing.seller.name.charAt(0)}
                    </div>
                  )}
                </div>
                <span className="text-xs text-muted-foreground line-clamp-1">{listing.seller.name}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
