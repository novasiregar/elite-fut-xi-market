"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Filter, ChevronDown, ChevronUp } from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

export function AdvancedFilters() {
  const [open, setOpen] = useState(false)
  const [priceRange, setPriceRange] = useState([500000, 5000000])
  const [ratingFilter, setRatingFilter] = useState(0)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID").format(price)
  }

  return (
    <Collapsible open={open} onOpenChange={setOpen} className="pixel-border p-4 bg-card/50 backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-futuristic">ADVANCED FILTERS</h3>
        </div>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="p-0 h-8 w-8">
            {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </CollapsibleTrigger>
      </div>

      <CollapsibleContent className="mt-4 space-y-4">
        <div className="space-y-2">
          <label className="text-xs font-futuristic">PRICE RANGE</label>
          <Slider
            defaultValue={[500000, 5000000]}
            min={0}
            max={10000000}
            step={100000}
            value={priceRange}
            onValueChange={setPriceRange}
            className="my-4"
          />
          <div className="flex justify-between text-xs">
            <span>Rp {formatPrice(priceRange[0])}</span>
            <span>Rp {formatPrice(priceRange[1])}</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-futuristic">MINIMUM RATING</label>
          <Slider
            defaultValue={[0]}
            min={0}
            max={5}
            step={0.5}
            value={[ratingFilter]}
            onValueChange={(value) => setRatingFilter(value[0])}
            className="my-4"
          />
          <div className="flex justify-between text-xs">
            <span>{ratingFilter.toFixed(1)} ★</span>
            <span>5.0 ★</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-futuristic">ACCOUNT TYPE</label>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-2">
              <Checkbox id="verified" />
              <label htmlFor="verified" className="text-xs">
                Verified Only
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="premium" />
              <label htmlFor="premium" className="text-xs">
                Premium
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="featured" />
              <label htmlFor="featured" className="text-xs">
                Featured
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="video" />
              <label htmlFor="video" className="text-xs">
                With Video
              </label>
            </div>
          </div>
        </div>

        <Button className="w-full text-xs font-futuristic">APPLY FILTERS</Button>
      </CollapsibleContent>
    </Collapsible>
  )
}
