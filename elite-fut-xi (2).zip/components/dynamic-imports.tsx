"use client"

import type React from "react"

import dynamic from "next/dynamic"
import { Suspense } from "react"
import { PixelLoading } from "@/components/pixel-loading"

// Dynamically import heavy components
export const DynamicCinematicHero = dynamic(
  () => import("@/components/cinematic-hero").then((mod) => ({ default: mod.CinematicHero })),
  {
    loading: () => <PixelLoading text="Loading hero..." />,
    ssr: true,
  },
)

export const DynamicImageGallery = dynamic(
  () => import("@/components/image-gallery").then((mod) => ({ default: mod.ImageGallery })),
  {
    loading: () => <PixelLoading text="Loading gallery..." />,
    ssr: false, // Load this client-side only
  },
)

export const DynamicEnhancedMessaging = dynamic(
  () => import("@/components/enhanced-messaging").then((mod) => ({ default: mod.EnhancedMessaging })),
  {
    loading: () => <PixelLoading text="Loading messages..." />,
    ssr: false,
  },
)

export const DynamicPaymentFlow = dynamic(
  () => import("@/components/enhanced-payment-flow").then((mod) => ({ default: mod.EnhancedPaymentFlow })),
  {
    loading: () => <PixelLoading text="Loading payment..." />,
    ssr: false,
  },
)

export const DynamicAdvancedFilters = dynamic(
  () => import("@/components/advanced-filters").then((mod) => ({ default: mod.AdvancedFilters })),
  {
    loading: () => <PixelLoading text="Loading filters..." />,
    ssr: false,
  },
)

// Wrapper component for dynamic imports with Suspense
export function DynamicComponent({
  component: Component,
  fallback,
  ...props
}: {
  component: React.ComponentType<any>
  fallback?: React.ReactNode
  [key: string]: any
}) {
  return (
    <Suspense fallback={fallback || <PixelLoading />}>
      <Component {...props} />
    </Suspense>
  )
}
