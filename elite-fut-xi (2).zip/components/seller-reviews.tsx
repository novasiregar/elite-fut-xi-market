"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Star, ThumbsUp, Flag, MessageSquare } from "lucide-react"
import { UserService } from "@/client/services/users"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import { Skeleton } from "@/components/ui/skeleton"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface Review {
  id: string
  userId: string
  userName: string
  userAvatar?: string
  rating: number
  comment: string
  createdAt: string
  transactionId: string
  helpful: number
  userHelpful: string[]
}

interface SellerReviewsProps {
  sellerId: string
}

export function SellerReviews({ sellerId }: SellerReviewsProps) {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [userRating, setUserRating] = useState(0)
  const [userComment, setUserComment] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [canReview, setCanReview] = useState(false)
  const [showReviewForm, setShowReviewForm] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()
  const { triggerHaptic } = useHapticFeedback()

  // Fetch reviews
  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true)
        const data = await UserService.getSellerReviews(sellerId)
        setReviews(data.reviews)

        // Check if user can review
        if (user) {
          const canUserReview = await UserService.canReviewSeller(sellerId)
          setCanReview(canUserReview)
        }
      } catch (error) {
        console.error("Error fetching reviews:", error)
        toast({
          title: "Error",
          description: "Failed to load reviews",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchReviews()
  }, [sellerId, user, toast])

  const submitReview = async () => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to leave a review",
        variant: "destructive",
      })
      return
    }

    if (userRating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a rating",
        variant: "destructive",
      })
      return
    }

    try {
      setSubmitting(true)
      triggerHaptic("medium")

      await UserService.submitSellerReview(sellerId, {
        rating: userRating,
        comment: userComment,
      })

      toast({
        title: "Review Submitted",
        description: "Thank you for your feedback!",
      })

      // Reset form
      setUserRating(0)
      setUserComment("")
      setShowReviewForm(false)

      // Refresh reviews
      const data = await UserService.getSellerReviews(sellerId)
      setReviews(data.reviews)
      setCanReview(false)
    } catch (error: any) {
      console.error("Error submitting review:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to submit review",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const markHelpful = async (reviewId: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to mark reviews as helpful",
        variant: "destructive",
      })
      return
    }

    try {
      triggerHaptic("light")
      await UserService.markReviewHelpful(reviewId)

      // Update local state
      setReviews((prev) =>
        prev.map((review) => {
          if (review.id === reviewId) {
            const alreadyMarked = review.userHelpful.includes(user.uid)
            return {
              ...review,
              helpful: alreadyMarked ? review.helpful - 1 : review.helpful + 1,
              userHelpful: alreadyMarked
                ? review.userHelpful.filter((id) => id !== user.uid)
                : [...review.userHelpful, user.uid],
            }
          }
          return review
        }),
      )
    } catch (error) {
      console.error("Error marking review as helpful:", error)
    }
  }

  const reportReview = async (reviewId: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to report reviews",
        variant: "destructive",
      })
      return
    }

    try {
      triggerHaptic("medium")
      await UserService.reportReview(reviewId)

      toast({
        title: "Review Reported",
        description: "Thank you for helping keep our community safe",
      })
    } catch (error) {
      console.error("Error reporting review:", error)
      toast({
        title: "Error",
        description: "Failed to report review",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="font-futuristic text-sm glow-text">SELLER REVIEWS</h2>

        {canReview && (
          <Dialog>
            <DialogTrigger asChild>
              <Button
                size="sm"
                onClick={() => {
                  setShowReviewForm(true)
                  triggerHaptic("light")
                }}
              >
                Write a Review
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Write a Review</DialogTitle>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="flex justify-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-8 w-8 cursor-pointer ${
                        star <= userRating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"
                      }`}
                      onClick={() => {
                        setUserRating(star)
                        triggerHaptic("light")
                      }}
                    />
                  ))}
                </div>

                <Textarea
                  placeholder="Share your experience with this seller..."
                  value={userComment}
                  onChange={(e) => setUserComment(e.target.value)}
                  rows={4}
                />

                <Button className="w-full" onClick={submitReview} disabled={submitting || userRating === 0}>
                  {submitting ? "Submitting..." : "Submit Review"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {reviews.length === 0 ? (
        <Card className="bg-muted/30">
          <CardContent className="p-6 text-center">
            <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm mb-4">No reviews yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id} className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={review.userAvatar || "/placeholder.svg"} />
                    <AvatarFallback>{review.userName.charAt(0)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-medium">{review.userName}</h3>
                        <div className="flex items-center mt-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-3 w-3 ${
                                star <= review.rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"
                              }`}
                            />
                          ))}
                          <span className="ml-2 text-xs text-muted-foreground">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <p className="text-sm mt-2">{review.comment}</p>

                    <div className="flex items-center gap-4 mt-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-2 text-xs"
                        onClick={() => markHelpful(review.id)}
                      >
                        <ThumbsUp
                          className={`h-3 w-3 mr-1 ${
                            user && review.userHelpful.includes(user.uid) ? "fill-primary" : ""
                          }`}
                        />
                        Helpful ({review.helpful})
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 px-2 text-xs text-muted-foreground"
                        onClick={() => reportReview(review.id)}
                      >
                        <Flag className="h-3 w-3 mr-1" />
                        Report
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
