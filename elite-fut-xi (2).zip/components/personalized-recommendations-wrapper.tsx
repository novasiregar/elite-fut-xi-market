"use client"

import { PersonalizedRecommendations } from "@/components/personalized-recommendations"
import { useAuth } from "@/context/auth-context"

export function PersonalizedRecommendationsWrapper() {
  const { user } = useAuth()

  // Only show recommendations for logged-in users or with a different title for guests
  return (
    <PersonalizedRecommendations
      title={user ? "Recommended for You" : "Popular Listings"}
      context="homepage"
      limit={10}
    />
  )
}
