"use client"

import { useEffect, useRef, useState } from "react"

export function CinematicHero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const video = videoRef.current
    const canvas = canvasRef.current

    if (!video || !canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions to match viewport
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Video background with pixel effect
    video.addEventListener("loadeddata", () => {
      setIsLoaded(true)
      video.play()
    })

    // Pixel effect animation
    let animationFrame: number

    const pixelSize = 8 // Size of each "pixel" in the effect

    const renderFrame = () => {
      if (!video || !ctx) return

      // Draw video frame to canvas
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

      // Apply pixel effect
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw pixelated version
      for (let y = 0; y < canvas.height; y += pixelSize) {
        for (let x = 0; x < canvas.width; x += pixelSize) {
          // Get the color of the pixel at (x, y)
          const index = (y * canvas.width + x) * 4
          const r = imageData.data[index]
          const g = imageData.data[index + 1]
          const b = imageData.data[index + 2]

          // Draw a rectangle with that color
          ctx.fillStyle = `rgb(${r},${g},${b})`
          ctx.fillRect(x, y, pixelSize, pixelSize)
        }
      }

      // Add scanlines effect
      ctx.fillStyle = "rgba(0, 0, 0, 0.1)"
      for (let y = 0; y < canvas.height; y += 4) {
        ctx.fillRect(0, y, canvas.width, 2)
      }

      // Add CRT vignette effect
      const gradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width / 1.5,
      )
      gradient.addColorStop(0, "rgba(0, 0, 0, 0)")
      gradient.addColorStop(1, "rgba(0, 0, 0, 0.4)")

      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Add RGB shift effect
      ctx.globalCompositeOperation = "screen"

      // Red channel
      ctx.fillStyle = "rgba(255, 0, 0, 0.03)"
      ctx.fillRect(2, 0, canvas.width, canvas.height)

      // Blue channel
      ctx.fillStyle = "rgba(0, 0, 255, 0.03)"
      ctx.fillRect(-2, 0, canvas.width, canvas.height)

      ctx.globalCompositeOperation = "source-over"

      // Continue animation
      animationFrame = requestAnimationFrame(renderFrame)
    }

    if (isLoaded) {
      renderFrame()
    }

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      cancelAnimationFrame(animationFrame)
    }
  }, [isLoaded])

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Hidden video element for source material */}
      <video
        ref={videoRef}
        className="hidden"
        muted
        loop
        playsInline
        preload="auto"
        src="/videos/football-gameplay.mp4" // This would be your actual video
      >
        <source src="/videos/football-gameplay.mp4" type="video/mp4" />
      </video>

      {/* Canvas for rendering the effect */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover" />

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background z-[1]"></div>

      {/* Grid overlay */}
      <div className="absolute inset-0 grid-bg opacity-30 z-[2]"></div>
    </div>
  )
}
