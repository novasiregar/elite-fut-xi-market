"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, TrendingUp } from "lucide-react"
import { triggerHaptic } from "@/utils/haptic"

interface PopularSearchesProps {
  onSelect: (query: string) => void
}

export function PopularSearches({ onSelect }: PopularSearchesProps) {
  const [popularSearches, setPopularSearches] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchPopularSearches = async () => {
      setIsLoading(true)
      try {
        // In a real app, this would fetch from your API
        // For now, we'll simulate a delay and return mock data
        await new Promise((resolve) => setTimeout(resolve, 500))

        setPopularSearches([
          "FIFA 23 Ultimate Team",
          "eFootball 2023",
          "FC 24",
          "PES 2021",
          "Football Manager 2023",
          "FIFA Mobile",
          "Dream League Soccer",
          "Top Eleven",
        ])
      } catch (error) {
        console.error("Error fetching popular searches:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPopularSearches()
  }, [])

  const handleSelect = (query: string) => {
    triggerHaptic("light")
    onSelect(query)
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-4 w-4 text-primary" />
          <h2 className="text-lg font-medium">Popular Searches</h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {Array(8)
            .fill(0)
            .map((_, index) => (
              <Skeleton key={index} className="h-8 w-32" />
            ))}
        </div>
      </div>
    )
  }

  if (popularSearches.length === 0) {
    return null
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-4 w-4 text-primary" />
        <h2 className="text-lg font-medium">Popular Searches</h2>
      </div>

      <div className="flex flex-wrap gap-2">
        {popularSearches.map((query, index) => (
          <Button key={index} variant="outline" size="sm" className="h-8 text-xs" onClick={() => handleSelect(query)}>
            <Search className="h-3 w-3 mr-1" />
            {query}
          </Button>
        ))}
      </div>
    </div>
  )
}
