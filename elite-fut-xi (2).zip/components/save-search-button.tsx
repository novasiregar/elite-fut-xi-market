"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Bookmark, Check } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { SearchService } from "@/client/services/search"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/utils/haptic"

interface SaveSearchProps {
  query: string
  filters: any
  resultCount: number
}

export function SaveSearch({ query, filters, resultCount }: SaveSearchProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [searchName, setSearchName] = useState("")
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [isSaved, setIsSaved] = useState(false)
  const { toast } = useToast()

  const handleSave = async () => {
    if (!searchName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a name for your search",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    triggerHaptic("medium")

    try {
      await SearchService.saveSearch({
        name: searchName,
        query,
        filters,
        notificationsEnabled,
      })

      setIsSaved(true)
      toast({
        title: "Search saved",
        description: "You'll be notified when new listings match your search",
        variant: "default",
      })

      // Close dialog after a delay
      setTimeout(() => {
        setIsOpen(false)
        // Reset form after dialog closes
        setTimeout(() => {
          setSearchName("")
          setNotificationsEnabled(true)
          setIsSaved(false)
        }, 300)
      }, 1500)
    } catch (error) {
      console.error("Error saving search:", error)
      toast({
        title: "Error",
        description: "Failed to save search. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="text-xs flex items-center gap-1"
          onClick={() => triggerHaptic("light")}
        >
          <Bookmark className="h-3 w-3" />
          Save this search
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Save Search</DialogTitle>
          <DialogDescription>Save this search to get notified when new listings match your criteria.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="search-name">Search Name</Label>
            <Input
              id="search-name"
              placeholder="e.g., FIFA 23 Ultimate Team"
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              disabled={isSaving || isSaved}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Search Details</Label>
            <div className="bg-muted p-3 rounded-md text-sm">
              <p>
                <span className="font-medium">Query:</span> {query || "(None)"}
              </p>
              <p>
                <span className="font-medium">Filters:</span>{" "}
                {Object.keys(filters).length > 0
                  ? Object.entries(filters)
                      .map(([key, value]) => `${key}: ${value}`)
                      .join(", ")
                  : "None"}
              </p>
              <p>
                <span className="font-medium">Results:</span> {resultCount}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="notifications"
              checked={notificationsEnabled}
              onCheckedChange={setNotificationsEnabled}
              disabled={isSaving || isSaved}
            />
            <Label htmlFor="notifications">Notify me when new listings match this search</Label>
          </div>
        </div>

        <DialogFooter>
          {isSaved ? (
            <Button disabled className="w-full sm:w-auto">
              <Check className="h-4 w-4 mr-2" />
              Saved
            </Button>
          ) : (
            <Button onClick={handleSave} disabled={isSaving || !searchName.trim()} className="w-full sm:w-auto">
              {isSaving ? "Saving..." : "Save Search"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
