"use client"

import { useState, useEffect, type ReactNode } from "react"

type Orientation = "portrait" | "landscape" | "unknown"

interface OrientationHandlerProps {
  children: ReactNode
  portrait?: ReactNode
  landscape?: ReactNode
  onOrientationChange?: (orientation: Orientation) => void
  className?: string
}

export function OrientationHandler({
  children,
  portrait,
  landscape,
  onOrientationChange,
  className,
}: OrientationHandlerProps) {
  const [orientation, setOrientation] = useState<Orientation>("unknown")

  // Detect initial orientation
  useEffect(() => {
    const detectOrientation = () => {
      if (window.matchMedia("(orientation: portrait)").matches) {
        setOrientation("portrait")
      } else {
        setOrientation("landscape")
      }
    }

    detectOrientation()

    // Listen for orientation changes
    const handleOrientationChange = () => {
      detectOrientation()
    }

    window.addEventListener("resize", handleOrientationChange)
    window.addEventListener("orientationchange", handleOrientationChange)

    return () => {
      window.removeEventListener("resize", handleOrientationChange)
      window.removeEventListener("orientationchange", handleOrientationChange)
    }
  }, [])

  // Call onOrientationChange when orientation changes
  useEffect(() => {
    if (orientation !== "unknown" && onOrientationChange) {
      onOrientationChange(orientation)
    }
  }, [orientation, onOrientationChange])

  // Render based on orientation
  if (orientation === "portrait" && portrait) {
    return <div className={className}>{portrait}</div>
  }

  if (orientation === "landscape" && landscape) {
    return <div className={className}>{landscape}</div>
  }

  // Default rendering
  return <div className={className}>{children}</div>
}

// Hook for using orientation
export function useOrientation() {
  const [orientation, setOrientation] = useState<Orientation>("unknown")
  const [isPortrait, setIsPortrait] = useState<boolean | null>(null)
  const [isLandscape, setIsLandscape] = useState<boolean | null>(null)

  useEffect(() => {
    const detectOrientation = () => {
      if (window.matchMedia("(orientation: portrait)").matches) {
        setOrientation("portrait")
        setIsPortrait(true)
        setIsLandscape(false)
      } else {
        setOrientation("landscape")
        setIsPortrait(false)
        setIsLandscape(true)
      }
    }

    detectOrientation()

    const handleOrientationChange = () => {
      detectOrientation()
    }

    window.addEventListener("resize", handleOrientationChange)
    window.addEventListener("orientationchange", handleOrientationChange)

    return () => {
      window.removeEventListener("resize", handleOrientationChange)
      window.removeEventListener("orientationchange", handleOrientationChange)
    }
  }, [])

  return { orientation, isPortrait, isLandscape }
}
