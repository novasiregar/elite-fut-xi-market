"use client"

import { useEffect, useState } from "react"
import { Zap } from "lucide-react"

const newsItems = [
  "🔥 New FIFA 25 accounts just added!",
  "⚡ Limited time offer: 20% off all premium accounts",
  "🏆 Champions League ready accounts available now",
  "💰 Sell your account in under 24 hours - guaranteed",
  "🛡️ All transactions protected by our secure escrow system",
  "🌟 New verified sellers joined this week",
]

export function NewsMarquee() {
  const [duplicatedItems, setDuplicatedItems] = useState<string[]>([])

  useEffect(() => {
    // Duplicate items to create seamless loop
    setDuplicatedItems([...newsItems, ...newsItems])
  }, [])

  return (
    <div className="w-full bg-primary/10 border-y border-primary/30 py-2 overflow-hidden">
      <div className="flex items-center">
        <div className="flex-shrink-0 bg-primary/20 rounded-full p-1 mx-4">
          <Zap className="h-4 w-4 text-primary" />
        </div>

        <div className="overflow-hidden relative w-full">
          <div className="animate-marquee whitespace-nowrap flex">
            {duplicatedItems.map((item, index) => (
              <span key={index} className="mx-4 text-sm font-futuristic">
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
