"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Info } from "lucide-react"
import { useLanguage } from "@/context/language-context"

type ComplianceIssue = {
  id: string
  type: "error" | "warning" | "info"
  description: string
  element?: string
  guideline: string
}

export function WcagComplianceChecker() {
  const { t } = useLanguage()
  const [issues, setIssues] = useState<ComplianceIssue[]>([])
  const [isChecking, setIsChecking] = useState(false)
  const [lastChecked, setLastChecked] = useState<Date | null>(null)

  const runAccessibilityCheck = () => {
    setIsChecking(true)

    // Simulate checking process
    setTimeout(() => {
      // This would be replaced with actual accessibility checking logic
      const detectedIssues: ComplianceIssue[] = [
        {
          id: "1",
          type: "error",
          description: "Some images are missing alternative text",
          element: "img",
          guideline: "WCAG 1.1.1 Non-text Content (Level A)",
        },
        {
          id: "2",
          type: "warning",
          description: "Color contrast ratio is below 4.5:1 in some text elements",
          element: ".low-contrast-text",
          guideline: "WCAG 1.4.3 Contrast (Minimum) (Level AA)",
        },
        {
          id: "3",
          type: "info",
          description: "Consider adding ARIA landmarks for better screen reader navigation",
          guideline: "WCAG 2.4.1 Bypass Blocks (Level A)",
        },
      ]

      setIssues(detectedIssues)
      setIsChecking(false)
      setLastChecked(new Date())
    }, 2000)
  }

  useEffect(() => {
    // Initial check on component mount
    runAccessibilityCheck()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("accessibility.wcagComplianceChecker")}</CardTitle>
        <CardDescription>{t("accessibility.wcagComplianceCheckerDescription")}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {issues.length === 0 && !isChecking ? (
            <div className="flex items-center justify-center p-6 bg-muted/30 rounded-lg">
              <p className="text-muted-foreground">{t("accessibility.noIssuesFound")}</p>
            </div>
          ) : (
            issues.map((issue) => (
              <Alert
                key={issue.id}
                variant={issue.type === "error" ? "destructive" : issue.type === "warning" ? "default" : "outline"}
              >
                {issue.type === "error" ? (
                  <AlertTriangle className="h-4 w-4" />
                ) : issue.type === "warning" ? (
                  <AlertTriangle className="h-4 w-4" />
                ) : (
                  <Info className="h-4 w-4" />
                )}
                <AlertTitle className="flex items-center gap-2">
                  {issue.type === "error"
                    ? t("accessibility.error")
                    : issue.type === "warning"
                      ? t("accessibility.warning")
                      : t("accessibility.info")}
                  <Badge variant="outline" className="ml-2">
                    {issue.guideline}
                  </Badge>
                </AlertTitle>
                <AlertDescription>
                  <p>{issue.description}</p>
                  {issue.element && (
                    <code className="text-xs bg-muted p-1 rounded mt-1 inline-block">{issue.element}</code>
                  )}
                </AlertDescription>
              </Alert>
            ))
          )}

          {isChecking && (
            <div className="flex items-center justify-center p-6">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <span className="ml-2">{t("accessibility.checkingCompliance")}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="text-sm text-muted-foreground">
          {lastChecked && (
            <span>
              {t("accessibility.lastChecked")}: {lastChecked.toLocaleString()}
            </span>
          )}
        </div>
        <Button onClick={runAccessibilityCheck} disabled={isChecking}>
          {isChecking ? t("common.checking") : t("accessibility.runCheck")}
        </Button>
      </CardFooter>
    </Card>
  )
}
