"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PaymentService, PaymentStatus } from "@/client/services/payments"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Check, Copy, ExternalLink, RefreshCw, Upload, X } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { motion, AnimatePresence } from "framer-motion"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface EnhancedPaymentFlowProps {
  transactionId: string
  amount: number
  onPaymentComplete?: () => void
  onPaymentCancel?: () => void
}

export function EnhancedPaymentFlow({
  transactionId,
  amount,
  onPaymentComplete,
  onPaymentCancel,
}: EnhancedPaymentFlowProps) {
  const [selectedMethod, setSelectedMethod] = useState<string>("")
  const [paymentMethods, setPaymentMethods] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [initializing, setInitializing] = useState(false)
  const [paymentReference, setPaymentReference] = useState<string | null>(null)
  const [paymentDetails, setPaymentDetails] = useState<any | null>(null)
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus | null>(null)
  const [statusCheckInterval, setStatusCheckInterval] = useState<NodeJS.Timeout | null>(null)
  const [timeLeft, setTimeLeft] = useState<number | null>(null)
  const [receiptFile, setReceiptFile] = useState<File | null>(null)
  const [uploadingReceipt, setUploadingReceipt] = useState(false)
  const [copiedText, setCopiedText] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()
  const { triggerHaptic } = useHapticFeedback()

  // Load payment methods
  useEffect(() => {
    setPaymentMethods(PaymentService.getPaymentMethods())
  }, [])

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (statusCheckInterval) {
        clearInterval(statusCheckInterval)
      }
    }
  }, [statusCheckInterval])

  // Update time left
  useEffect(() => {
    if (!paymentDetails?.expiresAt) return

    const updateTimeLeft = () => {
      const expiresAt = new Date(paymentDetails.expiresAt).getTime()
      const now = Date.now()
      const diff = expiresAt - now

      if (diff <= 0) {
        setTimeLeft(0)
        // Payment expired, check status one last time
        checkPaymentStatus()
        return
      }

      setTimeLeft(diff)
    }

    updateTimeLeft()
    const interval = setInterval(updateTimeLeft, 1000)

    return () => clearInterval(interval)
  }, [paymentDetails])

  const initializePayment = async () => {
    if (!selectedMethod) {
      toast({
        title: "Please select a payment method",
        variant: "destructive",
      })
      return
    }

    try {
      setInitializing(true)
      triggerHaptic("medium")

      const result = await PaymentService.initializePayment(transactionId, selectedMethod)
      setPaymentReference(result.paymentReference)
      setPaymentDetails(result.paymentDetails)
      setPaymentStatus(PaymentStatus.PENDING)

      // Start checking payment status
      const interval = setInterval(checkPaymentStatus, 10000) // Check every 10 seconds
      setStatusCheckInterval(interval)

      toast({
        title: "Payment initialized",
        description: "Please complete the payment using your selected method",
      })
    } catch (error: any) {
      console.error("Initialize payment error:", error)
      toast({
        title: "Failed to initialize payment",
        description: error.message || "Please try again or select a different payment method",
        variant: "destructive",
      })
    } finally {
      setInitializing(false)
    }
  }

  const checkPaymentStatus = async () => {
    if (!paymentReference) return

    try {
      setLoading(true)
      const payment = await PaymentService.checkPaymentStatus(paymentReference)
      setPaymentStatus(payment.status)

      // If payment is completed, stop checking
      if (
        payment.status === PaymentStatus.COMPLETED ||
        payment.status === PaymentStatus.FAILED ||
        payment.status === PaymentStatus.EXPIRED
      ) {
        if (statusCheckInterval) {
          clearInterval(statusCheckInterval)
          setStatusCheckInterval(null)
        }

        if (payment.status === PaymentStatus.COMPLETED) {
          triggerHaptic("success")
          toast({
            title: "Payment successful",
            description: "Your payment has been processed successfully",
            variant: "default",
          })
          if (onPaymentComplete) {
            onPaymentComplete()
          }
        } else if (payment.status === PaymentStatus.FAILED) {
          triggerHaptic("error")
          toast({
            title: "Payment failed",
            description: "Your payment could not be processed. Please try again.",
            variant: "destructive",
          })
        } else if (payment.status === PaymentStatus.EXPIRED) {
          triggerHaptic("warning")
          toast({
            title: "Payment expired",
            description: "Your payment session has expired. Please try again.",
            variant: "destructive",
          })
        }
      }
    } catch (error) {
      console.error("Check payment status error:", error)
    } finally {
      setLoading(false)
    }
  }

  const cancelPayment = async () => {
    if (!paymentReference) return

    try {
      setLoading(true)
      triggerHaptic("medium")

      await PaymentService.cancelPayment(paymentReference)

      if (statusCheckInterval) {
        clearInterval(statusCheckInterval)
        setStatusCheckInterval(null)
      }

      setPaymentStatus(PaymentStatus.CANCELLED)

      toast({
        title: "Payment cancelled",
        description: "Your payment has been cancelled",
      })

      if (onPaymentCancel) {
        onPaymentCancel()
      }
    } catch (error: any) {
      console.error("Cancel payment error:", error)
      toast({
        title: "Failed to cancel payment",
        description: error.message || "Please try again",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceiptFile(e.target.files[0])
    }
  }

  const uploadReceipt = async () => {
    if (!paymentReference || !receiptFile) return

    try {
      setUploadingReceipt(true)
      triggerHaptic("medium")

      // Convert file to base64
      const reader = new FileReader()
      reader.readAsDataURL(receiptFile)

      reader.onload = async () => {
        const base64data = reader.result

        // Send to server
        await PaymentService.verifyPayment(paymentReference, {
          receipt: base64data,
          filename: receiptFile.name,
          contentType: receiptFile.type,
        })

        setPaymentStatus(PaymentStatus.PROCESSING)

        toast({
          title: "Receipt uploaded",
          description: "Your payment receipt is being verified",
        })

        setUploadingReceipt(false)
      }
    } catch (error: any) {
      console.error("Upload receipt error:", error)
      toast({
        title: "Failed to upload receipt",
        description: error.message || "Please try again",
        variant: "destructive",
      })
      setUploadingReceipt(false)
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    setCopiedText(label)
    triggerHaptic("light")

    toast({
      title: "Copied to clipboard",
      description: `${label} has been copied to your clipboard`,
      duration: 2000,
    })

    setTimeout(() => {
      setCopiedText(null)
    }, 2000)
  }

  const formatTimeLeft = () => {
    if (timeLeft === null) return ""

    const minutes = Math.floor(timeLeft / 60000)
    const seconds = Math.floor((timeLeft % 60000) / 1000)

    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const getProgressValue = () => {
    if (!timeLeft || !paymentDetails?.expiresAt) return 100

    const expiresAt = new Date(paymentDetails.expiresAt).getTime()
    const startTime = expiresAt - (selectedMethod === "bank_transfer" ? 24 * 60 * 60 * 1000 : 15 * 60 * 1000)
    const totalTime = expiresAt - startTime
    const elapsed = Date.now() - startTime

    return Math.max(0, Math.min(100, (elapsed / totalTime) * 100))
  }

  // Render payment method selection
  if (!paymentReference) {
    return (
      <Card className="w-full max-w-md mx-auto bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-futuristic">SELECT PAYMENT METHOD</CardTitle>
          <CardDescription>Choose how you want to pay for your purchase</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod} className="space-y-3">
            {paymentMethods.map((method) => {
              const fee = PaymentService.calculateFee(amount, method.id)
              const total = amount + fee

              return (
                <div
                  key={method.id}
                  className={`flex items-center space-x-3 rounded-md border p-3 cursor-pointer transition-colors ${
                    selectedMethod === method.id ? "border-primary bg-primary/5" : "border-border"
                  }`}
                  onClick={() => setSelectedMethod(method.id)}
                >
                  <RadioGroupItem value={method.id} id={method.id} />
                  <div className="flex flex-1 items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Image
                        src={method.icon || "/placeholder.svg"}
                        alt={method.name}
                        width={32}
                        height={32}
                        className="rounded-md"
                      />
                      <div>
                        <Label htmlFor={method.id} className="font-medium">
                          {method.name}
                        </Label>
                        <p className="text-xs text-muted-foreground">{method.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Fee: Rp {fee.toLocaleString()}</p>
                      <p className="font-medium">Rp {total.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </RadioGroup>

          <div className="mt-6 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Subtotal:</span>
              <span>Rp {amount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Fee:</span>
              <span>
                Rp {(selectedMethod ? PaymentService.calculateFee(amount, selectedMethod) : 0).toLocaleString()}
              </span>
            </div>
            <Separator className="my-2" />
            <div className="flex justify-between font-medium">
              <span>Total:</span>
              <span>
                Rp {(selectedMethod ? PaymentService.calculateTotal(amount, selectedMethod) : amount).toLocaleString()}
              </span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onPaymentCancel}>
            Cancel
          </Button>
          <Button onClick={initializePayment} disabled={!selectedMethod || initializing}>
            {initializing ? "Processing..." : "Continue to Payment"}
          </Button>
        </CardFooter>
      </Card>
    )
  }

  // Render payment details
  return (
    <Card className="w-full max-w-md mx-auto bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="font-futuristic">COMPLETE YOUR PAYMENT</CardTitle>
        <CardDescription>
          {paymentStatus === PaymentStatus.PENDING && "Please complete your payment using the details below"}
          {paymentStatus === PaymentStatus.PROCESSING && "Your payment is being processed"}
          {paymentStatus === PaymentStatus.COMPLETED && "Your payment has been completed successfully"}
          {paymentStatus === PaymentStatus.FAILED && "Your payment has failed"}
          {paymentStatus === PaymentStatus.EXPIRED && "Your payment session has expired"}
          {paymentStatus === PaymentStatus.CANCELLED && "Your payment has been cancelled"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <AnimatePresence mode="wait">
          {paymentStatus === PaymentStatus.PENDING && (
            <motion.div
              key="pending"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              {/* Time remaining */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Time remaining:</span>
                  <span className="font-mono">{formatTimeLeft()}</span>
                </div>
                <Progress value={getProgressValue()} className="h-2" />
              </div>

              {/* Payment method specific UI */}
              {selectedMethod === "gopay" && paymentDetails?.qrCode && (
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <div className="bg-white p-4 rounded-md">
                      <Image
                        src={paymentDetails.qrCode || "/placeholder.svg"}
                        alt="GoPay QR Code"
                        width={200}
                        height={200}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-center">Scan this QR code with your GoPay app</p>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        if (paymentDetails.deepLink) {
                          window.location.href = paymentDetails.deepLink
                        }
                      }}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Open GoPay App
                    </Button>
                  </div>
                </div>
              )}

              {selectedMethod === "ovo" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Enter your OVO phone number</Label>
                    <div className="flex space-x-2">
                      <input
                        type="tel"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="e.g. 08123456789"
                      />
                      <Button>Send</Button>
                    </div>
                    <p className="text-xs text-muted-foreground">We'll send a payment request to your OVO account</p>
                  </div>
                </div>
              )}

              {selectedMethod === "dana" && paymentDetails?.qrCode && (
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <div className="bg-white p-4 rounded-md">
                      <Image
                        src={paymentDetails.qrCode || "/placeholder.svg"}
                        alt="DANA QR Code"
                        width={200}
                        height={200}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-center">Scan this QR code with your DANA app</p>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        if (paymentDetails.deepLink) {
                          window.location.href = paymentDetails.deepLink
                        }
                      }}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Open DANA App
                    </Button>
                  </div>
                </div>
              )}

              {selectedMethod === "bank_transfer" && paymentDetails?.bankAccounts && (
                <div className="space-y-4">
                  <Tabs defaultValue={paymentDetails.bankAccounts[0].bank.toLowerCase()}>
                    <TabsList className="grid grid-cols-3">
                      {paymentDetails.bankAccounts.map((account: any) => (
                        <TabsTrigger key={account.bank} value={account.bank.toLowerCase()}>
                          {account.bank}
                        </TabsTrigger>
                      ))}
                    </TabsList>

                    {paymentDetails.bankAccounts.map((account: any) => (
                      <TabsContent key={account.bank} value={account.bank.toLowerCase()} className="space-y-4 mt-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm">Bank:</span>
                            <span className="font-medium">{account.bank}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Account Number:</span>
                            <div className="flex items-center space-x-2">
                              <span className="font-mono">{account.accountNumber}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard(account.accountNumber, "Account number")}
                              >
                                {copiedText === "Account number" ? (
                                  <Check className="h-4 w-4" />
                                ) : (
                                  <Copy className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Account Name:</span>
                            <span>{account.accountName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Amount:</span>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">Rp {paymentDetails.amount.toLocaleString()}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard(paymentDetails.amount.toString(), "Amount")}
                              >
                                {copiedText === "Amount" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                              </Button>
                            </div>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Reference:</span>
                            <div className="flex items-center space-x-2">
                              <span className="font-mono text-xs">{paymentReference}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard(paymentReference, "Reference")}
                              >
                                {copiedText === "Reference" ? (
                                  <Check className="h-4 w-4" />
                                ) : (
                                  <Copy className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <p className="text-sm text-muted-foreground">
                            Please include the reference number in your transfer description
                          </p>
                          <div className="border border-border rounded-md p-3 bg-background/50">
                            <p className="text-xs">
                              After making the transfer, please upload your payment receipt for faster verification:
                            </p>
                            <div className="mt-2 flex items-center space-x-2">
                              <input
                                type="file"
                                id="receipt"
                                className="hidden"
                                accept="image/*"
                                onChange={handleFileChange}
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("receipt")?.click()}
                              >
                                {receiptFile ? receiptFile.name : "Select Receipt"}
                              </Button>
                              {receiptFile && (
                                <Button size="sm" onClick={uploadReceipt} disabled={uploadingReceipt}>
                                  {uploadingReceipt ? "Uploading..." : "Upload"}
                                  <Upload className="h-4 w-4 ml-2" />
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    ))}
                  </Tabs>
                </div>
              )}
            </motion.div>
          )}

          {paymentStatus === PaymentStatus.PROCESSING && (
            <motion.div
              key="processing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div className="flex flex-col items-center justify-center py-6">
                <div className="relative h-16 w-16">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <RefreshCw className="h-8 w-8 text-primary animate-spin" />
                  </div>
                </div>
                <h3 className="mt-4 text-lg font-medium">Processing Your Payment</h3>
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  We're verifying your payment. This may take a few moments.
                </p>
              </div>
            </motion.div>
          )}

          {paymentStatus === PaymentStatus.COMPLETED && (
            <motion.div
              key="completed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div className="flex flex-col items-center justify-center py-6">
                <div className="relative h-16 w-16">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                      <Check className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                </div>
                <h3 className="mt-4 text-lg font-medium">Payment Successful</h3>
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  Your payment has been processed successfully. The seller has been notified.
                </p>
              </div>
            </motion.div>
          )}

          {(paymentStatus === PaymentStatus.FAILED ||
            paymentStatus === PaymentStatus.EXPIRED ||
            paymentStatus === PaymentStatus.CANCELLED) && (
            <motion.div
              key="failed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <div className="flex flex-col items-center justify-center py-6">
                <div className="relative h-16 w-16">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-16 w-16 rounded-full bg-red-100 flex items-center justify-center">
                      <X className="h-8 w-8 text-red-600" />
                    </div>
                  </div>
                </div>
                <h3 className="mt-4 text-lg font-medium">
                  {paymentStatus === PaymentStatus.FAILED && "Payment Failed"}
                  {paymentStatus === PaymentStatus.EXPIRED && "Payment Expired"}
                  {paymentStatus === PaymentStatus.CANCELLED && "Payment Cancelled"}
                </h3>
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  {paymentStatus === PaymentStatus.FAILED &&
                    "Your payment could not be processed. Please try again with a different payment method."}
                  {paymentStatus === PaymentStatus.EXPIRED && "Your payment session has expired. Please try again."}
                  {paymentStatus === PaymentStatus.CANCELLED && "Your payment has been cancelled."}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
      <CardFooter className="flex justify-between">
        {paymentStatus === PaymentStatus.PENDING && (
          <>
            <Button variant="outline" onClick={cancelPayment} disabled={loading}>
              Cancel Payment
            </Button>
            <Button onClick={checkPaymentStatus} disabled={loading}>
              {loading ? "Checking..." : "Check Status"}
            </Button>
          </>
        )}

        {paymentStatus === PaymentStatus.PROCESSING && (
          <Button className="w-full" onClick={checkPaymentStatus} disabled={loading}>
            {loading ? "Checking..." : "Refresh Status"}
          </Button>
        )}

        {paymentStatus === PaymentStatus.COMPLETED && (
          <Button className="w-full" onClick={onPaymentComplete}>
            Continue
          </Button>
        )}

        {(paymentStatus === PaymentStatus.FAILED ||
          paymentStatus === PaymentStatus.EXPIRED ||
          paymentStatus === PaymentStatus.CANCELLED) && (
          <Button className="w-full" onClick={onPaymentCancel}>
            Try Again
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
