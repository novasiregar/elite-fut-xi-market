"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { OptimizedImage } from "@/components/optimized-image"
import { Skeleton } from "@/components/ui/skeleton"
import { Sparkles, ChevronRight, ChevronLeft } from "lucide-react"
import type { Listing } from "@/client/services/listings"
import { useAuth } from "@/context/auth-context"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"

interface PersonalizedRecommendationsProps {
  context?: string
  title?: string
  limit?: number
}

export function PersonalizedRecommendations({
  context = "homepage",
  title = "Recommended for You",
  limit = 10,
}: PersonalizedRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<Listing[]>([])
  const [loading, setLoading] = useState(true)
  const [scrollPosition, setScrollPosition] = useState(0)
  const { user } = useAuth()
  const { triggerHaptic } = useHapticFeedback()

  useEffect(() => {
    async function fetchRecommendations() {
      setLoading(true)
      try {
        if (user) {
          // Fetch personalized recommendations for logged-in users
          const response = await fetch(`/api/search/recommendations?limit=${limit}&context=${context}`)
          const data = await response.json()
          setRecommendations(data.recommendations)
        } else {
          // Fetch popular listings for guests
          const response = await fetch(`/api/listings/popular?limit=${limit}`)
          const data = await response.json()
          setRecommendations(data.listings)
        }
      } catch (error) {
        console.error("Error fetching recommendations:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRecommendations()
  }, [user, context, limit])

  const handleScroll = (direction: "left" | "right") => {
    triggerHaptic("light")
    const container = document.getElementById("recommendations-container")
    if (!container) return

    const scrollAmount = direction === "left" ? -300 : 300
    const newPosition = scrollPosition + scrollAmount

    container.scrollTo({
      left: newPosition,
      behavior: "smooth",
    })

    setScrollPosition(newPosition)
  }

  if (loading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-8 w-20" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array(5)
            .fill(0)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="aspect-square w-full" />
                <CardContent className="p-3">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    )
  }

  if (recommendations.length === 0) {
    return null
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          {title}
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleScroll("left")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleScroll("right")}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div id="recommendations-container" className="flex overflow-x-auto scrollbar-hide gap-4 pb-2">
        {recommendations.map((listing) => (
          <Link
            href={`/listings/${listing.id}`}
            key={listing.id}
            className="min-w-[200px] max-w-[200px] bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="aspect-square relative">
              <OptimizedImage
                src={listing.media?.[0]?.url || "/placeholder.svg?height=200&width=200"}
                alt={listing.title}
                fill
                className="object-cover"
                sizes="200px"
              />
              {listing.featured && (
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                  Featured
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="font-medium text-sm line-clamp-2">{listing.title}</h3>
              <p className="text-primary font-bold mt-1">Rp {listing.price.toLocaleString("id-ID")}</p>
              <div className="flex items-center mt-2 text-xs text-muted-foreground">
                <span>{listing.sellerName}</span>
                <span className="ml-auto flex items-center">★ {listing.rating || "N/A"}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
