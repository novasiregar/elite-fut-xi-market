"use client"

import { useLanguage } from "@/context/language-context"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Globe } from "lucide-react"
import { motion } from "framer-motion"

export function LanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-8 w-8 text-muted-foreground hover:text-foreground"
          aria-label={t("common.language")}
        >
          <Globe className="h-4 w-4" />
          <motion.div
            layoutId="language-indicator"
            className="absolute bottom-0 left-1/2 h-0.5 w-4 -translate-x-1/2 bg-primary"
            initial={false}
            transition={{ type: "spring", duration: 0.2 }}
          />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        <DropdownMenuItem className={language === "en" ? "bg-muted" : ""} onClick={() => setLanguage("en")}>
          <span className="mr-2">🇺🇸</span>
          {t("common.english")}
        </DropdownMenuItem>
        <DropdownMenuItem className={language === "id" ? "bg-muted" : ""} onClick={() => setLanguage("id")}>
          <span className="mr-2">🇮🇩</span>
          {t("common.indonesian")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
