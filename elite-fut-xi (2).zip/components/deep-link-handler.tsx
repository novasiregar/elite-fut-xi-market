"use client"

import { useEffect, useRef } from "react"
import { useRouter, usePathname, useSearchParams } from "next/navigation"
import { registerDeepLinkHandlers, parseDeepLink } from "@/utils/deep-linking"
import { useToast } from "@/components/ui/use-toast"

export function DeepLinkHandler() {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const initializedRef = useRef(false)

  useEffect(() => {
    if (initializedRef.current) return
    initializedRef.current = true

    // Register deep link handlers
    registerDeepLinkHandlers()

    // Handle initial URL
    const handleInitialDeepLink = () => {
      const url = window.location.href
      const parsedLink = parseDeepLink(url)

      if (!parsedLink) return

      // Check if we need to redirect
      if (parsedLink.route !== pathname) {
        // Handle specific deep link routes
        switch (parsedLink.route) {
          case "/listing":
          case "/listings":
            if (parsedLink.params?.id) {
              router.push(`/listings/${parsedLink.params.id}`)
              toast({
                title: "Deep Link Detected",
                description: "Redirecting to listing details",
              })
            }
            break

          case "/seller":
            if (parsedLink.params?.id) {
              router.push(`/profile/${parsedLink.params.id}`)
              toast({
                title: "Deep Link Detected",
                description: "Redirecting to seller profile",
              })
            }
            break

          case "/category":
            if (parsedLink.params?.id) {
              router.push(`/marketplace?category=${parsedLink.params.id}`)
              toast({
                title: "Deep Link Detected",
                description: "Redirecting to category",
              })
            }
            break

          case "/search":
            if (parsedLink.params?.q) {
              router.push(`/marketplace?search=${parsedLink.params.q}`)
              toast({
                title: "Deep Link Detected",
                description: "Redirecting to search results",
              })
            }
            break

          case "/message":
            if (parsedLink.params?.userId) {
              router.push(`/messages?userId=${parsedLink.params.userId}`)
              toast({
                title: "Deep Link Detected",
                description: "Opening message conversation",
              })
            }
            break

          default:
            // For other routes, just navigate directly
            if (parsedLink.route) {
              router.push(parsedLink.route)
            }
        }
      }
    }

    // Handle the initial deep link after a short delay
    // This ensures the app is fully loaded
    setTimeout(handleInitialDeepLink, 500)
  }, [pathname, router, toast])

  // This component doesn't render anything
  return null
}
