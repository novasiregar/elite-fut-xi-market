"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Home, Search, ShoppingBag, MessageCircle, User, Menu, X } from "lucide-react"
import { PixelLogo } from "@/components/pixel-logo"
import { useHapticFeedback } from "@/hooks/use-haptic-feedback"
import { EnhancedThemeToggle } from "@/components/enhanced-theme-toggle"
import { LanguageSwitcher } from "@/components/language-switcher"
import { AccessibilityMenu } from "@/components/accessibility-menu"
import { useLanguage } from "@/context/language-context"

export function EnhancedMobileNavbar() {
  const pathname = usePathname()
  const { triggerTap } = useHapticFeedback()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const { t } = useLanguage()

  const toggleMenu = () => {
    triggerTap()
    setIsMenuOpen(!isMenuOpen)
  }

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false)
  }, [pathname])

  const navItems = [
    { href: "/", icon: <Home className="h-5 w-5" />, label: t("common.home") },
    { href: "/marketplace", icon: <ShoppingBag className="h-5 w-5" />, label: t("common.marketplace") },
    { href: "/messages", icon: <MessageCircle className="h-5 w-5" />, label: t("common.messages") },
    { href: "/profile", icon: <User className="h-5 w-5" />, label: t("common.profile") },
  ]

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled ? "bg-background/80 backdrop-blur-md shadow-md" : "bg-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-16 px-4">
          <Link href="/" className="flex items-center gap-2" aria-label="ELITE FUT XI Market">
            <PixelLogo size={32} />
            <span className="font-pixel text-sm hidden sm:inline-block">ELITE FUT XI</span>
          </Link>

          <div className="flex items-center gap-2">
            <Link
              href="/search"
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label={t("common.search")}
            >
              <Search className="h-5 w-5" />
            </Link>

            <LanguageSwitcher />
            <AccessibilityMenu />

            <button
              onClick={toggleMenu}
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label={isMenuOpen ? t("common.closeMenu") : t("common.openMenu")}
              aria-expanded={isMenuOpen}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="fixed top-16 left-0 right-0 z-30 bg-background/95 backdrop-blur-lg shadow-lg border-b border-border"
          >
            <nav className="container py-4 px-4">
              <ul className="space-y-2">
                {navItems.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        pathname === item.href ? "bg-primary/10 text-primary" : "hover:bg-muted"
                      }`}
                      onClick={() => triggerTap()}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </Link>
                  </li>
                ))}
              </ul>

              <div className="mt-6 pt-6 border-t border-border">
                <h3 className="text-sm font-medium mb-4">{t("common.appearance")}</h3>
                <EnhancedThemeToggle />
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="h-16" /> {/* Spacer for fixed header */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-md border-t border-border">
        <div className="container flex items-center justify-around h-16">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-colors ${
                pathname === item.href ? "text-primary" : "text-muted-foreground"
              }`}
              onClick={() => triggerTap()}
              aria-label={item.label}
              aria-current={pathname === item.href ? "page" : undefined}
            >
              {item.icon}
              <span className="text-xs">{item.label}</span>
              {pathname === item.href && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute bottom-1 h-1 w-10 bg-primary rounded-full"
                  transition={{ type: "spring", duration: 0.3 }}
                />
              )}
            </Link>
          ))}
        </div>
      </nav>
      <div className="h-16" /> {/* Spacer for fixed footer */}
    </>
  )
}
