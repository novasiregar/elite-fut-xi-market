import { getOptimizedImageServer } from "@/utils/server-image-optimization"
import { OptimizedImage } from "@/components/optimized-image"

interface ServerOptimizedImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  priority?: boolean
  className?: string
  sizes?: string
  fill?: boolean
}

export async function ServerOptimizedImage({
  src,
  alt,
  width,
  height,
  priority = false,
  className = "",
  sizes,
  fill = false,
}: ServerOptimizedImageProps) {
  // Get optimized image data on the server
  const imageData = await getOptimizedImageServer(src)

  // Pass the data to the client component
  return (
    <OptimizedImage
      src={imageData.src}
      alt={alt}
      width={width || imageData.width}
      height={height || imageData.height}
      priority={priority}
      className={className}
      blurDataURL={imageData.blurDataURL}
      sizes={sizes}
      fill={fill}
    />
  )
}
