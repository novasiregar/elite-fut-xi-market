describe("Marketplace Page", () => {
  beforeEach(() => {
    // Visit the marketplace page before each test
    cy.visit("/marketplace")
  })

  it("should display the marketplace title", () => {
    cy.get("h1").should("contain", "Marketplace")
  })

  it("should display the search bar", () => {
    cy.get('input[placeholder*="Search"]').should("be.visible")
  })

  it("should display the filter options", () => {
    cy.get('[data-testid="filter-bar"]').should("be.visible")
  })

  it("should display account cards", () => {
    // Wait for the account cards to load
    cy.get('[data-testid="account-card"]', { timeout: 10000 }).should("have.length.at.least", 1)
  })

  it("should filter accounts when using the search bar", () => {
    // Get the initial number of account cards
    cy.get('[data-testid="account-card"]').then(($cards) => {
      const initialCount = $cards.length

      // Search for a specific term
      cy.searchFor("elite")

      // Wait for the filtered results
      cy.get('[data-testid="account-card"]').should(($filteredCards) => {
        // Either we have fewer cards or the same number
        expect($filteredCards.length).to.be.at.most(initialCount)
      })
    })
  })

  it("should navigate to account details when clicking on a card", () => {
    cy.get('[data-testid="account-card"]').first().click()
    cy.url().should("include", "/listings/")
  })
})
