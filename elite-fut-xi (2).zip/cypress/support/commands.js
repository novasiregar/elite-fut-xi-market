// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************

// -- This is a parent command --
Cypress.Commands.add("login", (email, password) => {
  cy.visit("/login")
  cy.get("input[name=email]").type(email)
  cy.get("input[name=password]").type(password)
  cy.get("button[type=submit]").click()
  cy.url().should("include", "/dashboard")
})

// -- This is a child command --
Cypress.Commands.add("navigateToMarketplace", () => {
  cy.get('a[href="/marketplace"]').click()
  cy.url().should("include", "/marketplace")
})

// -- This is a dual command --
Cypress.Commands.add("searchFor", (query) => {
  cy.get('input[placeholder*="Search"]').type(query)
  cy.get('button[aria-label="Search"]').click()
})

// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
