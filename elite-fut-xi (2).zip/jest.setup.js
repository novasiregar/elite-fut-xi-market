// Optional: configure or set up a testing framework before each test.
// If you delete this file, remove `setupFilesAfterEnv` from `jest.config.js`

// Used for __tests__/testing-library.js
// Learn more: https://github.com/testing-library/jest-dom
import "@testing-library/jest-dom"

// Mock the Firebase services
jest.mock("firebase/app", () => {
  return {
    initializeApp: jest.fn(() => ({})),
    getApps: jest.fn(() => []),
  }
})

jest.mock("firebase/auth", () => {
  return {
    getAuth: jest.fn(() => ({})),
    signInWithEmailAndPassword: jest.fn(),
    createUserWithEmailAndPassword: jest.fn(),
    signOut: jest.fn(),
    onAuthStateChanged: jest.fn(),
  }
})

jest.mock("firebase/firestore", () => {
  return {
    getFirestore: jest.fn(() => ({})),
    collection: jest.fn(),
    doc: jest.fn(),
    getDoc: jest.fn(),
    getDocs: jest.fn(),
    query: jest.fn(),
    where: jest.fn(),
    orderBy: jest.fn(),
    limit: jest.fn(),
    startAfter: jest.fn(),
    addDoc: jest.fn(),
    updateDoc: jest.fn(),
    deleteDoc: jest.fn(),
    serverTimestamp: jest.fn(() => new Date()),
  }
})

jest.mock("firebase/storage", () => {
  return {
    getStorage: jest.fn(() => ({})),
    ref: jest.fn(),
    uploadBytes: jest.fn(),
    getDownloadURL: jest.fn(),
    deleteObject: jest.fn(),
  }
})

// Mock next/router
jest.mock("next/navigation", () => ({
  useRouter: jest.fn(() => ({
    push: jest.fn(),
    replace: jest.fn(),
    prefetch: jest.fn(),
    back: jest.fn(),
    reload: jest.fn(),
    refresh: jest.fn(),
    pathname: "/",
    query: {},
  })),
  usePathname: jest.fn(() => "/"),
  useSearchParams: jest.fn(() => new URLSearchParams()),
}))

// Mock Elasticsearch client
jest.mock("@elastic/elasticsearch", () => {
  return {
    Client: jest.fn(() => ({
      search: jest.fn(),
      index: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      indices: {
        create: jest.fn(),
        exists: jest.fn(),
        putMapping: jest.fn(),
      },
    })),
  }
})

// Mock Redis client
jest.mock("redis", () => {
  return {
    createClient: jest.fn(() => ({
      connect: jest.fn(),
      disconnect: jest.fn(),
      get: jest.fn(),
      set: jest.fn(),
      del: jest.fn(),
      expire: jest.fn(),
    })),
  }
})

// Mock environment variables
process.env = {
  ...process.env,
  NEXT_PUBLIC_FIREBASE_API_KEY: "mock-api-key",
  NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: "mock-auth-domain",
  NEXT_PUBLIC_FIREBASE_PROJECT_ID: "mock-project-id",
  NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: "mock-storage-bucket",
  NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: "mock-messaging-sender-id",
  NEXT_PUBLIC_FIREBASE_APP_ID: "mock-app-id",
  NEXT_PUBLIC_API_URL: "http://localhost:3001/api",
  API_URL: "http://localhost:3001/api",
}

// Mock window.matchMedia
Object.defineProperty(window, "matchMedia", {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
})

// Mock IntersectionObserver
class MockIntersectionObserver {
  constructor(callback) {
    this.callback = callback
  }
  observe() {}
  unobserve() {}
  disconnect() {}
}

window.IntersectionObserver = MockIntersectionObserver
