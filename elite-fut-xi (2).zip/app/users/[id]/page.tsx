"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ListingService } from "@/client/services/listings"
import { UserService } from "@/client/services/users"
import { useToast } from "@/components/ui/use-toast"
import { Star, Shield, MessageCircle, Calendar, Package, User, MapPin } from "lucide-react"
import { AccountCard } from "@/components/account-card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/context/auth-context"
import { SellerReviews } from "@/components/seller-reviews"
import { SellerStats } from "@/components/seller-stats"

export default function UserProfilePage() {
  const { id } = useParams()
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<any>(null)
  const [userListings, setUserListings] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("listings")
  const [loading, setLoading] = useState(true)
  const [loadingListings, setLoadingListings] = useState(true)
  const { toast } = useToast()
  const router = useRouter()
  const isOwnProfile = user?.uid === id

  // Fetch user profile
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        setLoading(true)
        const profile = await UserService.getUserById(id as string)
        setUserProfile(profile)
      } catch (error) {
        console.error("Error fetching user profile:", error)
        toast({
          title: "Error",
          description: "Failed to load user profile",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      fetchUserProfile()
    }
  }, [id, toast])

  // Fetch user listings
  useEffect(() => {
    const fetchUserListings = async () => {
      try {
        setLoadingListings(true)
        const listings = await ListingService.getUserListingsById(id as string)
        setUserListings(listings)
      } catch (error) {
        console.error("Error fetching user listings:", error)
        toast({
          title: "Error",
          description: "Failed to load user listings",
          variant: "destructive",
        })
      } finally {
        setLoadingListings(false)
      }
    }

    if (id) {
      fetchUserListings()
    }
  }, [id, toast])

  // Start a conversation with the user
  const startConversation = async () => {
    try {
      if (!user) {
        toast({
          title: "Login Required",
          description: "Please login to message this user",
          variant: "destructive",
        })
        router.push("/login")
        return
      }

      const conversationId = await UserService.createConversation(id as string)
      router.push(`/messages/${conversationId}`)
    } catch (error) {
      console.error("Error starting conversation:", error)
      toast({
        title: "Error",
        description: "Failed to start conversation",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col items-center justify-center h-[70vh]">
            <Skeleton className="h-24 w-24 rounded-full" />
            <Skeleton className="h-8 w-48 mt-4" />
            <Skeleton className="h-4 w-32 mt-2" />
          </div>
        </main>
      </div>
    )
  }

  if (!userProfile) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col items-center justify-center h-[70vh]">
            <User className="h-24 w-24 text-muted-foreground" />
            <h1 className="mt-4 text-xl font-medium">User Not Found</h1>
            <p className="mt-2 text-muted-foreground">The user you're looking for doesn't exist or has been removed</p>
            <Button className="mt-6" onClick={() => router.push("/marketplace")}>
              Back to Marketplace
            </Button>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <Card className="pixel-border bg-card/50 backdrop-blur-sm mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20 rounded-md">
                <AvatarImage src={userProfile.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-primary/20 text-primary text-xl">
                  {userProfile.displayName?.charAt(0)}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h1 className="font-futuristic text-lg glow-text-secondary">{userProfile.displayName}</h1>
                  {userProfile.isVerified && <Shield className="h-4 w-4 text-primary" />}
                </div>

                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={userProfile.status === "online" ? "default" : "secondary"} className="text-xs">
                    {userProfile.status === "online" ? "Online" : "Offline"}
                  </Badge>

                  <span className="text-xs text-muted-foreground">
                    <Calendar className="inline-block h-3 w-3 mr-1" />
                    Joined {new Date(userProfile.createdAt).toLocaleDateString()}
                  </span>
                </div>

                {userProfile.location && (
                  <div className="flex items-center mt-1 text-xs text-muted-foreground">
                    <MapPin className="h-3 w-3 mr-1" />
                    {userProfile.location}
                  </div>
                )}

                {userProfile.rating !== undefined && (
                  <div className="flex items-center mt-2">
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= Math.round(userProfile.rating)
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-muted-foreground"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm">
                      {userProfile.rating.toFixed(1)} ({userProfile.ratingCount})
                    </span>
                  </div>
                )}

                {!isOwnProfile && (
                  <Button variant="outline" size="sm" className="mt-2" onClick={startConversation}>
                    <MessageCircle className="h-3 w-3 mr-1" /> Message
                  </Button>
                )}
              </div>
            </div>

            {userProfile.bio && (
              <div className="mt-4">
                <p className="text-sm">{userProfile.bio}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="listings" className="font-futuristic">
              LISTINGS
            </TabsTrigger>
            <TabsTrigger value="reviews" className="font-futuristic">
              REVIEWS
            </TabsTrigger>
            <TabsTrigger value="stats" className="font-futuristic">
              STATS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="listings" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-futuristic text-sm glow-text">ACTIVE LISTINGS</h2>
              <span className="text-sm">{userListings.length} listings</span>
            </div>

            {loadingListings ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Skeleton key={i} className="h-40 w-full rounded-md" />
                ))}
              </div>
            ) : userListings.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {userListings.map((listing) => (
                  <AccountCard key={listing.id} account={listing} />
                ))}
              </div>
            ) : (
              <Card className="bg-muted/30">
                <CardContent className="p-6 text-center">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm mb-4">No active listings</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="reviews" className="space-y-4">
            <SellerReviews sellerId={id as string} />
          </TabsContent>

          <TabsContent value="stats" className="space-y-4">
            <SellerStats sellerId={id as string} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
