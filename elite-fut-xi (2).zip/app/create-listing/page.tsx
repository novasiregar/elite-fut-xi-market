"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { ArrowLeft, Upload, AlertCircle, X, ImageIcon, Film } from "lucide-react"
import { ListingService } from "@/client/services/listings"
import { Skeleton } from "@/components/ui/skeleton"

export default function CreateListingPage() {
  const { user, userProfile, loading } = useAuth()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [price, setPrice] = useState("")
  const [tags, setTags] = useState("")
  const [accountDetails, setAccountDetails] = useState("")
  const [media, setMedia] = useState<File[]>([])
  const [mediaPreview, setMediaPreview] = useState<{ file: File; preview: string; type: string }[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()
  const router = useRouter()

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }

    // Check if user is verified seller
    if (!loading && userProfile && !userProfile.isVerified) {
      toast({
        title: "Verification Required",
        description: "You need to be a verified seller to create listings",
        variant: "destructive",
      })
      router.push("/profile")
    }
  }, [loading, user, userProfile, router, toast])

  const handleMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files)

      // Check if adding these files would exceed the limit
      if (media.length + selectedFiles.length > 5) {
        toast({
          title: "Too many files",
          description: "You can upload a maximum of 5 media files",
          variant: "destructive",
        })
        return
      }

      // Check file sizes (max 5MB each)
      const oversizedFiles = selectedFiles.filter((file) => file.size > 5 * 1024 * 1024)
      if (oversizedFiles.length > 0) {
        toast({
          title: "File too large",
          description: "Each media file must be less than 5MB",
          variant: "destructive",
        })
        return
      }

      // Check file types
      const invalidFiles = selectedFiles.filter(
        (file) => !file.type.startsWith("image/") && !file.type.startsWith("video/"),
      )
      if (invalidFiles.length > 0) {
        toast({
          title: "Invalid file type",
          description: "Please upload only images or videos",
          variant: "destructive",
        })
        return
      }

      // Add new files
      setMedia((prev) => [...prev, ...selectedFiles])

      // Create previews
      const newPreviews = selectedFiles.map((file) => ({
        file,
        preview: URL.createObjectURL(file),
        type: file.type.startsWith("image/") ? "image" : "video",
      }))

      setMediaPreview((prev) => [...prev, ...newPreviews])
    }
  }

  const removeMedia = (index: number) => {
    setMedia((prev) => prev.filter((_, i) => i !== index))

    // Revoke object URL to avoid memory leaks
    URL.revokeObjectURL(mediaPreview[index].preview)
    setMediaPreview((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!title.trim()) {
      setError("Title is required")
      return
    }

    if (!description.trim()) {
      setError("Description is required")
      return
    }

    if (!price || isNaN(Number(price)) || Number(price) <= 0) {
      setError("Please enter a valid price")
      return
    }

    if (media.length === 0) {
      setError("Please upload at least one image or video")
      return
    }

    try {
      setIsSubmitting(true)

      const formData = new FormData()
      formData.append("title", title)
      formData.append("description", description)
      formData.append("price", price)
      formData.append("tags", tags)
      formData.append("accountDetails", accountDetails)

      media.forEach((file) => {
        formData.append("media", file)
      })

      const response = await ListingService.createListing(formData)

      toast({
        title: "Listing created",
        description: "Your listing has been created successfully",
      })

      router.push(`/listings/${response.id}`)
    } catch (error: any) {
      console.error("Create listing error:", error)
      setError(error.message || "Failed to create listing")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Clean up object URLs when component unmounts
  useEffect(() => {
    return () => {
      mediaPreview.forEach((item) => URL.revokeObjectURL(item.preview))
    }
  }, [mediaPreview])

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col space-y-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-40 w-full rounded-md" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-futuristic text-lg glow-text ml-2">CREATE LISTING</h1>
        </div>

        <Card className="pixel-border bg-card/50 backdrop-blur-sm">
          <CardContent className="p-6">
            {error && (
              <div className="bg-destructive/20 p-3 rounded-md mb-4 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <p className="text-xs text-destructive">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="title" className="text-sm font-medium">
                  Title
                </label>
                <Input
                  id="title"
                  type="text"
                  placeholder="e.g. Ultimate Team 94 OVR"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  disabled={isSubmitting}
                  maxLength={100}
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="description" className="text-sm font-medium">
                  Description
                </label>
                <Textarea
                  id="description"
                  placeholder="Describe your account in detail"
                  className="resize-none"
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={isSubmitting}
                  maxLength={1000}
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="price" className="text-sm font-medium">
                  Price (Rp)
                </label>
                <Input
                  id="price"
                  type="number"
                  placeholder="e.g. 2500000"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  disabled={isSubmitting}
                  min="1"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="tags" className="text-sm font-medium">
                  Tags (comma separated)
                </label>
                <Input
                  id="tags"
                  type="text"
                  placeholder="e.g. featured, premium, trending"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="accountDetails" className="text-sm font-medium">
                  Account Details
                </label>
                <Textarea
                  id="accountDetails"
                  placeholder="Provide details about the account (players, stats, etc.)"
                  className="resize-none"
                  rows={4}
                  value={accountDetails}
                  onChange={(e) => setAccountDetails(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Media (Images/Videos)</label>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {mediaPreview.map((item, index) => (
                    <div key={index} className="relative aspect-square rounded-md overflow-hidden bg-muted">
                      {item.type === "image" ? (
                        <ImageIcon
                          src={item.preview || "/placeholder.svg"}
                          alt={`Preview ${index}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-black">
                          <Film className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                      <button
                        type="button"
                        className="absolute top-1 right-1 bg-background/80 rounded-full p-1"
                        onClick={() => removeMedia(index)}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}

                  {media.length < 5 && (
                    <label
                      htmlFor="media-upload"
                      className="aspect-square rounded-md border-2 border-dashed border-muted flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors"
                    >
                      <Upload className="h-6 w-6 text-muted-foreground mb-1" />
                      <span className="text-xs text-muted-foreground">Add</span>
                    </label>
                  )}
                </div>
                <input
                  id="media-upload"
                  type="file"
                  accept="image/*,video/*"
                  type="file"
                  accept="image/*,video/*"
                  className="hidden"
                  onChange={handleMediaChange}
                  multiple
                  disabled={isSubmitting || media.length >= 5}
                />
                <p className="text-xs text-muted-foreground">Upload up to 5 images or videos (max 5MB each)</p>
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => router.back()}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 font-futuristic" disabled={isSubmitting}>
                  {isSubmitting ? "Creating..." : "Create Listing"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
