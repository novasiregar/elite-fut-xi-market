"use client"

import { useLanguage } from "@/context/language-context"
import { CinematicHero } from "@/components/cinematic-hero"
import { CategoryScroller } from "@/components/category-scroller"
import { NewsMarquee } from "@/components/news-marquee"
import { SmartSearch } from "@/components/smart-search"
import { InstallPWA } from "@/components/install-pwa"
import { EnhancedMobileNavbar } from "@/components/enhanced-mobile-navbar"
import { FeaturedListings } from "@/components/featured-listings"

export default function Home() {
  const { t } = useLanguage()

  return (
    <main id="main-content">
      <EnhancedMobileNavbar />

      <CinematicHero title={t("home.welcome")} subtitle={t("home.tagline")} />

      <div className="container px-4 py-8 space-y-12">
        <SmartSearch onSearch={(filters) => console.log("Search:", filters)} />

        <CategoryScroller title={t("home.browseCategories")} />

        <section>
          <h2 className="text-2xl font-bold mb-4">{t("home.featuredListings")}</h2>
          <FeaturedListings />
        </section>

        <NewsMarquee />

        <InstallPWA />
      </div>
    </main>
  )
}
