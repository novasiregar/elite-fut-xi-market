"use client"
import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { FloatingPixels } from "@/components/floating-pixels"
import { EnhancedMobileNavbar } from "@/components/enhanced-mobile-navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Copy, Gift, Users, Coins, Award, Share2, ArrowRight, Mail, MessageSquare } from "lucide-react"
import { triggerHaptic } from "@/utils/haptic"
import { SkeletonCard } from "@/components/ui/skeleton-elements"

// Mock ReferralService if it doesn't exist
const ReferralService = {
  getReferralData: async () => {
    // Mock data
    return {
      referralCode: "ELITE25",
      referralLink: "https://elitefutxi.com/register?ref=ELITE25",
      referralCount: 5,
      pendingReferrals: 2,
      completedReferrals: 3,
      totalEarnings: 150000,
      availableBalance: 100000,
      referralHistory: [],
      rewards: [],
    }
  },
}

const StatCard = ({ title, value, icon }) => (
  <Card className="bg-card/50 backdrop-blur-sm">
    <CardContent className="flex items-center space-x-4 p-3">
      {icon}
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xl font-bold">{value}</p>
      </div>
    </CardContent>
  </Card>
)

export default function ReferralsPage() {
  const { user, userProfile } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [referralData, setReferralData] = useState({
    referralCode: "",
    referralLink: "",
    referralCount: 0,
    pendingReferrals: 0,
    completedReferrals: 0,
    totalEarnings: 0,
    availableBalance: 0,
    referralHistory: [],
    rewards: [],
  })
  const [copied, setCopied] = useState(false)

  // Fetch referral data
  useEffect(() => {
    if (!user) {
      router.push("/login?redirect=/referrals")
      return
    }

    const fetchReferralData = async () => {
      try {
        setIsLoading(true)

        // Fetch referral data
        const data = await ReferralService.getReferralData()

        setReferralData({
          referralCode: data?.referralCode || "ELITE25",
          referralLink: data?.referralLink || `https://elitefutxi.com/register?ref=ELITE25`,
          referralCount: data?.referralCount || 0,
          pendingReferrals: data?.pendingReferrals || 0,
          completedReferrals: data?.completedReferrals || 0,
          totalEarnings: data?.totalEarnings || 0,
          availableBalance: data?.availableBalance || 0,
          referralHistory: data?.referralHistory || [],
          rewards: data?.rewards || [],
        })
      } catch (error) {
        console.error("Error fetching referral data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchReferralData()
  }, [user, router])

  const handleTabChange = (value) => {
    setActiveTab(value)
    triggerHaptic("light")
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    triggerHaptic("success")
    setTimeout(() => setCopied(false), 2000)
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <EnhancedMobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="mb-6">
          <h1 className="font-futuristic text-xl glow-text">REFERRAL PROGRAM</h1>
          <p className="text-sm text-muted-foreground">Invite friends and earn rewards</p>
        </div>

        {/* Referral Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {isLoading ? (
            Array(4)
              .fill(0)
              .map((_, i) => <SkeletonCard key={i} className="h-24" />)
          ) : (
            <>
              <StatCard
                title="Total Referrals"
                value={referralData.referralCount}
                icon={<Users className="h-5 w-5 text-primary" />}
              />
              <StatCard
                title="Completed"
                value={referralData.completedReferrals}
                icon={<Award className="h-5 w-5 text-green-500" />}
              />
              <StatCard
                title="Total Earnings"
                value={formatCurrency(referralData.totalEarnings)}
                icon={<Coins className="h-5 w-5 text-secondary" />}
              />
              <StatCard
                title="Available Balance"
                value={formatCurrency(referralData.availableBalance)}
                icon={<Gift className="h-5 w-5 text-accent" />}
              />
            </>
          )}
        </div>

        {/* Referral Code */}
        <Card className="mb-6 bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <h3 className="font-futuristic text-sm mb-4 glow-text">YOUR REFERRAL CODE</h3>

            {isLoading ? (
              <div className="h-20 bg-muted/30 rounded-md animate-pulse"></div>
            ) : (
              <div className="space-y-4">
                <div className="bg-muted/30 p-3 rounded-md">
                  <Label htmlFor="referral-code" className="text-xs text-muted-foreground">
                    Referral Code
                  </Label>
                  <div className="flex items-center mt-1">
                    <Input
                      id="referral-code"
                      value={referralData.referralCode}
                      readOnly
                      className="bg-background/50 border-0"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="ml-2"
                      onClick={() => copyToClipboard(referralData.referralCode)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="bg-muted/30 p-3 rounded-md">
                  <Label htmlFor="referral-link" className="text-xs text-muted-foreground">
                    Referral Link
                  </Label>
                  <div className="flex items-center mt-1">
                    <Input
                      id="referral-link"
                      value={referralData.referralLink}
                      readOnly
                      className="bg-background/50 border-0 text-xs"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="ml-2"
                      onClick={() => copyToClipboard(referralData.referralLink)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {copied && (
                  <div className="bg-primary/20 p-2 rounded-md text-center">
                    <p className="text-xs text-primary">Copied to clipboard!</p>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-3">
                  <Button
                    variant="outline"
                    className="text-xs h-10"
                    onClick={() => {
                      triggerHaptic("light")
                      window.open(
                        `https://wa.me/?text=Join%20ELITE%20FUT%20XI%20Market%20using%20my%20referral%20code%20${referralData.referralCode}%20and%20get%20a%20bonus!%20${referralData.referralLink}`,
                        "_blank",
                      )
                    }}
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    WhatsApp
                  </Button>
                  <Button
                    variant="outline"
                    className="text-xs h-10"
                    onClick={() => {
                      triggerHaptic("light")
                      window.open(
                        `mailto:?subject=Join%20ELITE%20FUT%20XI%20Market&body=Join%20ELITE%20FUT%20XI%20Market%20using%20my%20referral%20code%20${referralData.referralCode}%20and%20get%20a%20bonus!%20${referralData.referralLink}`,
                        "_blank",
                      )
                    }}
                  >
                    <Mail className="h-4 w-4 mr-1" />
                    Email
                  </Button>
                  <Button
                    variant="outline"
                    className="text-xs h-10"
                    onClick={() => {
                      triggerHaptic("light")
                    }}
                  >
                    <Share2 className="h-4 w-4 mr-1" />
                    More
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="overview" className="font-futuristic">
              OVERVIEW
            </TabsTrigger>
            <TabsTrigger value="history" className="font-futuristic">
              HISTORY
            </TabsTrigger>
            <TabsTrigger value="rewards" className="font-futuristic">
              REWARDS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            {/* How It Works */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">HOW IT WORKS</h3>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-primary">1</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Share Your Code</p>
                      <p className="text-xs text-muted-foreground">
                        Share your unique referral code or link with friends
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-secondary">2</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Friends Register</p>
                      <p className="text-xs text-muted-foreground">Your friends register using your referral code</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-accent">3</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Friends Make a Purchase</p>
                      <p className="text-xs text-muted-foreground">
                        When your friends make their first purchase, the referral is completed
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-green-500">4</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Earn Rewards</p>
                      <p className="text-xs text-muted-foreground">
                        You earn Rp 50,000 for each completed referral, and your friend gets Rp 25,000 off their first
                        purchase
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Pending Referrals */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">PENDING REFERRALS</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(2)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-16 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : referralData.pendingReferrals === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No pending referrals</p>
                    <Button
                      className="mt-4"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Invite Friends
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-yellow-500/20 flex items-center justify-center">
                          <Users className="h-5 w-5 text-yellow-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Ahmad Rizki</p>
                          <p className="text-xs text-muted-foreground">Registered 2 days ago</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs text-yellow-500">
                        Pending
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-yellow-500/20 flex items-center justify-center">
                          <Users className="h-5 w-5 text-yellow-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Budi Santoso</p>
                          <p className="text-xs text-muted-foreground">Registered 3 days ago</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs text-yellow-500">
                        Pending
                      </Badge>
                    </div>

                    <Button
                      variant="ghost"
                      className="w-full text-xs"
                      onClick={() => {
                        triggerHaptic("light")
                        handleTabChange("history")
                      }}
                    >
                      View All Referrals
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history">
            {/* Referral History */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">REFERRAL HISTORY</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(4)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-16 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : referralData.referralHistory.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No referral history yet</p>
                    <Button
                      className="mt-4"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Invite Friends
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-green-500/20 flex items-center justify-center">
                          <Users className="h-5 w-5 text-green-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Dian Sastro</p>
                          <p className="text-xs text-muted-foreground">Completed on May 15, 2023</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">Rp 50,000</p>
                        <Badge variant="outline" className="text-xs text-green-500">
                          Completed
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-green-500/20 flex items-center justify-center">
                          <Users className="h-5 w-5 text-green-500" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Rudi Hartono</p>
                          <p className="text-xs text-muted-foreground">Completed on Apr 28, 2023</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">Rp 50,000</p>
                        <Badge variant="outline" className="text-xs text-green-500">
                          Completed
                        </Badge>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rewards">
            {/* Rewards */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">YOUR REWARDS</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-16 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-muted/30 p-4 rounded-md">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">Available Balance</h4>
                        <p className="text-lg font-bold">{formatCurrency(referralData.availableBalance)}</p>
                      </div>
                      <Button className="w-full" disabled={referralData.availableBalance === 0}>
                        Withdraw to Wallet
                      </Button>
                    </div>

                    <div className="bg-muted/30 p-4 rounded-md">
                      <h4 className="font-medium mb-3">Reward Tiers</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                              <Award className="h-4 w-4 text-primary" />
                            </div>
                            <p className="text-sm">5 Referrals</p>
                          </div>
                          <p className="text-sm font-medium">Rp 50,000 Bonus</p>
                        </div>

                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center">
                              <Award className="h-4 w-4 text-secondary" />
                            </div>
                            <p className="text-sm">10 Referrals</p>
                          </div>
                          <p className="text-sm font-medium">Rp 150,000 Bonus</p>
                        </div>

                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                              <Award className="h-4 w-4 text-accent" />
                            </div>
                            <p className="text-sm">25 Referrals</p>
                          </div>
                          <p className="text-sm font-medium">Rp 500,000 Bonus</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
