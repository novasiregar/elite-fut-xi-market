"use client"

import { useState } from "react"
import { useAuth } from "@/context/auth-context"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ListingService } from "@/client/services/listings"
import { TransactionService } from "@/client/services/transactions"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { Edit, Star, Shield, Clock, Package, ShoppingCart, Upload } from "lucide-react"
import { AccountCard } from "@/components/account-card"
import { Skeleton } from "@/components/ui/skeleton"
import { useEffect } from "react"

export default function ProfilePage() {
  const { user, userProfile, loading } = useAuth()
  const [activeTab, setActiveTab] = useState("listings")
  const [userListings, setUserListings] = useState<any[]>([])
  const [userTransactions, setUserTransactions] = useState<any[]>([])
  const [loadingListings, setLoadingListings] = useState(true)
  const [loadingTransactions, setLoadingTransactions] = useState(true)
  const { toast } = useToast()
  const router = useRouter()

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  // Fetch user listings
  useEffect(() => {
    if (user) {
      const fetchListings = async () => {
        try {
          setLoadingListings(true)
          const listings = await ListingService.getUserListings()
          setUserListings(listings)
        } catch (error) {
          console.error("Error fetching listings:", error)
          toast({
            title: "Error",
            description: "Failed to load your listings",
            variant: "destructive",
          })
        } finally {
          setLoadingListings(false)
        }
      }

      fetchListings()
    }
  }, [user, toast])

  // Fetch user transactions
  useEffect(() => {
    if (user) {
      const fetchTransactions = async () => {
        try {
          setLoadingTransactions(true)
          const transactions = await TransactionService.getTransactions(undefined, "all")
          setUserTransactions(transactions)
        } catch (error) {
          console.error("Error fetching transactions:", error)
          toast({
            title: "Error",
            description: "Failed to load your transactions",
            variant: "destructive",
          })
        } finally {
          setLoadingTransactions(false)
        }
      }

      fetchTransactions()
    }
  }, [user, toast])

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col items-center justify-center h-[70vh]">
            <Skeleton className="h-24 w-24 rounded-full" />
            <Skeleton className="h-8 w-48 mt-4" />
            <Skeleton className="h-4 w-32 mt-2" />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <Card className="pixel-border bg-card/50 backdrop-blur-sm mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20 rounded-md">
                <AvatarImage src={userProfile?.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-primary/20 text-primary text-xl">
                  {userProfile?.displayName?.charAt(0) || user.email?.charAt(0)}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <h1 className="font-futuristic text-lg glow-text-secondary">
                  {userProfile?.displayName || "PLAYER"}
                  {userProfile?.isVerified && <Shield className="inline-block ml-2 h-4 w-4 text-primary" />}
                </h1>
                <p className="text-sm text-muted-foreground">{user.email}</p>

                {userProfile?.rating && (
                  <div className="flex items-center mt-1">
                    <Star className="h-3 w-3 text-yellow-500 mr-1" />
                    <span className="text-xs">{userProfile.rating.toFixed(1)}</span>
                    <span className="text-xs text-muted-foreground ml-1">
                      ({userProfile.ratingCount} {userProfile.ratingCount === 1 ? "review" : "reviews"})
                    </span>
                  </div>
                )}

                <Button variant="outline" size="sm" className="mt-2" onClick={() => router.push("/profile/edit")}>
                  <Edit className="h-3 w-3 mr-1" /> Edit Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="listings" className="font-futuristic">
              MY LISTINGS
            </TabsTrigger>
            <TabsTrigger value="transactions" className="font-futuristic">
              TRANSACTIONS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="listings" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-futuristic text-sm glow-text">YOUR LISTINGS</h2>
              <Button size="sm" onClick={() => router.push("/create-listing")}>
                <Upload className="h-3 w-3 mr-1" /> New Listing
              </Button>
            </div>

            {loadingListings ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Skeleton key={i} className="h-40 w-full rounded-md" />
                ))}
              </div>
            ) : userListings.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {userListings.map((listing) => (
                  <AccountCard key={listing.id} account={listing} />
                ))}
              </div>
            ) : (
              <Card className="bg-muted/30">
                <CardContent className="p-6 text-center">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm mb-4">You haven't created any listings yet</p>
                  <Button onClick={() => router.push("/create-listing")}>Create Your First Listing</Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-futuristic text-sm glow-text">YOUR TRANSACTIONS</h2>
            </div>

            {loadingTransactions ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Skeleton key={i} className="h-24 w-full rounded-md" />
                ))}
              </div>
            ) : userTransactions.length > 0 ? (
              <div className="space-y-4">
                {userTransactions.map((transaction) => (
                  <TransactionCard
                    key={transaction.id}
                    transaction={transaction}
                    userRole={transaction.buyerId === user.uid ? "buyer" : "seller"}
                    onClick={() => router.push(`/transactions/${transaction.id}`)}
                  />
                ))}
              </div>
            ) : (
              <Card className="bg-muted/30">
                <CardContent className="p-6 text-center">
                  <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm mb-4">You don't have any transactions yet</p>
                  <Button onClick={() => router.push("/marketplace")}>Browse Marketplace</Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function TransactionCard({
  transaction,
  userRole,
  onClick,
}: {
  transaction: any
  userRole: "buyer" | "seller"
  onClick: () => void
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-500"
      case "pending":
      case "payment_processing":
      case "payment_completed":
      case "escrow_funded":
      case "account_delivered":
        return "text-yellow-500"
      case "disputed":
        return "text-red-500"
      case "cancelled":
      case "refunded":
        return "text-muted-foreground"
      default:
        return "text-muted-foreground"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "Pending Payment"
      case "payment_processing":
        return "Payment Processing"
      case "payment_completed":
        return "Payment Completed"
      case "escrow_funded":
        return "Escrow Funded"
      case "account_delivered":
        return "Delivered, Awaiting Confirmation"
      case "completed":
        return "Completed"
      case "disputed":
        return "Disputed"
      case "refunded":
        return "Refunded"
      case "cancelled":
        return "Cancelled"
      default:
        return status.replace(/_/g, " ")
    }
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm hover:bg-card/70 transition-colors cursor-pointer" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            {userRole === "buyer" ? (
              <ShoppingCart className="h-4 w-4 text-primary mr-2" />
            ) : (
              <Package className="h-4 w-4 text-secondary mr-2" />
            )}
            <span className="font-futuristic text-sm">{userRole === "buyer" ? "Purchase" : "Sale"}</span>
          </div>
          <span className={`text-xs font-futuristic ${getStatusColor(transaction.status)}`}>
            {getStatusText(transaction.status)}
          </span>
        </div>

        <h3 className="text-sm font-medium mb-1 truncate">{transaction.listingTitle}</h3>

        <div className="flex justify-between items-center">
          <span className="text-xs text-muted-foreground">{new Date(transaction.createdAt).toLocaleDateString()}</span>
          <span className="text-sm font-futuristic">Rp {transaction.amount.toLocaleString()}</span>
        </div>
      </CardContent>
    </Card>
  )
}
