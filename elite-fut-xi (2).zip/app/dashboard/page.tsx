import { MobileNavbar } from "@/components/mobile-navbar"
import { AccountCard } from "@/components/account-card"
import { Button } from "@/components/ui/button"
import { FloatingPixels } from "@/components/floating-pixels"
import { Plus, TrendingUp, Clock, Star } from "lucide-react"

export default function Dashboard() {
  // Sample data for demonstration
  const accounts = [
    {
      id: 1,
      title: "Ultimate Team 94 OVR",
      price: "2,500,000",
      rating: 4.9,
      image: "/placeholder.svg?height=200&width=400",
      seller: "EliteTrader",
      verified: true,
    },
    {
      id: 2,
      title: "FUT Champions Ready",
      price: "1,800,000",
      rating: 4.7,
      image: "/placeholder.svg?height=200&width=400",
      seller: "GameMaster",
      verified: true,
    },
    {
      id: 3,
      title: "Ronaldo + Messi Account",
      price: "3,200,000",
      rating: 5.0,
      image: "/placeholder.svg?height=200&width=400",
      seller: "LegendaryAccounts",
      verified: false,
    },
  ]

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />

      <MobileNavbar />

      <main className="pt-16 pb-20 px-4 max-w-md mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-futuristic text-lg glow-text">MARKETPLACE</h1>
          <Button size="sm" variant="outline" className="pixel-border">
            <Plus className="h-4 w-4 mr-1" /> SELL
          </Button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          <Button variant="secondary" size="sm" className="whitespace-nowrap">
            <TrendingUp className="h-3 w-3 mr-1" /> Trending
          </Button>
          <Button variant="outline" size="sm" className="whitespace-nowrap">
            <Clock className="h-3 w-3 mr-1" /> New Listings
          </Button>
          <Button variant="outline" size="sm" className="whitespace-nowrap">
            <Star className="h-3 w-3 mr-1" /> Top Rated
          </Button>
          <Button variant="outline" size="sm" className="whitespace-nowrap">
            Price: Low to High
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {accounts.map((account) => (
            <AccountCard key={account.id} account={account} />
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button variant="outline" className="w-full">
            LOAD MORE
          </Button>
        </div>
      </main>
    </div>
  )
}
