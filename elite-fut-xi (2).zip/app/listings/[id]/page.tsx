import { Suspense } from "react"
import type React from "react"
import { MobileNavbar } from "@/components/mobile-navbar"
import { ShareListing } from "@/components/share-listing"
import { PixelLoading } from "@/components/pixel-loading"
import { ServerOptimizedImage } from "@/components/server-optimized-image"
import { getOptimizedImage } from "@/utils/image-optimization"
import Link from "next/link"
import { DynamicImageGallery } from "@/components/dynamic-imports"

// Types for our listing
interface Listing {
  id: string
  title: string
  description: string
  price: number
  images: string[]
  seller: {
    id: string
    name: string
    rating: number
    avatar: string
  }
  category: string
  features: string[]
  createdAt: string
  sellerId: string
  sellerName: string
  sellerVerified: boolean
  ratingCount: number
  viewCount: number
  favoriteCount: number
  status: string
  tags: string[]
  media: any[]
  accountDetails: any
}

// Server-side data fetching
async function getListing(id: string): Promise<Listing> {
  // In a real app, this would fetch from your API
  // For now, we'll simulate a delay and return mock data
  await new Promise((resolve) => setTimeout(resolve, 300))

  return {
    id,
    title: "FIFA 23 Ultimate Team - 95 OVR",
    description: "Top-rated Ultimate Team account with multiple special cards and high overall rating.",
    price: 1500000,
    images: ["/images/listings/listing-1.jpg", "/images/listings/listing-1-2.jpg", "/images/listings/listing-1-3.jpg"],
    seller: {
      id: "seller1",
      name: "TopSeller",
      rating: 4.8,
      avatar: "/images/avatars/seller1.jpg",
    },
    category: "FIFA",
    features: ["95 OVR Team", "5 Icon Players", "2M Coins Balance"],
    createdAt: "2023-05-15T10:30:00Z",
    sellerId: "seller1",
    sellerName: "TopSeller",
    sellerVerified: true,
    ratingCount: 100,
    viewCount: 500,
    favoriteCount: 50,
    status: "active",
    tags: ["fifa", "ultimate team", "95 ovr"],
    media: [],
    accountDetails: null,
  }
}

// Generate metadata for SEO
export async function generateMetadata({ params }: { params: { id: string } }) {
  const listing = await getListing(params.id)

  return {
    title: `${listing.title} | ELITE FUT XI Market`,
    description: listing.description.substring(0, 160),
    openGraph: {
      images: [listing.images[0]],
    },
  }
}

export default async function ListingDetail({ params }: { params: { id: string } }) {
  // Fetch listing data on the server
  const listing = await getListing(params.id)

  // Pre-optimize the seller avatar
  const optimizedAvatar = await getOptimizedImage(listing.seller.avatar)

  return (
    <main className="flex min-h-screen flex-col">
      <MobileNavbar />

      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb navigation */}
        <div className="text-sm text-muted-foreground mb-4">
          <span>Marketplace</span> &gt; <span>{listing.category}</span> &gt;{" "}
          <span className="text-foreground">{listing.title}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Image gallery - loaded dynamically but with SSR for first image */}
          <div>
            <Suspense fallback={<PixelLoading text="Loading images..." />}>
              <DynamicImageGallery images={listing.images} />
            </Suspense>
          </div>

          {/* Listing details - critical content */}
          <div>
            <h1 className="text-2xl font-bold">{listing.title}</h1>
            <p className="text-3xl text-primary font-bold mt-2">Rp {listing.price.toLocaleString("id-ID")}</p>

            {/* Seller info with optimized avatar */}
            <div className="flex items-center mt-4 p-3 bg-card rounded-lg">
              <div className="w-12 h-12 rounded-full overflow-hidden">
                <ServerOptimizedImage
                  src={optimizedAvatar.src}
                  alt={listing.seller.name}
                  width={48}
                  height={48}
                  blurDataURL={optimizedAvatar.blurDataURL}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="ml-3">
                <p className="font-medium">{listing.seller.name}</p>
                <p className="text-sm text-muted-foreground">★ {listing.seller.rating} Rating</p>
              </div>
              <Link href={`/users/${listing.seller.id}`} className="ml-auto text-sm text-primary">
                View Profile
              </Link>
            </div>

            {/* Features list */}
            <div className="mt-6">
              <h2 className="text-lg font-semibold mb-2">Features</h2>
              <ul className="list-disc list-inside space-y-1">
                {listing.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>

            {/* Description */}
            <div className="mt-6">
              <h2 className="text-lg font-semibold mb-2">Description</h2>
              <p className="text-muted-foreground">{listing.description}</p>
            </div>

            {/* Action buttons */}
            <div className="mt-8 flex gap-4">
              <button className="flex-1 bg-primary text-primary-foreground py-3 rounded-lg font-medium">
                Contact Seller
              </button>
              <ShareListing listing={listing} />
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

function StatItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-muted/30 rounded-md p-3">
      <div className="flex items-center mb-1">
        {icon}
        <span className="text-xs ml-1">{label}</span>
      </div>
      <p className="text-sm font-futuristic">{value}</p>
    </div>
  )
}
