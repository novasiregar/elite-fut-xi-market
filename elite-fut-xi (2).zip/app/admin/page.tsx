"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { FloatingPixels } from "@/components/floating-pixels"
import { EnhancedMobileNavbar } from "@/components/enhanced-mobile-navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import {
  DollarSign,
  ShoppingBag,
  Users,
  TrendingUp,
  AlertCircle,
  Search,
  Shield,
  Settings,
  Bell,
  Flag,
} from "lucide-react"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { triggerHaptic } from "@/utils/haptic"
import { AdminService } from "@/client/services/admin"
import { PageTransition } from "@/components/page-transition"
import { PixelLoading } from "@/components/pixel-loading"
import { AdminUserManagement } from "@/components/admin/admin-user-management"
import { AdminListingManagement } from "@/components/admin/admin-listing-management"
import { AdminTransactionManagement } from "@/components/admin/admin-transaction-management"
import { AdminReports } from "@/components/admin/admin-reports"
import { AdminSettings } from "@/components/admin/admin-settings"
import { AdminFlaggedContent } from "@/components/admin/admin-flagged-content"
import { AdminPromotionManagement } from "@/components/admin/admin-promotion-management"
import { useToast } from "@/hooks/use-toast"

export default function AdminDashboardPage() {
  const { user, userProfile } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const { toast } = useToast()
  const [dashboardData, setDashboardData] = useState({
    stats: {
      totalUsers: 0,
      totalListings: 0,
      totalTransactions: 0,
      totalRevenue: 0,
      pendingVerifications: 0,
      reportedListings: 0,
      disputedTransactions: 0,
    },
    recentUsers: [],
    recentListings: [],
    recentTransactions: [],
    recentReports: [],
    salesData: [],
  })

  // Fetch dashboard data
  useEffect(() => {
    if (!user) {
      router.push("/login?redirect=/admin")
      return
    }

    // Check if user is admin
    if (userProfile?.role !== "admin") {
      toast({
        title: "Access Denied",
        description: "You don't have permission to access this page.",
        variant: "destructive",
      })
      router.push("/")
      return
    }

    const fetchDashboardData = async () => {
      try {
        setIsLoading(true)

        // Fetch admin stats
        const stats = await AdminService.getStats()

        // Fetch recent users
        const users = await AdminService.getUsers({ page: 1, limit: 5 })

        // Fetch recent listings
        const listings = await AdminService.getListings({ page: 1, limit: 5 })

        // Fetch recent transactions
        const transactions = await AdminService.getTransactions({ page: 1, limit: 5 })

        // Fetch recent reports
        const reports = await AdminService.getReports({ page: 1, limit: 5 })

        // Prepare dashboard data
        setDashboardData({
          stats: {
            totalUsers: stats.totalUsers || 0,
            totalListings: stats.totalListings || 0,
            totalTransactions: stats.totalTransactions || 0,
            totalRevenue: stats.totalRevenue || 0,
            pendingVerifications: stats.pendingVerifications || 0,
            reportedListings: stats.reportedListings || 0,
            disputedTransactions: stats.disputedTransactions || 0,
          },
          recentUsers: users.data || [],
          recentListings: listings.data || [],
          recentTransactions: transactions.data || [],
          recentReports: reports.data || [],
          salesData: stats.salesData || [
            { name: "Jan", transactions: 45, revenue: 22500000 },
            { name: "Feb", transactions: 58, revenue: 29000000 },
            { name: "Mar", transactions: 72, revenue: 36000000 },
            { name: "Apr", transactions: 80, revenue: 40000000 },
            { name: "May", transactions: 95, revenue: 47500000 },
            { name: "Jun", transactions: 110, revenue: 55000000 },
          ],
        })
      } catch (error) {
        console.error("Error fetching admin dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [user, userProfile, router, toast])

  const handleTabChange = (value) => {
    setActiveTab(value)
    triggerHaptic("light")
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value)
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  if (isLoading) {
    return <PixelLoading text="Loading Admin Dashboard..." />
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <EnhancedMobileNavbar />

        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="mb-6">
            <h1 className="font-futuristic text-xl glow-text">ADMIN DASHBOARD</h1>
            <p className="text-sm text-muted-foreground">Manage users, listings, transactions, and platform settings</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <StatCard
              title="Total Users"
              value={dashboardData.stats.totalUsers}
              icon={<Users className="h-5 w-5 text-primary" />}
              trend="+15%"
            />
            <StatCard
              title="Revenue"
              value={formatCurrency(dashboardData.stats.totalRevenue)}
              icon={<DollarSign className="h-5 w-5 text-green-500" />}
              trend="+12%"
            />
            <StatCard
              title="Transactions"
              value={dashboardData.stats.totalTransactions}
              icon={<ShoppingBag className="h-5 w-5 text-secondary" />}
              trend="+8%"
            />
            <StatCard
              title="Listings"
              value={dashboardData.stats.totalListings}
              icon={<TrendingUp className="h-5 w-5 text-accent" />}
              trend="+5%"
            />
          </div>

          {/* Alert Cards */}
          <div className="mb-6 space-y-3">
            <AlertCard
              title="Pending Verifications"
              count={dashboardData.stats.pendingVerifications}
              icon={<Shield className="h-5 w-5 text-primary" />}
              onClick={() => handleTabChange("users")}
            />
            <AlertCard
              title="Reported Listings"
              count={dashboardData.stats.reportedListings}
              icon={<Flag className="h-5 w-5 text-red-500" />}
              onClick={() => handleTabChange("listings")}
            />
            <AlertCard
              title="Disputed Transactions"
              count={dashboardData.stats.disputedTransactions}
              icon={<AlertCircle className="h-5 w-5 text-yellow-500" />}
              onClick={() => handleTabChange("transactions")}
            />
          </div>

          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search users, listings, transactions..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
            <TabsList className="grid grid-cols-4 md:grid-cols-8 gap-2 mb-4">
              <TabsTrigger value="overview" className="font-futuristic">
                OVERVIEW
              </TabsTrigger>
              <TabsTrigger value="users" className="font-futuristic">
                USERS
              </TabsTrigger>
              <TabsTrigger value="listings" className="font-futuristic">
                LISTINGS
              </TabsTrigger>
              <TabsTrigger value="transactions" className="font-futuristic">
                TRANSACTIONS
              </TabsTrigger>
              <TabsTrigger value="promotions" className="font-futuristic">
                PROMOS
              </TabsTrigger>
              <TabsTrigger value="reports" className="font-futuristic">
                REPORTS
              </TabsTrigger>
              <TabsTrigger value="flagged" className="font-futuristic">
                FLAGGED
              </TabsTrigger>
              <TabsTrigger value="settings" className="font-futuristic">
                SETTINGS
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              {/* Platform Performance Chart */}
              <Card className="mb-6 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-4">
                  <h3 className="font-futuristic text-sm mb-4 glow-text">PLATFORM PERFORMANCE</h3>
                  <div className="h-64">
                    <ChartContainer
                      config={{
                        transactions: {
                          label: "Transactions",
                          color: "hsl(var(--chart-1))",
                        },
                        revenue: {
                          label: "Revenue (IDR)",
                          color: "hsl(var(--chart-2))",
                        },
                      }}
                      className="h-full"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={dashboardData.salesData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                          <YAxis stroke="rgba(255,255,255,0.5)" />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Line
                            type="monotone"
                            dataKey="transactions"
                            stroke="var(--color-transactions)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                          <Line
                            type="monotone"
                            dataKey="revenue"
                            stroke="var(--color-revenue)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Reports */}
              <Card className="mb-6 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-futuristic text-sm glow-text">RECENT REPORTS</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => router.push("/admin/reports")}
                    >
                      View All
                    </Button>
                  </div>

                  {dashboardData.recentReports.length === 0 ? (
                    <div className="text-center py-6">
                      <p className="text-sm text-muted-foreground">No reports</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {dashboardData.recentReports.map((report) => (
                        <div
                          key={report.id}
                          className="flex items-center justify-between p-3 bg-muted/30 rounded-md cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => {
                            triggerHaptic("light")
                            router.push(`/admin/reports/${report.id}`)
                          }}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-md bg-red-500/20 flex items-center justify-center">
                              <Flag className="h-5 w-5 text-red-500" />
                            </div>
                            <div>
                              <p className="text-sm font-medium truncate w-36">{report.reason}</p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(report.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <Badge
                            variant="outline"
                            className={`text-xs capitalize ${
                              report.status === "resolved"
                                ? "text-green-500"
                                : report.status === "pending"
                                  ? "text-yellow-500"
                                  : "text-red-500"
                            }`}
                          >
                            {report.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="users">
              <AdminUserManagement initialUsers={dashboardData.recentUsers} />
            </TabsContent>

            <TabsContent value="listings">
              <AdminListingManagement initialListings={dashboardData.recentListings} />
            </TabsContent>

            <TabsContent value="transactions">
              <AdminTransactionManagement initialTransactions={dashboardData.recentTransactions} />
            </TabsContent>

            <TabsContent value="promotions">
              <AdminPromotionManagement />
            </TabsContent>

            <TabsContent value="reports">
              <AdminReports initialReports={dashboardData.recentReports} />
            </TabsContent>

            <TabsContent value="flagged">
              <AdminFlaggedContent />
            </TabsContent>

            <TabsContent value="settings">
              <AdminSettings />
            </TabsContent>
          </Tabs>

          {/* Platform Settings */}
          <Card className="bg-card/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-futuristic text-sm glow-text">PLATFORM SETTINGS</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    triggerHaptic("light")
                  }}
                >
                  <Settings className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Maintenance Mode</p>
                    <p className="text-xs text-muted-foreground">Take the platform offline for maintenance</p>
                  </div>
                  <Switch
                    id="maintenance-mode"
                    onCheckedChange={() => {
                      triggerHaptic("medium")
                    }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">New User Registration</p>
                    <p className="text-xs text-muted-foreground">Allow new users to register</p>
                  </div>
                  <Switch
                    id="new-user-registration"
                    defaultChecked
                    onCheckedChange={() => {
                      triggerHaptic("medium")
                    }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">New Listing Creation</p>
                    <p className="text-xs text-muted-foreground">Allow users to create new listings</p>
                  </div>
                  <Switch
                    id="new-listing-creation"
                    defaultChecked
                    onCheckedChange={() => {
                      triggerHaptic("medium")
                    }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">System Notifications</p>
                    <p className="text-xs text-muted-foreground">Send system-wide notifications</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => {
                      triggerHaptic("light")
                    }}
                  >
                    <Bell className="h-4 w-4 mr-2" />
                    Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </PageTransition>
  )
}

function StatCard({ title, value, icon, trend }) {
  const isTrendPositive = trend.startsWith("+")

  return (
    <Card className="bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs text-muted-foreground">{title}</p>
          <div className="text-primary">{icon}</div>
        </div>

        <div className="flex items-end justify-between">
          <p className="text-lg font-futuristic">{value}</p>
          <Badge
            variant="outline"
            className={`text-xs ${isTrendPositive ? "text-green-500" : trend === "0" ? "text-muted-foreground" : "text-red-500"}`}
          >
            {trend}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}

function AlertCard({ title, count, icon, onClick }) {
  return (
    <Card className="bg-card/50 backdrop-blur-sm">
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-primary">{icon}</div>
            <p className="text-sm font-medium">{title}</p>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs"
            onClick={() => {
              triggerHaptic("light")
              onClick()
            }}
          >
            {count > 0 ? `View ${count}` : "None"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
