"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
  AreaChart,
  Area,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { api } from "@/client/services/auth"
import { PixelLoading } from "@/components/pixel-loading"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SearchAnalytics() {
  const [isLoading, setIsLoading] = useState(true)
  const [popularSearches, setPopularSearches] = useState([])
  const [searchMetrics, setSearchMetrics] = useState<any>(null)
  const [searchSources, setSearchSources] = useState([])
  const [searchTrends, setSearchTrends] = useState([])
  const [ctrByPosition, setCtrByPosition] = useState([])
  const [timeRange, setTimeRange] = useState("7")
  const [trendInterval, setTrendInterval] = useState("day")
  const [relevanceConfig, setRelevanceConfig] = useState<any>(null)

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setIsLoading(true)

        // Fetch popular searches
        const popularResponse = await api.get(`/search/analytics/popular?days=${timeRange}&limit=20`)
        setPopularSearches(popularResponse.data.popularSearches)

        // Fetch search metrics
        const metricsResponse = await api.get(`/search/analytics/metrics?days=${timeRange}`)
        setSearchMetrics(metricsResponse.data)

        // Fetch search sources
        const sourcesResponse = await api.get(`/search/analytics/sources?days=${timeRange}`)
        setSearchSources(sourcesResponse.data.sources)

        // Fetch search trends
        const trendsResponse = await api.get(`/search/analytics/trends?days=${timeRange}&interval=${trendInterval}`)
        setSearchTrends(trendsResponse.data.trends)

        // Fetch CTR by position
        const ctrResponse = await api.get(`/search/analytics/ctr-by-position?days=${timeRange}`)
        setCtrByPosition(ctrResponse.data.ctrByPosition)

        // Fetch relevance configuration
        const relevanceResponse = await api.get(`/search/relevance-config`)
        setRelevanceConfig(relevanceResponse.data.config)
      } catch (error) {
        console.error("Error fetching search analytics:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnalytics()
  }, [timeRange, trendInterval])

  const updateRelevanceConfig = async (newConfig: any) => {
    try {
      const response = await api.post(`/search/relevance-config`, { config: newConfig })
      setRelevanceConfig(response.data.config)
    } catch (error) {
      console.error("Error updating relevance config:", error)
    }
  }

  if (isLoading) {
    return <PixelLoading text="Loading search analytics..." />
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Search Analytics</h1>

      <div className="mb-6">
        <Tabs defaultValue="7" onValueChange={setTimeRange}>
          <TabsList>
            <TabsTrigger value="1">Last 24 Hours</TabsTrigger>
            <TabsTrigger value="7">Last 7 Days</TabsTrigger>
            <TabsTrigger value="30">Last 30 Days</TabsTrigger>
            <TabsTrigger value="90">Last 90 Days</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Searches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{searchMetrics?.totalSearches.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">
              {searchMetrics?.uniqueSearches.toLocaleString()} unique queries
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Click-Through Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{(searchMetrics?.ctr * 100).toFixed(1)}%</div>
            <p className="text-sm text-muted-foreground">{searchMetrics?.totalClicks.toLocaleString()} total clicks</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Conversion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{(searchMetrics?.conversionRate * 100).toFixed(1)}%</div>
            <p className="text-sm text-muted-foreground">
              {searchMetrics?.totalConversions.toLocaleString()} conversions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Zero Results Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{(searchMetrics?.zeroResultRate * 100).toFixed(1)}%</div>
            <p className="text-sm text-muted-foreground">
              {(searchMetrics?.abandonmentRate * 100).toFixed(1)}% abandonment
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Search Trends</CardTitle>
            <CardDescription>Search volume over time</CardDescription>
            <Select value={trendInterval} onValueChange={setTrendInterval}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Interval" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hour">Hourly</SelectItem>
                <SelectItem value="day">Daily</SelectItem>
                <SelectItem value="week">Weekly</SelectItem>
                <SelectItem value="month">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ChartContainer
                config={{
                  count: {
                    label: "Search Count",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={searchTrends} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="count"
                      stroke="var(--color-count)"
                      fill="var(--color-count)"
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Search Sources</CardTitle>
            <CardDescription>Distribution of search types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={searchSources}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {searchSources.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Popular Searches</CardTitle>
            <CardDescription>Most frequent search terms</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ChartContainer
                config={{
                  count: {
                    label: "Search Count",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={popularSearches}
                    layout="vertical"
                    margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis type="category" dataKey="query" width={100} tick={{ fontSize: 12 }} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" fill="var(--color-count)" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Click-Through Rate by Position</CardTitle>
            <CardDescription>How position affects CTR</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ChartContainer
                config={{
                  ctr: {
                    label: "CTR",
                    color: "hsl(var(--chart-1))",
                  },
                  clicks: {
                    label: "Clicks",
                    color: "hsl(var(--chart-2))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={ctrByPosition} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="position" />
                    <YAxis yAxisId="left" orientation="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="ctr"
                      stroke="var(--color-ctr)"
                      name="CTR"
                      dot={{ r: 4 }}
                    />
                    <Line yAxisId="right" type="monotone" dataKey="clicks" stroke="var(--color-clicks)" name="Clicks" />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Relevance Configuration</CardTitle>
          <CardDescription>Adjust search relevance parameters</CardDescription>
        </CardHeader>
        <CardContent>
          {relevanceConfig && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <h3 className="font-medium mb-2">Field Weights</h3>
                {Object.entries(relevanceConfig.fieldWeights).map(([field, weight]) => (
                  <div key={field} className="flex items-center justify-between mb-2">
                    <span className="text-sm">{field}</span>
                    <input
                      type="number"
                      min="0"
                      max="10"
                      step="0.1"
                      value={weight}
                      onChange={(e) => {
                        const newConfig = { ...relevanceConfig }
                        newConfig.fieldWeights[field] = Number.parseFloat(e.target.value)
                        updateRelevanceConfig(newConfig)
                      }}
                      className="w-20 p-1 border rounded"
                    />
                  </div>
                ))}
              </div>

              <div>
                <h3 className="font-medium mb-2">Recency Boost</h3>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    checked={relevanceConfig.recencyBoost.enabled}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.recencyBoost.enabled = e.target.checked
                      updateRelevanceConfig(newConfig)
                    }}
                    className="mr-2"
                  />
                  <span className="text-sm">Enabled</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm">Weight</span>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={relevanceConfig.recencyBoost.weight}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.recencyBoost.weight = Number.parseFloat(e.target.value)
                      updateRelevanceConfig(newConfig)
                    }}
                    className="w-20 p-1 border rounded"
                  />
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm">Decay Scale</span>
                  <input
                    type="text"
                    value={relevanceConfig.recencyBoost.decayScale}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.recencyBoost.decayScale = e.target.value
                      updateRelevanceConfig(newConfig)
                    }}
                    className="w-20 p-1 border rounded"
                  />
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Other Boosts</h3>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    checked={relevanceConfig.popularityBoost.enabled}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.popularityBoost.enabled = e.target.checked
                      updateRelevanceConfig(newConfig)
                    }}
                    className="mr-2"
                  />
                  <span className="text-sm">Popularity Boost</span>
                </div>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    checked={relevanceConfig.featuredBoost.enabled}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.featuredBoost.enabled = e.target.checked
                      updateRelevanceConfig(newConfig)
                    }}
                    className="mr-2"
                  />
                  <span className="text-sm">Featured Boost</span>
                </div>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    checked={relevanceConfig.verifiedSellerBoost.enabled}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.verifiedSellerBoost.enabled = e.target.checked
                      updateRelevanceConfig(newConfig)
                    }}
                    className="mr-2"
                  />
                  <span className="text-sm">Verified Seller Boost</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm">Min Should Match</span>
                  <input
                    type="text"
                    value={relevanceConfig.minimumShouldMatch}
                    onChange={(e) => {
                      const newConfig = { ...relevanceConfig }
                      newConfig.minimumShouldMatch = e.target.value
                      updateRelevanceConfig(newConfig)
                    }}
                    className="w-20 p-1 border rounded"
                  />
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
