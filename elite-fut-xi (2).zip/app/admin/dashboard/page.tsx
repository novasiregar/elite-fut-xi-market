"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Users, ShoppingBag, CreditCard, BarChart3, Settings, AlertTriangle, TrendingUp, Flag } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { PageTransition } from "@/components/page-transition"
import { PixelLoading } from "@/components/pixel-loading"
import { AdminUserManagement } from "@/components/admin/admin-user-management"
import { AdminListingManagement } from "@/components/admin/admin-listing-management"
import { AdminTransactionManagement } from "@/components/admin/admin-transaction-management"
import { AdminReports } from "@/components/admin/admin-reports"
import { AdminSettings } from "@/components/admin/admin-settings"
import { AdminMetricsOverview } from "@/components/admin/admin-metrics-overview"
import { AdminFlaggedContent } from "@/components/admin/admin-flagged-content"
import { AdminPromotionManagement } from "@/components/admin/admin-promotion-management"
import { useAuth } from "@/context/auth-context"

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Check if user is admin
    const checkAdmin = async () => {
      try {
        // Simulate admin check
        const isAdmin = user?.role === "admin"
        if (!isAdmin) {
          toast({
            title: "Access Denied",
            description: "You don't have permission to access this page.",
            variant: "destructive",
          })
          router.push("/dashboard")
        }
        setLoading(false)
      } catch (error) {
        console.error("Error checking admin status:", error)
        setLoading(false)
        router.push("/dashboard")
      }
    }

    checkAdmin()
  }, [user, router, toast])

  if (loading) {
    return <PixelLoading text="Loading Admin Dashboard..." />
  }

  return (
    <PageTransition>
      <div className="container px-4 py-6 mx-auto">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage your marketplace, users, and transactions.</p>
          </div>

          <AdminMetricsOverview />

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid grid-cols-4 md:grid-cols-8 gap-2">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden md:inline">Overview</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Users</span>
              </TabsTrigger>
              <TabsTrigger value="listings" className="flex items-center gap-2">
                <ShoppingBag className="h-4 w-4" />
                <span className="hidden md:inline">Listings</span>
              </TabsTrigger>
              <TabsTrigger value="transactions" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <span className="hidden md:inline">Transactions</span>
              </TabsTrigger>
              <TabsTrigger value="promotions" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span className="hidden md:inline">Promotions</span>
              </TabsTrigger>
              <TabsTrigger value="reports" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                <span className="hidden md:inline">Reports</span>
              </TabsTrigger>
              <TabsTrigger value="flagged" className="flex items-center gap-2">
                <Flag className="h-4 w-4" />
                <span className="hidden md:inline">Flagged</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                <span className="hidden md:inline">Settings</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <AdminMetricsOverview detailed />
            </TabsContent>

            <TabsContent value="users" className="space-y-4">
              <AdminUserManagement />
            </TabsContent>

            <TabsContent value="listings" className="space-y-4">
              <AdminListingManagement />
            </TabsContent>

            <TabsContent value="transactions" className="space-y-4">
              <AdminTransactionManagement />
            </TabsContent>

            <TabsContent value="promotions" className="space-y-4">
              <AdminPromotionManagement />
            </TabsContent>

            <TabsContent value="reports" className="space-y-4">
              <AdminReports />
            </TabsContent>

            <TabsContent value="flagged" className="space-y-4">
              <AdminFlaggedContent />
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <AdminSettings />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PageTransition>
  )
}
