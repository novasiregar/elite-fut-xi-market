"use client"

import { useState, useEffect } from "react"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Wifi, WifiOff, RefreshCw, Clock, ShoppingCart, MessageCircle } from "lucide-react"
import { PixelLoading } from "@/components/pixel-loading"

export default function OfflinePage() {
  const [isOnline, setIsOnline] = useState(false)
  const [isChecking, setIsChecking] = useState(false)
  const [offlineData, setOfflineData] = useState<any>({
    pendingActions: [],
    cachedListings: [],
    recentMessages: [],
  })
  const [activeTab, setActiveTab] = useState("status")

  // Check online status
  useEffect(() => {
    setIsOnline(navigator.onLine)

    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Load offline data
  useEffect(() => {
    const loadOfflineData = async () => {
      try {
        // Try to fetch cached offline data
        const response = await fetch("/offline-data.json")
        if (response.ok) {
          const data = await response.json()
          setOfflineData(data)
        }
      } catch (error) {
        console.error("Failed to load offline data:", error)
      }
    }

    loadOfflineData()
  }, [])

  const checkConnection = () => {
    setIsChecking(true)

    // Simulate checking connection
    setTimeout(() => {
      setIsOnline(navigator.onLine)
      setIsChecking(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <Card className="pixel-border bg-card/50 backdrop-blur-sm mb-6">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              {isOnline ? (
                <Wifi className="h-8 w-8 text-green-500" />
              ) : (
                <WifiOff className="h-8 w-8 text-muted-foreground" />
              )}
            </div>

            <h1 className="font-futuristic text-xl mb-2 glow-text">{isOnline ? "BACK ONLINE" : "YOU'RE OFFLINE"}</h1>

            <p className="text-sm text-muted-foreground mb-4">
              {isOnline
                ? "Your connection has been restored. You can now continue using all features."
                : "Don't worry! You can still access some features while offline."}
            </p>

            <Button onClick={checkConnection} disabled={isChecking} className="w-full">
              {isChecking ? (
                <>
                  <PixelLoading size={16} className="mr-2" />
                  Checking Connection...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Check Connection
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="status" className="font-futuristic">
              STATUS
            </TabsTrigger>
            <TabsTrigger value="cached" className="font-futuristic">
              CACHED
            </TabsTrigger>
            <TabsTrigger value="pending" className="font-futuristic">
              PENDING
            </TabsTrigger>
          </TabsList>

          <TabsContent value="status">
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h2 className="font-futuristic text-sm mb-4 glow-text">NETWORK STATUS</h2>

                <div className="space-y-4">
                  <StatusItem
                    title="Connection"
                    status={isOnline ? "Online" : "Offline"}
                    statusColor={isOnline ? "text-green-500" : "text-red-500"}
                  />

                  <StatusItem
                    title="Cached Pages"
                    status={`${offlineData.cachedPages || 5} pages`}
                    statusColor="text-primary"
                  />

                  <StatusItem
                    title="Pending Actions"
                    status={`${offlineData.pendingActions?.length || 0} actions`}
                    statusColor={offlineData.pendingActions?.length ? "text-yellow-500" : "text-green-500"}
                  />

                  <StatusItem
                    title="Last Synced"
                    status={offlineData.lastSynced || "Unknown"}
                    statusColor="text-muted-foreground"
                  />
                </div>

                <div className="mt-6 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    While offline, you can browse cached listings, view your profile, and prepare messages. Actions will
                    be synced when you're back online.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cached">
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h2 className="font-futuristic text-sm mb-4 glow-text">CACHED CONTENT</h2>

                {offlineData.cachedListings && offlineData.cachedListings.length > 0 ? (
                  <div className="space-y-3">
                    {offlineData.cachedListings.map((listing: any, index: number) => (
                      <div key={index} className="flex items-center p-3 bg-muted/30 rounded-md">
                        <div className="w-12 h-12 bg-primary/10 rounded-md mr-3 flex items-center justify-center">
                          <ShoppingCart className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{listing.title || "Cached Listing"}</p>
                          <p className="text-xs text-muted-foreground">
                            Rp {listing.price?.toLocaleString() || "1,000,000"}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No cached content available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending">
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h2 className="font-futuristic text-sm mb-4 glow-text">PENDING ACTIONS</h2>

                {offlineData.pendingActions && offlineData.pendingActions.length > 0 ? (
                  <div className="space-y-3">
                    {offlineData.pendingActions.map((action: any, index: number) => (
                      <div key={index} className="flex items-center p-3 bg-muted/30 rounded-md">
                        <div className="w-10 h-10 rounded-full bg-yellow-500/20 mr-3 flex items-center justify-center">
                          {action.type === "message" ? (
                            <MessageCircle className="h-5 w-5 text-yellow-500" />
                          ) : (
                            <Clock className="h-5 w-5 text-yellow-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium capitalize">{action.type || "Action"}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {action.description || "Pending action will sync when online"}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No pending actions</p>
                  </div>
                )}

                <div className="mt-6 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    Pending actions will automatically sync when your connection is restored.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function StatusItem({
  title,
  status,
  statusColor,
}: {
  title: string
  status: string
  statusColor: string
}) {
  return (
    <div className="flex justify-between items-center p-3 bg-muted/30 rounded-md">
      <span className="text-sm">{title}</span>
      <span className={`text-sm font-futuristic ${statusColor}`}>{status}</span>
    </div>
  )
}
