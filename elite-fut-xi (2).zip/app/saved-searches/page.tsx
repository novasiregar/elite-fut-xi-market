import { SavedSearches } from "@/components/saved-searches"
import { MobileNavbar } from "@/components/mobile-navbar"

export default function SavedSearchesPage() {
  return (
    <main className="flex min-h-screen flex-col">
      <MobileNavbar />
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Saved Searches</h1>
        <SavedSearches />
      </div>
    </main>
  )
}
