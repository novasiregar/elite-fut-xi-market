import { Suspense } from "react"
import { VisualSearchResultsClient } from "@/components/visual-search-results-client"
import { MobileNavbar } from "@/components/mobile-navbar"
import { PixelLoading } from "@/components/pixel-loading"

interface VisualSearchResultsPageProps {
  searchParams: {
    id?: string
  }
}

export default function VisualSearchResultsPage({ searchParams }: VisualSearchResultsPageProps) {
  const searchId = searchParams.id

  if (!searchId) {
    return (
      <main className="flex min-h-screen flex-col">
        <MobileNavbar />
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold mb-6">Visual Search Results</h1>
          <div className="p-4 border border-red-200 rounded-md bg-red-50 text-red-800">
            <p>No search ID provided. Please try searching again.</p>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex min-h-screen flex-col">
      <MobileNavbar />
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Visual Search Results</h1>

        <Suspense fallback={<PixelLoading text="Loading visual search results..." />}>
          <VisualSearchResultsClient searchId={searchId} />
        </Suspense>
      </div>
    </main>
  )
}
