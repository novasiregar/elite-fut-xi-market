"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/context/auth-context"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { useRouter, useSearchParams } from "next/navigation"
import { ArrowLeft, Send, Shield, Clock, User } from "lucide-react"
import { MessageService } from "@/client/services/messages"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MessagesPage() {
  const { user, loading } = useAuth()
  const [conversations, setConversations] = useState<any[]>([])
  const [loadingConversations, setLoadingConversations] = useState(true)
  const [activeConversation, setActiveConversation] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [loadingMessages, setLoadingMessages] = useState(false)
  const [newMessage, setNewMessage] = useState("")
  const [sendingMessage, setSendingMessage] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()
  const userId = searchParams.get("userId")
  const listingId = searchParams.get("listingId")

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  // Fetch conversations
  useEffect(() => {
    if (user) {
      const fetchConversations = async () => {
        try {
          setLoadingConversations(true)
          const data = await MessageService.getConversations()
          setConversations(data)

          // If userId is provided in query params, find or create conversation
          if (userId) {
            const existingConversation = data.find((conv: any) => conv.otherParticipant.id === userId)

            if (existingConversation) {
              setActiveConversation(existingConversation)
            } else if (userId && userId !== user.uid) {
              // We'll handle new conversation creation when user sends first message
              setActiveConversation({
                newConversation: true,
                otherParticipant: {
                  id: userId,
                },
                listingId,
              })
            }
          } else if (data.length > 0) {
            // Set first conversation as active if no userId provided
            setActiveConversation(data[0])
          }
        } catch (error) {
          console.error("Error fetching conversations:", error)
          toast({
            title: "Error",
            description: "Failed to load conversations",
            variant: "destructive",
          })
        } finally {
          setLoadingConversations(false)
        }
      }

      fetchConversations()
    }
  }, [user, userId, listingId, toast])

  // Fetch messages when active conversation changes
  useEffect(() => {
    if (activeConversation && !activeConversation.newConversation) {
      const fetchMessages = async () => {
        try {
          setLoadingMessages(true)
          const data = await MessageService.getMessages(activeConversation.id)
          setMessages(data.messages || [])
        } catch (error) {
          console.error("Error fetching messages:", error)
          toast({
            title: "Error",
            description: "Failed to load messages",
            variant: "destructive",
          })
        } finally {
          setLoadingMessages(false)
        }
      }

      fetchMessages()
    } else {
      setMessages([])
      setLoadingMessages(false)
    }
  }, [activeConversation, toast])

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim()) return

    try {
      setSendingMessage(true)

      if (activeConversation.newConversation) {
        // Create new conversation
        const response = await MessageService.createConversation(
          activeConversation.otherParticipant.id,
          newMessage,
          activeConversation.listingId,
        )

        // Refresh conversations
        const conversationsData = await MessageService.getConversations()
        setConversations(conversationsData)

        // Find the new conversation
        const newConv = conversationsData.find((conv: any) => conv.id === response.conversationId)
        if (newConv) {
          setActiveConversation(newConv)
        }

        // Clear new message
        setNewMessage("")

        toast({
          title: "Message sent",
          description: "Your message has been sent",
        })
      } else {
        // Send message to existing conversation
        await MessageService.sendMessage(activeConversation.id, newMessage)

        // Add message to UI immediately
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            senderId: user?.uid,
            content: newMessage,
            createdAt: new Date().toISOString(),
            read: false,
          },
        ])

        // Clear new message
        setNewMessage("")
      }
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      })
    } finally {
      setSendingMessage(false)
    }
  }

  const selectConversation = (conversation: any) => {
    setActiveConversation(conversation)
  }

  if (loading || loadingConversations) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col space-y-4">
            <Skeleton className="h-8 w-48" />
            <div className="flex gap-2">
              <Skeleton className="h-10 w-20" />
              <Skeleton className="h-10 w-20" />
            </div>
            <Skeleton className="h-[60vh] w-full rounded-md" />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-futuristic text-lg glow-text ml-2">MESSAGES</h1>
        </div>

        <Tabs defaultValue="messages" className="mb-4">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="messages" className="font-futuristic">
              MESSAGES
            </TabsTrigger>
            <TabsTrigger value="contacts" className="font-futuristic">
              CONTACTS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages">
            {conversations.length === 0 ? (
              <Card className="pixel-border bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h2 className="text-lg font-futuristic mb-2">No Messages Yet</h2>
                  <p className="text-sm text-muted-foreground mb-4">
                    You don't have any conversations yet. Start by messaging a seller or buyer.
                  </p>
                  <Button onClick={() => router.push("/marketplace")}>Browse Marketplace</Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {conversations.map((conversation) => (
                  <ConversationCard
                    key={conversation.id}
                    conversation={conversation}
                    isActive={activeConversation?.id === conversation.id}
                    onClick={() => selectConversation(conversation)}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="contacts">
            <Card className="pixel-border bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <p className="text-sm text-muted-foreground">
                  Your contacts will appear here. You can message sellers directly from their listings.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {activeConversation && (
          <Card className="pixel-border bg-card/50 backdrop-blur-sm">
            {/* Conversation Header */}
            <div className="p-3 border-b border-border flex items-center gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={activeConversation.otherParticipant?.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-primary/20 text-primary">
                  {activeConversation.otherParticipant?.displayName?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-futuristic text-sm truncate">
                  {activeConversation.otherParticipant?.displayName || "User"}
                  {activeConversation.otherParticipant?.isVerified && (
                    <Shield className="inline-block ml-1 h-3 w-3 text-primary" />
                  )}
                </p>
                {!activeConversation.newConversation && (
                  <p className="text-xs text-muted-foreground">
                    Last active:{" "}
                    {activeConversation.updatedAt ? new Date(activeConversation.updatedAt).toLocaleString() : "Unknown"}
                  </p>
                )}
              </div>
            </div>

            {/* Messages */}
            <div className="p-3 h-[50vh] overflow-y-auto">
              {loadingMessages ? (
                <div className="flex flex-col gap-2">
                  <Skeleton className="h-10 w-3/4 ml-auto" />
                  <Skeleton className="h-10 w-2/3" />
                  <Skeleton className="h-10 w-3/4 ml-auto" />
                </div>
              ) : activeConversation.newConversation ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <p className="text-sm text-muted-foreground text-center">Start a new conversation with this user.</p>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <p className="text-sm text-muted-foreground text-center">No messages yet. Start the conversation!</p>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {messages.map((message) => (
                    <MessageBubble key={message.id} message={message} isOwn={message.senderId === user?.uid} />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* Message Input */}
            <div className="p-3 border-t border-border">
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  disabled={sendingMessage}
                  className="flex-1"
                />
                <Button type="submit" size="icon" disabled={sendingMessage || !newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </Card>
        )}
      </main>
    </div>
  )
}

function ConversationCard({
  conversation,
  isActive,
  onClick,
}: {
  conversation: any
  isActive: boolean
  onClick: () => void
}) {
  return (
    <Card
      className={`hover:bg-card/70 transition-colors cursor-pointer ${isActive ? "bg-primary/10 border-primary/50" : "bg-card/50"}`}
      onClick={onClick}
    >
      <CardContent className="p-3 flex items-center gap-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={conversation.otherParticipant?.avatar || "/placeholder.svg"} />
          <AvatarFallback className="bg-primary/20 text-primary">
            {conversation.otherParticipant?.displayName?.charAt(0) || "U"}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <p className="font-futuristic text-sm truncate">
              {conversation.otherParticipant?.displayName || "User"}
              {conversation.otherParticipant?.isVerified && (
                <Shield className="inline-block ml-1 h-3 w-3 text-primary" />
              )}
            </p>
            <p className="text-xs text-muted-foreground">
              {new Date(conversation.lastMessageTimestamp).toLocaleDateString()}
            </p>
          </div>

          <p className="text-sm truncate">
            {conversation.lastMessageSentBy === conversation.otherParticipant.id ? "" : "You: "}
            {conversation.lastMessage}
          </p>

          <div className="flex items-center justify-between mt-1">
            <p className="text-xs text-muted-foreground flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {new Date(conversation.lastMessageTimestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>

            {conversation.unreadCount > 0 && (
              <span className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5">
                {conversation.unreadCount}
              </span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function MessageBubble({
  message,
  isOwn,
}: {
  message: any
  isOwn: boolean
}) {
  return (
    <div className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-lg px-3 py-2 ${
          isOwn ? "bg-primary text-primary-foreground rounded-br-none" : "bg-muted rounded-bl-none"
        }`}
      >
        <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
        <p className="text-xs text-right mt-1 opacity-70">
          {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>
    </div>
  )
}
