/// <reference lib="webworker" />

// Enhanced service worker with improved caching strategies and offline support
declare const self: ServiceWorkerGlobalScope

const CACHE_NAME = "elite-fut-xi-v2"
const DYNAMIC_CACHE = "elite-fut-xi-dynamic-v2"

// Assets that should be cached immediately on install
const PRECACHE_ASSETS = [
  "/",
  "/offline",
  "/dashboard",
  "/marketplace",
  "/icons/icon-192x192.png",
  "/icons/icon-512x512.png",
  "/icons/icon-192x192-maskable.png",
  "/icons/icon-512x512-maskable.png",
  "/offline-data.json",
]

// Cache strategies
const STRATEGIES = {
  CACHE_FIRST: "cache-first", // Check cache first, then network
  NETWORK_FIRST: "network-first", // Try network first, fall back to cache
  STALE_WHILE_REVALIDATE: "stale-while-revalidate", // Return from cache while updating in background
}

// Route patterns and their corresponding strategies
const ROUTE_STRATEGIES = [
  { pattern: /\/api\/static\/.*/, strategy: STRATEGIES.CACHE_FIRST },
  { pattern: /\/api\/listings\/featured/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\/api\/listings\/.*/, strategy: STRATEGIES.STALE_WHILE_REVALIDATE },
  { pattern: /\/api\/.*/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\.(js|css|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/, strategy: STRATEGIES.CACHE_FIRST },
  { pattern: /\/marketplace.*/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\/listings\/.*/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\/profile.*/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\/messages.*/, strategy: STRATEGIES.NETWORK_FIRST },
  { pattern: /\/.*/, strategy: STRATEGIES.NETWORK_FIRST }, // Default strategy
]

// Install event - cache core assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[Service Worker] Precaching app shell")
      return cache.addAll(PRECACHE_ASSETS)
    }),
  )
  // Force the waiting service worker to become the active service worker
  self.skipWaiting()
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME && key !== DYNAMIC_CACHE) {
            console.log("[Service Worker] Removing old cache", key)
            return caches.delete(key)
          }
          return Promise.resolve()
        }),
      )
    }),
  )
  // Tell the active service worker to take control of the page immediately
  self.clients.claim()
})

// Helper function to determine which strategy to use for a given URL
function getStrategy(url: string): string {
  const matchedRoute = ROUTE_STRATEGIES.find((route) => route.pattern.test(url))
  return matchedRoute ? matchedRoute.strategy : STRATEGIES.NETWORK_FIRST
}

// Fetch event - handle all fetch requests
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url)

  // Skip cross-origin requests
  if (url.origin !== self.location.origin) {
    return
  }

  // Skip Chrome extensions and DevTools
  if (event.request.url.includes("chrome-extension") || event.request.url.includes("devtools")) {
    return
  }

  // Handle API requests
  if (url.pathname.startsWith("/api/")) {
    // For POST/PUT/DELETE requests, add to background sync if offline
    if (event.request.method !== "GET") {
      event.respondWith(
        fetch(event.request).catch((err) => {
          // If offline, store in IndexedDB for later sync
          return saveRequestForLater(event.request.clone()).then(() => {
            return Response.json(
              {
                success: false,
                offline: true,
                message: "You are offline. This action will be completed when you're back online.",
              },
              { status: 503 },
            )
          })
        }),
      )
      return
    }
  }

  // Handle navigation requests (HTML)
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match("/offline")
      }),
    )
    return
  }

  // Determine and apply the appropriate caching strategy
  const strategy = getStrategy(url.pathname)

  switch (strategy) {
    case STRATEGIES.CACHE_FIRST:
      event.respondWith(cacheFirst(event.request))
      break
    case STRATEGIES.NETWORK_FIRST:
      event.respondWith(networkFirst(event.request))
      break
    case STRATEGIES.STALE_WHILE_REVALIDATE:
      event.respondWith(staleWhileRevalidate(event.request))
      break
    default:
      event.respondWith(networkFirst(event.request))
  }
})

// Cache-first strategy
async function cacheFirst(request: Request) {
  const cachedResponse = await caches.match(request)
  if (cachedResponse) {
    return cachedResponse
  }

  try {
    const networkResponse = await fetch(request)
    await updateCache(request, networkResponse.clone())
    return networkResponse
  } catch (error) {
    // For images, return a fallback
    if (request.destination === "image") {
      return createImageFallback()
    }

    // For other resources, just return an error response
    return new Response("Network error", { status: 408 })
  }
}

// Network-first strategy
async function networkFirst(request: Request) {
  try {
    const networkResponse = await fetch(request)
    await updateCache(request, networkResponse.clone())
    return networkResponse
  } catch (error) {
    const cachedResponse = await caches.match(request)
    if (cachedResponse) {
      return cachedResponse
    }

    // For images, return a fallback
    if (request.destination === "image") {
      return createImageFallback()
    }

    // For other resources, just return an error response
    return new Response("Network error", { status: 408 })
  }
}

// Stale-while-revalidate strategy
async function staleWhileRevalidate(request: Request) {
  const cachedResponse = await caches.match(request)

  const fetchPromise = fetch(request)
    .then((networkResponse) => {
      updateCache(request, networkResponse.clone())
      return networkResponse
    })
    .catch((error) => {
      console.error("[Service Worker] Fetch failed:", error)
      // For images, return a fallback
      if (request.destination === "image") {
        return createImageFallback()
      }

      // For other resources, just return an error response
      return new Response("Network error", { status: 408 })
    })

  return cachedResponse || fetchPromise
}

// Helper function to update the cache
async function updateCache(request: Request, response: Response) {
  if (!response || response.status !== 200) {
    return
  }

  const cache = await caches.open(DYNAMIC_CACHE)
  cache.put(request, response)
}

// Create a fallback image
function createImageFallback() {
  return new Response(
    '<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg"><rect width="400" height="300" fill="#1e1e3a"/><text x="50%" y="50%" font-family="monospace" font-size="24" text-anchor="middle" fill="#00ffff">Image Offline</text></svg>',
    {
      headers: { "Content-Type": "image/svg+xml" },
    },
  )
}

// Save request for later (when back online)
async function saveRequestForLater(request: Request) {
  // This would normally save to IndexedDB
  // For simplicity, we're just logging it
  console.log("[Service Worker] Saving request for later:", request.url)

  // In a real implementation, you would:
  // 1. Open your IndexedDB
  // 2. Store the request URL, method, headers, and body
  // 3. Tag it for the appropriate sync operation

  // Register a sync event
  try {
    await self.registration.sync.register("sync-pending-requests")
    return Promise.resolve()
  } catch (err) {
    return Promise.reject(err)
  }
}

// Background sync for pending requests
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-messages") {
    event.waitUntil(syncMessages())
  } else if (event.tag === "sync-transactions") {
    event.waitUntil(syncTransactions())
  } else if (event.tag === "sync-pending-requests") {
    event.waitUntil(syncPendingRequests())
  }
})

// Push notifications
self.addEventListener("push", (event) => {
  const data = event.data?.json() ?? {}

  const title = data.title || "ELITE FUT XI Market"
  const options = {
    body: data.body || "You have a new notification",
    icon: "/icons/icon-192x192.png",
    badge: "/icons/badge-72x72.png",
    vibrate: [100, 50, 100],
    data: {
      url: data.url || "/",
      action: data.action || "default",
    },
    actions: data.actions || [
      { action: "view", title: "View" },
      { action: "close", title: "Close" },
    ],
  }

  event.waitUntil(self.registration.showNotification(title, options))
})

// Notification click event
self.addEventListener("notificationclick", (event) => {
  event.notification.close()

  // Handle notification action clicks
  if (event.action) {
    // Custom action handling based on the action type
    console.log(`[Service Worker] Notification action clicked: ${event.action}`)

    // If the action is "close", just close the notification
    if (event.action === "close") {
      return
    }
  }

  event.waitUntil(
    clients.matchAll({ type: "window" }).then((clientList) => {
      const url = event.notification.data.url

      // Check if there's already a window/tab open with the target URL
      for (const client of clientList) {
        if (client.url === url && "focus" in client) {
          return client.focus()
        }
      }

      // If not, open a new window/tab
      if (clients.openWindow) {
        return clients.openWindow(url)
      }
    }),
  )
})

// Sync pending messages
async function syncMessages() {
  // Implementation for syncing messages when back online
  const outbox = await getOutboxMessages()

  for (const message of outbox) {
    try {
      // Send message to server
      await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message),
      })

      // Remove from outbox if successful
      await removeFromOutbox(message.id)
    } catch (error) {
      console.error("Failed to sync message:", error)
    }
  }
}

// Sync pending transactions
async function syncTransactions() {
  // Implementation for syncing transactions when back online
  const pendingTransactions = await getPendingTransactions()

  for (const transaction of pendingTransactions) {
    try {
      // Send transaction to server
      await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(transaction),
      })

      // Remove from pending if successful
      await removeFromPending(transaction.id)
    } catch (error) {
      console.error("Failed to sync transaction:", error)
    }
  }
}

// Sync all pending requests
async function syncPendingRequests() {
  // This would normally retrieve from IndexedDB
  console.log("[Service Worker] Syncing pending requests")

  // In a real implementation, you would:
  // 1. Open your IndexedDB
  // 2. Get all pending requests
  // 3. For each request, send it to the server
  // 4. If successful, remove from IndexedDB

  return Promise.resolve()
}

// Helper functions to interact with IndexedDB
async function getOutboxMessages() {
  // Implementation to get outbox messages from IndexedDB
  return []
}

async function removeFromOutbox(id: string) {
  // Implementation to remove message from outbox
}

async function getPendingTransactions() {
  // Implementation to get pending transactions from IndexedDB
  return []
}

async function removeFromPending(id: string) {
  // Implementation to remove transaction from pending
}

export {}
