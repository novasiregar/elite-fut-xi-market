"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { FloatingPixels } from "@/components/floating-pixels"
import { EnhancedMobileNavbar } from "@/components/enhanced-mobile-navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Sparkles, Rocket, Zap, TrendingUp, DollarSign, Plus, Edit, Trash } from "lucide-react"
import { triggerHaptic } from "@/utils/haptic"
import { PromotionService } from "@/client/services/promotions"
import { SkeletonCard } from "@/components/ui/skeleton-elements"

export default function PromotionsPage() {
  const { user, userProfile } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("featured")
  const [isLoading, setIsLoading] = useState(true)
  const [promotions, setPromotions] = useState({
    featured: [],
    campaigns: [],
    available: [],
  })
  const [date, setDate] = useState(new Date())

  // Fetch promotions data
  useEffect(() => {
    if (!user) {
      router.push("/login?redirect=/promotions")
      return
    }

    const fetchPromotions = async () => {
      try {
        setIsLoading(true)

        // Fetch featured listings
        const featured = await PromotionService.getFeaturedListings()

        // Fetch promotional campaigns
        const campaigns = await PromotionService.getCampaigns()

        // Fetch available promotion options
        const available = await PromotionService.getAvailablePromotions()

        setPromotions({
          featured: featured || [],
          campaigns: campaigns || [],
          available: available || [],
        })
      } catch (error) {
        console.error("Error fetching promotions:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPromotions()
  }, [user, router])

  const handleTabChange = (value) => {
    setActiveTab(value)
    triggerHaptic("light")
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <EnhancedMobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="mb-6">
          <h1 className="font-futuristic text-xl glow-text">PROMOTIONAL TOOLS</h1>
          <p className="text-sm text-muted-foreground">Boost your listings and increase visibility</p>
        </div>

        {/* Promotion Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {isLoading ? (
            Array(4)
              .fill(0)
              .map((_, i) => <SkeletonCard key={i} className="h-24" />)
          ) : (
            <>
              <StatCard
                title="Featured Listings"
                value={promotions.featured.length}
                icon={<Sparkles className="h-5 w-5 text-primary" />}
              />
              <StatCard
                title="Active Campaigns"
                value={promotions.campaigns.filter((c) => c.status === "active").length}
                icon={<Rocket className="h-5 w-5 text-secondary" />}
              />
              <StatCard
                title="Visibility Boost"
                value="+45%"
                icon={<TrendingUp className="h-5 w-5 text-green-500" />}
              />
              <StatCard
                title="Promotion Budget"
                value={formatCurrency(5000000)}
                icon={<DollarSign className="h-5 w-5 text-accent" />}
              />
            </>
          )}
        </div>

        {/* Create New Promotion Button */}
        <div className="mb-6">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
                onClick={() => triggerHaptic("medium")}
              >
                <Plus className="mr-2 h-4 w-4" />
                Create New Promotion
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Promotion</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="promotion-type">Promotion Type</Label>
                  <Select defaultValue="featured">
                    <SelectTrigger>
                      <SelectValue placeholder="Select promotion type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="featured">Featured Listing</SelectItem>
                      <SelectItem value="campaign">Marketing Campaign</SelectItem>
                      <SelectItem value="boost">Visibility Boost</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="listing">Select Listing</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a listing" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="listing1">FIFA 25 Ultimate Team</SelectItem>
                      <SelectItem value="listing2">eFootball 2025 Legend</SelectItem>
                      <SelectItem value="listing3">FC 25 Pro Account</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration</Label>
                  <Select defaultValue="7">
                    <SelectTrigger>
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 Days (Rp 150,000)</SelectItem>
                      <SelectItem value="7">7 Days (Rp 300,000)</SelectItem>
                      <SelectItem value="14">14 Days (Rp 500,000)</SelectItem>
                      <SelectItem value="30">30 Days (Rp 800,000)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                        onClick={() => triggerHaptic("light")}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="auto-renew" />
                  <Label htmlFor="auto-renew">Auto-renew promotion</Label>
                </div>
              </div>
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => {
                    triggerHaptic("light")
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    triggerHaptic("success")
                  }}
                >
                  Create Promotion
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="featured" className="font-futuristic">
              FEATURED
            </TabsTrigger>
            <TabsTrigger value="campaigns" className="font-futuristic">
              CAMPAIGNS
            </TabsTrigger>
            <TabsTrigger value="available" className="font-futuristic">
              AVAILABLE
            </TabsTrigger>
          </TabsList>

          <TabsContent value="featured">
            {/* Featured Listings */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">FEATURED LISTINGS</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-20 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : promotions.featured.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No featured listings yet</p>
                    <Button
                      className="mt-4"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Feature Your First Listing
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {promotions.featured.map((listing) => (
                      <div
                        key={listing.id}
                        className="flex gap-3 p-3 bg-muted/30 rounded-md cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => {
                          triggerHaptic("light")
                          router.push(`/listings/${listing.id}`)
                        }}
                      >
                        <div className="w-16 h-16 rounded-md overflow-hidden">
                          <img
                            src={listing.image || "/placeholder.svg"}
                            alt={listing.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium truncate w-36">{listing.title}</p>
                            <Badge variant="outline" className="text-xs text-primary">
                              Featured
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{formatCurrency(listing.price)}</p>
                          <div className="flex items-center justify-between mt-2">
                            <p className="text-xs text-muted-foreground">
                              Expires: {new Date(listing.featuredUntil).toLocaleDateString()}
                            </p>
                            <div className="flex gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-6 text-xs"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  triggerHaptic("light")
                                }}
                              >
                                Extend
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 text-xs text-destructive"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  triggerHaptic("error")
                                }}
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Featured Performance */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">PERFORMANCE METRICS</h3>

                <div className="space-y-4">
                  <div className="bg-muted/30 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-sm font-medium">View Increase</h4>
                      <Badge variant="outline" className="text-xs text-green-500">
                        +125%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Featured listings receive 2.25x more views than regular listings
                    </p>
                  </div>

                  <div className="bg-muted/30 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-sm font-medium">Message Rate</h4>
                      <Badge variant="outline" className="text-xs text-green-500">
                        +85%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Featured listings receive 1.85x more messages than regular listings
                    </p>
                  </div>

                  <div className="bg-muted/30 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-sm font-medium">Sale Speed</h4>
                      <Badge variant="outline" className="text-xs text-green-500">
                        -40%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Featured listings sell 40% faster than regular listings
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="campaigns">
            {/* Marketing Campaigns */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">MARKETING CAMPAIGNS</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-20 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : promotions.campaigns.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No marketing campaigns yet</p>
                    <Button
                      className="mt-4"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Create Your First Campaign
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {promotions.campaigns.map((campaign) => (
                      <div
                        key={campaign.id}
                        className="p-3 bg-muted/30 rounded-md cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => {
                          triggerHaptic("light")
                          router.push(`/promotions/campaigns/${campaign.id}`)
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-10 h-10 rounded-md flex items-center justify-center ${
                                campaign.status === "active"
                                  ? "bg-green-500/20"
                                  : campaign.status === "scheduled"
                                    ? "bg-yellow-500/20"
                                    : "bg-muted/50"
                              }`}
                            >
                              <Rocket className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">{campaign.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {campaign.status === "active"
                                  ? `Ends: ${new Date(campaign.endDate).toLocaleDateString()}`
                                  : campaign.status === "scheduled"
                                    ? `Starts: ${new Date(campaign.startDate).toLocaleDateString()}`
                                    : `Ended: ${new Date(campaign.endDate).toLocaleDateString()}`}
                              </p>
                            </div>
                          </div>
                          <Badge
                            variant="outline"
                            className={`text-xs capitalize ${
                              campaign.status === "active"
                                ? "text-green-500"
                                : campaign.status === "scheduled"
                                  ? "text-yellow-500"
                                  : "text-muted-foreground"
                            }`}
                          >
                            {campaign.status}
                          </Badge>
                        </div>

                        <div className="mt-2 flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            {campaign.listingCount} listings • Budget: {formatCurrency(campaign.budget)}
                          </p>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={(e) => {
                                e.stopPropagation()
                                triggerHaptic("light")
                              }}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-destructive"
                              onClick={(e) => {
                                e.stopPropagation()
                                triggerHaptic("error")
                              }}
                            >
                              <Trash className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Create Campaign */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">CREATE CAMPAIGN</h3>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="campaign-name">Campaign Name</Label>
                    <Input id="campaign-name" placeholder="Enter campaign name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="campaign-description">Description</Label>
                    <Textarea id="campaign-description" placeholder="Enter campaign description" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Start Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal"
                            onClick={() => triggerHaptic("light")}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="duration">Duration</Label>
                      <Select defaultValue="7">
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 Days</SelectItem>
                          <SelectItem value="7">7 Days</SelectItem>
                          <SelectItem value="14">14 Days</SelectItem>
                          <SelectItem value="30">30 Days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="budget">Budget</Label>
                    <Input id="budget" placeholder="Enter budget amount" type="number" />
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => {
                      triggerHaptic("medium")
                    }}
                  >
                    Create Campaign
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="available">
            {/* Available Promotions */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">AVAILABLE PROMOTIONS</h3>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-20 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-md bg-primary/20 flex items-center justify-center">
                            <Sparkles className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Featured Listing</p>
                            <p className="text-xs text-muted-foreground">Highlight your listing at the top</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          From Rp 150,000
                        </Badge>
                      </div>

                      <div className="mt-2 flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">2.25x more visibility</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-6 text-xs"
                          onClick={() => {
                            triggerHaptic("light")
                          }}
                        >
                          Select
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-md bg-secondary/20 flex items-center justify-center">
                            <Rocket className="h-5 w-5 text-secondary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Marketing Campaign</p>
                            <p className="text-xs text-muted-foreground">Promote multiple listings</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          From Rp 500,000
                        </Badge>
                      </div>

                      <div className="mt-2 flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">Target specific audiences</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-6 text-xs"
                          onClick={() => {
                            triggerHaptic("light")
                          }}
                        >
                          Select
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 bg-muted/30 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-md bg-accent/20 flex items-center justify-center">
                            <Zap className="h-5 w-5 text-accent" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Visibility Boost</p>
                            <p className="text-xs text-muted-foreground">Short-term visibility increase</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          From Rp 50,000
                        </Badge>
                      </div>

                      <div className="mt-2 flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">24-hour boost in search results</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-6 text-xs"
                          onClick={() => {
                            triggerHaptic("light")
                          }}
                        >
                          Select
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Promotion Packages */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">PROMOTION PACKAGES</h3>

                <div className="space-y-3">
                  <div className="p-3 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-md border border-primary/30">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Starter Package</p>
                      <Badge variant="outline" className="text-xs text-primary">
                        Rp 250,000
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      7-day featured listing + 24-hour visibility boost
                    </p>
                    <Button
                      className="w-full mt-3 text-xs h-8"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Purchase
                    </Button>
                  </div>

                  <div className="p-3 bg-gradient-to-r from-secondary/20 to-accent/20 rounded-md border border-secondary/30">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Pro Package</p>
                      <Badge variant="outline" className="text-xs text-secondary">
                        Rp 500,000
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      14-day featured listing + 3-day visibility boost
                    </p>
                    <Button
                      className="w-full mt-3 text-xs h-8"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Purchase
                    </Button>
                  </div>

                  <div className="p-3 bg-gradient-to-r from-accent/20 to-primary/20 rounded-md border border-accent/30">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Premium Package</p>
                      <Badge variant="outline" className="text-xs text-accent">
                        Rp 1,000,000
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      30-day featured listing + 7-day visibility boost + marketing campaign
                    </p>
                    <Button
                      className="w-full mt-3 text-xs h-8"
                      onClick={() => {
                        triggerHaptic("medium")
                      }}
                    >
                      Purchase
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function StatCard({ title, value, icon }) {
  return (
    <Card className="bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs text-muted-foreground">{title}</p>
          <div className="text-primary">{icon}</div>
        </div>

        <div className="flex items-end justify-between">
          <p className="text-lg font-futuristic">{value}</p>
        </div>
      </CardContent>
    </Card>
  )
}
