"use client"

import { useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { TransactionHistoryDashboard } from "@/components/transaction-history-dashboard"
import { useRouter } from "next/navigation"

export default function TransactionHistoryPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-4xl mx-auto">
        <TransactionHistoryDashboard />
      </main>
    </div>
  )
}
