"use client"

import { useLanguage } from "@/context/language-context"
import { EnhancedThemeToggle } from "@/components/enhanced-theme-toggle"
import { LanguageSwitcher } from "@/components/language-switcher"
import { AccessibilityMenu } from "@/components/accessibility-menu"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"

export default function AccessibilityPage() {
  const { t } = useLanguage()

  return (
    <div className="container max-w-4xl py-8 px-4">
      <h1 id="main-content" className="text-3xl font-bold mb-6">
        {t("accessibility.accessibilitySettings")}
      </h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t("common.language")}</CardTitle>
            <CardDescription>{t("accessibility.changeLanguageDescription")}</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <LanguageSwitcher />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t("common.appearance")}</CardTitle>
            <CardDescription>{t("accessibility.changeAppearanceDescription")}</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <EnhancedThemeToggle />
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>{t("accessibility.accessibilityFeatures")}</CardTitle>
            <CardDescription>{t("accessibility.accessibilityFeaturesDescription")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center mb-6">
              <AccessibilityMenu />
            </div>

            <Tabs defaultValue="keyboard">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="keyboard">{t("accessibility.keyboardNavigation")}</TabsTrigger>
                <TabsTrigger value="screen-reader">{t("accessibility.screenReader")}</TabsTrigger>
                <TabsTrigger value="visual">{t("accessibility.visualAdjustments")}</TabsTrigger>
              </TabsList>

              <TabsContent value="keyboard" className="space-y-4 mt-4">
                <h3 className="text-lg font-medium">{t("accessibility.keyboardShortcuts")}</h3>
                <ul className="space-y-2">
                  <li className="flex justify-between">
                    <span>Tab</span>
                    <span>{t("accessibility.navigateElements")}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Shift + Tab</span>
                    <span>{t("accessibility.navigateElementsReverse")}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Enter / Space</span>
                    <span>{t("accessibility.activateElement")}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Esc</span>
                    <span>{t("accessibility.closeModal")}</span>
                  </li>
                </ul>

                <div className="border rounded-md p-4 mt-4">
                  <h4 className="text-sm font-medium mb-2">{t("accessibility.tryKeyboardNavigation")}</h4>
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">{t("common.name")}</Label>
                      <Input id="name" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">{t("common.email")}</Label>
                      <Input id="email" type="email" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="terms" />
                      <Label htmlFor="terms">{t("common.acceptTerms")}</Label>
                    </div>
                    <Button>{t("common.submit")}</Button>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="screen-reader" className="space-y-4 mt-4">
                <h3 className="text-lg font-medium">{t("accessibility.screenReaderSupport")}</h3>
                <p>{t("accessibility.screenReaderDescription")}</p>

                <div className="border rounded-md p-4 mt-4">
                  <h4 className="text-sm font-medium mb-2">{t("accessibility.ariaLabels")}</h4>
                  <p>{t("accessibility.ariaLabelsDescription")}</p>

                  <div className="mt-4">
                    <Button aria-label={t("accessibility.exampleButtonAriaLabel")}>
                      {t("accessibility.exampleButton")}
                    </Button>
                    <p className="text-sm text-muted-foreground mt-2">{t("accessibility.buttonHasAriaLabel")}</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="visual" className="space-y-4 mt-4">
                <h3 className="text-lg font-medium">{t("accessibility.visualAdjustments")}</h3>
                <p>{t("accessibility.visualAdjustmentsDescription")}</p>

                <div className="grid gap-4 mt-4">
                  <div className="flex items-center justify-between p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">{t("accessibility.highContrast")}</h4>
                      <p className="text-sm text-muted-foreground">{t("accessibility.highContrastDescription")}</p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => document.documentElement.classList.toggle("high-contrast")}
                    >
                      {t("common.toggle")}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">{t("accessibility.readingMode")}</h4>
                      <p className="text-sm text-muted-foreground">{t("accessibility.readingModeDescription")}</p>
                    </div>
                    <Button variant="outline" onClick={() => document.documentElement.classList.toggle("reading-mode")}>
                      {t("common.toggle")}
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
