import type React from "react"
import type { Metadata } from "next"
import { Press_Start_2P, Orbitron } from "next/font/google"
import { PageTransition } from "@/components/page-transition"
import { HapticProvider } from "@/utils/haptic"
import { ThemeProvider } from "@/components/theme-provider"
import { LanguageProvider } from "@/context/language-context"
import { DeepLinkHandler } from "@/components/deep-link-handler"
import { SkipToContent } from "@/components/skip-to-content"
import "./globals.css"

const pixelFont = Press_Start_2P({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-pixel",
})

const futuristicFont = Orbitron({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  variable: "--font-futuristic",
})

export const metadata: Metadata = {
  title: "ELITE FUT XI Market",
  description: "Indonesia's first mobile-only marketplace for football simulation gaming accounts",
  manifest: "/manifest.json",
    generator: 'v0.dev'
}

export const viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a1a" },
  ],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${pixelFont.variable} ${futuristicFont.variable} font-sans bg-background text-foreground min-h-screen`}
      >
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <LanguageProvider>
            <HapticProvider>
              <SkipToContent />
              <PageTransition>{children}</PageTransition>
              <DeepLinkHandler />
            </HapticProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
