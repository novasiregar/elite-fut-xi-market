"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { MobileNavbar } from "@/components/mobile-navbar"
import { ProductGrid } from "@/components/product-grid"
import { ProductGridSkeleton } from "@/components/product-grid-skeleton"
import { UnifiedSearch } from "@/components/unified-search"
import { PopularSearches } from "@/components/popular-searches"
import { SavedSearches } from "@/components/saved-searches"
import { SimilarListings } from "@/components/similar-listings"
import { RecommendationCarousel } from "@/components/recommendation-carousel"
import { useToast } from "@/hooks/use-toast"
import { SearchService } from "@/client/services/search"
import { useAuth } from "@/context/auth-context"
import { Button } from "@/components/ui/button"
import { SaveSearch } from "@/components/save-search-button"
import { PageTransition } from "@/components/page-transition"
import { FloatingPixels } from "@/components/floating-pixels"

export default function MarketplacePage() {
  const [listings, setListings] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [totalResults, setTotalResults] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [filters, setFilters] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [showSavedSearches, setShowSavedSearches] = useState(false)
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { user } = useAuth()

  // Initialize filters and search query from URL
  useEffect(() => {
    const initialFilters = {}

    // Parse search query
    const query = searchParams.get("q") || ""
    setSearchQuery(query)

    // Parse category
    if (searchParams.has("category")) {
      initialFilters.category = searchParams.get("category")
    }

    // Parse price range
    if (searchParams.has("minPrice") || searchParams.has("maxPrice")) {
      initialFilters.priceRange = [
        Number.parseInt(searchParams.get("minPrice") || "500000", 10),
        Number.parseInt(searchParams.get("maxPrice") || "5000000", 10),
      ]
    }

    // Parse rating
    if (searchParams.has("rating")) {
      initialFilters.rating = Number.parseFloat(searchParams.get("rating") || "0")
    }

    // Parse tags/filters
    if (searchParams.has("filters")) {
      initialFilters.tags = searchParams.get("filters")?.split(",") || []
    }

    setFilters(initialFilters)
  }, [searchParams])

  // Fetch listings when filters change
  useEffect(() => {
    const fetchListings = async () => {
      setIsLoading(true)

      try {
        const response = await SearchService.searchListings({
          query: searchQuery,
          filters,
          page: currentPage,
          limit: 12,
        })

        setListings(response.results)
        setTotalResults(response.total)
      } catch (error) {
        console.error("Error fetching listings:", error)
        toast({
          title: "Error",
          description: "Failed to load listings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchListings()
  }, [filters, currentPage, searchQuery, toast])

  const handleSearch = (searchParams) => {
    setSearchQuery(searchParams.searchTerm || "")
    setFilters((prevFilters) => ({
      ...prevFilters,
      ...searchParams.filters,
    }))
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const toggleSavedSearches = () => {
    setShowSavedSearches(!showSavedSearches)
  }

  return (
    <PageTransition>
      <main className="flex min-h-screen flex-col">
        <FloatingPixels count={10} />
        <MobileNavbar />

        <div className="container mx-auto px-4 py-6 pt-20">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold font-futuristic glow-text">MARKETPLACE</h1>
            {user && (
              <Button variant="outline" size="sm" onClick={toggleSavedSearches} className="text-xs">
                {showSavedSearches ? "Hide Saved" : "Saved Searches"}
              </Button>
            )}
          </div>

          {/* Unified search component */}
          <UnifiedSearch onSearch={handleSearch} initialFilters={filters} enableVisualSearch={true} />

          {/* Popular searches */}
          {!searchQuery && !Object.keys(filters).length && (
            <div className="mb-6">
              <PopularSearches onSelect={(query) => setSearchQuery(query)} />
            </div>
          )}

          {/* Saved searches (for logged in users) */}
          {user && showSavedSearches && (
            <div className="mb-6">
              <SavedSearches onSelect={handleSearch} />
            </div>
          )}

          {/* Save search button (when search is performed) */}
          {user && (searchQuery || Object.keys(filters).length > 0) && (
            <div className="mb-4">
              <SaveSearch query={searchQuery} filters={filters} resultCount={totalResults} />
            </div>
          )}

          {/* Search results count */}
          {!isLoading && (
            <div className="mb-4 text-sm text-muted-foreground">
              {totalResults > 0
                ? `Found ${totalResults} listings${searchQuery ? ` for "${searchQuery}"` : ""}`
                : `No listings found${searchQuery ? ` for "${searchQuery}"` : ""}`}
            </div>
          )}

          {/* Product grid with loading state */}
          {isLoading ? (
            <ProductGridSkeleton />
          ) : (
            <ProductGrid
              listings={listings}
              totalResults={totalResults}
              currentPage={currentPage}
              onPageChange={handlePageChange}
            />
          )}

          {/* Recommendations (when no search is performed) */}
          {!searchQuery && !Object.keys(filters).length && (
            <div className="mt-8">
              <h2 className="text-xl font-bold mb-4 font-futuristic">RECOMMENDED FOR YOU</h2>
              <RecommendationCarousel />
            </div>
          )}

          {/* Similar listings (when search is performed) */}
          {(searchQuery || Object.keys(filters).length > 0) && listings.length > 0 && (
            <div className="mt-8">
              <h2 className="text-xl font-bold mb-4 font-futuristic">SIMILAR LISTINGS</h2>
              <SimilarListings listingId={listings[0].id} />
            </div>
          )}
        </div>
      </main>
    </PageTransition>
  )
}
