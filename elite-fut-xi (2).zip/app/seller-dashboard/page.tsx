"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { FloatingPixels } from "@/components/floating-pixels"
import { EnhancedMobileNavbar } from "@/components/enhanced-mobile-navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import {
  DollarSign,
  ShoppingBag,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  Plus,
  ChevronRight,
  Eye,
  Heart,
  MessageCircle,
} from "lucide-react"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { triggerHaptic } from "@/utils/haptic"
import { SellerService } from "@/client/services/seller"
import { SkeletonCard } from "@/components/ui/skeleton-elements"

export default function SellerDashboardPage() {
  const { user, userProfile } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [dashboardData, setDashboardData] = useState({
    stats: {
      totalSales: 0,
      activeListings: 0,
      pendingTransactions: 0,
      totalRevenue: 0,
    },
    recentListings: [],
    recentTransactions: [],
    salesData: [],
    categoryData: [],
  })

  // Fetch dashboard data
  useEffect(() => {
    if (!user) {
      router.push("/login?redirect=/seller-dashboard")
      return
    }

    const fetchDashboardData = async () => {
      try {
        setIsLoading(true)

        // Fetch seller stats
        const stats = await SellerService.getStats()

        // Fetch seller's listings
        const listings = await SellerService.getListings()

        // Fetch seller's transactions
        const transactions = await SellerService.getTransactions()

        // Prepare dashboard data
        setDashboardData({
          stats: {
            totalSales: stats.totalSales || 0,
            activeListings: listings.filter((l) => l.status === "active").length,
            pendingTransactions: transactions.filter((t) => t.status === "pending").length,
            totalRevenue: stats.totalRevenue || 0,
          },
          recentListings: listings.slice(0, 5),
          recentTransactions: transactions.slice(0, 5),
          salesData: stats.salesData || [
            { name: "Jan", sales: 5, revenue: 2500000 },
            { name: "Feb", sales: 8, revenue: 4000000 },
            { name: "Mar", sales: 12, revenue: 6000000 },
            { name: "Apr", sales: 10, revenue: 5000000 },
            { name: "May", sales: 15, revenue: 7500000 },
            { name: "Jun", sales: 20, revenue: 10000000 },
          ],
          categoryData: stats.categoryData || [
            { name: "Premium", value: 40 },
            { name: "Standard", value: 30 },
            { name: "Budget", value: 20 },
            { name: "Other", value: 10 },
          ],
        })
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [user, router])

  const handleTabChange = (value) => {
    setActiveTab(value)
    triggerHaptic("light")
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  const COLORS = ["#00FFFF", "#9D00FF", "#4D7CFF", "#FF4D4D"]

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <EnhancedMobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="mb-6">
          <h1 className="font-futuristic text-xl glow-text">SELLER DASHBOARD</h1>
          <p className="text-sm text-muted-foreground">Manage your listings, track sales, and analyze performance</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {isLoading ? (
            Array(4)
              .fill(0)
              .map((_, i) => <SkeletonCard key={i} className="h-24" />)
          ) : (
            <>
              <StatCard
                title="Total Sales"
                value={dashboardData.stats.totalSales}
                icon={<ShoppingBag className="h-5 w-5 text-primary" />}
                trend="+12%"
              />
              <StatCard
                title="Revenue"
                value={formatCurrency(dashboardData.stats.totalRevenue)}
                icon={<DollarSign className="h-5 w-5 text-green-500" />}
                trend="+8%"
              />
              <StatCard
                title="Active Listings"
                value={dashboardData.stats.activeListings}
                icon={<TrendingUp className="h-5 w-5 text-secondary" />}
                trend="+3"
              />
              <StatCard
                title="Pending"
                value={dashboardData.stats.pendingTransactions}
                icon={<Clock className="h-5 w-5 text-yellow-500" />}
                trend="0"
              />
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <h2 className="font-futuristic text-sm mb-3 glow-text-secondary">QUICK ACTIONS</h2>
          <div className="grid grid-cols-2 gap-3">
            <Button
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80"
              onClick={() => {
                triggerHaptic("medium")
                router.push("/create-listing")
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              New Listing
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                triggerHaptic("light")
                router.push("/transactions")
              }}
            >
              <ShoppingBag className="mr-2 h-4 w-4" />
              Transactions
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="overview" className="font-futuristic">
              OVERVIEW
            </TabsTrigger>
            <TabsTrigger value="listings" className="font-futuristic">
              LISTINGS
            </TabsTrigger>
            <TabsTrigger value="analytics" className="font-futuristic">
              ANALYTICS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            {/* Sales Chart */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">SALES PERFORMANCE</h3>
                {isLoading ? (
                  <div className="h-64 bg-muted/30 rounded-md animate-pulse"></div>
                ) : (
                  <div className="h-64">
                    <ChartContainer
                      config={{
                        sales: {
                          label: "Sales",
                          color: "hsl(var(--chart-1))",
                        },
                        revenue: {
                          label: "Revenue (IDR)",
                          color: "hsl(var(--chart-2))",
                        },
                      }}
                      className="h-full"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={dashboardData.salesData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                          <YAxis stroke="rgba(255,255,255,0.5)" />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Line
                            type="monotone"
                            dataKey="sales"
                            stroke="var(--color-sales)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                          <Line
                            type="monotone"
                            dataKey="revenue"
                            stroke="var(--color-revenue)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-futuristic text-sm glow-text">RECENT TRANSACTIONS</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      triggerHaptic("light")
                      router.push("/transactions")
                    }}
                  >
                    View All
                  </Button>
                </div>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-16 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : dashboardData.recentTransactions.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No transactions yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {dashboardData.recentTransactions.map((transaction) => (
                      <div
                        key={transaction.id}
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-md cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => {
                          triggerHaptic("light")
                          router.push(`/transactions/${transaction.id}`)
                        }}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-md flex items-center justify-center ${
                              transaction.status === "completed"
                                ? "bg-green-500/20"
                                : transaction.status === "pending"
                                  ? "bg-yellow-500/20"
                                  : "bg-muted/50"
                            }`}
                          >
                            {transaction.status === "completed" ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : transaction.status === "pending" ? (
                              <Clock className="h-5 w-5 text-yellow-500" />
                            ) : (
                              <AlertCircle className="h-5 w-5 text-red-500" />
                            )}
                          </div>
                          <div>
                            <p className="text-sm font-medium truncate w-36">{transaction.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(transaction.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{formatCurrency(transaction.amount)}</p>
                          <Badge
                            variant="outline"
                            className={`text-xs capitalize ${
                              transaction.status === "completed"
                                ? "text-green-500"
                                : transaction.status === "pending"
                                  ? "text-yellow-500"
                                  : "text-red-500"
                            }`}
                          >
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="listings">
            {/* Active Listings */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-futuristic text-sm glow-text">YOUR LISTINGS</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      triggerHaptic("light")
                      router.push("/create-listing")
                    }}
                  >
                    <Plus className="mr-1 h-3 w-3" />
                    New
                  </Button>
                </div>

                {isLoading ? (
                  <div className="space-y-3">
                    {Array(3)
                      .fill(0)
                      .map((_, i) => (
                        <div key={i} className="h-20 bg-muted/30 rounded-md animate-pulse"></div>
                      ))}
                  </div>
                ) : dashboardData.recentListings.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground">No listings yet</p>
                    <Button
                      className="mt-4"
                      onClick={() => {
                        triggerHaptic("medium")
                        router.push("/create-listing")
                      }}
                    >
                      Create Your First Listing
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {dashboardData.recentListings.map((listing) => (
                      <div
                        key={listing.id}
                        className="flex gap-3 p-3 bg-muted/30 rounded-md cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => {
                          triggerHaptic("light")
                          router.push(`/listings/${listing.id}`)
                        }}
                      >
                        <div className="w-16 h-16 rounded-md overflow-hidden">
                          <img
                            src={listing.image || "/placeholder.svg"}
                            alt={listing.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium truncate w-36">{listing.title}</p>
                            <Badge
                              variant="outline"
                              className={`text-xs capitalize ${
                                listing.status === "active"
                                  ? "text-green-500"
                                  : listing.status === "pending"
                                    ? "text-yellow-500"
                                    : "text-red-500"
                              }`}
                            >
                              {listing.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{formatCurrency(listing.price)}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <div className="flex items-center text-xs text-muted-foreground">
                              <Eye className="h-3 w-3 mr-1" />
                              {listing.viewCount || 0}
                            </div>
                            <div className="flex items-center text-xs text-muted-foreground">
                              <Heart className="h-3 w-3 mr-1" />
                              {listing.favoriteCount || 0}
                            </div>
                            <div className="flex items-center text-xs text-muted-foreground">
                              <MessageCircle className="h-3 w-3 mr-1" />
                              {listing.messageCount || 0}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}

                    <Button
                      variant="ghost"
                      className="w-full text-xs"
                      onClick={() => {
                        triggerHaptic("light")
                        router.push("/seller-listings")
                      }}
                    >
                      View All Listings
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Listing Performance */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">LISTING PERFORMANCE</h3>
                {isLoading ? (
                  <div className="h-64 bg-muted/30 rounded-md animate-pulse"></div>
                ) : (
                  <div className="h-64">
                    <ChartContainer
                      config={{
                        views: {
                          label: "Views",
                          color: "hsl(var(--chart-1))",
                        },
                        favorites: {
                          label: "Favorites",
                          color: "hsl(var(--chart-2))",
                        },
                        messages: {
                          label: "Messages",
                          color: "hsl(var(--chart-3))",
                        },
                      }}
                      className="h-full"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Listing 1", views: 120, favorites: 15, messages: 8 },
                            { name: "Listing 2", views: 98, favorites: 12, messages: 5 },
                            { name: "Listing 3", views: 86, favorites: 10, messages: 7 },
                            { name: "Listing 4", views: 99, favorites: 11, messages: 3 },
                            { name: "Listing 5", views: 85, favorites: 9, messages: 4 },
                          ]}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                          <YAxis stroke="rgba(255,255,255,0.5)" />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Bar dataKey="views" fill="var(--color-views)" />
                          <Bar dataKey="favorites" fill="var(--color-favorites)" />
                          <Bar dataKey="messages" fill="var(--color-messages)" />
                        </BarChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            {/* Revenue Chart */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">REVENUE BREAKDOWN</h3>
                {isLoading ? (
                  <div className="h-64 bg-muted/30 rounded-md animate-pulse"></div>
                ) : (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={dashboardData.categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {dashboardData.categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value) => [`${value}%`, "Percentage"]}
                          contentStyle={{ background: "rgba(0, 0, 0, 0.8)", border: "none", borderRadius: "4px" }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Buyer Demographics */}
            <Card className="mb-6 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">BUYER DEMOGRAPHICS</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-muted/30 p-3 rounded-md">
                    <h4 className="text-xs text-muted-foreground mb-2">Age Groups</h4>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>18-24</span>
                          <span>45%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-primary h-full" style={{ width: "45%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>25-34</span>
                          <span>30%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-secondary h-full" style={{ width: "30%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>35-44</span>
                          <span>15%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-accent h-full" style={{ width: "15%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>45+</span>
                          <span>10%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-green-500 h-full" style={{ width: "10%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-muted/30 p-3 rounded-md">
                    <h4 className="text-xs text-muted-foreground mb-2">Regions</h4>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Jakarta</span>
                          <span>40%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-primary h-full" style={{ width: "40%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Bandung</span>
                          <span>20%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-secondary h-full" style={{ width: "20%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Surabaya</span>
                          <span>15%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-accent h-full" style={{ width: "15%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Other</span>
                          <span>25%</span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div className="bg-green-500 h-full" style={{ width: "25%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Conversion Rates */}
            <Card className="bg-card/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <h3 className="font-futuristic text-sm mb-4 glow-text">CONVERSION METRICS</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-muted/30 p-3 rounded-md text-center">
                    <p className="text-xs text-muted-foreground mb-1">View to Message</p>
                    <p className="text-xl font-futuristic glow-text">12.5%</p>
                    <p className="text-xs text-green-500">+2.3% vs last month</p>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-md text-center">
                    <p className="text-xs text-muted-foreground mb-1">Message to Sale</p>
                    <p className="text-xl font-futuristic glow-text-secondary">35.8%</p>
                    <p className="text-xs text-green-500">+5.1% vs last month</p>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-md text-center">
                    <p className="text-xs text-muted-foreground mb-1">Avg. Response Time</p>
                    <p className="text-xl font-futuristic glow-text-accent">2.5h</p>
                    <p className="text-xs text-red-500">+0.5h vs last month</p>
                  </div>
                  <div className="bg-muted/30 p-3 rounded-md text-center">
                    <p className="text-xs text-muted-foreground mb-1">Repeat Buyers</p>
                    <p className="text-xl font-futuristic glow-text">18%</p>
                    <p className="text-xs text-green-500">+3% vs last month</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function StatCard({ title, value, icon, trend }) {
  const isTrendPositive = trend.startsWith("+")

  return (
    <Card className="bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs text-muted-foreground">{title}</p>
          <div className="text-primary">{icon}</div>
        </div>

        <div className="flex items-end justify-between">
          <p className="text-lg font-futuristic">{value}</p>
          <Badge
            variant="outline"
            className={`text-xs ${isTrendPositive ? "text-green-500" : trend === "0" ? "text-muted-foreground" : "text-red-500"}`}
          >
            {trend}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
