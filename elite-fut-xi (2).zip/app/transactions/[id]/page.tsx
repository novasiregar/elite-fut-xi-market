"use client"

import type React from "react"

import { Input } from "@/components/ui/input"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { MobileNavbar } from "@/components/mobile-navbar"
import { FloatingPixels } from "@/components/floating-pixels"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, AlertCircle, CheckCircle, Clock, Shield, Send, MessageCircle } from "lucide-react"
import { TransactionService, TransactionStatus } from "@/client/services/transactions"
import { PaymentService, PaymentStatus } from "@/client/services/payments"
import { Skeleton } from "@/components/ui/skeleton"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function TransactionPage() {
  const { user, loading } = useAuth()
  const [transaction, setTransaction] = useState<any>(null)
  const [loadingTransaction, setLoadingTransaction] = useState(true)
  const [paymentMethods, setPaymentMethods] = useState<any[]>([])
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("")
  const [paymentDetails, setPaymentDetails] = useState<any>(null)
  const [loadingPayment, setLoadingPayment] = useState(false)
  const [deliveryDetails, setDeliveryDetails] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()
  const router = useRouter()
  const params = useParams()
  const transactionId = params.id as string

  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  // Fetch transaction details
  useEffect(() => {
    if (user && transactionId) {
      const fetchTransaction = async () => {
        try {
          setLoadingTransaction(true)
          const data = await TransactionService.getTransaction(transactionId)
          setTransaction(data)

          // If transaction is in payment processing state, check payment status
          if (data.status === TransactionStatus.PAYMENT_PROCESSING && data.paymentReference) {
            try {
              const paymentData = await PaymentService.checkPaymentStatus(data.paymentReference)
              setPaymentDetails(paymentData)
            } catch (error) {
              console.error("Error fetching payment status:", error)
            }
          }
        } catch (error) {
          console.error("Error fetching transaction:", error)
          toast({
            title: "Error",
            description: "Failed to load transaction details",
            variant: "destructive",
          })
        } finally {
          setLoadingTransaction(false)
        }
      }

      fetchTransaction()
    }
  }, [user, transactionId, toast])

  // Get payment methods
  useEffect(() => {
    setPaymentMethods(PaymentService.getPaymentMethods())
  }, [])

  const initializePayment = async () => {
    if (!selectedPaymentMethod) {
      setError("Please select a payment method")
      return
    }

    try {
      setLoadingPayment(true)
      setError("")

      const response = await PaymentService.initializePayment(transactionId, selectedPaymentMethod)
      setPaymentDetails(response.paymentDetails)

      // Refresh transaction to get updated status
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      toast({
        title: "Payment initialized",
        description: "Please complete your payment",
      })
    } catch (error: any) {
      console.error("Initialize payment error:", error)
      setError(error.message || "Failed to initialize payment")
    } finally {
      setLoadingPayment(false)
    }
  }

  const checkPaymentStatus = async () => {
    if (!transaction?.paymentReference) return

    try {
      setLoadingPayment(true)

      const paymentData = await PaymentService.checkPaymentStatus(transaction.paymentReference)
      setPaymentDetails(paymentData)

      // Refresh transaction to get updated status
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      if (paymentData.status === PaymentStatus.COMPLETED) {
        toast({
          title: "Payment completed",
          description: "Your payment has been processed successfully",
        })
      }
    } catch (error) {
      console.error("Check payment status error:", error)
    } finally {
      setLoadingPayment(false)
    }
  }

  const markAsDelivered = async () => {
    if (!deliveryDetails.trim()) {
      setError("Please enter delivery details")
      return
    }

    try {
      setIsSubmitting(true)
      setError("")

      await TransactionService.markAsDelivered(transactionId, deliveryDetails, "direct")

      // Refresh transaction
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      toast({
        title: "Account delivered",
        description: "You have marked the account as delivered",
      })
    } catch (error: any) {
      console.error("Mark as delivered error:", error)
      setError(error.message || "Failed to mark as delivered")
    } finally {
      setIsSubmitting(false)
    }
  }

  const confirmDelivery = async () => {
    try {
      setIsSubmitting(true)

      await TransactionService.confirmDelivery(transactionId)

      // Refresh transaction
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      toast({
        title: "Delivery confirmed",
        description: "You have confirmed the delivery and released the funds",
      })
    } catch (error: any) {
      console.error("Confirm delivery error:", error)
      setError(error.message || "Failed to confirm delivery")
    } finally {
      setIsSubmitting(false)
    }
  }

  const openDispute = async (reason: string, details: string) => {
    if (!reason.trim() || !details.trim()) {
      setError("Please provide a reason and details for the dispute")
      return
    }

    try {
      setIsSubmitting(true)
      setError("")

      await TransactionService.openDispute(transactionId, reason, details)

      // Refresh transaction
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      toast({
        title: "Dispute opened",
        description: "Your dispute has been submitted",
      })
    } catch (error: any) {
      console.error("Open dispute error:", error)
      setError(error.message || "Failed to open dispute")
    } finally {
      setIsSubmitting(false)
    }
  }

  const cancelTransaction = async () => {
    try {
      setIsSubmitting(true)

      await TransactionService.cancelTransaction(transactionId, "Cancelled by user")

      // Refresh transaction
      const updatedTransaction = await TransactionService.getTransaction(transactionId)
      setTransaction(updatedTransaction)

      toast({
        title: "Transaction cancelled",
        description: "The transaction has been cancelled",
      })
    } catch (error: any) {
      console.error("Cancel transaction error:", error)
      setError(error.message || "Failed to cancel transaction")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading || loadingTransaction) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex flex-col space-y-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-40 w-full rounded-md" />
            <Skeleton className="h-20 w-full rounded-md" />
            <Skeleton className="h-10 w-full" />
          </div>
        </main>
      </div>
    )
  }

  if (!transaction) {
    return (
      <div className="min-h-screen bg-background relative">
        <FloatingPixels count={15} />
        <MobileNavbar />
        <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
          <div className="flex items-center mb-6">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="font-futuristic text-lg glow-text ml-2">TRANSACTION</h1>
          </div>

          <Card className="pixel-border bg-card/50 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
              <h2 className="text-lg font-futuristic mb-2">Transaction Not Found</h2>
              <p className="text-sm text-muted-foreground mb-4">
                The transaction you're looking for doesn't exist or you don't have permission to view it.
              </p>
              <Button onClick={() => router.push("/profile")}>Go to Profile</Button>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  const isBuyer = user?.uid === transaction.buyerId
  const isSeller = user?.uid === transaction.sellerId

  const renderTransactionStatus = () => {
    switch (transaction.status) {
      case TransactionStatus.PENDING:
        return (
          <div className="bg-yellow-500/20 p-4 rounded-md">
            <h3 className="font-futuristic text-yellow-500 flex items-center mb-2">
              <Clock className="h-4 w-4 mr-2" /> PAYMENT PENDING
            </h3>
            {isBuyer && (
              <div className="space-y-4">
                <p className="text-sm">Please select a payment method to proceed with your purchase.</p>

                <RadioGroup value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                  <div className="grid grid-cols-2 gap-2">
                    {paymentMethods.map((method) => (
                      <div key={method.id} className="flex items-center space-x-2 border border-border rounded-md p-2">
                        <RadioGroupItem value={method.id} id={method.id} />
                        <Label htmlFor={method.id} className="flex items-center cursor-pointer">
                          <span className="text-xs">{method.name}</span>
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>

                {error && <div className="bg-destructive/20 p-2 rounded-md text-xs text-destructive">{error}</div>}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={cancelTransaction}
                    disabled={loadingPayment || isSubmitting}
                  >
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={initializePayment}
                    disabled={!selectedPaymentMethod || loadingPayment || isSubmitting}
                  >
                    {loadingPayment ? "Processing..." : "Pay Now"}
                  </Button>
                </div>
              </div>
            )}

            {isSeller && <p className="text-sm">Waiting for the buyer to complete payment.</p>}
          </div>
        )

      case TransactionStatus.PAYMENT_PROCESSING:
        return (
          <div className="bg-yellow-500/20 p-4 rounded-md">
            <h3 className="font-futuristic text-yellow-500 flex items-center mb-2">
              <Clock className="h-4 w-4 mr-2" /> PAYMENT PROCESSING
            </h3>

            {isBuyer && paymentDetails && (
              <div className="space-y-4">
                <p className="text-sm">Please complete your payment using the details below:</p>

                {transaction.paymentMethod === "gopay" && (
                  <div className="flex flex-col items-center">
                    {paymentDetails.qrCode && (
                      <div className="bg-white p-2 rounded-md mb-2">
                        <img
                          src={paymentDetails.qrCode || "/placeholder.svg"}
                          alt="GoPay QR Code"
                          className="w-48 h-48"
                        />
                      </div>
                    )}
                    <p className="text-xs text-center">Scan this QR code with your GoPay app</p>
                    {paymentDetails.deepLink && (
                      <Button size="sm" className="mt-2" onClick={() => window.open(paymentDetails.deepLink, "_blank")}>
                        Open GoPay App
                      </Button>
                    )}
                  </div>
                )}

                {transaction.paymentMethod === "ovo" && (
                  <div className="space-y-2">
                    <p className="text-sm">Enter your OVO phone number:</p>
                    <Input value={paymentDetails.phoneNumber || ""} readOnly />
                    <p className="text-xs">Amount: Rp {transaction.amount.toLocaleString()}</p>
                  </div>
                )}

                {transaction.paymentMethod === "dana" && (
                  <div className="flex flex-col items-center">
                    {paymentDetails.qrCode && (
                      <div className="bg-white p-2 rounded-md mb-2">
                        <img
                          src={paymentDetails.qrCode || "/placeholder.svg"}
                          alt="DANA QR Code"
                          className="w-48 h-48"
                        />
                      </div>
                    )}
                    <p className="text-xs text-center">Scan this QR code with your DANA app</p>
                    {paymentDetails.deepLink && (
                      <Button size="sm" className="mt-2" onClick={() => window.open(paymentDetails.deepLink, "_blank")}>
                        Open DANA App
                      </Button>
                    )}
                  </div>
                )}

                {transaction.paymentMethod === "bank_transfer" && paymentDetails.bankAccounts && (
                  <div className="space-y-3">
                    {paymentDetails.bankAccounts.map((account: any, index: number) => (
                      <div key={index} className="bg-muted/30 p-2 rounded-md">
                        <p className="text-xs font-medium">{account.bank}</p>
                        <p className="text-sm font-mono">{account.accountNumber}</p>
                        <p className="text-xs">{account.accountName}</p>
                      </div>
                    ))}
                    <p className="text-xs">Amount: Rp {transaction.amount.toLocaleString()}</p>
                    <p className="text-xs">Reference: {transaction.paymentReference}</p>
                  </div>
                )}

                <p className="text-xs text-muted-foreground">
                  Payment expires:{" "}
                  {paymentDetails.expiresAt ? new Date(paymentDetails.expiresAt).toLocaleString() : "N/A"}
                </p>

                <Button size="sm" className="w-full" onClick={checkPaymentStatus} disabled={loadingPayment}>
                  {loadingPayment ? "Checking..." : "I've Completed Payment"}
                </Button>
              </div>
            )}

            {isSeller && (
              <p className="text-sm">
                The buyer is in the process of making payment. You'll be notified once the payment is completed.
              </p>
            )}
          </div>
        )

      case TransactionStatus.ESCROW_FUNDED:
        return (
          <div className="bg-primary/20 p-4 rounded-md">
            <h3 className="font-futuristic text-primary flex items-center mb-2">
              <Shield className="h-4 w-4 mr-2" /> ESCROW FUNDED
            </h3>

            {isBuyer && (
              <p className="text-sm">
                Your payment has been received and is being held in escrow. Waiting for the seller to deliver the
                account.
              </p>
            )}

            {isSeller && (
              <div className="space-y-4">
                <p className="text-sm">
                  Payment has been received and is being held in escrow. Please deliver the account to the buyer.
                </p>

                <Textarea
                  placeholder="Enter account details, credentials, and instructions for the buyer..."
                  value={deliveryDetails}
                  onChange={(e) => setDeliveryDetails(e.target.value)}
                  className="h-32"
                  disabled={isSubmitting}
                />

                {error && <div className="bg-destructive/20 p-2 rounded-md text-xs text-destructive">{error}</div>}

                <Button className="w-full" onClick={markAsDelivered} disabled={isSubmitting}>
                  {isSubmitting ? "Processing..." : "Mark as Delivered"}
                </Button>
              </div>
            )}
          </div>
        )

      case TransactionStatus.ACCOUNT_DELIVERED:
        return (
          <div className="bg-primary/20 p-4 rounded-md">
            <h3 className="font-futuristic text-primary flex items-center mb-2">
              <Send className="h-4 w-4 mr-2" /> ACCOUNT DELIVERED
            </h3>

            {isBuyer && (
              <div className="space-y-4">
                <p className="text-sm">The seller has delivered the account. Please check the details below:</p>

                <div className="bg-muted/30 p-3 rounded-md">
                  <p className="text-sm whitespace-pre-wrap">{transaction.deliveryDetails}</p>
                </div>

                <p className="text-sm">
                  If you've received the account and everything is correct, please confirm the delivery to release the
                  funds to the seller.
                </p>

                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1">
                        Open Dispute
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Open Dispute</DialogTitle>
                      </DialogHeader>
                      <DisputeForm transactionId={transactionId} onSubmit={openDispute} />
                    </DialogContent>
                  </Dialog>

                  <Button size="sm" className="flex-1" onClick={confirmDelivery} disabled={isSubmitting}>
                    {isSubmitting ? "Processing..." : "Confirm & Release Funds"}
                  </Button>
                </div>
              </div>
            )}

            {isSeller && (
              <p className="text-sm">
                You have delivered the account. Waiting for the buyer to confirm receipt and release the funds.
              </p>
            )}
          </div>
        )

      case TransactionStatus.COMPLETED:
        return (
          <div className="bg-green-500/20 p-4 rounded-md">
            <h3 className="font-futuristic text-green-500 flex items-center mb-2">
              <CheckCircle className="h-4 w-4 mr-2" /> TRANSACTION COMPLETED
            </h3>
            <p className="text-sm">
              This transaction has been completed successfully. The funds have been released to the seller.
            </p>
          </div>
        )

      case TransactionStatus.DISPUTED:
        return (
          <div className="bg-destructive/20 p-4 rounded-md">
            <h3 className="font-futuristic text-destructive flex items-center mb-2">
              <AlertCircle className="h-4 w-4 mr-2" /> DISPUTE OPENED
            </h3>
            <p className="text-sm">
              A dispute has been opened for this transaction. Our support team will review the case and contact both
              parties.
            </p>
          </div>
        )

      case TransactionStatus.CANCELLED:
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-futuristic text-muted-foreground flex items-center mb-2">
              <AlertCircle className="h-4 w-4 mr-2" /> TRANSACTION CANCELLED
            </h3>
            <p className="text-sm">This transaction has been cancelled.</p>
          </div>
        )

      default:
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-futuristic text-muted-foreground flex items-center mb-2">
              <AlertCircle className="h-4 w-4 mr-2" /> UNKNOWN STATUS
            </h3>
            <p className="text-sm">The status of this transaction is unknown.</p>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingPixels count={15} />
      <MobileNavbar />

      <main className="pt-20 pb-20 px-4 max-w-md mx-auto">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-futuristic text-lg glow-text ml-2">TRANSACTION DETAILS</h1>
        </div>

        <Card className="pixel-border bg-card/50 backdrop-blur-sm mb-4">
          <CardContent className="p-4">
            <h2 className="font-futuristic text-base mb-2">{transaction.listingTitle}</h2>

            <div className="flex justify-between items-center mb-4">
              <div className="text-sm">
                <span className="text-muted-foreground">Transaction ID:</span>
                <span className="font-mono text-xs ml-1">{transaction.id.substring(0, 8)}</span>
              </div>
              <div className="text-sm font-futuristic">Rp {transaction.amount.toLocaleString()}</div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground text-xs">Date</p>
                <p>{new Date(transaction.createdAt).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Payment Method</p>
                <p className="capitalize">{transaction.paymentMethod?.replace("_", " ") || "Not selected"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Your Role</p>
                <p>{isBuyer ? "Buyer" : "Seller"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Escrow ID</p>
                <p className="font-mono text-xs">{transaction.escrowId}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transaction Status and Actions */}
        <div className="mb-4">{renderTransactionStatus()}</div>

        {/* Transaction Timeline */}
        <Card className="pixel-border bg-card/50 backdrop-blur-sm mb-4">
          <CardContent className="p-4">
            <h3 className="font-futuristic text-sm mb-3">TRANSACTION TIMELINE</h3>

            <div className="space-y-3">
              {transaction.timeline.map((event: any, index: number) => (
                <div key={index} className="flex gap-3">
                  <div className="relative">
                    <div className="w-2 h-2 rounded-full bg-primary mt-1.5"></div>
                    {index < transaction.timeline.length - 1 && (
                      <div className="absolute top-3 left-1 w-px h-full bg-border -ml-px"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{new Date(event.timestamp).toLocaleString()}</p>
                    <p className="text-sm">{event.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Contact Button */}
        <Button
          variant="outline"
          className="w-full mb-4"
          onClick={() => router.push(`/messages?userId=${isBuyer ? transaction.sellerId : transaction.buyerId}`)}
        >
          <MessageCircle className="h-4 w-4 mr-2" />
          Contact {isBuyer ? "Seller" : "Buyer"}
        </Button>
      </main>
    </div>
  )
}

function DisputeForm({
  transactionId,
  onSubmit,
}: {
  transactionId: string
  onSubmit: (reason: string, details: string) => Promise<void>
}) {
  const [reason, setReason] = useState("")
  const [details, setDetails] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!reason.trim() || !details.trim()) {
      setError("Please provide both a reason and details")
      return
    }

    try {
      setIsSubmitting(true)
      setError("")

      await onSubmit(reason, details)
    } catch (error: any) {
      setError(error.message || "Failed to open dispute")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <div className="bg-destructive/20 p-2 rounded-md text-xs text-destructive">{error}</div>}

      <div className="space-y-2">
        <label htmlFor="reason" className="text-sm font-medium">
          Reason for Dispute
        </label>
        <Input
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g., Account not as described"
          disabled={isSubmitting}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="details" className="text-sm font-medium">
          Dispute Details
        </label>
        <Textarea
          id="details"
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          placeholder="Provide detailed information about the issue..."
          className="h-32"
          disabled={isSubmitting}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? "Submitting..." : "Submit Dispute"}
      </Button>
    </form>
  )
}
