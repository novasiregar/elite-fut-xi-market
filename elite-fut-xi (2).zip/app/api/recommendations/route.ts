import { type NextRequest, NextResponse } from "next/server"
import { RecommendationEngine } from "@/server/services/recommendation-engine"
import { validateAuth } from "@/server/middleware/auth"

export async function GET(request: NextRequest) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId

    // Get query parameters
    const searchParams = request.nextUrl.searchParams
    const limit = Number.parseInt(searchParams.get("limit") || "10", 10)
    const context = searchParams.get("context") || "homepage"
    const listingId = searchParams.get("listingId") || undefined
    const categories = searchParams.getAll("categories")

    // Build context object
    const contextObj: any = {
      context,
    }

    if (listingId) {
      contextObj.listingId = listingId
    }

    if (categories.length > 0) {
      contextObj.categories = categories
    }

    const minPrice = searchParams.get("minPrice")
    const maxPrice = searchParams.get("maxPrice")

    if (minPrice && maxPrice) {
      contextObj.priceRange = {
        min: Number.parseInt(minPrice, 10),
        max: Number.parseInt(maxPrice, 10),
      }
    }

    // Get recommendations
    const recommendations = await RecommendationEngine.getPersonalizedRecommendations(userId, limit, contextObj)

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error("Error in recommendations API:", error)
    return NextResponse.json({ error: "Failed to fetch recommendations" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId

    // Get request body
    const body = await request.json()
    const { listingId, context } = body

    if (!listingId) {
      return NextResponse.json({ error: "listingId is required" }, { status: 400 })
    }

    // Record recommendation click
    await RecommendationEngine.recordUserAction(userId, "view", {
      listingId,
      category: context || "general",
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error in recommendation click API:", error)
    return NextResponse.json({ error: "Failed to record recommendation click" }, { status: 500 })
  }
}
