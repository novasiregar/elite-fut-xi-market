import { type NextRequest, NextResponse } from "next/server"
import { RecommendationEngine } from "@/server/services/recommendation-engine"

export async function GET(request: NextRequest) {
  try {
    // Get query parameters
    const searchParams = request.nextUrl.searchParams
    const limit = Number.parseInt(searchParams.get("limit") || "10", 10)

    // Get trending listings
    const listings = await RecommendationEngine.getTrendingListings(limit)

    return NextResponse.json({ listings })
  } catch (error) {
    console.error("Error in trending recommendations API:", error)
    return NextResponse.json({ error: "Failed to fetch trending listings" }, { status: 500 })
  }
}
