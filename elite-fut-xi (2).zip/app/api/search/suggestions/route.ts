import { type NextRequest, NextResponse } from "next/server"
import { SearchService } from "@/server/services/search-service"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    // Get query parameter
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q") || ""

    if (!query || query.length < 2) {
      return NextResponse.json({ suggestions: [] })
    }

    // Get user session for personalization
    const session = await getServerSession(authOptions)
    const userId = session?.user?.id || null

    // Get suggestions
    const suggestions = await SearchService.getSuggestions(query, userId)

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error("Suggestions error:", error)
    return NextResponse.json({ error: "Failed to get suggestions" }, { status: 500 })
  }
}
