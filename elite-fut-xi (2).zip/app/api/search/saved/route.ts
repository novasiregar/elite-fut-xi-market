import { type NextRequest, NextResponse } from "next/server"
import { SearchService } from "@/server/services/search-service"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    // Get user session
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's saved searches
    const savedSearches = await SearchService.getSavedSearches(session.user.id)

    return NextResponse.json({ savedSearches })
  } catch (error) {
    console.error("Error getting saved searches:", error)
    return NextResponse.json({ error: "Failed to get saved searches" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get user session
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const body = await request.json()
    const { name, query, filters, notificationsEnabled = false } = body

    if (!name) {
      return NextResponse.json({ error: "Search name is required" }, { status: 400 })
    }

    // Save search
    const savedSearch = await SearchService.saveSearch({
      userId: session.user.id,
      name,
      query: query || "",
      filters: filters || {},
      notificationsEnabled,
    })

    return NextResponse.json({ savedSearch })
  } catch (error) {
    console.error("Error saving search:", error)
    return NextResponse.json({ error: "Failed to save search" }, { status: 500 })
  }
}
