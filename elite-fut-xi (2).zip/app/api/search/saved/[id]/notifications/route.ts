import { type NextRequest, NextResponse } from "next/server"
import { validateAuth } from "@/server/middleware/auth"
import { db } from "@/server/index"

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId
    const searchId = params.id

    // Get saved search from database
    const savedSearchDoc = await db.collection("savedSearches").doc(searchId).get()

    if (!savedSearchDoc.exists) {
      return NextResponse.json({ error: "Saved search not found" }, { status: 404 })
    }

    const savedSearch = savedSearchDoc.data()

    // Check if the saved search belongs to the user
    if (savedSearch?.userId !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get request body
    const body = await request.json()
    const { enabled } = body

    if (enabled === undefined) {
      return NextResponse.json({ error: "Enabled status is required" }, { status: 400 })
    }

    // Update notifications status
    await db.collection("savedSearches").doc(searchId).update({
      notificationsEnabled: enabled,
    })

    return NextResponse.json({
      id: searchId,
      ...savedSearch,
      notificationsEnabled: enabled,
    })
  } catch (error) {
    console.error("Error in saved search notifications API:", error)
    return NextResponse.json({ error: "Failed to update notifications status" }, { status: 500 })
  }
}
