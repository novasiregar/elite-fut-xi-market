import { type NextRequest, NextResponse } from "next/server"
import { validateAuth } from "@/server/middleware/auth"
import { db } from "@/server/index"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId
    const searchId = params.id

    // Get saved search from database
    const savedSearchDoc = await db.collection("savedSearches").doc(searchId).get()

    if (!savedSearchDoc.exists) {
      return NextResponse.json({ error: "Saved search not found" }, { status: 404 })
    }

    const savedSearch = savedSearchDoc.data()

    // Check if the saved search belongs to the user
    if (savedSearch?.userId !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    return NextResponse.json({
      id: savedSearchDoc.id,
      ...savedSearch,
    })
  } catch (error) {
    console.error("Error in saved search API:", error)
    return NextResponse.json({ error: "Failed to fetch saved search" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId
    const searchId = params.id

    // Get saved search from database
    const savedSearchDoc = await db.collection("savedSearches").doc(searchId).get()

    if (!savedSearchDoc.exists) {
      return NextResponse.json({ error: "Saved search not found" }, { status: 404 })
    }

    const savedSearch = savedSearchDoc.data()

    // Check if the saved search belongs to the user
    if (savedSearch?.userId !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Get request body
    const body = await request.json()
    const { name, notificationsEnabled } = body

    // Update saved search
    const updates: Record<string, any> = {}

    if (name !== undefined) {
      updates.name = name
    }

    if (notificationsEnabled !== undefined) {
      updates.notificationsEnabled = notificationsEnabled
    }

    await db.collection("savedSearches").doc(searchId).update(updates)

    return NextResponse.json({
      id: searchId,
      ...savedSearch,
      ...updates,
    })
  } catch (error) {
    console.error("Error in saved search API:", error)
    return NextResponse.json({ error: "Failed to update saved search" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Validate authentication
    const authResult = await validateAuth(request)
    if (!authResult.isAuthenticated) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = authResult.userId
    const searchId = params.id

    // Get saved search from database
    const savedSearchDoc = await db.collection("savedSearches").doc(searchId).get()

    if (!savedSearchDoc.exists) {
      return NextResponse.json({ error: "Saved search not found" }, { status: 404 })
    }

    const savedSearch = savedSearchDoc.data()

    // Check if the saved search belongs to the user
    if (savedSearch?.userId !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Delete saved search
    await db.collection("savedSearches").doc(searchId).delete()

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error in saved search API:", error)
    return NextResponse.json({ error: "Failed to delete saved search" }, { status: 500 })
  }
}
