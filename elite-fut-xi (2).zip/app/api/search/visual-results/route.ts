import { type NextRequest, NextResponse } from "next/server"
import { VisualSearchService } from "@/server/services/visual-search-service"
import { ElasticsearchService } from "@/server/services/elasticsearch"

export async function GET(request: NextRequest) {
  try {
    // Get search ID from query parameters
    const searchParams = request.nextUrl.searchParams
    const searchId = searchParams.get("id")

    if (!searchId) {
      return NextResponse.json({ error: "Search ID is required" }, { status: 400 })
    }

    // Get visual search data from cache
    const visualSearchData = await VisualSearchService.getVisualSearchResults(searchId)

    if (!visualSearchData.terms || visualSearchData.terms.length === 0) {
      return NextResponse.json({ error: "Visual search data not found" }, { status: 404 })
    }

    // Build Elasticsearch query based on cached search terms
    const should: any[] = []

    // Add text search
    should.push({
      multi_match: {
        query: visualSearchData.terms.join(" "),
        fields: ["title^3", "description^2", "tags^2", "accountDetails.topPlayers^2"],
        type: "best_fields",
        fuzziness: "AUTO",
      },
    })

    // Execute search
    const response = await ElasticsearchService.searchListings({
      query: {
        bool: {
          must: [{ term: { status: "active" } }],
          should,
          minimum_should_match: 1,
        },
      },
      limit: 24,
    })

    return NextResponse.json({
      results: response.results,
      detectedObjects: visualSearchData.objects,
      searchTerms: visualSearchData.terms,
    })
  } catch (error) {
    console.error("Error in visual search results API:", error)
    return NextResponse.json({ error: "Failed to fetch visual search results" }, { status: 500 })
  }
}
