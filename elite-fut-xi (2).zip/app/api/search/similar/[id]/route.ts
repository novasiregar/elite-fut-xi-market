import { type NextRequest, NextResponse } from "next/server"
import { RecommendationEngine } from "@/server/services/recommendation-engine"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const listingId = params.id

    if (!listingId) {
      return NextResponse.json({ error: "Listing ID is required" }, { status: 400 })
    }

    // Get query parameters
    const searchParams = request.nextUrl.searchParams
    const limit = Number.parseInt(searchParams.get("limit") || "6", 10)

    // Get similar listings
    const listings = await RecommendationEngine.getSimilarListings(listingId, limit)

    return NextResponse.json({ listings })
  } catch (error) {
    console.error("Error in similar listings API:", error)
    return NextResponse.json({ error: "Failed to fetch similar listings" }, { status: 500 })
  }
}
