import { type NextRequest, NextResponse } from "next/server"
import { SearchService } from "@/server/services/search-service"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    // Get search parameters from query string
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q") || ""
    const page = Number.parseInt(searchParams.get("page") || "1", 10)
    const limit = Number.parseInt(searchParams.get("limit") || "10", 10)
    const sort = searchParams.get("sort")
    const order = searchParams.get("order") || "desc"

    // Parse filters
    const filters: any = {}

    // Add basic filters
    if (searchParams.has("category")) filters.category = searchParams.get("category")
    if (searchParams.has("minPrice")) filters.minPrice = Number.parseInt(searchParams.get("minPrice") || "0", 10)
    if (searchParams.has("maxPrice")) filters.maxPrice = Number.parseInt(searchParams.get("maxPrice") || "0", 10)
    if (searchParams.has("rating")) filters.rating = Number.parseFloat(searchParams.get("rating") || "0")
    if (searchParams.has("featured")) filters.featured = searchParams.get("featured") === "true"
    if (searchParams.has("verified")) filters.verified = searchParams.get("verified") === "true"

    // Parse tags filter
    if (searchParams.has("tags")) {
      const tagsParam = searchParams.get("tags")
      filters.tags = tagsParam ? tagsParam.split(",") : []
    }

    // Get user session for personalization
    const session = await getServerSession(authOptions)
    const userId = session?.user?.id || null

    // Execute search
    const results = await SearchService.searchListings({
      query,
      filters,
      sort: sort ? { field: sort, order } : undefined,
      page,
      limit,
      userId,
    })

    return NextResponse.json(results)
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ error: "Failed to perform search" }, { status: 500 })
  }
}
