import { initializeApp, cert } from "firebase-admin/app"
import { getFirestore } from "firebase-admin/firestore"
import dotenv from "dotenv"
import { seedUsers } from "./seed-users"
import { seedListings } from "./seed-listings"
import { seedTransactions } from "./seed-transactions"
import { seedMessages } from "./seed-messages"
import { seedReviews } from "./seed-reviews"
import { seedSavedSearches } from "./seed-saved-searches"
import { seedNotifications } from "./seed-notifications"
import { ElasticsearchService } from "../server/services/elasticsearch"

// Load environment variables
dotenv.config()

// Initialize Firebase Admin
initializeApp({
  credential: cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  }),
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
})

// Get Firestore instance
const db = getFirestore()

async function seedDatabase() {
  console.log("🌱 Starting database seeding...")

  try {
    // Initialize Elasticsearch
    await ElasticsearchService.initializeIndex()
    console.log("✅ Elasticsearch initialized")

    // Seed users first (we need them for other entities)
    const users = await seedUsers(db, 50)
    console.log(`✅ Seeded ${users.length} users`)

    // Seed listings
    const listings = await seedListings(db, users, 200)
    console.log(`✅ Seeded ${listings.length} listings`)

    // Seed transactions
    const transactions = await seedTransactions(db, users, listings, 100)
    console.log(`✅ Seeded ${transactions.length} transactions`)

    // Seed messages
    const messages = await seedMessages(db, users, listings, 300)
    console.log(`✅ Seeded ${messages.length} messages`)

    // Seed reviews
    const reviews = await seedReviews(db, users, transactions, 80)
    console.log(`✅ Seeded ${reviews.length} reviews`)

    // Seed saved searches
    const savedSearches = await seedSavedSearches(db, users, 60)
    console.log(`✅ Seeded ${savedSearches.length} saved searches`)

    // Seed notifications
    const notifications = await seedNotifications(db, users, listings, transactions, 150)
    console.log(`✅ Seeded ${notifications.length} notifications`)

    console.log("🎉 Database seeding completed successfully!")
  } catch (error) {
    console.error("❌ Error seeding database:", error)
    process.exit(1)
  }
}

// Run the seed function
seedDatabase()
