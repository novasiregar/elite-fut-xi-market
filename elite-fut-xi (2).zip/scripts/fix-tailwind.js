const fs = require("fs")
const { execSync } = require("child_process")
const path = require("path")

// Colors for console output
const colors = {
  reset: "\x1b[0m",
  bright: "\x1b[1m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  red: "\x1b[31m",
  cyan: "\x1b[36m",
}

console.log(`${colors.bright}${colors.cyan}=== Fixing Tailwind CSS Configuration ===${colors.reset}\n`)

// Step 1: Install @tailwindcss/postcss
try {
  console.log(`${colors.yellow}Installing @tailwindcss/postcss...${colors.reset}`)
  execSync("npm install @tailwindcss/postcss --save-dev", { stdio: "inherit" })
  console.log(`${colors.green}Successfully installed @tailwindcss/postcss${colors.reset}\n`)
} catch (error) {
  console.error(`${colors.red}Failed to install @tailwindcss/postcss:${colors.reset}`, error.message)
  process.exit(1)
}

// Step 2: Update postcss.config.js
try {
  console.log(`${colors.yellow}Updating PostCSS configuration...${colors.reset}`)

  const postcssConfig = `module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
}`

  fs.writeFileSync(path.join(process.cwd(), "postcss.config.js"), postcssConfig)
  console.log(`${colors.green}Successfully updated postcss.config.js${colors.reset}\n`)
} catch (error) {
  console.error(`${colors.red}Failed to update postcss.config.js:${colors.reset}`, error.message)
  process.exit(1)
}

// Step 3: Clear Next.js cache
try {
  console.log(`${colors.yellow}Clearing Next.js cache...${colors.reset}`)

  const nextCacheDir = path.join(process.cwd(), ".next")
  if (fs.existsSync(nextCacheDir)) {
    execSync(`rm -rf ${nextCacheDir}`, { stdio: "inherit" })
  }

  console.log(`${colors.green}Successfully cleared Next.js cache${colors.reset}\n`)
} catch (error) {
  console.error(`${colors.red}Failed to clear Next.js cache:${colors.reset}`, error.message)
  // Continue even if this fails
}

console.log(`${colors.bright}${colors.green}Configuration updated successfully!${colors.reset}`)
console.log(`${colors.cyan}You can now run 'npm run build' to build your project.${colors.reset}`)
