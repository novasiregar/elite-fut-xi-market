import { execSync } from "child_process"
import fs from "fs"
import path from "path"
import readline from "readline"

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

// Colors for console output
const colors = {
  reset: "\x1b[0m",
  bright: "\x1b[1m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  red: "\x1b[31m",
  cyan: "\x1b[36m",
}

console.log(`${colors.bright}${colors.cyan}
╔═══════════════════════════════════════════════════╗
║                                                   ║
║   ELITE FUT XI MARKET - LOCAL DEVELOPMENT SETUP   ║
║                                                   ║
╚═══════════════════════════════════════════════════╝${colors.reset}
`)

// Check if .env file exists, if not create it
const setupEnvFile = () => {
  console.log(`${colors.yellow}Checking environment configuration...${colors.reset}`)

  const envPath = path.join(process.cwd(), ".env.local")

  if (!fs.existsSync(envPath)) {
    console.log(`${colors.yellow}Creating .env.local file...${colors.reset}`)

    const envContent = `# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_FIREBASE_VAPID_KEY=

# Server Configuration
FIREBASE_PROJECT_ID=
FIREBASE_CLIENT_EMAIL=
FIREBASE_PRIVATE_KEY=
FIREBASE_STORAGE_BUCKET=
PORT=3001
FRONTEND_URL=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:3001/api
API_URL=http://localhost:3001/api

# Payment Gateway
GOPAY_API_KEY=test_key

# Webhook Secret
WEBHOOK_SECRET=local_webhook_secret

# Elasticsearch Configuration
ELASTICSEARCH_URL=http://localhost:9200
ELASTICSEARCH_USERNAME=
ELASTICSEARCH_PASSWORD=

# Redis Configuration
REDIS_URL=redis://localhost:6379
`

    fs.writeFileSync(envPath, envContent)
    console.log(`${colors.green}Created .env.local file. Please fill in your configuration values.${colors.reset}`)
    return false
  }

  console.log(`${colors.green}Environment file already exists.${colors.reset}`)
  return true
}

// Check if dependencies are installed
const checkDependencies = () => {
  console.log(`${colors.yellow}Checking dependencies...${colors.reset}`)

  try {
    // Check Node.js version
    const nodeVersion = execSync("node --version").toString().trim()
    console.log(`${colors.green}✓ Node.js ${nodeVersion} installed${colors.reset}`)

    // Check npm version
    const npmVersion = execSync("npm --version").toString().trim()
    console.log(`${colors.green}✓ npm ${npmVersion} installed${colors.reset}`)

    // Check if Firebase CLI is installed
    try {
      const firebaseVersion = execSync("firebase --version").toString().trim()
      console.log(`${colors.green}✓ Firebase CLI ${firebaseVersion} installed${colors.reset}`)
    } catch (error) {
      console.log(`${colors.red}✗ Firebase CLI not found. Installing...${colors.reset}`)
      execSync("npm install -g firebase-tools")
      console.log(`${colors.green}✓ Firebase CLI installed${colors.reset}`)
    }

    return true
  } catch (error) {
    console.error(`${colors.red}Error checking dependencies:${colors.reset}`, error)
    return false
  }
}

// Install project dependencies
const installDependencies = () => {
  console.log(`${colors.yellow}Installing project dependencies...${colors.reset}`)

  try {
    execSync("npm install", { stdio: "inherit" })
    console.log(`${colors.green}✓ Dependencies installed successfully${colors.reset}`)
    return true
  } catch (error) {
    console.error(`${colors.red}Error installing dependencies:${colors.reset}`, error)
    return false
  }
}

// Setup local services (Redis, Elasticsearch)
const setupLocalServices = async () => {
  console.log(`${colors.yellow}Setting up local services...${colors.reset}`)

  // Check if Docker is installed
  try {
    execSync("docker --version").toString().trim()
    console.log(`${colors.green}✓ Docker is installed${colors.reset}`)
  } catch (error) {
    console.log(
      `${colors.red}✗ Docker is not installed. Please install Docker to run Redis and Elasticsearch locally.${colors.reset}`,
    )
    console.log(
      `${colors.yellow}You can download Docker from: https://www.docker.com/products/docker-desktop${colors.reset}`,
    )
    return false
  }

  // Ask if user wants to start Redis and Elasticsearch
  return new Promise((resolve) => {
    rl.question(
      `${colors.yellow}Do you want to start Redis and Elasticsearch using Docker? (y/n) ${colors.reset}`,
      (answer) => {
        if (answer.toLowerCase() === "y") {
          try {
            // Create docker-compose.yml if it doesn't exist
            const dockerComposePath = path.join(process.cwd(), "docker-compose.yml")

            if (!fs.existsSync(dockerComposePath)) {
              const dockerComposeContent = `version: '3'
services:
  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped

  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:7.17.0
    environment:
      - discovery.type=single-node
      - "ES_JAVA_OPTS=-Xms512m -Xmx512m"
      - xpack.security.enabled=false
    ports:
      - "9200:9200"
    volumes:
      - elasticsearch-data:/usr/share/elasticsearch/data
    restart: unless-stopped

volumes:
  redis-data:
  elasticsearch-data:
`
              fs.writeFileSync(dockerComposePath, dockerComposeContent)
              console.log(`${colors.green}Created docker-compose.yml file.${colors.reset}`)
            }

            // Start services with Docker Compose
            console.log(`${colors.yellow}Starting Redis and Elasticsearch...${colors.reset}`)
            execSync("docker-compose up -d", { stdio: "inherit" })
            console.log(`${colors.green}✓ Redis and Elasticsearch started successfully${colors.reset}`)

            // Wait for Elasticsearch to be ready
            console.log(`${colors.yellow}Waiting for Elasticsearch to be ready...${colors.reset}`)
            let attempts = 0
            const maxAttempts = 30

            const checkElasticsearch = () => {
              try {
                execSync("curl -s http://localhost:9200/_cluster/health")
                console.log(`${colors.green}✓ Elasticsearch is ready${colors.reset}`)
                return true
              } catch (error) {
                attempts++
                if (attempts >= maxAttempts) {
                  console.log(
                    `${colors.red}Elasticsearch did not become ready in time. You may need to check its status manually.${colors.reset}`,
                  )
                  return false
                }
                console.log(
                  `${colors.yellow}Waiting for Elasticsearch (attempt ${attempts}/${maxAttempts})...${colors.reset}`,
                )
                return false
              }
            }

            // Check every 2 seconds
            const interval = setInterval(() => {
              if (checkElasticsearch()) {
                clearInterval(interval)
                resolve(true)
              }
            }, 2000)

            // Set a timeout
            setTimeout(() => {
              clearInterval(interval)
              console.log(`${colors.yellow}Timed out waiting for Elasticsearch, but continuing setup...${colors.reset}`)
              resolve(true)
            }, 60000) // 1 minute timeout
          } catch (error) {
            console.error(`${colors.red}Error starting services:${colors.reset}`, error)
            resolve(false)
          }
        } else {
          console.log(
            `${colors.yellow}Skipping local services setup. You'll need to configure Redis and Elasticsearch manually.${colors.reset}`,
          )
          resolve(true)
        }
      },
    )
  })
}

// Setup Firebase emulators
const setupFirebaseEmulators = async () => {
  console.log(`${colors.yellow}Setting up Firebase emulators...${colors.reset}`)

  // Check if firebase.json exists
  const firebaseConfigPath = path.join(process.cwd(), "firebase.json")

  if (!fs.existsSync(firebaseConfigPath)) {
    console.log(`${colors.yellow}Creating Firebase configuration...${colors.reset}`)

    const firebaseConfig = {
      firestore: {
        rules: "server/firebase/firestore.rules",
        indexes: "firestore.indexes.json",
      },
      storage: {
        rules: "server/firebase/storage.rules",
      },
      emulators: {
        auth: {
          port: 9099,
        },
        firestore: {
          port: 8080,
        },
        storage: {
          port: 9199,
        },
        ui: {
          enabled: true,
          port: 4000,
        },
      },
    }

    fs.writeFileSync(firebaseConfigPath, JSON.stringify(firebaseConfig, null, 2))
    console.log(`${colors.green}Created Firebase configuration.${colors.reset}`)

    // Create firestore.indexes.json if it doesn't exist
    const firestoreIndexesPath = path.join(process.cwd(), "firestore.indexes.json")

    if (!fs.existsSync(firestoreIndexesPath)) {
      const firestoreIndexes = {
        indexes: [],
        fieldOverrides: [],
      }

      fs.writeFileSync(firestoreIndexesPath, JSON.stringify(firestoreIndexes, null, 2))
    }
  }

  // Ask if user wants to start Firebase emulators
  return new Promise((resolve) => {
    rl.question(`${colors.yellow}Do you want to start Firebase emulators? (y/n) ${colors.reset}`, (answer) => {
      if (answer.toLowerCase() === "y") {
        try {
          console.log(`${colors.yellow}Starting Firebase emulators...${colors.reset}`)
          execSync("firebase emulators:start --only auth,firestore,storage", { stdio: "inherit" })
          resolve(true)
        } catch (error) {
          console.error(`${colors.red}Error starting Firebase emulators:${colors.reset}`, error)
          resolve(false)
        }
      } else {
        console.log(
          `${colors.yellow}Skipping Firebase emulators. You can start them later with 'firebase emulators:start'.${colors.reset}`,
        )
        resolve(true)
      }
    })
  })
}

// Main setup function
const runSetup = async () => {
  const envReady = setupEnvFile()
  const depsChecked = checkDependencies()

  if (!depsChecked) {
    console.log(`${colors.red}Please install the required dependencies and run the setup again.${colors.reset}`)
    rl.close()
    return
  }

  const depsInstalled = installDependencies()

  if (!depsInstalled) {
    console.log(`${colors.red}Failed to install dependencies. Please check for errors and try again.${colors.reset}`)
    rl.close()
    return
  }

  const servicesReady = await setupLocalServices()

  if (!envReady) {
    console.log(
      `${colors.yellow}Please fill in your environment variables in the .env.local file before continuing.${colors.reset}`,
    )
    rl.question(`${colors.yellow}Press Enter when you've updated the .env.local file... ${colors.reset}`, async () => {
      await setupFirebaseEmulators()
      showFinalInstructions()
      rl.close()
    })
  } else {
    await setupFirebaseEmulators()
    showFinalInstructions()
    rl.close()
  }
}

// Show final instructions
const showFinalInstructions = () => {
  console.log(`
${colors.bright}${colors.green}✓ Setup completed!${colors.reset}

${colors.bright}${colors.cyan}To start the development server:${colors.reset}
1. In one terminal: ${colors.yellow}npm run dev${colors.reset} (for Next.js frontend)
2. In another terminal: ${colors.yellow}npm run server${colors.reset} (for backend API)

${colors.bright}${colors.cyan}Additional commands:${colors.reset}
- ${colors.yellow}npm run build${colors.reset}: Build the production version
- ${colors.yellow}npm run start${colors.reset}: Start the production server
- ${colors.yellow}firebase emulators:start${colors.reset}: Start Firebase emulators

${colors.bright}${colors.cyan}Local URLs:${colors.reset}
- Frontend: ${colors.green}http://localhost:3000${colors.reset}
- Backend API: ${colors.green}http://localhost:3001/api${colors.reset}
- Firebase Emulator UI: ${colors.green}http://localhost:4000${colors.reset}
- Elasticsearch: ${colors.green}http://localhost:9200${colors.reset}
- Redis: ${colors.green}localhost:6379${colors.reset}

${colors.bright}${colors.cyan}Enjoy developing ELITE FUT XI MARKET!${colors.reset}
`)
}

// Run the setup
runSetup()
