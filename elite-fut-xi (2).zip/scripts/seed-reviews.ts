import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"
import type { SeedTransaction } from "./seed-transactions"

export interface SeedReview {
  id: string
  transactionId: string
  reviewerId: string
  reviewerName: string
  sellerId: string
  sellerName: string
  rating: number
  comment: string
  helpfulCount: number
  reportCount: number
  createdAt: string
}

export async function seedReviews(
  db: Firestore,
  users: SeedUser[],
  transactions: SeedTransaction[],
  count: number,
): Promise<SeedReview[]> {
  console.log(`Seeding ${count} reviews...`)

  const reviews: SeedReview[] = []
  const batch = db.batch()

  // Get only completed transactions
  const completedTransactions = transactions.filter((t) => t.status === "completed")

  // Ensure we don't try to create more reviews than completed transactions
  const actualCount = Math.min(count, completedTransactions.length)

  // Randomly select transactions to review
  const transactionsToReview = faker.helpers.arrayElements(completedTransactions, actualCount)

  for (const transaction of transactionsToReview) {
    const reviewer = users.find((u) => u.id === transaction.buyerId)!
    const seller = users.find((u) => u.id === transaction.sellerId)!

    const createdAt = faker.date.between({
      from: new Date(transaction.createdAt),
      to: new Date(),
    })

    // Generate rating (weighted towards positive)
    const rating = faker.helpers.weightedArrayElement([
      { weight: 50, value: 5 },
      { weight: 25, value: 4 },
      { weight: 15, value: 3 },
      { weight: 7, value: 2 },
      { weight: 3, value: 1 },
    ])

    // Generate comment based on rating
    let comment
    if (rating >= 4) {
      comment = faker.helpers.arrayElement([
        `Great seller! The account was exactly as described and the transaction was smooth.`,
        `Very satisfied with my purchase. The seller was responsive and helpful.`,
        `Excellent service and fast delivery. Would definitely buy from this seller again.`,
        `The account has even more coins than advertised. Very happy with this purchase!`,
        `Trustworthy seller and a fantastic account. Thanks!`,
      ])
    } else if (rating === 3) {
      comment = faker.helpers.arrayElement([
        `Decent transaction. The account was as described but the seller was a bit slow to respond.`,
        `OK experience. Nothing special but no major issues either.`,
        `The account is good but some of the players were different from the listing.`,
        `Average experience. Took longer than expected but got what I paid for.`,
      ])
    } else {
      comment = faker.helpers.arrayElement([
        `Disappointing experience. The account had less coins than advertised.`,
        `Seller was unresponsive and I had to chase for the account details.`,
        `Some features of the account were not as described. Wouldn't recommend.`,
        `Had issues accessing the account. Seller eventually helped but it was frustrating.`,
        `Not happy with this purchase. The account rating was lower than stated.`,
      ])
    }

    const helpfulCount = faker.number.int({ min: 0, max: 20 })
    const reportCount = rating <= 2 ? faker.number.int({ min: 0, max: 3 }) : 0

    const review: SeedReview = {
      id: faker.string.uuid(),
      transactionId: transaction.id,
      reviewerId: reviewer.id,
      reviewerName: reviewer.displayName,
      sellerId: seller.id,
      sellerName: seller.displayName,
      rating,
      comment,
      helpfulCount,
      reportCount,
      createdAt: createdAt.toISOString(),
    }

    reviews.push(review)
    const reviewRef = db.collection("reviews").doc(review.id)
    batch.set(reviewRef, review)

    // Update seller's rating in users collection
    const currentRating = seller.rating || 0
    const currentCount = seller.ratingCount || 0

    // Calculate new average rating
    const newCount = currentCount + 1
    const newRating = (currentRating * currentCount + rating) / newCount

    // Update user document
    const userRef = db.collection("users").doc(seller.id)
    batch.update(userRef, {
      rating: newRating,
      ratingCount: newCount,
      updatedAt: new Date(),
    })
  }

  // Commit the batch
  await batch.commit()

  return reviews
}
