import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"
import type { SeedListing } from "./seed-listings"

export interface SeedTransaction {
  id: string
  listingId: string
  listingTitle: string
  sellerId: string
  sellerName: string
  buyerId: string
  buyerName: string
  amount: number
  fee: number
  total: number
  status: "pending" | "processing" | "completed" | "cancelled" | "refunded" | "disputed"
  paymentMethod: "gopay" | "bank_transfer" | "credit_card" | "escrow"
  paymentDetails: {
    transactionId?: string
    accountNumber?: string
    receiptUrl?: string
  }
  escrow?: {
    releaseDate: string
    isReleased: boolean
    disputeReason?: string
    resolution?: string
  }
  createdAt: string
  updatedAt: string
}

export async function seedTransactions(
  db: Firestore,
  users: SeedUser[],
  listings: SeedListing[],
  count: number,
): Promise<SeedTransaction[]> {
  console.log(`Seeding ${count} transactions...`)

  const transactions: SeedTransaction[] = []
  const batch = db.batch()

  // Get only active and sold listings
  const availableListings = listings.filter((listing) => listing.status === "active" || listing.status === "sold")

  // Get non-admin users
  const regularUsers = users.filter((user) => !user.isAdmin)

  for (let i = 0; i < count; i++) {
    // Get a random listing
    const listing = faker.helpers.arrayElement(availableListings)

    // Get seller from the listing
    const seller = users.find((user) => user.id === listing.sellerId)!

    // Get a random buyer (not the seller)
    let buyer
    do {
      buyer = faker.helpers.arrayElement(regularUsers)
    } while (buyer.id === seller.id)

    const createdAt = faker.date.past({ years: 1 })
    const updatedAt = faker.date.between({ from: createdAt, to: new Date() })

    const amount = listing.price
    const fee = Math.round(amount * 0.05) // 5% platform fee
    const total = amount + fee

    const paymentMethod = faker.helpers.arrayElement(["gopay", "bank_transfer", "credit_card", "escrow"])

    const status = faker.helpers.weightedArrayElement([
      { weight: 60, value: "completed" },
      { weight: 15, value: "pending" },
      { weight: 10, value: "processing" },
      { weight: 5, value: "cancelled" },
      { weight: 5, value: "refunded" },
      { weight: 5, value: "disputed" },
    ])

    // If the transaction is completed or refunded, mark the listing as sold
    if (status === "completed" || status === "refunded") {
      listing.status = "sold"

      // Update the listing in Firestore
      const listingRef = db.collection("listings").doc(listing.id)
      batch.update(listingRef, { status: "sold" })
    }

    const paymentDetails: any = {}

    if (paymentMethod === "gopay" || paymentMethod === "credit_card") {
      paymentDetails.transactionId = faker.string.alphanumeric(12).toUpperCase()
    }

    if (paymentMethod === "bank_transfer") {
      paymentDetails.accountNumber = faker.finance.accountNumber()
      paymentDetails.receiptUrl = `https://picsum.photos/seed/${faker.string.uuid()}/800/600`
    }

    let escrow
    if (paymentMethod === "escrow") {
      const releaseDate = faker.date.future({ refDate: createdAt })

      escrow = {
        releaseDate: releaseDate.toISOString(),
        isReleased: status === "completed",
      }

      if (status === "disputed") {
        escrow.disputeReason = faker.helpers.arrayElement([
          "Item not as described",
          "Account credentials don't work",
          "Seller not responding",
          "Account banned after purchase",
        ])

        if (Math.random() > 0.5) {
          escrow.resolution = faker.helpers.arrayElement(["Refunded to buyer", "Released to seller", "Partial refund"])
        }
      }
    }

    const transaction: SeedTransaction = {
      id: faker.string.uuid(),
      listingId: listing.id,
      listingTitle: listing.title,
      sellerId: seller.id,
      sellerName: seller.displayName,
      buyerId: buyer.id,
      buyerName: buyer.displayName,
      amount,
      fee,
      total,
      status: status as any,
      paymentMethod: paymentMethod as any,
      paymentDetails,
      ...(escrow && { escrow }),
      createdAt: createdAt.toISOString(),
      updatedAt: updatedAt.toISOString(),
    }

    transactions.push(transaction)
    const transactionRef = db.collection("transactions").doc(transaction.id)
    batch.set(transactionRef, transaction)
  }

  // Commit the batch
  await batch.commit()

  return transactions
}
