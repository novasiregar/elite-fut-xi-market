import { Client } from "@elastic/elasticsearch"
import { db } from "../server/index"
import { ElasticsearchService } from "../server/services/elasticsearch"

// Initialize Elasticsearch client
const client = new Client({
  node: process.env.ELASTICSEARCH_URL,
  auth: {
    username: process.env.ELASTICSEARCH_USERNAME || "",
    password: process.env.ELASTICSEARCH_PASSWORD || "",
  },
})

const INDEX_NAME = "listings"

async function setupElasticsearch() {
  console.log("Starting Elasticsearch setup...")

  try {
    // Initialize the index with proper mappings
    await ElasticsearchService.initializeIndex()
    console.log("Index initialized successfully")

    // Fetch all active listings from Firestore
    console.log("Fetching listings from Firestore...")
    const listingsSnapshot = await db.collection("listings").where("status", "==", "active").get()

    if (listingsSnapshot.empty) {
      console.log("No active listings found in Firestore")
      return
    }

    const listings = listingsSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    console.log(`Found ${listings.length} active listings to index`)

    // Index listings in batches of 100
    const batchSize = 100
    const batches = Math.ceil(listings.length / batchSize)

    for (let i = 0; i < batches; i++) {
      const start = i * batchSize
      const end = Math.min(start + batchSize, listings.length)
      const batch = listings.slice(start, end)

      console.log(`Indexing batch ${i + 1}/${batches} (${batch.length} listings)`)
      await ElasticsearchService.bulkIndexListings(batch)
    }

    console.log("All listings indexed successfully")

    // Verify index status
    const stats = await client.indices.stats({ index: INDEX_NAME })
    console.log(`Index stats: ${stats.indices[INDEX_NAME]._all.primaries.docs.count} documents indexed`)

    console.log("Elasticsearch setup completed successfully")
  } catch (error) {
    console.error("Error setting up Elasticsearch:", error)
    process.exit(1)
  }
}

// Run the setup
setupElasticsearch()
