import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import bcrypt from "bcrypt"

export interface SeedUser {
  id: string
  email: string
  username: string
  displayName: string
  password: string
  bio?: string
  avatar?: string
  phone?: string
  isVerified: boolean
  isSeller: boolean
  isAdmin: boolean
  balance: number
  rating: number
  ratingCount: number
  fcmTokens?: string[]
  preferences?: {
    notifications: {
      email: boolean
      push: boolean
      sms: boolean
    }
    privacy: {
      showEmail: boolean
      showPhone: boolean
    }
    theme: string
    language: string
  }
  stats?: {
    listingsCount: number
    salesCount: number
    purchasesCount: number
    totalSales: number
    totalPurchases: number
    joinedAt: Date
    lastActive: Date
  }
  createdAt: Date
  updatedAt: Date
}

export async function seedUsers(db: Firestore, count: number): Promise<SeedUser[]> {
  console.log(`Seeding ${count} users...`)

  const users: SeedUser[] = []
  const batch = db.batch()

  // Create admin user
  const adminUser: SeedUser = {
    id: "admin",
    email: "admin@elitefutxi.com",
    username: "admin",
    displayName: "Admin User",
    password: await bcrypt.hash("admin123", 10),
    bio: "System administrator",
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=admin`,
    isVerified: true,
    isSeller: true,
    isAdmin: true,
    balance: 1000000,
    rating: 5,
    ratingCount: 1,
    preferences: {
      notifications: {
        email: true,
        push: true,
        sms: true,
      },
      privacy: {
        showEmail: false,
        showPhone: false,
      },
      theme: "system",
      language: "en",
    },
    stats: {
      listingsCount: 0,
      salesCount: 0,
      purchasesCount: 0,
      totalSales: 0,
      totalPurchases: 0,
      joinedAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), // 90 days ago
      lastActive: new Date(),
    },
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), // 90 days ago
    updatedAt: new Date(),
  }

  users.push(adminUser)
  const adminRef = db.collection("users").doc(adminUser.id)
  batch.set(adminRef, adminUser)

  // Create regular users
  for (let i = 0; i < count - 1; i++) {
    const firstName = faker.person.firstName()
    const lastName = faker.person.lastName()
    const username = faker.internet.userName({ firstName, lastName }).toLowerCase()

    const isSeller = Math.random() > 0.5
    const isVerified = Math.random() > 0.3
    const createdAt = faker.date.past({ years: 1 })
    const lastActive = faker.date.between({ from: createdAt, to: new Date() })

    const salesCount = isSeller ? faker.number.int({ min: 0, max: 50 }) : 0
    const purchasesCount = faker.number.int({ min: 0, max: 20 })
    const totalSales = salesCount * faker.number.int({ min: 50000, max: 500000 })
    const totalPurchases = purchasesCount * faker.number.int({ min: 50000, max: 500000 })

    const user: SeedUser = {
      id: faker.string.uuid(),
      email: faker.internet.email({ firstName, lastName }),
      username,
      displayName: `${firstName} ${lastName}`,
      password: await bcrypt.hash("password123", 10),
      bio: Math.random() > 0.3 ? faker.person.bio() : undefined,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      phone: Math.random() > 0.7 ? faker.phone.number() : undefined,
      isVerified,
      isSeller,
      isAdmin: false,
      balance: faker.number.int({ min: 0, max: 1000000 }),
      rating: isSeller ? faker.number.float({ min: 3, max: 5, precision: 0.1 }) : 0,
      ratingCount: isSeller ? faker.number.int({ min: 0, max: 100 }) : 0,
      preferences: {
        notifications: {
          email: Math.random() > 0.2,
          push: Math.random() > 0.3,
          sms: Math.random() > 0.7,
        },
        privacy: {
          showEmail: Math.random() > 0.7,
          showPhone: Math.random() > 0.8,
        },
        theme: faker.helpers.arrayElement(["light", "dark", "system"]),
        language: faker.helpers.arrayElement(["en", "id"]),
      },
      stats: {
        listingsCount: isSeller ? faker.number.int({ min: 0, max: 30 }) : 0,
        salesCount,
        purchasesCount,
        totalSales,
        totalPurchases,
        joinedAt: createdAt,
        lastActive,
      },
      createdAt,
      updatedAt: lastActive,
    }

    users.push(user)
    const userRef = db.collection("users").doc(user.id)
    batch.set(userRef, user)
  }

  // Commit the batch
  await batch.commit()

  return users
}
