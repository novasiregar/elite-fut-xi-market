import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"
import type { SeedListing } from "./seed-listings"

export interface SeedMessage {
  id: string
  conversationId: string
  senderId: string
  senderName: string
  recipientId: string
  recipientName: string
  content: string
  isRead: boolean
  listingId?: string
  listingTitle?: string
  attachments?: Array<{
    url: string
    type: string
    fileName: string
  }>
  createdAt: string
}

export interface SeedConversation {
  id: string
  participants: string[]
  participantNames: Record<string, string>
  lastMessageId: string
  lastMessageContent: string
  lastMessageSenderId: string
  lastMessageTimestamp: string
  unreadCount: Record<string, number>
  listingId?: string
  listingTitle?: string
  createdAt: string
  updatedAt: string
}

export async function seedMessages(
  db: Firestore,
  users: SeedUser[],
  listings: SeedListing[],
  count: number,
): Promise<SeedMessage[]> {
  console.log(`Seeding messages and conversations...`)

  const messages: SeedMessage[] = []
  const conversations: SeedConversation[] = []
  const batch = db.batch()

  // Create 20 conversations
  for (let i = 0; i < 20; i++) {
    // Get two random users
    let user1, user2
    do {
      user1 = faker.helpers.arrayElement(users)
      user2 = faker.helpers.arrayElement(users)
    } while (user1.id === user2.id)

    // Decide if this conversation is about a listing
    const isAboutListing = Math.random() > 0.3
    let listing

    if (isAboutListing) {
      // Get a listing from one of the users
      const sellerListings = listings.filter((l) => l.sellerId === user1.id || l.sellerId === user2.id)

      if (sellerListings.length > 0) {
        listing = faker.helpers.arrayElement(sellerListings)

        // Make sure the seller is one of the conversation participants
        if (listing.sellerId !== user1.id && listing.sellerId !== user2.id) {
          // Swap users if needed
          if (listing.sellerId !== user1.id) {
            const temp = user1
            user1 = users.find((u) => u.id === listing.sellerId)!
            user2 = temp
          } else {
            const temp = user2
            user2 = users.find((u) => u.id === listing.sellerId)!
            user1 = temp
          }
        }
      }
    }

    const conversationId = faker.string.uuid()
    const createdAt = faker.date.past({ years: 1 })

    // Generate 5-15 messages for this conversation
    const messageCount = faker.number.int({ min: 5, max: 15 })
    const conversationMessages: SeedMessage[] = []

    for (let j = 0; j < messageCount; j++) {
      // Alternate sender and recipient
      const isFirstMessage = j === 0
      const isFromUser1 = j % 2 === 0

      const sender = isFromUser1 ? user1 : user2
      const recipient = isFromUser1 ? user2 : user1

      // Generate message timestamp (in chronological order)
      let messageDate
      if (isFirstMessage) {
        messageDate = createdAt
      } else {
        const prevMessageDate = new Date(conversationMessages[j - 1].createdAt)
        messageDate = faker.date.between({
          from: prevMessageDate,
          to: new Date(+prevMessageDate + 7 * 24 * 60 * 60 * 1000), // Up to 7 days after previous message
        })
      }

      // Generate message content
      let content
      if (isFirstMessage && listing) {
        content = faker.helpers.arrayElement([
          `Hi, I'm interested in your listing "${listing.title}". Is it still available?`,
          `Hello, I'd like to know more about "${listing.title}". Can you provide more details?`,
          `Hey there! I'm considering buying "${listing.title}". What's your best price?`,
        ])
      } else {
        content = faker.lorem.paragraph()
      }

      // Decide if message has attachments
      const hasAttachments = Math.random() > 0.8 // 20% chance
      let attachments

      if (hasAttachments) {
        const attachmentCount = faker.number.int({ min: 1, max: 3 })
        attachments = []

        for (let k = 0; k < attachmentCount; k++) {
          attachments.push({
            url: `https://picsum.photos/seed/${faker.string.uuid()}/800/600`,
            type: "image/jpeg",
            fileName: `attachment-${k}.jpg`,
          })
        }
      }

      const message: SeedMessage = {
        id: faker.string.uuid(),
        conversationId,
        senderId: sender.id,
        senderName: sender.displayName,
        recipientId: recipient.id,
        recipientName: recipient.displayName,
        content,
        isRead: Math.random() > 0.3 || j < messageCount - 3, // Most messages are read except recent ones
        ...(listing && {
          listingId: listing.id,
          listingTitle: listing.title,
        }),
        ...(attachments && { attachments }),
        createdAt: messageDate.toISOString(),
      }

      conversationMessages.push(message)
      messages.push(message)

      const messageRef = db.collection("messages").doc(message.id)
      batch.set(messageRef, message)
    }

    // Sort messages by date
    conversationMessages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())

    // Get the last message
    const lastMessage = conversationMessages[conversationMessages.length - 1]

    // Count unread messages for each participant
    const unreadCount: Record<string, number> = {
      [user1.id]: 0,
      [user2.id]: 0,
    }

    conversationMessages.forEach((msg) => {
      if (!msg.isRead) {
        unreadCount[msg.recipientId]++
      }
    })

    // Create conversation document
    const conversation: SeedConversation = {
      id: conversationId,
      participants: [user1.id, user2.id],
      participantNames: {
        [user1.id]: user1.displayName,
        [user2.id]: user2.displayName,
      },
      lastMessageId: lastMessage.id,
      lastMessageContent: lastMessage.content,
      lastMessageSenderId: lastMessage.senderId,
      lastMessageTimestamp: lastMessage.createdAt,
      unreadCount,
      ...(listing && {
        listingId: listing.id,
        listingTitle: listing.title,
      }),
      createdAt: createdAt.toISOString(),
      updatedAt: lastMessage.createdAt,
    }

    conversations.push(conversation)

    const conversationRef = db.collection("conversations").doc(conversation.id)
    batch.set(conversationRef, conversation)
  }

  // Commit the batch
  await batch.commit()

  return messages
}
