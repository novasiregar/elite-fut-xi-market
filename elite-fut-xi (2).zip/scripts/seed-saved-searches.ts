import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"

export interface SeedSavedSearch {
  id: string
  userId: string
  name: string
  query: string
  filters: {
    minPrice?: number
    maxPrice?: number
    platform?: string
    minLevel?: number
    maxLevel?: number
    minRating?: number
    tags?: string[]
    verified?: boolean
  }
  notificationsEnabled: boolean
  lastNotified?: string
  createdAt: string
  updatedAt: string
}

export async function seedSavedSearches(db: Firestore, users: SeedUser[], count: number): Promise<SeedSavedSearch[]> {
  console.log(`Seeding ${count} saved searches...`)

  const savedSearches: SeedSavedSearch[] = []
  const batch = db.batch()

  // Platforms
  const platforms = ["PS5", "PS4", "Xbox Series X", "Xbox One", "PC"]

  // Tags
  const tags = [
    "rare",
    "budget",
    "endgame",
    "meta",
    "icons",
    "toty",
    "totw",
    "potm",
    "bargain",
    "stacked",
    "verified",
    "competitive",
    "casual",
    "untradeable",
    "first-owner",
    "rtg",
    "pay-to-win",
    "investment",
    "coins",
    "points",
  ]

  // Search terms
  const searchTerms = [
    "Messi",
    "Ronaldo",
    "Icons",
    "TOTY",
    "Coins",
    "Cheap",
    "High Rated",
    "Division 1",
    "Weekend League",
    "Draft",
    "Ultimate Team",
    "FUT Champions",
    "Squad Battles",
    "Objectives",
    "SBC",
    "Untradeable",
    "First Owner",
    "Road to Glory",
    "Pay to Win",
    "Investment",
    "Trading",
    "Snipe",
  ]

  for (let i = 0; i < count; i++) {
    // Get a random user
    const user = faker.helpers.arrayElement(users)

    const createdAt = faker.date.past({ years: 1 })
    const updatedAt = faker.date.between({ from: createdAt, to: new Date() })

    // Generate random filters
    const hasMinPrice = Math.random() > 0.5
    const hasMaxPrice = Math.random() > 0.5
    const hasPlatform = Math.random() > 0.3
    const hasLevel = Math.random() > 0.7
    const hasRating = Math.random() > 0.6
    const hasTags = Math.random() > 0.4
    const hasVerified = Math.random() > 0.5

    const minPrice = hasMinPrice ? faker.number.int({ min: 50000, max: 1000000 }) : undefined
    const maxPrice = hasMaxPrice ? faker.number.int({ min: minPrice || 100000, max: 5000000 }) : undefined
    const platform = hasPlatform ? faker.helpers.arrayElement(platforms) : undefined
    const minLevel = hasLevel ? faker.number.int({ min: 1, max: 100 }) : undefined
    const maxLevel = hasLevel ? faker.number.int({ min: minLevel || 50, max: 150 }) : undefined
    const minRating = hasRating ? faker.number.int({ min: 80, max: 90 }) : undefined

    // Generate 1-3 random tags
    const randomTags = hasTags ? faker.helpers.arrayElements(tags, faker.number.int({ min: 1, max: 3 })) : undefined

    // Generate search query
    const query = faker.helpers.arrayElement(searchTerms)

    // Generate search name
    const name = `${query} ${platform || ""} ${randomTags ? randomTags.join(" ") : ""}`.trim()

    const notificationsEnabled = Math.random() > 0.3

    // Generate last notified date for some searches
    const hasLastNotified = notificationsEnabled && Math.random() > 0.5
    const lastNotified = hasLastNotified
      ? faker.date.between({ from: createdAt, to: new Date() }).toISOString()
      : undefined

    const savedSearch: SeedSavedSearch = {
      id: faker.string.uuid(),
      userId: user.id,
      name,
      query,
      filters: {
        ...(hasMinPrice && { minPrice }),
        ...(hasMaxPrice && { maxPrice }),
        ...(hasPlatform && { platform }),
        ...(hasLevel && { minLevel, maxLevel }),
        ...(hasRating && { minRating }),
        ...(hasTags && { tags: randomTags }),
        ...(hasVerified && { verified: true }),
      },
      notificationsEnabled,
      ...(hasLastNotified && { lastNotified }),
      createdAt: createdAt.toISOString(),
      updatedAt: updatedAt.toISOString(),
    }

    savedSearches.push(savedSearch)
    const savedSearchRef = db.collection("savedSearches").doc(savedSearch.id)
    batch.set(savedSearchRef, savedSearch)
  }

  // Commit the batch
  await batch.commit()

  return savedSearches
}
