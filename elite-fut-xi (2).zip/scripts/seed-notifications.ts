import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"
import type { SeedListing } from "./seed-listings"
import type { SeedTransaction } from "./seed-transactions"

export interface SeedNotification {
  id: string
  userId: string
  type: string
  title: string
  message: string
  isRead: boolean
  data?: {
    listingId?: string
    transactionId?: string
    conversationId?: string
    userId?: string
    reviewId?: string
    savedSearchId?: string
  }
  createdAt: string
}

// Notification types
const NOTIFICATION_TYPES = {
  LISTING_SOLD: "listing_sold",
  NEW_MESSAGE: "new_message",
  PAYMENT_RECEIVED: "payment_received",
  PAYMENT_RELEASED: "payment_released",
  NEW_REVIEW: "new_review",
  ACCOUNT_VERIFIED: "account_verified",
  LISTING_FEATURED: "listing_featured",
  SAVED_SEARCH_MATCH: "saved_search_match",
  PRICE_DROP: "price_drop",
  TRANSACTION_STATUS: "transaction_status",
  DISPUTE_OPENED: "dispute_opened",
  DISPUTE_RESOLVED: "dispute_resolved",
  PROMOTION_APPLIED: "promotion_applied",
}

export async function seedNotifications(
  db: Firestore,
  users: SeedUser[],
  listings: SeedListing[],
  transactions: SeedTransaction[],
  count: number,
): Promise<SeedNotification[]> {
  console.log(`Seeding ${count} notifications...`)

  const notifications: SeedNotification[] = []
  const batch = db.batch()

  for (let i = 0; i < count; i++) {
    // Get a random user
    const user = faker.helpers.arrayElement(users)

    // Get a random notification type
    const type = faker.helpers.objectValue(NOTIFICATION_TYPES)

    // Generate notification data based on type
    let title,
      message,
      data: any = {}

    switch (type) {
      case NOTIFICATION_TYPES.LISTING_SOLD: {
        const userListings = listings.filter((l) => l.sellerId === user.id && l.status === "sold")

        if (userListings.length > 0) {
          const listing = faker.helpers.arrayElement(userListings)
          title = "Listing Sold!"
          message = `Your listing "${listing.title}" has been sold.`
          data.listingId = listing.id

          // Find the transaction for this listing
          const transaction = transactions.find((t) => t.listingId === listing.id)
          if (transaction) {
            data.transactionId = transaction.id
          }
        } else {
          // Fallback if user has no sold listings
          title = "Listing Sold!"
          message = "Your listing has been sold."
        }
        break
      }

      case NOTIFICATION_TYPES.NEW_MESSAGE: {
        title = "New Message"
        message = "You have received a new message."
        data.conversationId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.PAYMENT_RECEIVED: {
        title = "Payment Received"
        message = `You have received a payment of ${faker.finance.amount(50000, 5000000, 0)} IDR.`
        data.transactionId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.PAYMENT_RELEASED: {
        title = "Payment Released"
        message = "Your payment has been released from escrow."
        data.transactionId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.NEW_REVIEW: {
        title = "New Review"
        message = "You have received a new review."
        data.reviewId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.ACCOUNT_VERIFIED: {
        title = "Account Verified"
        message = "Your account has been verified! You now have access to all platform features."
        break
      }

      case NOTIFICATION_TYPES.LISTING_FEATURED: {
        const userListings = listings.filter((l) => l.sellerId === user.id && l.featured)

        if (userListings.length > 0) {
          const listing = faker.helpers.arrayElement(userListings)
          title = "Listing Featured"
          message = `Your listing "${listing.title}" is now featured on the marketplace.`
          data.listingId = listing.id
        } else {
          // Fallback
          title = "Listing Featured"
          message = "Your listing is now featured on the marketplace."
        }
        break
      }

      case NOTIFICATION_TYPES.SAVED_SEARCH_MATCH: {
        title = "New Listing Match"
        message = "A new listing matches your saved search."
        data.savedSearchId = faker.string.uuid()

        // Get a random active listing
        const activeListing = faker.helpers.arrayElement(listings.filter((l) => l.status === "active"))
        data.listingId = activeListing.id
        break
      }

      case NOTIFICATION_TYPES.PRICE_DROP: {
        title = "Price Drop Alert"
        message = "A listing you're watching has dropped in price."

        // Get a random active listing
        const activeListing = faker.helpers.arrayElement(listings.filter((l) => l.status === "active"))
        data.listingId = activeListing.id
        break
      }

      case NOTIFICATION_TYPES.TRANSACTION_STATUS: {
        const userTransactions = transactions.filter((t) => t.buyerId === user.id || t.sellerId === user.id)

        if (userTransactions.length > 0) {
          const transaction = faker.helpers.arrayElement(userTransactions)
          title = "Transaction Update"
          message = `Your transaction status has been updated to: ${transaction.status}.`
          data.transactionId = transaction.id
        } else {
          // Fallback
          title = "Transaction Update"
          message = "Your transaction status has been updated."
        }
        break
      }

      case NOTIFICATION_TYPES.DISPUTE_OPENED: {
        title = "Dispute Opened"
        message = "A dispute has been opened for your transaction."
        data.transactionId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.DISPUTE_RESOLVED: {
        title = "Dispute Resolved"
        message = "A dispute for your transaction has been resolved."
        data.transactionId = faker.string.uuid()
        break
      }

      case NOTIFICATION_TYPES.PROMOTION_APPLIED: {
        title = "Promotion Applied"
        message = "A promotion has been applied to your account."
        break
      }

      default: {
        title = "Notification"
        message = "You have a new notification."
      }
    }

    const createdAt = faker.date.past({ years: 1 })
    const isRead = Math.random() > 0.3 // 70% chance of being read

    const notification: SeedNotification = {
      id: faker.string.uuid(),
      userId: user.id,
      type,
      title,
      message,
      isRead,
      ...(Object.keys(data).length > 0 && { data }),
      createdAt: createdAt.toISOString(),
    }

    notifications.push(notification)
    const notificationRef = db.collection("notifications").doc(notification.id)
    batch.set(notificationRef, notification)
  }

  // Commit the batch
  await batch.commit()

  return notifications
}
