import type { Firestore } from "firebase-admin/firestore"
import { faker } from "@faker-js/faker"
import type { SeedUser } from "./seed-users"
import { ElasticsearchService } from "../server/services/elasticsearch"

export interface SeedListing {
  id: string
  title: string
  description: string
  price: number
  sellerId: string
  sellerName: string
  sellerVerified: boolean
  media: Array<{
    url: string
    type: "image" | "video"
    fileName: string
  }>
  tags: string[]
  status: "active" | "pending_sale" | "sold" | "inactive"
  featured: boolean
  accountDetails: {
    level: number
    coins: number
    platform: "PS5" | "PS4" | "Xbox Series X" | "Xbox One" | "PC"
    teamRating: number
    topPlayers: string[]
    division: number
    achievements: string[]
    specialCards: number
  }
  createdAt: string
  updatedAt: string
  viewCount: number
  favoriteCount: number
}

// FIFA/Football player names for generating realistic data
const topPlayers = [
  "Lionel Messi",
  "Cristiano Ronaldo",
  "Kylian Mbappé",
  "Erling Haaland",
  "Kevin De Bruyne",
  "Neymar Jr",
  "Virgil van Dijk",
  "Mohamed Salah",
  "Robert Lewandowski",
  "Luka Modrić",
  "Thibaut Courtois",
  "Karim Benzema",
  "Sadio Mané",
  "Joshua Kimmich",
  "Harry Kane",
  "Trent Alexander-Arnold",
  "Alisson Becker",
  "Casemiro",
  "Son Heung-min",
  "Rúben Dias",
  "Bruno Fernandes",
  "Frenkie de Jong",
  "Jude Bellingham",
  "Phil Foden",
  "Vinícius Júnior",
  "Rodri",
  "Federico Valverde",
  "Bukayo Saka",
]

// Achievement names
const achievements = [
  "Division 1 Champion",
  "FUT Champions Elite",
  "Squad Battles Top 100",
  "Weekend League 30-0",
  "Draft King",
  "Icon SBC Completed",
  "TOTY Pack Luck",
  "Perfect Season",
  "Unbeaten Streak",
  "Market Mogul",
  "SBC Master",
  "Objective Grinder",
]

// Tags for listings
const tags = [
  "rare",
  "budget",
  "endgame",
  "meta",
  "icons",
  "toty",
  "totw",
  "potm",
  "bargain",
  "stacked",
  "verified",
  "competitive",
  "casual",
  "untradeable",
  "first-owner",
  "rtg",
  "pay-to-win",
  "investment",
  "coins",
  "points",
]

export async function seedListings(db: Firestore, users: SeedUser[], count: number): Promise<SeedListing[]> {
  console.log(`Seeding ${count} listings...`)

  const listings: SeedListing[] = []
  const batch = db.batch()

  // Get only sellers
  const sellers = users.filter((user) => user.isSeller)

  for (let i = 0; i < count; i++) {
    const seller = faker.helpers.arrayElement(sellers)
    const status = faker.helpers.weightedArrayElement([
      { weight: 70, value: "active" },
      { weight: 10, value: "pending_sale" },
      { weight: 15, value: "sold" },
      { weight: 5, value: "inactive" },
    ])

    const createdAt = faker.date.past({ years: 1 })
    const updatedAt = faker.date.between({ from: createdAt, to: new Date() })

    const platform = faker.helpers.arrayElement(["PS5", "PS4", "Xbox Series X", "Xbox One", "PC"])

    const level = faker.number.int({ min: 1, max: 150 })
    const teamRating = faker.number.int({ min: 80, max: 95 })
    const coins = faker.number.int({ min: 10000, max: 10000000 })
    const division = faker.number.int({ min: 1, max: 10 })
    const specialCards = faker.number.int({ min: 0, max: 50 })

    // Generate 3-5 random players
    const randomPlayers = faker.helpers.arrayElements(topPlayers, faker.number.int({ min: 3, max: 5 }))

    // Generate 2-4 random achievements
    const randomAchievements = faker.helpers.arrayElements(achievements, faker.number.int({ min: 2, max: 4 }))

    // Generate 3-6 random tags
    const randomTags = faker.helpers.arrayElements(tags, faker.number.int({ min: 3, max: 6 }))

    // Generate media (3-6 images)
    const mediaCount = faker.number.int({ min: 3, max: 6 })
    const media = []

    for (let j = 0; j < mediaCount; j++) {
      const width = 800
      const height = 600
      media.push({
        url: `https://picsum.photos/seed/${faker.string.uuid()}/${width}/${height}`,
        type: "image" as const,
        fileName: `listing-${i}-image-${j}.jpg`,
      })
    }

    // Add a video for some listings
    if (Math.random() > 0.7) {
      media.push({
        url: "https://storage.googleapis.com/elite-fut-xi-market/videos/football-gameplay.mp4",
        type: "video" as const,
        fileName: "gameplay.mp4",
      })
    }

    const price = faker.number.int({ min: 50000, max: 5000000 })

    const listing: SeedListing = {
      id: faker.string.uuid(),
      title: `${platform} - ${level} Level Account with ${teamRating} Rated Team`,
      description: faker.lorem.paragraphs({ min: 2, max: 5 }),
      price,
      sellerId: seller.id,
      sellerName: seller.displayName,
      sellerVerified: seller.isVerified,
      media,
      tags: randomTags,
      status: status as "active" | "pending_sale" | "sold" | "inactive",
      featured: Math.random() > 0.9, // 10% are featured
      accountDetails: {
        level,
        coins,
        platform: platform as any,
        teamRating,
        topPlayers: randomPlayers,
        division,
        achievements: randomAchievements,
        specialCards,
      },
      createdAt: createdAt.toISOString(),
      updatedAt: updatedAt.toISOString(),
      viewCount: faker.number.int({ min: 0, max: 1000 }),
      favoriteCount: faker.number.int({ min: 0, max: 100 }),
    }

    listings.push(listing)
    const listingRef = db.collection("listings").doc(listing.id)
    batch.set(listingRef, listing)

    // Index in Elasticsearch
    await ElasticsearchService.indexListing(listing)
  }

  // Commit the batch
  await batch.commit()

  return listings
}
