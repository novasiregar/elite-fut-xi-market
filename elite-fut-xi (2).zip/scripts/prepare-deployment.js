const fs = require("fs")
const path = require("path")

// Get environment (staging or production)
const environment = process.env.NODE_ENV || "development"
console.log(`Preparing deployment for ${environment} environment`)

// Create a version.json file with build information
const packageJson = require("../package.json")
const versionInfo = {
  version: packageJson.version,
  buildDate: new Date().toISOString(),
  environment: environment,
  commit: process.env.GITHUB_SHA || "local",
  branch: process.env.GITHUB_REF || "local",
}

fs.writeFileSync(path.join(__dirname, "../public/version.json"), JSON.stringify(versionInfo, null, 2))
console.log("Created version.json file")

// Create robots.txt based on environment
const robotsContent =
  environment === "production"
    ? `# Allow all crawlers
User-agent: *
Allow: /

# Sitemap location
Sitemap: https://elitefutxi.com/sitemap.xml`
    : `# Disallow all crawlers
User-agent: *
Disallow: /`

fs.writeFileSync(path.join(__dirname, "../public/robots.txt"), robotsContent)
console.log("Created robots.txt file")

// Ensure the public directory exists
const publicDir = path.join(__dirname, "../public")
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true })
}

console.log("Deployment preparation complete")
