import { db } from "../server/index"
import { ElasticsearchService } from "../server/services/elasticsearch"

async function startElasticsearchSync() {
  console.log("Starting Elasticsearch sync...")

  // Listen for changes to listings collection
  const listingsListener = db.collection("listings").onSnapshot(
    (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        const listing = { id: change.doc.id, ...change.doc.data() }

        try {
          if (change.type === "added" || change.type === "modified") {
            // Only index active listings
            if (listing.status === "active") {
              console.log(`Indexing listing ${listing.id}`)
              await ElasticsearchService.indexListing(listing)
            } else {
              // If status is not active, remove from index if exists
              console.log(`Removing inactive listing ${listing.id} from index`)
              await ElasticsearchService.removeListing(listing.id)
            }
          } else if (change.type === "removed") {
            console.log(`Removing listing ${listing.id} from index`)
            await ElasticsearchService.removeListing(listing.id)
          }
        } catch (error) {
          console.error(`Error syncing listing ${listing.id}:`, error)
        }
      })
    },
    (error) => {
      console.error("Error listening to listings changes:", error)
    },
  )

  // Handle process termination
  process.on("SIGINT", () => {
    console.log("Stopping Elasticsearch sync...")
    listingsListener()
    process.exit(0)
  })

  console.log("Elasticsearch sync started successfully")
}

// Run the sync
startElasticsearchSync()
