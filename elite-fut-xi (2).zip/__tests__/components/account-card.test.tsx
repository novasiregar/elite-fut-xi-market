import { render, screen } from "@testing-library/react"
import AccountCard from "@/components/account-card"

// Mock the data
const mockAccount = {
  id: "123",
  title: "Elite FIFA Account",
  price: 100,
  rating: 90,
  coins: 500000,
  image: "/placeholder.jpg",
  seller: {
    id: "seller123",
    name: "Top Seller",
    rating: 4.8,
  },
  featured: true,
}

describe("AccountCard Component", () => {
  it("renders account information correctly", () => {
    render(<AccountCard account={mockAccount} />)

    // Check if the title is rendered
    expect(screen.getByText("Elite FIFA Account")).toBeInTheDocument()

    // Check if the price is rendered
    expect(screen.getByText("$100")).toBeInTheDocument()

    // Check if the rating is rendered
    expect(screen.getByText("90")).toBeInTheDocument()

    // Check if the coins are rendered
    expect(screen.getByText("500,000")).toBeInTheDocument()

    // Check if the seller name is rendered
    expect(screen.getByText("Top Seller")).toBeInTheDocument()

    // Check if the featured badge is rendered
    expect(screen.getByText("Featured")).toBeInTheDocument()
  })

  it("does not show featured badge when account is not featured", () => {
    const nonFeaturedAccount = { ...mockAccount, featured: false }
    render(<AccountCard account={nonFeaturedAccount} />)

    // Featured badge should not be present
    expect(screen.queryByText("Featured")).not.toBeInTheDocument()
  })
})
