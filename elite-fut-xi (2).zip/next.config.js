/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Remove swcMinify as it's no longer needed in Next.js 15+
  experimental: {
    optimizeCss: false, // Disable Next.js built-in CSS optimization
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Add this to address the cross-origin warning
  allowedDevOrigins: ["http://localhost:3000", "http://192.168.1.9:3000"],
}

module.exports = nextConfig
