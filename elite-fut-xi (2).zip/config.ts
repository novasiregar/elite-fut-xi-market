// API URLs
export const API_URL = process.env.NEXT_PUBLIC_API_URL || ""

// Firebase config
export const FIREBASE_CONFIG = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "",
}

// Payment config
export const PAYMENT_CONFIG = {
  gopayApiKey: process.env.GOPAY_API_KEY || "",
  webhookSecret: process.env.WEBHOOK_SECRET || "",
}

// Search config
export const SEARCH_CONFIG = {
  elasticsearchUrl: process.env.ELASTICSEARCH_URL || "",
  elasticsearchUsername: process.env.ELASTICSEARCH_USERNAME || "",
  elasticsearchPassword: process.env.ELASTICSEARCH_PASSWORD || "",
}

// Cache config
export const CACHE_CONFIG = {
  redisUrl: process.env.REDIS_URL || "",
}

// App config
export const APP_CONFIG = {
  appName: "ELITE FUT XI Market",
  appDescription: "Marketplace for football simulation gaming accounts",
  appVersion: "1.0.0",
  defaultLanguage: "en",
  supportedLanguages: ["en", "id"],
  defaultCurrency: "IDR",
  defaultPageSize: 12,
  maxUploadSize: 5 * 1024 * 1024, // 5MB
  contactEmail: "support@elitefutxi.com",
}

// Feature flags
export const FEATURES = {
  visualSearch: true,
  recommendations: true,
  savedSearches: true,
  notifications: true,
  escrow: true,
  disputes: true,
  promotions: true,
  referrals: true,
  pwa: true,
}
