"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { getCookie, setCookie } from "cookies-next"

type Language = "en" | "id"
type Translations = Record<string, Record<string, string>>

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations: Translations = {
  // Common UI elements
  common: {
    en: {
      search: "Search",
      filter: "Filter",
      sort: "Sort",
      login: "Login",
      register: "Register",
      profile: "Profile",
      settings: "Settings",
      logout: "Logout",
      home: "Home",
      marketplace: "Marketplace",
      messages: "Messages",
      notifications: "Notifications",
      darkMode: "Dark Mode",
      lightMode: "Light Mode",
      language: "Language",
      english: "English",
      indonesian: "Bahasa Indonesia",
      save: "Save",
      cancel: "Cancel",
      submit: "Submit",
      loading: "Loading...",
      error: "An error occurred",
      success: "Success!",
      viewAll: "View All",
      back: "Back",
      next: "Next",
      previous: "Previous",
    },
    id: {
      search: "Cari",
      filter: "Filter",
      sort: "Urutkan",
      login: "Masuk",
      register: "Daftar",
      profile: "Profil",
      settings: "Pengaturan",
      logout: "Keluar",
      home: "Beranda",
      marketplace: "Pasar",
      messages: "Pesan",
      notifications: "Notifikasi",
      darkMode: "Mode Gelap",
      lightMode: "Mode Terang",
      language: "Bahasa",
      english: "English",
      indonesian: "Bahasa Indonesia",
      save: "Simpan",
      cancel: "Batal",
      submit: "Kirim",
      loading: "Memuat...",
      error: "Terjadi kesalahan",
      success: "Berhasil!",
      viewAll: "Lihat Semua",
      back: "Kembali",
      next: "Selanjutnya",
      previous: "Sebelumnya",
    },
  },
  // Homepage
  home: {
    en: {
      welcome: "Welcome to ELITE FUT XI Market",
      tagline: "Indonesia's first mobile-only marketplace for football simulation gaming accounts",
      featuredListings: "Featured Listings",
      topSellers: "Top Sellers",
      recentlyAdded: "Recently Added",
      browseCategories: "Browse Categories",
      joinCommunity: "Join Our Community",
      downloadApp: "Download Our App",
    },
    id: {
      welcome: "Selamat Datang di ELITE FUT XI Market",
      tagline: "Pasar khusus mobile pertama di Indonesia untuk akun game simulasi sepak bola",
      featuredListings: "Daftar Unggulan",
      topSellers: "Penjual Teratas",
      recentlyAdded: "Baru Ditambahkan",
      browseCategories: "Jelajahi Kategori",
      joinCommunity: "Bergabung dengan Komunitas Kami",
      downloadApp: "Unduh Aplikasi Kami",
    },
  },
  // Marketplace
  marketplace: {
    en: {
      title: "Marketplace",
      allListings: "All Listings",
      filterBy: "Filter By",
      sortBy: "Sort By",
      price: "Price",
      rating: "Rating",
      date: "Date",
      category: "Category",
      noResults: "No results found",
      priceRange: "Price Range",
      applyFilters: "Apply Filters",
      clearFilters: "Clear Filters",
      searchPlaceholder: "Search for listings...",
    },
    id: {
      title: "Pasar",
      allListings: "Semua Daftar",
      filterBy: "Filter Berdasarkan",
      sortBy: "Urutkan Berdasarkan",
      price: "Harga",
      rating: "Peringkat",
      date: "Tanggal",
      category: "Kategori",
      noResults: "Tidak ada hasil ditemukan",
      priceRange: "Rentang Harga",
      applyFilters: "Terapkan Filter",
      clearFilters: "Hapus Filter",
      searchPlaceholder: "Cari daftar...",
    },
  },
  // User profile
  profile: {
    en: {
      title: "Profile",
      editProfile: "Edit Profile",
      myListings: "My Listings",
      myPurchases: "My Purchases",
      mySales: "My Sales",
      accountSettings: "Account Settings",
      reviews: "Reviews",
      joinedOn: "Joined on",
      contactSeller: "Contact Seller",
      reportUser: "Report User",
    },
    id: {
      title: "Profil",
      editProfile: "Edit Profil",
      myListings: "Daftar Saya",
      myPurchases: "Pembelian Saya",
      mySales: "Penjualan Saya",
      accountSettings: "Pengaturan Akun",
      reviews: "Ulasan",
      joinedOn: "Bergabung pada",
      contactSeller: "Hubungi Penjual",
      reportUser: "Laporkan Pengguna",
    },
  },
  // Authentication
  auth: {
    en: {
      login: "Login",
      register: "Register",
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      forgotPassword: "Forgot Password?",
      dontHaveAccount: "Don't have an account?",
      alreadyHaveAccount: "Already have an account?",
      signUp: "Sign Up",
      signIn: "Sign In",
      signInWith: "Sign in with",
      signUpWith: "Sign up with",
      rememberMe: "Remember me",
      username: "Username",
      fullName: "Full Name",
      phoneNumber: "Phone Number",
    },
    id: {
      login: "Masuk",
      register: "Daftar",
      email: "Email",
      password: "Kata Sandi",
      confirmPassword: "Konfirmasi Kata Sandi",
      forgotPassword: "Lupa Kata Sandi?",
      dontHaveAccount: "Belum punya akun?",
      alreadyHaveAccount: "Sudah punya akun?",
      signUp: "Daftar",
      signIn: "Masuk",
      signInWith: "Masuk dengan",
      signUpWith: "Daftar dengan",
      rememberMe: "Ingat saya",
      username: "Nama Pengguna",
      fullName: "Nama Lengkap",
      phoneNumber: "Nomor Telepon",
    },
  },
  // Listings
  listings: {
    en: {
      createListing: "Create Listing",
      editListing: "Edit Listing",
      title: "Title",
      description: "Description",
      price: "Price",
      category: "Category",
      condition: "Condition",
      images: "Images",
      addImages: "Add Images",
      location: "Location",
      contactInfo: "Contact Information",
      listingDetails: "Listing Details",
      sellerInfo: "Seller Information",
      similarListings: "Similar Listings",
      reportListing: "Report Listing",
      shareListing: "Share Listing",
      addToWishlist: "Add to Wishlist",
      removeFromWishlist: "Remove from Wishlist",
      buyNow: "Buy Now",
      makeOffer: "Make an Offer",
      askQuestion: "Ask a Question",
    },
    id: {
      createListing: "Buat Daftar",
      editListing: "Edit Daftar",
      title: "Judul",
      description: "Deskripsi",
      price: "Harga",
      category: "Kategori",
      condition: "Kondisi",
      images: "Gambar",
      addImages: "Tambah Gambar",
      location: "Lokasi",
      contactInfo: "Informasi Kontak",
      listingDetails: "Detail Daftar",
      sellerInfo: "Informasi Penjual",
      similarListings: "Daftar Serupa",
      reportListing: "Laporkan Daftar",
      shareListing: "Bagikan Daftar",
      addToWishlist: "Tambahkan ke Wishlist",
      removeFromWishlist: "Hapus dari Wishlist",
      buyNow: "Beli Sekarang",
      makeOffer: "Buat Penawaran",
      askQuestion: "Ajukan Pertanyaan",
    },
  },
  // Transactions
  transactions: {
    en: {
      myTransactions: "My Transactions",
      transactionHistory: "Transaction History",
      orderDetails: "Order Details",
      paymentMethod: "Payment Method",
      paymentStatus: "Payment Status",
      orderStatus: "Order Status",
      orderDate: "Order Date",
      orderTotal: "Order Total",
      shippingInfo: "Shipping Information",
      billingInfo: "Billing Information",
      trackOrder: "Track Order",
      cancelOrder: "Cancel Order",
      confirmReceipt: "Confirm Receipt",
      leaveReview: "Leave a Review",
      transactionId: "Transaction ID",
    },
    id: {
      myTransactions: "Transaksi Saya",
      transactionHistory: "Riwayat Transaksi",
      orderDetails: "Detail Pesanan",
      paymentMethod: "Metode Pembayaran",
      paymentStatus: "Status Pembayaran",
      orderStatus: "Status Pesanan",
      orderDate: "Tanggal Pesanan",
      orderTotal: "Total Pesanan",
      shippingInfo: "Informasi Pengiriman",
      billingInfo: "Informasi Penagihan",
      trackOrder: "Lacak Pesanan",
      cancelOrder: "Batalkan Pesanan",
      confirmReceipt: "Konfirmasi Penerimaan",
      leaveReview: "Berikan Ulasan",
      transactionId: "ID Transaksi",
    },
  },
  // Messages
  messages: {
    en: {
      inbox: "Inbox",
      sent: "Sent",
      compose: "Compose",
      reply: "Reply",
      forward: "Forward",
      delete: "Delete",
      markAsRead: "Mark as Read",
      markAsUnread: "Mark as Unread",
      noMessages: "No messages found",
      typeMessage: "Type your message...",
      send: "Send",
      attachFiles: "Attach Files",
    },
    id: {
      inbox: "Kotak Masuk",
      sent: "Terkirim",
      compose: "Tulis",
      reply: "Balas",
      forward: "Teruskan",
      delete: "Hapus",
      markAsRead: "Tandai Sudah Dibaca",
      markAsUnread: "Tandai Belum Dibaca",
      noMessages: "Tidak ada pesan ditemukan",
      typeMessage: "Ketik pesan Anda...",
      send: "Kirim",
      attachFiles: "Lampirkan File",
    },
  },
  // Admin
  admin: {
    en: {
      dashboard: "Admin Dashboard",
      users: "Users",
      listings: "Listings",
      transactions: "Transactions",
      reports: "Reports",
      settings: "Settings",
      analytics: "Analytics",
      flaggedContent: "Flagged Content",
      userManagement: "User Management",
      contentModeration: "Content Moderation",
      systemSettings: "System Settings",
      adminLogs: "Admin Logs",
    },
    id: {
      dashboard: "Dasbor Admin",
      users: "Pengguna",
      listings: "Daftar",
      transactions: "Transaksi",
      reports: "Laporan",
      settings: "Pengaturan",
      analytics: "Analitik",
      flaggedContent: "Konten yang Ditandai",
      userManagement: "Manajemen Pengguna",
      contentModeration: "Moderasi Konten",
      systemSettings: "Pengaturan Sistem",
      adminLogs: "Log Admin",
    },
  },
  // Accessibility
  accessibility: {
    en: {
      skipToContent: "Skip to content",
      screenReader: "Screen reader",
      increaseText: "Increase text size",
      decreaseText: "Decrease text size",
      highContrast: "High contrast",
      readingMode: "Reading mode",
      accessibilitySettings: "Accessibility settings",
    },
    id: {
      skipToContent: "Lewati ke konten",
      screenReader: "Pembaca layar",
      increaseText: "Perbesar ukuran teks",
      decreaseText: "Perkecil ukuran teks",
      highContrast: "Kontras tinggi",
      readingMode: "Mode membaca",
      accessibilitySettings: "Pengaturan aksesibilitas",
    },
  },
}

const defaultLanguage: Language = "en"

const LanguageContext = createContext<LanguageContextType>({
  language: defaultLanguage,
  setLanguage: () => {},
  t: () => "",
})

export const useLanguage = () => useContext(LanguageContext)

export const LanguageProvider = ({ children }: { children: React.ReactNode }) => {
  const [language, setLanguageState] = useState<Language>(defaultLanguage)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Get language from cookie or browser preference
    const savedLanguage = getCookie("language") as Language
    const browserLanguage = navigator.language.startsWith("id") ? "id" : "en"
    setLanguageState(savedLanguage || browserLanguage)
    setIsLoaded(true)
  }, [])

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    setCookie("language", lang, { maxAge: 60 * 60 * 24 * 365 }) // 1 year
  }

  const t = (key: string): string => {
    const [section, textKey] = key.split(".")

    if (!translations[section]) {
      console.warn(`Translation section "${section}" not found`)
      return key
    }

    if (!translations[section][language]) {
      console.warn(`Language "${language}" not found in section "${section}"`)
      return key
    }

    if (!translations[section][language][textKey]) {
      console.warn(`Key "${textKey}" not found in section "${section}" for language "${language}"`)
      return key
    }

    return translations[section][language][textKey]
  }

  if (!isLoaded) {
    return null // Or a loading spinner
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}
