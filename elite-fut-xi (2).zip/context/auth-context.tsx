"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { AuthService } from "@/client/services/auth"
import type { User } from "firebase/auth"
import { useRouter } from "next/navigation"
import { UserService } from "@/client/services/users"

interface UserProfile {
  displayName: string
  email: string
  avatar?: string
  isVerified: boolean
  role: string
  createdAt: string
  bio?: string
  rating?: number
  ratingCount?: number
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  loginWithFacebook: () => Promise<void>
  loginWithDiscord: () => Promise<void>
  register: (email: string, password: string, displayName: string) => Promise<void>
  logout: () => Promise<void>
  updateProfile: (data: FormData) => Promise<void>
  linkSocialAccount: (provider: "google" | "facebook" | "discord") => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = AuthService.onAuthStateChanged(async (user) => {
      setUser(user)

      if (user) {
        try {
          const profile = await UserService.getUserProfile()
          setUserProfile(profile)
        } catch (error) {
          console.error("Error fetching user profile:", error)
        }
      } else {
        setUserProfile(null)
      }

      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      setLoading(true)
      await AuthService.login(email, password)
      router.push("/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const loginWithGoogle = async () => {
    try {
      setLoading(true)
      await AuthService.loginWithGoogle()
      router.push("/dashboard")
    } catch (error) {
      console.error("Google login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const loginWithFacebook = async () => {
    try {
      setLoading(true)
      await AuthService.loginWithFacebook()
      router.push("/dashboard")
    } catch (error) {
      console.error("Facebook login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const loginWithDiscord = async () => {
    try {
      setLoading(true)
      await AuthService.loginWithDiscord()
      router.push("/dashboard")
    } catch (error) {
      console.error("Discord login error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const register = async (email: string, password: string, displayName: string) => {
    try {
      setLoading(true)
      await AuthService.register(email, password, displayName)
      router.push("/dashboard")
    } catch (error) {
      console.error("Registration error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try {
      setLoading(true)
      await AuthService.logout()
      router.push("/")
    } catch (error) {
      console.error("Logout error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async (data: FormData) => {
    try {
      setLoading(true)
      await UserService.updateUserProfile(data)
      const profile = await UserService.getUserProfile()
      setUserProfile(profile)
    } catch (error) {
      console.error("Update profile error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const linkSocialAccount = async (provider: "google" | "facebook" | "discord") => {
    try {
      setLoading(true)
      await AuthService.linkWithSocialProvider(provider)
      const profile = await UserService.getUserProfile()
      setUserProfile(profile)
    } catch (error) {
      console.error("Link social account error:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        login,
        loginWithGoogle,
        loginWithFacebook,
        loginWithDiscord,
        register,
        logout,
        updateProfile,
        linkSocialAccount,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
