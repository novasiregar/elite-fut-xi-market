/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: ['firebasestorage.googleapis.com'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    formats: ['image/webp', 'image/avif'],
    unoptimized: true,
  },
  experimental: {
    optimizeCss: true,
    scrollRestoration: true,
    serverActions: {
      // This should be an object, not a boolean
      allowedOrigins: ['localhost:3000'],
      bodySizeLimit: '2mb'
    },
  },
  webpack: (config, { isServer, dev }) => {
    // Enable tree shaking and dead code elimination
    config.optimization.usedExports = true;
    
    // Add bundle analyzer in non-dev builds if needed
    if (!dev && !isServer) {
      try {
        const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
        config.plugins.push(
          new BundleAnalyzerPlugin({
            analyzerMode: 'disabled',
            generateStatsFile: true,
            statsFilename: 'stats.json',
          })
        );
      } catch (error) {
        console.warn('Warning: webpack-bundle-analyzer is not installed. Skipping bundle analysis.');
        // Continue without the bundle analyzer
      }
    }
    
    return config;
  },
}

export default nextConfig;
