import type { Request, Response, NextFunction } from "express"
import { auth } from "../index"
import type { DecodedIdToken } from "firebase-admin/auth"

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: DecodedIdToken
      userId?: string
    }
  }
}

export const validateFirebaseToken = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: No token provided" })
    }

    const token = authHeader.split("Bearer ")[1]

    try {
      const decodedToken = await auth.verifyIdToken(token)
      req.user = decodedToken
      req.userId = decodedToken.uid
      next()
    } catch (error) {
      return res.status(401).json({ error: "Unauthorized: Invalid token" })
    }
  } catch (error) {
    next(error)
  }
}

export const isAdmin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized: No user found" })
    }

    // Get user claims to check if admin
    const { customClaims } = await auth.getUser(req.userId!)

    if (customClaims && customClaims.admin === true) {
      next()
    } else {
      return res.status(403).json({ error: "Forbidden: Admin access required" })
    }
  } catch (error) {
    next(error)
  }
}

export const isVerifiedSeller = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized: No user found" })
    }

    // Get user claims to check if verified seller
    const { customClaims } = await auth.getUser(req.userId!)

    if (customClaims && customClaims.verifiedSeller === true) {
      next()
    } else {
      return res.status(403).json({ error: "Forbidden: Verified seller status required" })
    }
  } catch (error) {
    next(error)
  }
}
