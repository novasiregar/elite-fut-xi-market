import type { Request, Response, NextFunction } from "express"

export interface AppError extends Error {
  statusCode?: number
  code?: string
}

export const errorHandler = (err: AppError, req: Request, res: Response, next: NextFunction) => {
  console.error(`[ERROR] ${err.message}`, err)

  // Handle Firebase errors
  if (err.code) {
    switch (err.code) {
      case "auth/id-token-expired":
        return res.status(401).json({ error: "Token expired" })
      case "auth/id-token-revoked":
        return res.status(401).json({ error: "Token revoked" })
      case "auth/invalid-id-token":
        return res.status(401).json({ error: "Invalid token" })
      case "permission-denied":
        return res.status(403).json({ error: "Permission denied" })
    }
  }

  // Default error response
  const statusCode = err.statusCode || 500
  const message = statusCode === 500 ? "Internal server error" : err.message

  res.status(statusCode).json({
    error: message,
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  })
}

// Custom error class
export class ApiError extends Error {
  statusCode: number

  constructor(message: string, statusCode: number) {
    super(message)
    this.statusCode = statusCode
    this.name = this.constructor.name
    Error.captureStackTrace(this, this.constructor)
  }

  static badRequest(message: string) {
    return new ApiError(message, 400)
  }

  static unauthorized(message: string) {
    return new ApiError(message, 401)
  }

  static forbidden(message: string) {
    return new ApiError(message, 403)
  }

  static notFound(message: string) {
    return new ApiError(message, 404)
  }

  static internal(message: string) {
    return new ApiError(message, 500)
  }
}
