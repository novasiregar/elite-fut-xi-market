import express from "express"
import cors from "cors"
import helmet from "helmet"
import rateLimit from "express-rate-limit"
import { initializeApp, cert } from "firebase-admin/app"
import { getFirestore } from "firebase-admin/firestore"
import { getAuth } from "firebase-admin/auth"
import { getStorage } from "firebase-admin/storage"
import authRoutes from "./routes/auth"
import listingRoutes from "./routes/listings"
import transactionRoutes from "./routes/transactions"
import messageRoutes from "./routes/messages"
import paymentRoutes from "./routes/payments"
import userRoutes from "./routes/users"
import searchRoutes from "./routes/search"
import { errorHandler } from "./middleware/errorHandler"
import { validateFirebaseToken } from "./middleware/auth"
import { ElasticsearchService } from "./services/elasticsearch"

// Initialize Firebase Admin
initializeApp({
  credential: cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
  }),
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
})

// Initialize Express
const app = express()
const PORT = process.env.PORT || 3001

// Export Firebase services for use in other files
export const db = getFirestore()
export const auth = getAuth()
export const storage = getStorage()

// Security middleware
app.use(helmet())
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }))
app.use(express.json())

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
})

// Apply rate limiting to all routes
app.use(apiLimiter)

// Initialize Elasticsearch
ElasticsearchService.initializeIndex()
  .then(() => console.log("Elasticsearch initialized"))
  .catch((err) => console.error("Elasticsearch initialization error:", err))

// Public routes
app.use("/api/auth", authRoutes)
app.use("/api/search", searchRoutes) // Add search routes

// Protected routes
app.use("/api/listings", validateFirebaseToken, listingRoutes)
app.use("/api/transactions", validateFirebaseToken, transactionRoutes)
app.use("/api/messages", validateFirebaseToken, messageRoutes)
app.use("/api/payments", validateFirebaseToken, paymentRoutes)
app.use("/api/users", validateFirebaseToken, userRoutes)

// Error handling middleware
app.use(errorHandler)

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
