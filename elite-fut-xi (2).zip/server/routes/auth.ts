import { Router } from "express"
import { auth, db } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { validateFirebaseToken } from "../middleware/auth"
import type { UserRecord } from "firebase-admin/auth"
import crypto from "crypto"

const router = Router()

// Register a new user
router.post("/register", async (req, res, next) => {
  try {
    const { email, password, displayName, phoneNumber } = req.body

    if (!email || !password) {
      throw ApiError.badRequest("Email and password are required")
    }

    // Create user in Firebase Auth
    const userRecord = await auth.createUser({
      email,
      password,
      displayName,
      phoneNumber,
      emailVerified: false,
    })

    // Create user profile in Firestore
    await db
      .collection("users")
      .doc(userRecord.uid)
      .set({
        email,
        displayName: displayName || email.split("@")[0],
        phoneNumber: phoneNumber || "",
        createdAt: new Date(),
        isVerified: false,
        role: "user",
        profileComplete: false,
      })

    res.status(201).json({ message: "User registered successfully" })
  } catch (error) {
    next(error)
  }
})

// Social login (Google, Facebook, etc.)
router.post("/social-login", async (req, res, next) => {
  try {
    const { idToken, provider } = req.body

    if (!idToken) {
      throw ApiError.badRequest("ID token is required")
    }

    // Verify the ID token
    const decodedToken = await auth.verifyIdToken(idToken)
    const uid = decodedToken.uid

    // Check if user exists in Firestore
    const userDoc = await db.collection("users").doc(uid).get()

    if (!userDoc.exists) {
      // Create user profile if it doesn't exist
      const userRecord = await auth.getUser(uid)

      await db
        .collection("users")
        .doc(uid)
        .set({
          email: userRecord.email,
          displayName: userRecord.displayName || userRecord.email?.split("@")[0],
          phoneNumber: userRecord.phoneNumber || "",
          createdAt: new Date(),
          isVerified: false,
          role: "user",
          profileComplete: false,
          authProvider: provider,
        })
    }

    // Generate custom token for client
    const customToken = await auth.createCustomToken(uid)

    res.json({ token: customToken })
  } catch (error) {
    next(error)
  }
})

// Get current user profile
router.get("/profile", validateFirebaseToken, async (req, res, next) => {
  try {
    const userId = req.userId

    // Get user data from Firestore
    const userDoc = await db.collection("users").doc(userId!).get()

    if (!userDoc.exists) {
      throw ApiError.notFound("User profile not found")
    }

    const userData = userDoc.data()

    // Remove sensitive information
    delete userData?.securityKey

    res.json(userData)
  } catch (error) {
    next(error)
  }
})

// Update user profile
router.put("/profile", validateFirebaseToken, async (req, res, next) => {
  try {
    const userId = req.userId
    const { displayName, phoneNumber, avatar } = req.body

    // Update user in Firebase Auth
    const updateParams: Partial<UserRecord> = {}

    if (displayName) updateParams.displayName = displayName
    if (phoneNumber) updateParams.phoneNumber = phoneNumber

    if (Object.keys(updateParams).length > 0) {
      await auth.updateUser(userId!, updateParams)
    }

    // Update user in Firestore
    const updateData: Record<string, any> = {
      updatedAt: new Date(),
    }

    if (displayName) updateData.displayName = displayName
    if (phoneNumber) updateData.phoneNumber = phoneNumber
    if (avatar) updateData.avatar = avatar

    await db.collection("users").doc(userId!).update(updateData)

    res.json({ message: "Profile updated successfully" })
  } catch (error) {
    next(error)
  }
})

// Generate encryption keys for messaging
router.post("/generate-keys", validateFirebaseToken, async (req, res, next) => {
  try {
    const userId = req.userId

    // Generate RSA key pair for end-to-end encryption
    const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
      modulusLength: 2048,
      publicKeyEncoding: {
        type: "spki",
        format: "pem",
      },
      privateKeyEncoding: {
        type: "pkcs8",
        format: "pem",
      },
    })

    // Store public key in Firestore
    await db.collection("users").doc(userId!).update({
      publicKey,
      keysGeneratedAt: new Date(),
    })

    // Return private key to client (should be stored securely)
    res.json({ privateKey })
  } catch (error) {
    next(error)
  }
})

export default router
