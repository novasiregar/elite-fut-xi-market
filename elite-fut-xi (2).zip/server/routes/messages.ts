import { Router } from "express"
import { db } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { FieldValue } from "firebase-admin/firestore"
import { v4 as uuidv4 } from "uuid"
import crypto from "crypto"

const router = Router()

// Create a new conversation
router.post("/conversations", async (req, res, next) => {
  try {
    const userId = req.userId
    const { recipientId, initialMessage, listingId } = req.body

    if (!recipientId || !initialMessage) {
      throw ApiError.badRequest("Recipient ID and initial message are required")
    }

    // Check if recipient exists
    const recipientDoc = await db.collection("users").doc(recipientId).get()

    if (!recipientDoc.exists) {
      throw ApiError.notFound("Recipient not found")
    }

    // Check if conversation already exists
    const existingConversationQuery = await db
      .collection("conversations")
      .where("participants", "array-contains", userId)
      .get()

    let existingConversation = null

    existingConversationQuery.forEach((doc) => {
      const conversation = doc.data()
      if (conversation.participants.includes(recipientId)) {
        existingConversation = {
          id: doc.id,
          ...conversation,
        }
      }
    })

    let conversationId

    if (existingConversation) {
      conversationId = existingConversation.id
    } else {
      // Create new conversation
      conversationId = uuidv4()

      const conversationData = {
        participants: [userId, recipientId],
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
        lastMessage: initialMessage,
        lastMessageSentBy: userId,
        lastMessageTimestamp: FieldValue.serverTimestamp(),
      }

      if (listingId) {
        conversationData.listingId = listingId
      }

      await db.collection("conversations").doc(conversationId).set(conversationData)
    }

    // Get recipient's public key for encryption
    const recipientData = recipientDoc.data()
    const recipientPublicKey = recipientData?.publicKey

    // Encrypt message if recipient has a public key
    let encryptedMessage = initialMessage

    if (recipientPublicKey) {
      encryptedMessage = crypto
        .publicEncrypt(
          {
            key: recipientPublicKey,
            padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
          },
          Buffer.from(initialMessage),
        )
        .toString("base64")
    }

    // Add message to conversation
    const messageId = uuidv4()

    const messageData = {
      id: messageId,
      conversationId,
      senderId: userId,
      content: encryptedMessage,
      isEncrypted: !!recipientPublicKey,
      createdAt: FieldValue.serverTimestamp(),
      read: false,
    }

    await db.collection("messages").doc(messageId).set(messageData)

    // Update conversation with last message
    await db.collection("conversations").doc(conversationId).update({
      lastMessage: initialMessage,
      lastMessageSentBy: userId,
      lastMessageTimestamp: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for recipient
    await db.collection("notifications").add({
      userId: recipientId,
      type: "new_message",
      title: "New Message",
      message: "You have received a new message",
      conversationId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.status(201).json({
      conversationId,
      messageId,
    })
  } catch (error) {
    next(error)
  }
})

// Get all conversations for current user
router.get("/conversations", async (req, res, next) => {
  try {
    const userId = req.userId

    const conversationsQuery = await db
      .collection("conversations")
      .where("participants", "array-contains", userId)
      .orderBy("updatedAt", "desc")
      .get()

    const conversations = []

    for (const doc of conversationsQuery.docs) {
      const conversation = doc.data()

      // Get other participant's info
      const otherParticipantId = conversation.participants.find((id: string) => id !== userId)
      const otherParticipantDoc = await db.collection("users").doc(otherParticipantId).get()
      const otherParticipantData = otherParticipantDoc.data()

      // Get unread message count
      const unreadQuery = await db
        .collection("messages")
        .where("conversationId", "==", doc.id)
        .where("senderId", "==", otherParticipantId)
        .where("read", "==", false)
        .count()
        .get()

      const unreadCount = unreadQuery.data().count

      // Format timestamps
      const formattedConversation = {
        id: doc.id,
        ...conversation,
        otherParticipant: {
          id: otherParticipantId,
          displayName: otherParticipantData?.displayName || "Unknown User",
          avatar: otherParticipantData?.avatar || null,
        },
        unreadCount,
      }

      if (conversation.createdAt) {
        formattedConversation.createdAt = conversation.createdAt.toDate().toISOString()
      }

      if (conversation.updatedAt) {
        formattedConversation.updatedAt = conversation.updatedAt.toDate().toISOString()
      }

      if (conversation.lastMessageTimestamp) {
        formattedConversation.lastMessageTimestamp = conversation.lastMessageTimestamp.toDate().toISOString()
      }

      conversations.push(formattedConversation)
    }

    res.json(conversations)
  } catch (error) {
    next(error)
  }
})

// Get messages for a conversation
router.get("/conversations/:id", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId

    // Check if conversation exists and user is a participant
    const conversationDoc = await db.collection("conversations").doc(id).get()

    if (!conversationDoc.exists) {
      throw ApiError.notFound("Conversation not found")
    }

    const conversation = conversationDoc.data()

    if (!conversation?.participants.includes(userId)) {
      throw ApiError.forbidden("You don't have permission to view this conversation")
    }

    // Get messages
    const messagesQuery = await db
      .collection("messages")
      .where("conversationId", "==", id)
      .orderBy("createdAt", "asc")
      .get()

    const messages = []

    for (const doc of messagesQuery.docs) {
      const message = doc.data()

      // Format timestamp
      if (message.createdAt) {
        message.createdAt = message.createdAt.toDate().toISOString()
      }

      messages.push({
        id: doc.id,
        ...message,
      })

      // Mark messages as read if they were sent to current user
      if (message.senderId !== userId && !message.read) {
        await db.collection("messages").doc(doc.id).update({
          read: true,
        })
      }
    }

    // Get other participant's info
    const otherParticipantId = conversation?.participants.find((id: string) => id !== userId)
    const otherParticipantDoc = await db.collection("users").doc(otherParticipantId).get()
    const otherParticipantData = otherParticipantDoc.data()

    // Format conversation data
    const formattedConversation = {
      id: conversationDoc.id,
      ...conversation,
      otherParticipant: {
        id: otherParticipantId,
        displayName: otherParticipantData?.displayName || "Unknown User",
        avatar: otherParticipantData?.avatar || null,
      },
      messages,
    }

    if (conversation?.createdAt) {
      formattedConversation.createdAt = conversation.createdAt.toDate().toISOString()
    }

    if (conversation?.updatedAt) {
      formattedConversation.updatedAt = conversation.updatedAt.toDate().toISOString()
    }

    if (conversation?.lastMessageTimestamp) {
      formattedConversation.lastMessageTimestamp = conversation.lastMessageTimestamp.toDate().toISOString()
    }

    res.json(formattedConversation)
  } catch (error) {
    next(error)
  }
})

// Send a message
router.post("/conversations/:id/messages", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { message } = req.body

    if (!message) {
      throw ApiError.badRequest("Message content is required")
    }

    // Check if conversation exists and user is a participant
    const conversationDoc = await db.collection("conversations").doc(id).get()

    if (!conversationDoc.exists) {
      throw ApiError.notFound("Conversation not found")
    }

    const conversation = conversationDoc.data()

    if (!conversation?.participants.includes(userId)) {
      throw ApiError.forbidden("You don't have permission to send messages in this conversation")
    }

    // Get recipient's public key for encryption
    const recipientId = conversation?.participants.find((id: string) => id !== userId)
    const recipientDoc = await db.collection("users").doc(recipientId).get()
    const recipientData = recipientDoc.data()
    const recipientPublicKey = recipientData?.publicKey

    // Encrypt message if recipient has a public key
    let encryptedMessage = message

    if (recipientPublicKey) {
      encryptedMessage = crypto
        .publicEncrypt(
          {
            key: recipientPublicKey,
            padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
          },
          Buffer.from(message),
        )
        .toString("base64")
    }

    // Add message to conversation
    const messageId = uuidv4()

    const messageData = {
      id: messageId,
      conversationId: id,
      senderId: userId,
      content: encryptedMessage,
      isEncrypted: !!recipientPublicKey,
      createdAt: FieldValue.serverTimestamp(),
      read: false,
    }

    await db.collection("messages").doc(messageId).set(messageData)

    // Update conversation with last message
    await db.collection("conversations").doc(id).update({
      lastMessage: message,
      lastMessageSentBy: userId,
      lastMessageTimestamp: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for recipient
    await db.collection("notifications").add({
      userId: recipientId,
      type: "new_message",
      title: "New Message",
      message: "You have received a new message",
      conversationId: id,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.status(201).json({
      id: messageId,
      senderId: userId,
      content: message, // Return original message to sender
      isEncrypted: !!recipientPublicKey,
      createdAt: new Date().toISOString(),
      read: false,
    })
  } catch (error) {
    next(error)
  }
})

export default router
