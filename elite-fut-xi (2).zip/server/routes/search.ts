import { Router } from "express"
import { ElasticsearchService } from "../services/elasticsearch"
import { RecommendationService } from "../services/recommendations"
import { VisualSearchService } from "../services/visualSearch"
import { SearchAnalyticsService } from "../services/searchAnalytics"
import { validateFirebaseToken } from "../middleware/auth"
import { ApiError } from "../middleware/errorHandler"
import multer from "multer"

const router = Router()

// Configure multer for image uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true)
    } else {
      cb(new Error("Invalid file type. Only images are allowed.") as any)
    }
  },
})

// Search endpoint
router.post("/", async (req, res, next) => {
  try {
    const { query, filters, sort, page, limit } = req.body
    const userId = req.userId || null

    const searchResults = await ElasticsearchService.searchListings({
      query,
      filters,
      sort,
      page,
      limit,
    })

    // Generate a search ID for analytics
    const searchId = Math.random().toString(36).substring(2, 15)

    // Record search analytics
    await SearchAnalyticsService.recordSearch({
      userId,
      searchId,
      query: query || "",
      filters: filters || {},
      resultCount: searchResults.total,
      timestamp: new Date(),
      source: "text",
    })

    // Add the search ID to the response
    res.json({
      ...searchResults,
      searchId,
    })
  } catch (error) {
    next(error)
  }
})

// Search suggestions endpoint
router.get("/suggestions", async (req, res, next) => {
  try {
    const { q } = req.query

    if (!q || typeof q !== "string") {
      throw ApiError.badRequest("Query parameter 'q' is required")
    }

    const suggestions = await ElasticsearchService.getSuggestions(q)

    res.json({
      suggestions,
    })
  } catch (error) {
    next(error)
  }
})

// Similar listings endpoint
router.get("/similar/:id", async (req, res, next) => {
  try {
    const { id } = req.params
    const { limit } = req.query
    const userId = req.userId || null

    const limitNum = limit ? Number.parseInt(limit as string) : 6

    const similarListings = await ElasticsearchService.getSimilarListings(id, limitNum)

    // Record this as a search event
    const searchId = Math.random().toString(36).substring(2, 15)
    await SearchAnalyticsService.recordSearch({
      userId,
      searchId,
      query: `similar:${id}`,
      filters: {},
      resultCount: similarListings.length,
      timestamp: new Date(),
      source: "recommendation",
    })

    res.json({
      listings: similarListings,
      searchId,
    })
  } catch (error) {
    next(error)
  }
})

// Visual search endpoint
router.post("/visual", upload.single("image"), async (req, res, next) => {
  try {
    if (!req.file) {
      throw ApiError.badRequest("Image file is required")
    }

    const imageBuffer = req.file.buffer
    const { limit = "12" } = req.query
    const userId = req.userId || null

    const limitNum = Number.parseInt(limit as string)

    const visualSearchResults = await VisualSearchService.searchByImage(imageBuffer, limitNum)

    // Record this as a search event
    const searchId = Math.random().toString(36).substring(2, 15)
    await SearchAnalyticsService.recordSearch({
      userId,
      searchId,
      query: "visual-search",
      filters: {},
      resultCount: visualSearchResults.results.length,
      timestamp: new Date(),
      source: "visual",
    })

    res.json({
      results: visualSearchResults.results,
      detectedObjects: visualSearchResults.detectedObjects,
      searchId,
    })
  } catch (error) {
    next(error)
  }
})

// Record search click
router.post("/click", validateFirebaseToken, async (req, res, next) => {
  try {
    const { searchId, listingId, position } = req.body
    const userId = req.userId

    if (!searchId || !listingId || position === undefined) {
      throw ApiError.badRequest("searchId, listingId, and position are required")
    }

    await SearchAnalyticsService.recordClick({
      userId,
      searchId,
      listingId,
      position,
      timestamp: new Date(),
    })

    res.status(204).send()
  } catch (error) {
    next(error)
  }
})

// Get popular searches
router.get("/popular", async (req, res, next) => {
  try {
    const { days = "7", limit = "10" } = req.query

    const daysNum = Number.parseInt(days as string)
    const limitNum = Number.parseInt(limit as string)

    const popularSearches = await SearchAnalyticsService.getPopularSearches(daysNum, limitNum)

    res.json({
      popularSearches,
    })
  } catch (error) {
    next(error)
  }
})

// Personalized recommendations endpoint
router.get("/recommendations", validateFirebaseToken, async (req, res, next) => {
  try {
    const userId = req.userId

    if (!userId) {
      throw ApiError.unauthorized("User ID is required")
    }

    const { limit = "10", context } = req.query

    const limitNum = Number.parseInt(limit as string)

    const recommendations = await RecommendationService.getPersonalizedRecommendations(
      userId,
      limitNum,
      context as string,
    )

    // Record this as a search event
    const searchId = Math.random().toString(36).substring(2, 15)
    await SearchAnalyticsService.recordSearch({
      userId,
      searchId,
      query: `recommendations:${context || "general"}`,
      filters: {},
      resultCount: recommendations.length,
      timestamp: new Date(),
      source: "recommendation",
    })

    res.json({
      recommendations,
      searchId,
    })
  } catch (error) {
    next(error)
  }
})

export default router
