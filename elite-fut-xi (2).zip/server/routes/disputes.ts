import { Router } from "express"
import { DisputeService, DisputeResolution } from "../services/dispute-service"
import { ApiError } from "../middleware/errorHandler"
import multer from "multer"
import { v4 as uuidv4 } from "uuid"
import { Storage } from "@google-cloud/storage"
import { db } from "../config/firebase" // Import Firebase database

const router = Router()

// Configure multer for file uploads
const storage = multer.memoryStorage()
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
})

// Configure Google Cloud Storage
const cloudStorage = new Storage()
const bucket = cloudStorage.bucket(process.env.FIREBASE_STORAGE_BUCKET || "")

// Create a new dispute
router.post("/", async (req, res, next) => {
  try {
    const userId = req.userId
    const { transactionId, reason, details } = req.body

    if (!transactionId || !reason || !details) {
      throw ApiError.badRequest("Missing required fields")
    }

    const result = await DisputeService.createDispute(transactionId, userId, reason, details)

    res.status(201).json(result)
  } catch (error) {
    next(error)
  }
})

// Add message to dispute
router.post("/:disputeId/messages", async (req, res, next) => {
  try {
    const { disputeId } = req.params
    const userId = req.userId
    const { message } = req.body

    if (!message) {
      throw ApiError.badRequest("Message is required")
    }

    const result = await DisputeService.addMessage(disputeId, userId, message)

    res.status(201).json(result)
  } catch (error) {
    next(error)
  }
})

// Add evidence to dispute
router.post("/:disputeId/evidence", upload.single("file"), async (req, res, next) => {
  try {
    const { disputeId } = req.params
    const userId = req.userId
    const { evidenceType, description } = req.body

    if (!evidenceType || !description) {
      throw ApiError.badRequest("Evidence type and description are required")
    }

    if (!req.file) {
      throw ApiError.badRequest("File is required")
    }

    // Upload file to Google Cloud Storage
    const fileExtension = req.file.originalname.split(".").pop()
    const fileName = `disputes/${disputeId}/${uuidv4()}.${fileExtension}`

    const file = bucket.file(fileName)
    const stream = file.createWriteStream({
      metadata: {
        contentType: req.file.mimetype,
      },
    })

    stream.on("error", (error) => {
      next(error)
    })

    stream.on("finish", async () => {
      try {
        // Make file publicly accessible
        await file.makePublic()

        const fileUrl = `https://storage.googleapis.com/${bucket.name}/${fileName}`

        const result = await DisputeService.addEvidence(disputeId, userId, evidenceType, description, fileUrl)

        res.status(201).json(result)
      } catch (error) {
        next(error)
      }
    })

    stream.end(req.file.buffer)
  } catch (error) {
    next(error)
  }
})

// Resolve dispute (admin only)
router.post("/:disputeId/resolve", async (req, res, next) => {
  try {
    const { disputeId } = req.params
    const adminId = req.userId
    const { resolution, notes } = req.body

    if (!resolution) {
      throw ApiError.badRequest("Resolution is required")
    }

    if (!Object.values(DisputeResolution).includes(resolution)) {
      throw ApiError.badRequest("Invalid resolution type")
    }

    const result = await DisputeService.resolveDispute(disputeId, adminId, resolution, notes || "")

    res.json(result)
  } catch (error) {
    next(error)
  }
})

// Get dispute by ID
router.get("/:disputeId", async (req, res, next) => {
  try {
    const { disputeId } = req.params
    const userId = req.userId

    const dispute = await DisputeService.getDispute(disputeId, userId)

    res.json(dispute)
  } catch (error) {
    next(error)
  }
})

// Get all disputes for a user
router.get("/", async (req, res, next) => {
  try {
    const userId = req.userId
    const { status } = req.query

    // Get all transactions for the user
    const transactionsSnapshot = await db.collection("transactions").where("buyerId", "==", userId).get()

    const sellerTransactionsSnapshot = await db.collection("transactions").where("sellerId", "==", userId).get()

    // Combine transaction IDs
    const transactionIds = [
      ...transactionsSnapshot.docs.map((doc) => doc.id),
      ...sellerTransactionsSnapshot.docs.map((doc) => doc.id),
    ]

    if (transactionIds.length === 0) {
      return res.json([])
    }

    // Get disputes for these transactions
    let disputesQuery = db.collection("disputes").where("transactionId", "in", transactionIds)

    if (status) {
      disputesQuery = disputesQuery.where("status", "==", status)
    }

    const disputesSnapshot = await disputesQuery.orderBy("createdAt", "desc").get()

    const disputes = disputesSnapshot.docs.map((doc) => {
      const data = doc.data()

      // Format timestamps
      if (data.createdAt) {
        data.createdAt = data.createdAt.toDate().toISOString()
      }
      if (data.updatedAt) {
        data.updatedAt = data.updatedAt.toDate().toISOString()
      }
      if (data.resolvedAt) {
        data.resolvedAt = data.resolvedAt.toDate().toISOString()
      }

      return data
    })

    res.json(disputes)
  } catch (error) {
    next(error)
  }
})

export default router
