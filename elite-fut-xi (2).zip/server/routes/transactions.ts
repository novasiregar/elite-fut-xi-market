import { Router } from "express"
import { db } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { FieldValue } from "firebase-admin/firestore"
import { v4 as uuidv4 } from "uuid"

const router = Router()

// Transaction status enum
enum TransactionStatus {
  PENDING = "pending",
  PAYMENT_PROCESSING = "payment_processing",
  PAYMENT_COMPLETED = "payment_completed",
  ESCROW_FUNDED = "escrow_funded",
  ACCOUNT_DELIVERED = "account_delivered",
  COMPLETED = "completed",
  DISPUTED = "disputed",
  REFUNDED = "refunded",
  CANCELLED = "cancelled",
}

// Create a new transaction
router.post("/", async (req, res, next) => {
  try {
    const userId = req.userId
    const { listingId, paymentMethod } = req.body

    if (!listingId || !paymentMethod) {
      throw ApiError.badRequest("Listing ID and payment method are required")
    }

    // Get listing details
    const listingDoc = await db.collection("listings").doc(listingId).get()

    if (!listingDoc.exists) {
      throw ApiError.notFound("Listing not found")
    }

    const listing = listingDoc.data()

    if (listing?.status !== "active") {
      throw ApiError.badRequest("Listing is not available for purchase")
    }

    if (listing?.sellerId === userId) {
      throw ApiError.badRequest("You cannot purchase your own listing")
    }

    // Create transaction
    const transactionId = uuidv4()
    const escrowId = `escrow_${uuidv4().substring(0, 8)}`

    const transactionData = {
      id: transactionId,
      listingId,
      listingTitle: listing?.title,
      buyerId: userId,
      sellerId: listing?.sellerId,
      amount: listing?.price,
      escrowId,
      paymentMethod,
      status: TransactionStatus.PENDING,
      timeline: [
        {
          status: TransactionStatus.PENDING,
          timestamp: FieldValue.serverTimestamp(),
          note: "Transaction initiated",
        },
      ],
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }

    // Create transaction document
    await db.collection("transactions").doc(transactionId).set(transactionData)

    // Update listing status
    await db.collection("listings").doc(listingId).update({
      status: "pending_sale",
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for seller
    await db.collection("notifications").add({
      userId: listing?.sellerId,
      type: "new_transaction",
      title: "New Purchase",
      message: `Your listing "${listing?.title}" has a new buyer`,
      transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.status(201).json({
      transactionId,
      escrowId,
      status: TransactionStatus.PENDING,
    })
  } catch (error) {
    next(error)
  }
})

// Get all transactions for current user
router.get("/", async (req, res, next) => {
  try {
    const userId = req.userId
    const { status, role = "all" } = req.query

    let query = db.collection("transactions")

    if (role === "buyer") {
      query = query.where("buyerId", "==", userId)
    } else if (role === "seller") {
      query = query.where("sellerId", "==", userId)
    } else {
      // Get both buyer and seller transactions
      query = query.where("buyerId", "==", userId)
    }

    if (status) {
      query = query.where("status", "==", status)
    }

    // Order by creation date, newest first
    query = query.orderBy("createdAt", "desc")

    const snapshot = await query.get()

    const transactions = []

    for (const doc of snapshot.docs) {
      const transaction = doc.data()

      // Convert Firestore timestamps to ISO strings
      if (transaction.createdAt) {
        transaction.createdAt = transaction.createdAt.toDate().toISOString()
      }

      if (transaction.updatedAt) {
        transaction.updatedAt = transaction.updatedAt.toDate().toISOString()
      }

      if (transaction.timeline) {
        transaction.timeline = transaction.timeline.map((event: any) => ({
          ...event,
          timestamp: event.timestamp ? event.timestamp.toDate().toISOString() : null,
        }))
      }

      transactions.push(transaction)
    }

    // If role is "all", also get seller transactions
    if (role === "all") {
      const sellerQuery = db.collection("transactions").where("sellerId", "==", userId)

      if (status) {
        sellerQuery.where("status", "==", status)
      }

      const sellerSnapshot = await sellerQuery.orderBy("createdAt", "desc").get()

      for (const doc of sellerSnapshot.docs) {
        const transaction = doc.data()

        // Check if this transaction is already in the array (from buyer query)
        const exists = transactions.some((t) => t.id === transaction.id)

        if (!exists) {
          // Convert Firestore timestamps to ISO strings
          if (transaction.createdAt) {
            transaction.createdAt = transaction.createdAt.toDate().toISOString()
          }

          if (transaction.updatedAt) {
            transaction.updatedAt = transaction.updatedAt.toDate().toISOString()
          }

          if (transaction.timeline) {
            transaction.timeline = transaction.timeline.map((event: any) => ({
              ...event,
              timestamp: event.timestamp ? event.timestamp.toDate().toISOString() : null,
            }))
          }

          transactions.push(transaction)
        }
      }

      // Sort combined results by createdAt
      transactions.sort((a, b) => {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      })
    }

    res.json(transactions)
  } catch (error) {
    next(error)
  }
})

// Get a single transaction
router.get("/:id", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId

    const doc = await db.collection("transactions").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = doc.data()

    // Check if user is buyer or seller
    if (transaction?.buyerId !== userId && transaction?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to view this transaction")
    }

    // Convert Firestore timestamps to ISO strings
    if (transaction?.createdAt) {
      transaction.createdAt = transaction.createdAt.toDate().toISOString()
    }

    if (transaction?.updatedAt) {
      transaction.updatedAt = transaction.updatedAt.toDate().toISOString()
    }

    if (transaction?.timeline) {
      transaction.timeline = transaction.timeline.map((event: any) => ({
        ...event,
        timestamp: event.timestamp ? event.timestamp.toDate().toISOString() : null,
      }))
    }

    res.json(transaction)
  } catch (error) {
    next(error)
  }
})

// Update transaction status (for buyer to confirm delivery)
router.post("/:id/confirm-delivery", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { rating, review } = req.body

    const doc = await db.collection("transactions").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = doc.data()

    // Check if user is the buyer
    if (transaction?.buyerId !== userId) {
      throw ApiError.forbidden("Only the buyer can confirm delivery")
    }

    // Check if transaction is in the correct state
    if (transaction?.status !== TransactionStatus.ACCOUNT_DELIVERED) {
      throw ApiError.badRequest("Transaction is not in the delivery confirmation stage")
    }

    // Update transaction status
    await db
      .collection("transactions")
      .doc(id)
      .update({
        status: TransactionStatus.COMPLETED,
        updatedAt: FieldValue.serverTimestamp(),
        rating: rating || 5,
        review: review || "",
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.COMPLETED,
          timestamp: FieldValue.serverTimestamp(),
          note: "Buyer confirmed delivery and released funds",
        }),
      })

    // Release funds to seller (in a real app, this would call your payment processor)
    // This is a placeholder for the actual implementation

    // Update listing status
    await db.collection("listings").doc(transaction?.listingId).update({
      status: "sold",
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for seller
    await db.collection("notifications").add({
      userId: transaction?.sellerId,
      type: "transaction_completed",
      title: "Transaction Completed",
      message: `Transaction for "${transaction?.listingTitle}" has been completed`,
      transactionId: id,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    // Update seller ratings
    if (rating) {
      const sellerDoc = await db.collection("users").doc(transaction?.sellerId).get()
      const sellerData = sellerDoc.data()

      const currentRating = sellerData?.rating || 0
      const ratingCount = sellerData?.ratingCount || 0

      const newRatingCount = ratingCount + 1
      const newRating = (currentRating * ratingCount + rating) / newRatingCount

      await db.collection("users").doc(transaction?.sellerId).update({
        rating: newRating,
        ratingCount: newRatingCount,
      })
    }

    res.json({
      message: "Delivery confirmed and funds released",
      status: TransactionStatus.COMPLETED,
    })
  } catch (error) {
    next(error)
  }
})

// Mark account as delivered (for seller)
router.post("/:id/deliver", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { deliveryDetails, deliveryMethod } = req.body

    if (!deliveryDetails) {
      throw ApiError.badRequest("Delivery details are required")
    }

    const doc = await db.collection("transactions").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = doc.data()

    // Check if user is the seller
    if (transaction?.sellerId !== userId) {
      throw ApiError.forbidden("Only the seller can mark as delivered")
    }

    // Check if transaction is in the correct state
    if (transaction?.status !== TransactionStatus.ESCROW_FUNDED) {
      throw ApiError.badRequest("Transaction is not ready for delivery")
    }

    // Update transaction status
    await db
      .collection("transactions")
      .doc(id)
      .update({
        status: TransactionStatus.ACCOUNT_DELIVERED,
        deliveryDetails,
        deliveryMethod,
        deliveredAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.ACCOUNT_DELIVERED,
          timestamp: FieldValue.serverTimestamp(),
          note: "Seller delivered account credentials",
        }),
      })

    // Create notification for buyer
    await db.collection("notifications").add({
      userId: transaction?.buyerId,
      type: "account_delivered",
      title: "Account Delivered",
      message: `The seller has delivered the account for "${transaction?.listingTitle}"`,
      transactionId: id,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({
      message: "Account marked as delivered",
      status: TransactionStatus.ACCOUNT_DELIVERED,
    })
  } catch (error) {
    next(error)
  }
})

// Open a dispute
router.post("/:id/dispute", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { reason, details } = req.body

    if (!reason || !details) {
      throw ApiError.badRequest("Reason and details are required")
    }

    const doc = await db.collection("transactions").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = doc.data()

    // Check if user is buyer or seller
    if (transaction?.buyerId !== userId && transaction?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to open a dispute for this transaction")
    }

    // Check if transaction is in a valid state for dispute
    const validStates = [TransactionStatus.ESCROW_FUNDED, TransactionStatus.ACCOUNT_DELIVERED]

    if (!validStates.includes(transaction?.status)) {
      throw ApiError.badRequest("Transaction is not in a valid state for dispute")
    }

    // Create dispute
    const disputeId = uuidv4()

    const disputeData = {
      id: disputeId,
      transactionId: id,
      initiatedBy: userId,
      reason,
      details,
      status: "open",
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      messages: [
        {
          userId,
          message: details,
          timestamp: FieldValue.serverTimestamp(),
        },
      ],
    }

    await db.collection("disputes").doc(disputeId).set(disputeData)

    // Update transaction status
    await db
      .collection("transactions")
      .doc(id)
      .update({
        status: TransactionStatus.DISPUTED,
        disputeId,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.DISPUTED,
          timestamp: FieldValue.serverTimestamp(),
          note: `Dispute opened by ${userId === transaction?.buyerId ? "buyer" : "seller"}`,
        }),
      })

    // Create notification for the other party
    const otherPartyId = userId === transaction?.buyerId ? transaction?.sellerId : transaction?.buyerId

    await db.collection("notifications").add({
      userId: otherPartyId,
      type: "dispute_opened",
      title: "Dispute Opened",
      message: `A dispute has been opened for transaction "${transaction?.listingTitle}"`,
      transactionId: id,
      disputeId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    // Notify admin
    await db.collection("admin_notifications").add({
      type: "new_dispute",
      title: "New Dispute",
      message: `A new dispute has been opened for transaction ${id}`,
      transactionId: id,
      disputeId,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({
      message: "Dispute opened successfully",
      disputeId,
      status: TransactionStatus.DISPUTED,
    })
  } catch (error) {
    next(error)
  }
})

// Cancel a transaction (only in PENDING state)
router.post("/:id/cancel", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { reason } = req.body

    const doc = await db.collection("transactions").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = doc.data()

    // Check if user is buyer or seller
    if (transaction?.buyerId !== userId && transaction?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to cancel this transaction")
    }

    // Check if transaction is in PENDING state
    if (transaction?.status !== TransactionStatus.PENDING) {
      throw ApiError.badRequest("Only pending transactions can be cancelled")
    }

    // Update transaction status
    await db
      .collection("transactions")
      .doc(id)
      .update({
        status: TransactionStatus.CANCELLED,
        cancelledBy: userId,
        cancellationReason: reason || "No reason provided",
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.CANCELLED,
          timestamp: FieldValue.serverTimestamp(),
          note: `Cancelled by ${userId === transaction?.buyerId ? "buyer" : "seller"}: ${reason || "No reason provided"}`,
        }),
      })

    // Update listing status back to active
    await db.collection("listings").doc(transaction?.listingId).update({
      status: "active",
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for the other party
    const otherPartyId = userId === transaction?.buyerId ? transaction?.sellerId : transaction?.buyerId

    await db.collection("notifications").add({
      userId: otherPartyId,
      type: "transaction_cancelled",
      title: "Transaction Cancelled",
      message: `Transaction for "${transaction?.listingTitle}" has been cancelled`,
      transactionId: id,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({
      message: "Transaction cancelled successfully",
      status: TransactionStatus.CANCELLED,
    })
  } catch (error) {
    next(error)
  }
})

export default router
