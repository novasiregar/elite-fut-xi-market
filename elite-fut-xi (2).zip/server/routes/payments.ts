import { Router } from "express"
import { db } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { FieldValue } from "firebase-admin/firestore"
import crypto from "crypto"
import axios from "axios"

const router = Router()

// Payment status enum
enum PaymentStatus {
  PENDING = "pending",
  PROCESSING = "processing",
  COMPLETED = "completed",
  FAILED = "failed",
  EXPIRED = "expired",
  REFUNDED = "refunded",
}

// Transaction status enum (same as in transactions.ts)
enum TransactionStatus {
  PENDING = "pending",
  PAYMENT_PROCESSING = "payment_processing",
  PAYMENT_COMPLETED = "payment_completed",
  ESCROW_FUNDED = "escrow_funded",
  ACCOUNT_DELIVERED = "account_delivered",
  COMPLETED = "completed",
  DISPUTED = "disputed",
  REFUNDED = "refunded",
  CANCELLED = "cancelled",
}

// Initialize payment for a transaction
router.post("/initialize", async (req, res, next) => {
  try {
    const userId = req.userId
    const { transactionId, paymentMethod } = req.body

    if (!transactionId || !paymentMethod) {
      throw ApiError.badRequest("Transaction ID and payment method are required")
    }

    // Check if transaction exists and user is the buyer
    const transactionDoc = await db.collection("transactions").doc(transactionId).get()

    if (!transactionDoc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = transactionDoc.data()

    if (transaction?.buyerId !== userId) {
      throw ApiError.forbidden("Only the buyer can initialize payment")
    }

    if (transaction?.status !== TransactionStatus.PENDING) {
      throw ApiError.badRequest("Transaction is not in pending state")
    }

    // Generate payment reference
    const paymentReference = `PAY-${crypto.randomBytes(8).toString("hex").toUpperCase()}`

    // Calculate fee
    const fee = calculateFee(transaction?.amount, paymentMethod)
    const totalAmount = transaction?.amount + fee

    // Create payment record
    const paymentData = {
      transactionId,
      paymentReference,
      amount: transaction?.amount,
      fee,
      totalAmount,
      buyerId: userId,
      sellerId: transaction?.sellerId,
      paymentMethod,
      status: PaymentStatus.PENDING,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }

    await db.collection("payments").doc(paymentReference).set(paymentData)

    // Update transaction status
    await db
      .collection("transactions")
      .doc(transactionId)
      .update({
        status: TransactionStatus.PAYMENT_PROCESSING,
        paymentReference,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.PAYMENT_PROCESSING,
          timestamp: FieldValue.serverTimestamp(),
          note: "Payment initialized",
        }),
      })

    // Generate payment details based on payment method
    let paymentDetails

    switch (paymentMethod) {
      case "gopay":
        paymentDetails = await createGopayPayment(totalAmount, paymentReference)
        break
      case "ovo":
        paymentDetails = await createOvoPayment(totalAmount, paymentReference)
        break
      case "dana":
        paymentDetails = await createDanaPayment(totalAmount, paymentReference)
        break
      case "bank_transfer":
        paymentDetails = await createBankTransferPayment(totalAmount, paymentReference)
        break
      default:
        throw ApiError.badRequest("Unsupported payment method")
    }

    // Update payment with details
    await db.collection("payments").doc(paymentReference).update({
      paymentDetails,
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Create notification for buyer
    await db.collection("notifications").add({
      userId,
      type: "payment_initialized",
      title: "Payment Initialized",
      message: `Your payment of Rp ${totalAmount.toLocaleString()} has been initialized`,
      paymentReference,
      transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({
      paymentReference,
      amount: transaction?.amount,
      fee,
      totalAmount,
      paymentDetails,
    })
  } catch (error) {
    next(error)
  }
})

// Check payment status
router.get("/status/:reference", async (req, res, next) => {
  try {
    const { reference } = req.params
    const userId = req.userId

    // Get payment record
    const paymentDoc = await db.collection("payments").doc(reference).get()

    if (!paymentDoc.exists) {
      throw ApiError.notFound("Payment not found")
    }

    const payment = paymentDoc.data()

    // Check if user is buyer or seller
    if (payment?.buyerId !== userId && payment?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to view this payment")
    }

    // Format timestamps
    if (payment?.createdAt) {
      payment.createdAt = payment.createdAt.toDate().toISOString()
    }

    if (payment?.updatedAt) {
      payment.updatedAt = payment.updatedAt.toDate().toISOString()
    }

    if (payment?.completedAt) {
      payment.completedAt = payment.completedAt.toDate().toISOString()
    }

    // If payment is pending, check with payment gateway for updates
    if (payment?.status === PaymentStatus.PENDING || payment?.status === PaymentStatus.PROCESSING) {
      const updatedStatus = await checkPaymentWithGateway(reference, payment?.paymentMethod)

      if (updatedStatus && updatedStatus !== payment?.status) {
        // Update payment status
        await updatePaymentStatus(reference, updatedStatus)

        // Update the response data
        payment.status = updatedStatus
        payment.updatedAt = new Date().toISOString()

        if (updatedStatus === PaymentStatus.COMPLETED) {
          payment.completedAt = new Date().toISOString()
        }
      }
    }

    res.json(payment)
  } catch (error) {
    next(error)
  }
})

// Verify payment (manual verification for bank transfers)
router.post("/verify/:reference", async (req, res, next) => {
  try {
    const { reference } = req.params
    const { receiptData } = req.body
    const userId = req.userId

    // Get payment record
    const paymentDoc = await db.collection("payments").doc(reference).get()

    if (!paymentDoc.exists) {
      throw ApiError.notFound("Payment not found")
    }

    const payment = paymentDoc.data()

    // Check if user is buyer
    if (payment?.buyerId !== userId) {
      throw ApiError.forbidden("Only the buyer can verify payment")
    }

    // Check if payment is pending
    if (payment?.status !== PaymentStatus.PENDING && payment?.status !== PaymentStatus.PROCESSING) {
      throw ApiError.badRequest("Payment is not in pending or processing state")
    }

    // For bank transfers, store receipt data
    if (payment?.paymentMethod === "bank_transfer" && receiptData) {
      await db.collection("payments").doc(reference).update({
        receiptData,
        status: PaymentStatus.PROCESSING,
        updatedAt: FieldValue.serverTimestamp(),
        verificationRequestedAt: FieldValue.serverTimestamp(),
      })

      // Create notification for admin to verify payment
      await db.collection("admin_notifications").add({
        type: "payment_verification",
        title: "Payment Verification Required",
        message: `Bank transfer payment ${reference} requires verification`,
        paymentReference: reference,
        transactionId: payment?.transactionId,
        read: false,
        createdAt: FieldValue.serverTimestamp(),
      })

      res.json({
        success: true,
        message: "Payment verification requested. We will process it shortly.",
      })
    } else {
      // For other payment methods, check with gateway
      const updatedStatus = await checkPaymentWithGateway(reference, payment?.paymentMethod)

      if (updatedStatus) {
        await updatePaymentStatus(reference, updatedStatus)

        res.json({
          success: true,
          status: updatedStatus,
          message:
            updatedStatus === PaymentStatus.COMPLETED ? "Payment verified successfully" : "Payment status updated",
        })
      } else {
        res.json({
          success: false,
          message: "Unable to verify payment at this time",
        })
      }
    }
  } catch (error) {
    next(error)
  }
})

// Cancel payment
router.post("/cancel/:reference", async (req, res, next) => {
  try {
    const { reference } = req.params
    const userId = req.userId

    // Get payment record
    const paymentDoc = await db.collection("payments").doc(reference).get()

    if (!paymentDoc.exists) {
      throw ApiError.notFound("Payment not found")
    }

    const payment = paymentDoc.data()

    // Check if user is buyer
    if (payment?.buyerId !== userId) {
      throw ApiError.forbidden("Only the buyer can cancel payment")
    }

    // Check if payment is in a state that can be cancelled
    if (payment?.status !== PaymentStatus.PENDING && payment?.status !== PaymentStatus.PROCESSING) {
      throw ApiError.badRequest("Payment cannot be cancelled in its current state")
    }

    // Cancel payment with gateway if needed
    if (payment?.paymentMethod !== "bank_transfer") {
      await cancelPaymentWithGateway(reference, payment?.paymentMethod)
    }

    // Update payment status
    await db.collection("payments").doc(reference).update({
      status: PaymentStatus.CANCELLED,
      updatedAt: FieldValue.serverTimestamp(),
      cancelledAt: FieldValue.serverTimestamp(),
    })

    // Update transaction status
    await db
      .collection("transactions")
      .doc(payment?.transactionId)
      .update({
        status: TransactionStatus.CANCELLED,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.CANCELLED,
          timestamp: FieldValue.serverTimestamp(),
          note: "Payment cancelled by buyer",
        }),
      })

    // Create notification for seller
    await db.collection("notifications").add({
      userId: payment?.sellerId,
      type: "payment_cancelled",
      title: "Payment Cancelled",
      message: "The buyer has cancelled the payment",
      transactionId: payment?.transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({ success: true, message: "Payment cancelled successfully" })
  } catch (error) {
    next(error)
  }
})

// Webhook for payment notifications
router.post("/webhook", async (req, res, next) => {
  try {
    const { paymentReference, status, signature } = req.body

    // Verify webhook signature (implementation depends on payment provider)
    const isValidSignature = verifyWebhookSignature(req.body, signature)

    if (!isValidSignature) {
      throw ApiError.forbidden("Invalid webhook signature")
    }

    // Get payment record
    const paymentDoc = await db.collection("payments").doc(paymentReference).get()

    if (!paymentDoc.exists) {
      throw ApiError.notFound("Payment not found")
    }

    const payment = paymentDoc.data()

    // Update payment status
    await updatePaymentStatus(paymentReference, status)

    res.json({ success: true })
  } catch (error) {
    next(error)
  }
})

// Helper function to update payment status
async function updatePaymentStatus(reference: string, status: PaymentStatus) {
  // Get payment record
  const paymentDoc = await db.collection("payments").doc(reference).get()

  if (!paymentDoc.exists) {
    throw new ApiError("Payment not found", 404)
  }

  const payment = paymentDoc.data()

  // If status is already set, don't update
  if (payment?.status === status) {
    return
  }

  // Update payment status
  await db
    .collection("payments")
    .doc(reference)
    .update({
      status,
      updatedAt: FieldValue.serverTimestamp(),
      ...(status === PaymentStatus.COMPLETED && { completedAt: FieldValue.serverTimestamp() }),
    })

  // If payment is completed, update transaction status
  if (status === PaymentStatus.COMPLETED) {
    const transactionId = payment?.transactionId

    await db
      .collection("transactions")
      .doc(transactionId)
      .update({
        status: TransactionStatus.ESCROW_FUNDED,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.ESCROW_FUNDED,
          timestamp: FieldValue.serverTimestamp(),
          note: "Payment completed and escrow funded",
        }),
      })

    // Create notification for seller
    await db.collection("notifications").add({
      userId: payment?.sellerId,
      type: "payment_received",
      title: "Payment Received",
      message: "Payment has been received and escrow is funded",
      transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    // Create notification for buyer
    await db.collection("notifications").add({
      userId: payment?.buyerId,
      type: "payment_confirmed",
      title: "Payment Confirmed",
      message: "Your payment has been confirmed and the seller has been notified",
      transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })
  } else if (status === PaymentStatus.FAILED) {
    // If payment failed, update transaction status
    const transactionId = payment?.transactionId

    await db
      .collection("transactions")
      .doc(transactionId)
      .update({
        status: TransactionStatus.PENDING,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: TransactionStatus.PENDING,
          timestamp: FieldValue.serverTimestamp(),
          note: "Payment failed, transaction reverted to pending",
        }),
      })

    // Create notification for buyer
    await db.collection("notifications").add({
      userId: payment?.buyerId,
      type: "payment_failed",
      title: "Payment Failed",
      message: "Your payment has failed. Please try again or use a different payment method.",
      transactionId,
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })
  }
}

// Helper functions for payment providers
// These would be replaced with actual API calls to payment gateways

async function createGopayPayment(amount: number, reference: string) {
  // This is a placeholder for actual GoPay API integration
  try {
    // In a real implementation, this would call the GoPay API
    const response = await axios
      .post(
        "https://api.gopay.com/v1/payments",
        {
          amount,
          reference,
          callback_url: `${process.env.API_URL}/api/payments/webhook`,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.GOPAY_API_KEY}`,
          },
        },
      )
      .catch(() => null) // Catch error but continue for demo

    // For demo purposes, we'll simulate a response
    const qrCode = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${reference}`
    const deepLink = `gopay://payments?reference=${reference}&amount=${amount}`

    return {
      qrCode,
      deepLink,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes
    }
  } catch (error) {
    console.error("GoPay payment creation failed:", error)
    throw new ApiError("Failed to create GoPay payment", 500)
  }
}

async function createOvoPayment(amount: number, reference: string) {
  // This is a placeholder for actual OVO API integration
  try {
    // Simulate API response
    return {
      phoneNumber: "Enter your OVO phone number",
      amount,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes
    }
  } catch (error) {
    console.error("OVO payment creation failed:", error)
    throw new ApiError("Failed to create OVO payment", 500)
  }
}

async function createDanaPayment(amount: number, reference: string) {
  // This is a placeholder for actual DANA API integration
  try {
    // Simulate API response
    const qrCode = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${reference}`
    const deepLink = `dana://payments?reference=${reference}&amount=${amount}`

    return {
      qrCode,
      deepLink,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes
    }
  } catch (error) {
    console.error("DANA payment creation failed:", error)
    throw new ApiError("Failed to create DANA payment", 500)
  }
}

async function createBankTransferPayment(amount: number, reference: string) {
  // This is a placeholder for actual bank transfer API integration
  try {
    // Simulate virtual account numbers
    return {
      bankAccounts: [
        {
          bank: "BCA",
          accountNumber: `8277${Math.floor(1000000000 + Math.random() * 9000000000)}`,
          accountName: "ELITE FUT XI MARKET",
        },
        {
          bank: "Mandiri",
          accountNumber: `1470${Math.floor(1000000000 + Math.random() * 9000000000)}`,
          accountName: "ELITE FUT XI MARKET",
        },
        {
          bank: "BNI",
          accountNumber: `8277${Math.floor(1000000000 + Math.random() * 9000000000)}`,
          accountName: "ELITE FUT XI MARKET",
        },
      ],
      amount,
      reference,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
    }
  } catch (error) {
    console.error("Bank transfer payment creation failed:", error)
    throw new ApiError("Failed to create bank transfer payment", 500)
  }
}

async function checkPaymentWithGateway(reference: string, paymentMethod: string): Promise<PaymentStatus | null> {
  // This is a placeholder for actual payment gateway status check
  try {
    // In a real implementation, this would call the payment gateway API
    // For demo purposes, we'll simulate a response with a 30% chance of completion
    const random = Math.random()

    if (random < 0.3) {
      return PaymentStatus.COMPLETED
    } else if (random < 0.4) {
      return PaymentStatus.FAILED
    } else if (random < 0.5) {
      return PaymentStatus.EXPIRED
    } else {
      return PaymentStatus.PROCESSING
    }
  } catch (error) {
    console.error(`Check payment with ${paymentMethod} gateway failed:`, error)
    return null
  }
}

async function cancelPaymentWithGateway(reference: string, paymentMethod: string): Promise<boolean> {
  // This is a placeholder for actual payment gateway cancellation
  try {
    // In a real implementation, this would call the payment gateway API
    // For demo purposes, we'll simulate a successful cancellation
    return true
  } catch (error) {
    console.error(`Cancel payment with ${paymentMethod} gateway failed:`, error)
    return false
  }
}

function verifyWebhookSignature(payload: any, signature: string): boolean {
  // This is a placeholder for actual signature verification
  // In a real implementation, this would verify the signature from the payment provider

  // Example implementation for a HMAC-based signature:
  const expectedSignature = crypto
    .createHmac("sha256", process.env.WEBHOOK_SECRET || "default-secret")
    .update(JSON.stringify(payload))
    .digest("hex")

  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
}

function calculateFee(amount: number, paymentMethod: string): number {
  // Calculate fee based on payment method
  switch (paymentMethod) {
    case "gopay":
    case "ovo":
    case "dana":
      return Math.ceil(amount * 0.02) // 2% fee
    case "bank_transfer":
      return Math.ceil(amount * 0.01) // 1% fee
    default:
      return 0
  }
}

export default router
