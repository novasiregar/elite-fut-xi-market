import { Router } from "express"
import { RecommendationEngine } from "../services/recommendation-engine"
import { validateFirebaseToken } from "../middleware/auth"
import { ApiError } from "../middleware/errorHandler"

const router = Router()

// Get personalized recommendations
router.get("/", validateFirebaseToken, async (req, res, next) => {
  try {
    const userId = req.userId

    if (!userId) {
      throw ApiError.unauthorized("User ID is required")
    }

    const { limit = "10", context = "homepage", listingId, categories, minPrice, maxPrice } = req.query

    const limitNum = Number.parseInt(limit as string, 10)

    // Build context object
    const contextObj: any = {
      context: context as string,
    }

    if (listingId) {
      contextObj.listingId = listingId as string
    }

    if (categories) {
      contextObj.categories = Array.isArray(categories) ? (categories as string[]) : [categories as string]
    }

    if (minPrice && maxPrice) {
      contextObj.priceRange = {
        min: Number.parseInt(minPrice as string, 10),
        max: Number.parseInt(maxPrice as string, 10),
      }
    }

    const recommendations = await RecommendationEngine.getPersonalizedRecommendations(userId, limitNum, contextObj)

    res.json({
      recommendations,
    })
  } catch (error) {
    next(error)
  }
})

// Record recommendation click
router.post("/recommendation-click", validateFirebaseToken, async (req, res, next) => {
  try {
    const { userId, listingId, context } = req.body

    if (!userId || !listingId) {
      throw ApiError.badRequest("userId and listingId are required")
    }

    await RecommendationEngine.recordUserAction(userId, "view", {
      listingId,
      category: context,
    })

    res.status(204).send()
  } catch (error) {
    next(error)
  }
})

// Get trending listings
router.get("/trending", async (req, res, next) => {
  try {
    const { limit = "10" } = req.query
    const limitNum = Number.parseInt(limit as string, 10)

    const trendingListings = await RecommendationEngine.getTrendingListings(limitNum)

    res.json({
      listings: trendingListings,
    })
  } catch (error) {
    next(error)
  }
})

export default router
