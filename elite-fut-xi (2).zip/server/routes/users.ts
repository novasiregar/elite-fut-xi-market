import { Router } from "express"
import { db, auth, storage } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { isAdmin } from "../middleware/auth"
import { FieldValue } from "firebase-admin/firestore"
import multer from "multer"
import { v4 as uuidv4 } from "uuid"
import path from "path"

const router = Router()

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [".jpg", ".jpeg", ".png"]
    const ext = path.extname(file.originalname).toLowerCase()

    if (allowedTypes.includes(ext)) {
      cb(null, true)
    } else {
      cb(new Error("Invalid file type. Only JPG and PNG are allowed.") as any)
    }
  },
})

// Get user profile
router.get("/profile", async (req, res, next) => {
  try {
    const userId = req.userId

    const userDoc = await db.collection("users").doc(userId!).get()

    if (!userDoc.exists) {
      throw ApiError.notFound("User not found")
    }

    const userData = userDoc.data()

    // Remove sensitive information
    delete userData?.securityKey

    // Format timestamps
    if (userData?.createdAt) {
      userData.createdAt = userData.createdAt.toDate().toISOString()
    }

    if (userData?.updatedAt) {
      userData.updatedAt = userData.updatedAt.toDate().toISOString()
    }

    res.json(userData)
  } catch (error) {
    next(error)
  }
})

// Update user profile
router.put("/profile", upload.single("avatar"), async (req, res, next) => {
  try {
    const userId = req.userId
    const { displayName, phoneNumber, bio } = req.body

    // Upload avatar if provided
    let avatarUrl

    if (req.file) {
      const fileId = uuidv4()
      const fileExtension = path.extname(req.file.originalname)
      const fileName = `avatars/${userId}/${fileId}${fileExtension}`

      const fileBuffer = req.file.buffer
      const fileType = req.file.mimetype

      // Upload to Firebase Storage
      const bucket = storage.bucket()
      const fileRef = bucket.file(fileName)

      await fileRef.save(fileBuffer, {
        metadata: {
          contentType: fileType,
        },
      })

      // Make file publicly accessible
      await fileRef.makePublic()

      avatarUrl = `https://storage.googleapis.com/${bucket.name}/${fileName}`
    }

    // Update user in Firebase Auth
    const updateParams: Record<string, any> = {}

    if (displayName) updateParams.displayName = displayName

    if (Object.keys(updateParams).length > 0) {
      await auth.updateUser(userId!, updateParams)
    }

    // Update user in Firestore
    const updateData: Record<string, any> = {
      updatedAt: FieldValue.serverTimestamp(),
    }

    if (displayName) updateData.displayName = displayName
    if (phoneNumber) updateData.phoneNumber = phoneNumber
    if (bio) updateData.bio = bio
    if (avatarUrl) updateData.avatar = avatarUrl

    await db.collection("users").doc(userId!).update(updateData)

    res.json({
      message: "Profile updated successfully",
      ...(avatarUrl && { avatar: avatarUrl }),
    })
  } catch (error) {
    next(error)
  }
})

// Get user's listings
router.get("/listings", async (req, res, next) => {
  try {
    const userId = req.userId
    const { status } = req.query

    let query = db.collection("listings").where("sellerId", "==", userId)

    if (status) {
      query = query.where("status", "==", status)
    }

    // Order by creation date, newest first
    query = query.orderBy("createdAt", "desc")

    const snapshot = await query.get()

    const listings = []

    for (const doc of snapshot.docs) {
      const listing = {
        id: doc.id,
        ...doc.data(),
      }

      // Convert Firestore timestamps to ISO strings
      if (listing.createdAt) {
        listing.createdAt = listing.createdAt.toDate().toISOString()
      }

      if (listing.updatedAt) {
        listing.updatedAt = listing.updatedAt.toDate().toISOString()
      }

      listings.push(listing)
    }

    res.json(listings)
  } catch (error) {
    next(error)
  }
})

// Get user's transactions
router.get("/transactions", async (req, res, next) => {
  try {
    const userId = req.userId
    const { role = "all", status } = req.query

    let buyerQuery = db.collection("transactions").where("buyerId", "==", userId)
    let sellerQuery = db.collection("transactions").where("sellerId", "==", userId)

    if (status) {
      buyerQuery = buyerQuery.where("status", "==", status)
      sellerQuery = sellerQuery.where("status", "==", status)
    }

    // Order by creation date, newest first
    buyerQuery = buyerQuery.orderBy("createdAt", "desc")
    sellerQuery = sellerQuery.orderBy("createdAt", "desc")

    const transactions = []

    if (role === "buyer" || role === "all") {
      const buyerSnapshot = await buyerQuery.get()

      for (const doc of buyerSnapshot.docs) {
        const transaction = doc.data()

        // Convert Firestore timestamps to ISO strings
        if (transaction.createdAt) {
          transaction.createdAt = transaction.createdAt.toDate().toISOString()
        }

        if (transaction.updatedAt) {
          transaction.updatedAt = transaction.updatedAt.toDate().toISOString()
        }

        transactions.push({
          ...transaction,
          role: "buyer",
        })
      }
    }

    if (role === "seller" || role === "all") {
      const sellerSnapshot = await sellerQuery.get()

      for (const doc of sellerSnapshot.docs) {
        const transaction = doc.data()

        // Convert Firestore timestamps to ISO strings
        if (transaction.createdAt) {
          transaction.createdAt = transaction.createdAt.toDate().toISOString()
        }

        if (transaction.updatedAt) {
          transaction.updatedAt = transaction.updatedAt.toDate().toISOString()
        }

        transactions.push({
          ...transaction,
          role: "seller",
        })
      }
    }

    // Sort by createdAt
    transactions.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    })

    res.json(transactions)
  } catch (error) {
    next(error)
  }
})

// Get user's notifications
router.get("/notifications", async (req, res, next) => {
  try {
    const userId = req.userId
    const { read } = req.query

    let query = db.collection("notifications").where("userId", "==", userId)

    if (read === "true") {
      query = query.where("read", "==", true)
    } else if (read === "false") {
      query = query.where("read", "==", false)
    }

    // Order by creation date, newest first
    query = query.orderBy("createdAt", "desc")

    const snapshot = await query.get()

    const notifications = []

    for (const doc of snapshot.docs) {
      const notification = {
        id: doc.id,
        ...doc.data(),
      }

      // Convert Firestore timestamps to ISO strings
      if (notification.createdAt) {
        notification.createdAt = notification.createdAt.toDate().toISOString()
      }

      notifications.push(notification)
    }

    res.json(notifications)
  } catch (error) {
    next(error)
  }
})

// Mark notification as read
router.put("/notifications/:id/read", async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId

    // Check if notification exists and belongs to user
    const notificationDoc = await db.collection("notifications").doc(id).get()

    if (!notificationDoc.exists) {
      throw ApiError.notFound("Notification not found")
    }

    const notification = notificationDoc.data()

    if (notification?.userId !== userId) {
      throw ApiError.forbidden("You don't have permission to update this notification")
    }

    // Update notification
    await db.collection("notifications").doc(id).update({
      read: true,
    })

    res.json({ message: "Notification marked as read" })
  } catch (error) {
    next(error)
  }
})

// Mark all notifications as read
router.put("/notifications/read-all", async (req, res, next) => {
  try {
    const userId = req.userId

    // Get all unread notifications
    const snapshot = await db.collection("notifications").where("userId", "==", userId).where("read", "==", false).get()

    // Update each notification
    const batch = db.batch()

    snapshot.docs.forEach((doc) => {
      batch.update(doc.ref, { read: true })
    })

    await batch.commit()

    res.json({
      message: "All notifications marked as read",
      count: snapshot.size,
    })
  } catch (error) {
    next(error)
  }
})

// Admin routes

// Get all users (admin only)
router.get("/all", isAdmin, async (req, res, next) => {
  try {
    const { page = "1", limit = "20" } = req.query

    const pageNum = Number.parseInt(page as string)
    const limitNum = Number.parseInt(limit as string)
    const startAt = (pageNum - 1) * limitNum

    // Get total count
    const countSnapshot = await db.collection("users").count().get()
    const totalUsers = countSnapshot.data().count

    // Get paginated users
    const snapshot = await db.collection("users").orderBy("createdAt", "desc").limit(limitNum).offset(startAt).get()

    const users = []

    for (const doc of snapshot.docs) {
      const userData = doc.data()

      // Remove sensitive information
      delete userData.securityKey

      // Format timestamps
      if (userData.createdAt) {
        userData.createdAt = userData.createdAt.toDate().toISOString()
      }

      if (userData.updatedAt) {
        userData.updatedAt = userData.updatedAt.toDate().toISOString()
      }

      users.push({
        id: doc.id,
        ...userData,
      })
    }

    res.json({
      users,
      pagination: {
        total: totalUsers,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(totalUsers / limitNum),
      },
    })
  } catch (error) {
    next(error)
  }
})

// Set user as verified seller (admin only)
router.put("/:id/verify", isAdmin, async (req, res, next) => {
  try {
    const { id } = req.params

    // Check if user exists
    const userDoc = await db.collection("users").doc(id).get()

    if (!userDoc.exists) {
      throw ApiError.notFound("User not found")
    }

    // Update user in Firestore
    await db.collection("users").doc(id).update({
      isVerified: true,
      verifiedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    })

    // Set custom claim for verified seller
    await auth.setCustomUserClaims(id, { verifiedSeller: true })

    // Create notification for user
    await db.collection("notifications").add({
      userId: id,
      type: "account_verified",
      title: "Account Verified",
      message: "Your account has been verified as a seller",
      read: false,
      createdAt: FieldValue.serverTimestamp(),
    })

    res.json({ message: "User verified successfully" })
  } catch (error) {
    next(error)
  }
})

export default router
