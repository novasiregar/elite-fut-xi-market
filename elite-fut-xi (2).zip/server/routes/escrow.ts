import { Router } from "express"
import { EnhancedEscrowService, EscrowReleaseType } from "../services/enhanced-escrow-service"
import { ApiError } from "../middleware/errorHandler"
import { db } from "../config/firebase" // Import db from firebase config

const router = Router()

// Create escrow (typically called internally by transaction service)
router.post("/", async (req, res, next) => {
  try {
    const { transactionId, amount, sellerId } = req.body

    if (!transactionId || !amount || !sellerId) {
      throw ApiError.badRequest("Missing required fields")
    }

    const escrow = await EnhancedEscrowService.createEscrow(transactionId, amount, sellerId)

    res.status(201).json(escrow)
  } catch (error) {
    next(error)
  }
})

// Release escrow funds (buyer confirmation)
router.post("/:transactionId/release", async (req, res, next) => {
  try {
    const { transactionId } = req.params
    const userId = req.userId

    // Verify user is the buyer for this transaction
    const transactionDoc = await db.collection("transactions").doc(transactionId).get()

    if (!transactionDoc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = transactionDoc.data()

    if (transaction.buyerId !== userId) {
      throw ApiError.forbidden("Only the buyer can release escrow funds")
    }

    const result = await EnhancedEscrowService.releaseFunds(transactionId, EscrowReleaseType.BUYER_CONFIRMED)

    res.json(result)
  } catch (error) {
    next(error)
  }
})

// Admin route to resolve disputes
router.post("/:transactionId/resolve-dispute", async (req, res, next) => {
  try {
    const { transactionId } = req.params
    const { winningParty } = req.body
    const adminId = req.userId

    // Verify user is an admin
    const userDoc = await db.collection("users").doc(adminId).get()

    if (!userDoc.exists || !userDoc.data().isAdmin) {
      throw ApiError.forbidden("Only admins can resolve disputes")
    }

    if (winningParty !== "buyer" && winningParty !== "seller") {
      throw ApiError.badRequest("Winning party must be either 'buyer' or 'seller'")
    }

    const result = await EnhancedEscrowService.resolveDispute(transactionId, winningParty, adminId)

    res.json(result)
  } catch (error) {
    next(error)
  }
})

// Get escrow details
router.get("/:transactionId", async (req, res, next) => {
  try {
    const { transactionId } = req.params
    const userId = req.userId

    // Get escrow document
    const escrowDoc = await db.collection("escrows").doc(transactionId).get()

    if (!escrowDoc.exists) {
      throw ApiError.notFound("Escrow not found")
    }

    // Get transaction to verify user is buyer or seller
    const transactionDoc = await db.collection("transactions").doc(transactionId).get()

    if (!transactionDoc.exists) {
      throw ApiError.notFound("Transaction not found")
    }

    const transaction = transactionDoc.data()

    // Verify user is buyer or seller
    if (transaction.buyerId !== userId && transaction.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to view this escrow")
    }

    const escrow = escrowDoc.data()

    // Format timestamps
    if (escrow.createdAt) {
      escrow.createdAt = escrow.createdAt.toDate().toISOString()
    }
    if (escrow.releaseDate) {
      escrow.releaseDate = escrow.releaseDate.toDate().toISOString()
    }
    if (escrow.releasedAt) {
      escrow.releasedAt = escrow.releasedAt.toDate().toISOString()
    }
    if (escrow.lastUpdated) {
      escrow.lastUpdated = escrow.lastUpdated.toDate().toISOString()
    }

    res.json(escrow)
  } catch (error) {
    next(error)
  }
})

export default router
