import { Router } from "express"
import { db, storage } from "../index"
import { ApiError } from "../middleware/errorHandler"
import { isVerifiedSeller } from "../middleware/auth"
import { v4 as uuidv4 } from "uuid"
import multer from "multer"
import path from "path"
import { Timestamp, FieldValue } from "firebase-admin/firestore"

const router = Router()

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [".jpg", ".jpeg", ".png", ".mp4", ".webm"]
    const ext = path.extname(file.originalname).toLowerCase()

    if (allowedTypes.includes(ext)) {
      cb(null, true)
    } else {
      cb(new Error("Invalid file type. Only images and videos are allowed.") as any)
    }
  },
})

// Get all listings with pagination and filtering
router.get("/", async (req, res, next) => {
  try {
    const {
      page = "1",
      limit = "10",
      sort = "createdAt",
      order = "desc",
      minPrice,
      maxPrice,
      minRating,
      featured,
      verified,
      search,
      tags,
    } = req.query

    const pageNum = Number.parseInt(page as string)
    const limitNum = Number.parseInt(limit as string)
    const startAt = (pageNum - 1) * limitNum

    // Build query
    let query = db.collection("listings").where("status", "==", "active")

    // Apply filters
    if (minPrice) {
      query = query.where("price", ">=", Number.parseInt(minPrice as string))
    }

    if (maxPrice) {
      query = query.where("price", "<=", Number.parseInt(maxPrice as string))
    }

    if (minRating) {
      query = query.where("rating", ">=", Number.parseFloat(minRating as string))
    }

    if (featured === "true") {
      query = query.where("featured", "==", true)
    }

    if (verified === "true") {
      query = query.where("sellerVerified", "==", true)
    }

    if (tags) {
      const tagArray = (tags as string).split(",")
      query = query.where("tags", "array-contains-any", tagArray)
    }

    // Apply sorting
    query = query.orderBy(sort as string, order as "asc" | "desc")

    // Get total count for pagination
    const countSnapshot = await query.count().get()
    const totalItems = countSnapshot.data().count

    // Get paginated results
    const snapshot = await query.limit(limitNum).offset(startAt).get()

    const listings = []

    for (const doc of snapshot.docs) {
      const listing = {
        id: doc.id,
        ...doc.data(),
      }

      // Convert Firestore timestamps to ISO strings
      if (listing.createdAt instanceof Timestamp) {
        listing.createdAt = listing.createdAt.toDate().toISOString()
      }

      if (listing.updatedAt instanceof Timestamp) {
        listing.updatedAt = listing.updatedAt.toDate().toISOString()
      }

      listings.push(listing)
    }

    // If search query is provided, filter results client-side
    // (Firestore doesn't support full-text search natively)
    let filteredListings = listings
    if (search) {
      const searchLower = (search as string).toLowerCase()
      filteredListings = listings.filter(
        (listing) =>
          listing.title.toLowerCase().includes(searchLower) || listing.description.toLowerCase().includes(searchLower),
      )
    }

    res.json({
      listings: filteredListings,
      pagination: {
        total: totalItems,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(totalItems / limitNum),
      },
    })
  } catch (error) {
    next(error)
  }
})

// Get a single listing by ID
router.get("/:id", async (req, res, next) => {
  try {
    const { id } = req.params

    const doc = await db.collection("listings").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Listing not found")
    }

    const listing = {
      id: doc.id,
      ...doc.data(),
    }

    // Convert Firestore timestamps to ISO strings
    if (listing.createdAt instanceof Timestamp) {
      listing.createdAt = listing.createdAt.toDate().toISOString()
    }

    if (listing.updatedAt instanceof Timestamp) {
      listing.updatedAt = listing.updatedAt.toDate().toISOString()
    }

    // Increment view count
    await db
      .collection("listings")
      .doc(id)
      .update({
        viewCount: FieldValue.increment(1),
      })

    res.json(listing)
  } catch (error) {
    next(error)
  }
})

// Create a new listing
router.post("/", isVerifiedSeller, upload.array("media", 5), async (req, res, next) => {
  try {
    const userId = req.userId
    const { title, description, price, tags, accountDetails } = req.body

    if (!title || !description || !price) {
      throw ApiError.badRequest("Title, description, and price are required")
    }

    // Get user data to check verification status
    const userDoc = await db.collection("users").doc(userId!).get()
    const userData = userDoc.data()

    if (!userData) {
      throw ApiError.notFound("User not found")
    }

    // Upload media files
    const mediaUrls = []
    const files = req.files as Express.Multer.File[]

    if (files && files.length > 0) {
      for (const file of files) {
        const fileId = uuidv4()
        const fileExtension = path.extname(file.originalname)
        const fileName = `listings/${userId}/${fileId}${fileExtension}`

        const fileBuffer = file.buffer
        const fileType = file.mimetype

        // Upload to Firebase Storage
        const bucket = storage.bucket()
        const fileRef = bucket.file(fileName)

        await fileRef.save(fileBuffer, {
          metadata: {
            contentType: fileType,
          },
        })

        // Make file publicly accessible
        await fileRef.makePublic()

        const publicUrl = `https://storage.googleapis.com/${bucket.name}/${fileName}`

        mediaUrls.push({
          url: publicUrl,
          type: fileType.startsWith("image/") ? "image" : "video",
          fileName,
        })
      }
    }

    // Parse account details
    let parsedAccountDetails = {}
    try {
      parsedAccountDetails = JSON.parse(accountDetails)
    } catch (e) {
      parsedAccountDetails = accountDetails || {}
    }

    // Create listing document
    const listingData = {
      title,
      description,
      price: Number.parseInt(price),
      sellerId: userId,
      sellerName: userData.displayName,
      sellerVerified: userData.isVerified || false,
      media: mediaUrls,
      tags: tags ? tags.split(",") : [],
      status: "active",
      featured: false,
      accountDetails: parsedAccountDetails,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      viewCount: 0,
      favoriteCount: 0,
    }

    const docRef = await db.collection("listings").add(listingData)

    res.status(201).json({
      id: docRef.id,
      ...listingData,
    })
  } catch (error) {
    next(error)
  }
})

// Update a listing
router.put("/:id", isVerifiedSeller, async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId
    const { title, description, price, tags, accountDetails, status } = req.body

    // Check if listing exists and belongs to user
    const doc = await db.collection("listings").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Listing not found")
    }

    const listing = doc.data()

    if (listing?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to update this listing")
    }

    // Update listing
    const updateData: Record<string, any> = {
      updatedAt: FieldValue.serverTimestamp(),
    }

    if (title) updateData.title = title
    if (description) updateData.description = description
    if (price) updateData.price = Number.parseInt(price)
    if (tags) updateData.tags = tags.split(",")
    if (status) updateData.status = status

    if (accountDetails) {
      try {
        updateData.accountDetails = JSON.parse(accountDetails)
      } catch (e) {
        updateData.accountDetails = accountDetails
      }
    }

    await db.collection("listings").doc(id).update(updateData)

    res.json({ message: "Listing updated successfully" })
  } catch (error) {
    next(error)
  }
})

// Delete a listing
router.delete("/:id", isVerifiedSeller, async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId

    // Check if listing exists and belongs to user
    const doc = await db.collection("listings").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Listing not found")
    }

    const listing = doc.data()

    if (listing?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to delete this listing")
    }

    // Delete media files from storage
    if (listing?.media && listing.media.length > 0) {
      const bucket = storage.bucket()

      for (const media of listing.media) {
        if (media.fileName) {
          try {
            await bucket.file(media.fileName).delete()
          } catch (error) {
            console.error(`Failed to delete file: ${media.fileName}`, error)
          }
        }
      }
    }

    // Delete listing document
    await db.collection("listings").doc(id).delete()

    res.json({ message: "Listing deleted successfully" })
  } catch (error) {
    next(error)
  }
})

// Add media to a listing
router.post("/:id/media", isVerifiedSeller, upload.array("media", 5), async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.userId

    // Check if listing exists and belongs to user
    const doc = await db.collection("listings").doc(id).get()

    if (!doc.exists) {
      throw ApiError.notFound("Listing not found")
    }

    const listing = doc.data()

    if (listing?.sellerId !== userId) {
      throw ApiError.forbidden("You don't have permission to update this listing")
    }

    // Upload media files
    const mediaUrls = []
    const files = req.files as Express.Multer.File[]

    if (files && files.length > 0) {
      for (const file of files) {
        const fileId = uuidv4()
        const fileExtension = path.extname(file.originalname)
        const fileName = `listings/${userId}/${fileId}${fileExtension}`

        const fileBuffer = file.buffer
        const fileType = file.mimetype

        // Upload to Firebase Storage
        const bucket = storage.bucket()
        const fileRef = bucket.file(fileName)

        await fileRef.save(fileBuffer, {
          metadata: {
            contentType: fileType,
          },
        })

        // Make file publicly accessible
        await fileRef.makePublic()

        const publicUrl = `https://storage.googleapis.com/${bucket.name}/${fileName}`

        mediaUrls.push({
          url: publicUrl,
          type: fileType.startsWith("image/") ? "image" : "video",
          fileName,
        })
      }
    }

    // Update listing with new media
    await db
      .collection("listings")
      .doc(id)
      .update({
        media: FieldValue.arrayUnion(...mediaUrls),
        updatedAt: FieldValue.serverTimestamp(),
      })

    res.json({
      message: "Media added successfully",
      media: mediaUrls,
    })
  } catch (error) {
    next(error)
  }
})

export default router
