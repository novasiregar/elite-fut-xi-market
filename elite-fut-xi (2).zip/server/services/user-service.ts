import { db } from "../index"
import admin from "firebase-admin"
import { NotificationService, NotificationType } from "./notification-service"

export interface User {
  id: string
  email: string
  username: string
  displayName: string
  bio?: string
  avatar?: string
  phone?: string
  isVerified: boolean
  isSeller: boolean
  isAdmin: boolean
  balance: number
  rating: number
  ratingCount: number
  fcmTokens?: string[]
  preferences?: {
    notifications: {
      email: boolean
      push: boolean
      sms: boolean
    }
    privacy: {
      showEmail: boolean
      showPhone: boolean
    }
    theme: string
    language: string
  }
  stats?: {
    listingsCount: number
    salesCount: number
    purchasesCount: number
    totalSales: number
    totalPurchases: number
    joinedAt: Date
    lastActive: Date
  }
  createdAt: Date
  updatedAt: Date
}

export const UserService = {
  // Create a new user
  async createUser(userData: {
    email: string
    username: string
    displayName: string
    password: string
  }): Promise<User> {
    // Check if email or username already exists
    const emailExists = await this.getUserByEmail(userData.email)
    if (emailExists) {
      throw new Error("Email already in use")
    }

    const usernameExists = await this.getUserByUsername(userData.username)
    if (usernameExists) {
      throw new Error("Username already taken")
    }

    // Create Firebase auth user
    const userRecord = await admin.auth().createUser({
      email: userData.email,
      password: userData.password,
      displayName: userData.displayName,
    })

    // Create user document
    const user: User = {
      id: userRecord.uid,
      email: userData.email,
      username: userData.username,
      displayName: userData.displayName,
      isVerified: false,
      isSeller: false,
      isAdmin: false,
      balance: 0,
      rating: 0,
      ratingCount: 0,
      preferences: {
        notifications: {
          email: true,
          push: true,
          sms: false,
        },
        privacy: {
          showEmail: false,
          showPhone: false,
        },
        theme: "system",
        language: "en",
      },
      stats: {
        listingsCount: 0,
        salesCount: 0,
        purchasesCount: 0,
        totalSales: 0,
        totalPurchases: 0,
        joinedAt: new Date(),
        lastActive: new Date(),
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await db.collection("users").doc(user.id).set(user)

    return user
  },

  // Get user by ID
  async getUserById(userId: string): Promise<User | null> {
    const doc = await db.collection("users").doc(userId).get()

    if (!doc.exists) {
      return null
    }

    return doc.data() as User
  },

  // Get user by email
  async getUserByEmail(email: string): Promise<User | null> {
    const snapshot = await db.collection("users").where("email", "==", email).limit(1).get()

    if (snapshot.empty) {
      return null
    }

    return snapshot.docs[0].data() as User
  },

  // Get user by username
  async getUserByUsername(username: string): Promise<User | null> {
    const snapshot = await db.collection("users").where("username", "==", username).limit(1).get()

    if (snapshot.empty) {
      return null
    }

    return snapshot.docs[0].data() as User
  },

  // Update user profile
  async updateUserProfile(userId: string, updates: Partial<User>): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Check if username is being updated and is unique
    if (updates.username && updates.username !== user.username) {
      const usernameExists = await this.getUserByUsername(updates.username)
      if (usernameExists) {
        throw new Error("Username already taken")
      }
    }

    // Update user document
    const updatedUser = {
      ...user,
      ...updates,
      updatedAt: new Date(),
    }

    await db.collection("users").doc(userId).update(updatedUser)

    return updatedUser
  },

  // Update user balance
  async updateUserBalance(userId: string, amount: number): Promise<number> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Calculate new balance
    const newBalance = (user.balance || 0) + amount

    if (newBalance < 0) {
      throw new Error("Insufficient balance")
    }

    // Update user balance
    await db.collection("users").doc(userId).update({
      balance: newBalance,
      updatedAt: new Date(),
    })

    return newBalance
  },

  // Add FCM token for push notifications
  async addFcmToken(userId: string, token: string): Promise<void> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Add token if it doesn't exist
    const tokens = user.fcmTokens || []
    if (!tokens.includes(token)) {
      tokens.push(token)

      await db.collection("users").doc(userId).update({
        fcmTokens: tokens,
        updatedAt: new Date(),
      })
    }
  },

  // Remove FCM token
  async removeFcmToken(userId: string, token: string): Promise<void> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Remove token if it exists
    const tokens = user.fcmTokens || []
    const updatedTokens = tokens.filter((t) => t !== token)

    await db.collection("users").doc(userId).update({
      fcmTokens: updatedTokens,
      updatedAt: new Date(),
    })
  },

  // Update user preferences
  async updateUserPreferences(userId: string, preferences: Partial<User["preferences"]>): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Update preferences
    const updatedPreferences = {
      ...user.preferences,
      ...preferences,
    }

    await db.collection("users").doc(userId).update({
      preferences: updatedPreferences,
      updatedAt: new Date(),
    })

    return {
      ...user,
      preferences: updatedPreferences,
    }
  },

  // Update user stats
  async updateUserStats(userId: string, stats: Partial<User["stats"]>): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Update stats
    const updatedStats = {
      ...user.stats,
      ...stats,
      lastActive: new Date(),
    }

    await db.collection("users").doc(userId).update({
      stats: updatedStats,
      updatedAt: new Date(),
    })

    return {
      ...user,
      stats: updatedStats,
    }
  },

  // Verify user
  async verifyUser(userId: string): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Update verification status
    await db.collection("users").doc(userId).update({
      isVerified: true,
      updatedAt: new Date(),
    })

    // Send notification
    await NotificationService.createNotification({
      userId,
      type: NotificationType.ACCOUNT_VERIFIED,
      title: "Account Verified",
      message: "Your account has been verified! You now have access to all platform features.",
    })

    return {
      ...user,
      isVerified: true,
    }
  },

  // Enable seller mode
  async enableSellerMode(userId: string): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Update seller status
    await db.collection("users").doc(userId).update({
      isSeller: true,
      updatedAt: new Date(),
    })

    return {
      ...user,
      isSeller: true,
    }
  },

  // Update user rating
  async updateUserRating(userId: string, newRating: number): Promise<User> {
    const user = await this.getUserById(userId)

    if (!user) {
      throw new Error("User not found")
    }

    // Calculate new average rating
    const totalRating = user.rating * user.ratingCount + newRating
    const newRatingCount = user.ratingCount + 1
    const newAverageRating = totalRating / newRatingCount

    // Update rating
    await db.collection("users").doc(userId).update({
      rating: newAverageRating,
      ratingCount: newRatingCount,
      updatedAt: new Date(),
    })

    return {
      ...user,
      rating: newAverageRating,
      ratingCount: newRatingCount,
    }
  },

  // Search users
  async searchUsers(query: string, limit = 10): Promise<User[]> {
    // Search by username, displayName, or email
    const snapshot = await db
      .collection("users")
      .where("username", ">=", query)
      .where("username", "<=", query + "\uf8ff")
      .limit(limit)
      .get()

    const displayNameSnapshot = await db
      .collection("users")
      .where("displayName", ">=", query)
      .where("displayName", "<=", query + "\uf8ff")
      .limit(limit)
      .get()

    // Combine results and remove duplicates
    const results = new Map<string, User>()

    snapshot.docs.forEach((doc) => {
      results.set(doc.id, doc.data() as User)
    })

    displayNameSnapshot.docs.forEach((doc) => {
      if (!results.has(doc.id)) {
        results.set(doc.id, doc.data() as User)
      }
    })

    return Array.from(results.values()).slice(0, limit)
  },

  // Get top sellers
  async getTopSellers(limit = 10): Promise<User[]> {
    const snapshot = await db
      .collection("users")
      .where("isSeller", "==", true)
      .orderBy("rating", "desc")
      .limit(limit)
      .get()

    return snapshot.docs.map((doc) => doc.data() as User)
  },
}
