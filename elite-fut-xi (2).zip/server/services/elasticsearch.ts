import { Client } from "@elastic/elasticsearch"
import type { Listing } from "../models/listing"

// Initialize Elasticsearch client
const client = new Client({
  node: process.env.ELASTICSEARCH_URL,
  auth: {
    username: process.env.ELASTICSEARCH_USERNAME || "",
    password: process.env.ELASTICSEARCH_PASSWORD || "",
  },
})

const INDEX_NAME = "listings"

export const ElasticsearchService = {
  // Initialize index with proper mappings
  async initializeIndex() {
    const indexExists = await client.indices.exists({ index: INDEX_NAME })

    if (!indexExists) {
      await client.indices.create({
        index: INDEX_NAME,
        body: {
          settings: {
            analysis: {
              analyzer: {
                custom_analyzer: {
                  type: "custom",
                  tokenizer: "standard",
                  filter: ["lowercase", "asciifolding", "word_delimiter"],
                },
              },
            },
          },
          mappings: {
            properties: {
              title: {
                type: "text",
                analyzer: "custom_analyzer",
                fields: {
                  keyword: { type: "keyword" },
                },
              },
              description: { type: "text", analyzer: "custom_analyzer" },
              price: { type: "integer" },
              sellerId: { type: "keyword" },
              sellerName: { type: "text" },
              sellerVerified: { type: "boolean" },
              tags: { type: "keyword" },
              status: { type: "keyword" },
              featured: { type: "boolean" },
              createdAt: { type: "date" },
              updatedAt: { type: "date" },
              viewCount: { type: "integer" },
              favoriteCount: { type: "integer" },
              rating: { type: "float" },
              category: { type: "keyword" },
              accountDetails: {
                properties: {
                  level: { type: "integer" },
                  playerCount: { type: "integer" },
                  teamRating: { type: "integer" },
                  topPlayers: { type: "keyword" },
                },
              },
              media: {
                properties: {
                  url: { type: "keyword" },
                  type: { type: "keyword" },
                },
              },
            },
          },
        },
      })
      console.log("Elasticsearch index created")
    }
  },

  // Index a single listing
  async indexListing(listing: Listing) {
    await client.index({
      index: INDEX_NAME,
      id: listing.id,
      document: {
        ...listing,
        // Ensure dates are in ISO format
        createdAt: listing.createdAt instanceof Date ? listing.createdAt.toISOString() : listing.createdAt,
        updatedAt: listing.updatedAt instanceof Date ? listing.updatedAt.toISOString() : listing.updatedAt,
      },
    })
  },

  // Bulk index multiple listings
  async bulkIndexListings(listings: Listing[]) {
    const operations = listings.flatMap((listing) => [
      { index: { _index: INDEX_NAME, _id: listing.id } },
      {
        ...listing,
        createdAt: listing.createdAt instanceof Date ? listing.createdAt.toISOString() : listing.createdAt,
        updatedAt: listing.updatedAt instanceof Date ? listing.updatedAt.toISOString() : listing.updatedAt,
      },
    ])

    await client.bulk({ operations })
  },

  // Remove a listing from the index
  async removeListing(listingId: string) {
    await client.delete({
      index: INDEX_NAME,
      id: listingId,
    })
  },

  // Update a listing in the index
  async updateListing(listingId: string, updates: Partial<Listing>) {
    await client.update({
      index: INDEX_NAME,
      id: listingId,
      doc: updates,
    })
  },

  // Search listings with advanced query and filtering
  async searchListings(params: {
    query?: string
    filters?: any
    sort?: { field: string; order: string }
    page?: number
    limit?: number
  }) {
    const { query, filters = {}, sort, page = 1, limit = 10 } = params

    // Build query
    const must: any[] = []
    const filter: any[] = []

    // Text search
    if (query) {
      must.push({
        multi_match: {
          query,
          fields: ["title^3", "description^2", "sellerName", "tags", "accountDetails.topPlayers"],
          fuzziness: "AUTO",
        },
      })
    }

    // Only active listings
    filter.push({ term: { status: "active" } })

    // Apply filters
    if (filters.minPrice) {
      filter.push({ range: { price: { gte: filters.minPrice } } })
    }

    if (filters.maxPrice) {
      filter.push({ range: { price: { lte: filters.maxPrice } } })
    }

    if (filters.category && filters.category.length) {
      filter.push({ terms: { category: filters.category } })
    }

    if (filters.tags && filters.tags.length) {
      filter.push({ terms: { tags: filters.tags } })
    }

    if (filters.rating) {
      filter.push({ range: { rating: { gte: filters.rating } } })
    }

    if (filters.featured !== undefined) {
      filter.push({ term: { featured: filters.featured } })
    }

    if (filters.verified !== undefined) {
      filter.push({ term: { sellerVerified: filters.verified } })
    }

    // Build sort
    const sortOptions: any[] = []
    if (sort) {
      sortOptions.push({ [sort.field]: { order: sort.order } })
    } else {
      // Default sort by relevance (if query provided) or recency
      if (query) {
        sortOptions.push({ _score: { order: "desc" } })
      }
      sortOptions.push({ createdAt: { order: "desc" } })
    }

    // Execute search
    const response = await client.search({
      index: INDEX_NAME,
      body: {
        query: {
          bool: {
            must,
            filter,
          },
        },
        sort: sortOptions,
        from: (page - 1) * limit,
        size: limit,
        aggs: {
          price_range: {
            stats: {
              field: "price",
            },
          },
          categories: {
            terms: {
              field: "category",
              size: 20,
            },
          },
          tags: {
            terms: {
              field: "tags",
              size: 30,
            },
          },
        },
      },
    })

    // Format response
    const hits = response.hits.hits
    const total = response.hits.total as { value: number }

    return {
      results: hits.map((hit) => ({
        ...hit._source,
        id: hit._id,
        score: hit._score,
      })) as Listing[],
      total: total.value,
      page,
      totalPages: Math.ceil(total.value / limit),
      aggregations: {
        priceRange: {
          min: response.aggregations?.price_range.min,
          max: response.aggregations?.price_range.max,
        },
        categories: response.aggregations?.categories.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
        tags: response.aggregations?.tags.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
      },
    }
  },

  // Get search suggestions
  async getSuggestions(query: string) {
    const response = await client.search({
      index: INDEX_NAME,
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              {
                multi_match: {
                  query,
                  fields: ["title", "tags", "category", "accountDetails.topPlayers"],
                  fuzziness: "AUTO",
                },
              },
              { term: { status: "active" } },
            ],
          },
        },
        aggs: {
          title_suggestions: {
            terms: {
              field: "title.keyword",
              size: 5,
              order: { _count: "desc" },
            },
          },
          category_suggestions: {
            terms: {
              field: "category",
              size: 3,
            },
          },
          tag_suggestions: {
            terms: {
              field: "tags",
              size: 5,
            },
          },
          player_suggestions: {
            terms: {
              field: "accountDetails.topPlayers",
              size: 5,
            },
          },
        },
      },
    })

    const suggestions: Array<{ text: string; type: string; count: number }> = []

    // Process title suggestions
    response.aggregations?.title_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "query",
        count: bucket.doc_count,
      })
    })

    // Process category suggestions
    response.aggregations?.category_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "category",
        count: bucket.doc_count,
      })
    })

    // Process tag suggestions
    response.aggregations?.tag_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "tag",
        count: bucket.doc_count,
      })
    })

    // Process player suggestions
    response.aggregations?.player_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "player",
        count: bucket.doc_count,
      })
    })

    return suggestions
  },

  // Get similar listings based on a listing ID
  async getSimilarListings(listingId: string, limit = 6) {
    // First get the source listing
    const listing = await client.get({
      index: INDEX_NAME,
      id: listingId,
    })

    if (!listing.found) {
      throw new Error("Listing not found")
    }

    const source = listing._source as Listing

    // Find similar listings based on title, tags, and category
    const response = await client.search({
      index: INDEX_NAME,
      body: {
        query: {
          bool: {
            must: [
              {
                more_like_this: {
                  fields: ["title", "description", "tags", "category", "accountDetails.topPlayers"],
                  like: [
                    {
                      _index: INDEX_NAME,
                      _id: listingId,
                    },
                  ],
                  min_term_freq: 1,
                  max_query_terms: 12,
                  min_doc_freq: 1,
                },
              },
              { term: { status: "active" } },
            ],
            must_not: [{ term: { _id: listingId } }],
          },
        },
        size: limit,
      },
    })

    return response.hits.hits.map((hit) => ({
      ...hit._source,
      id: hit._id,
    })) as Listing[]
  },
}
