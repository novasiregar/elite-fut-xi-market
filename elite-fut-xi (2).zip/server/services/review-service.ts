import { db } from "../index"
import { v4 as uuidv4 } from "uuid"
import { UserService } from "./user-service"
import { NotificationService, NotificationType } from "./notification-service"

export interface Review {
  id: string
  transactionId: string
  reviewerId: string
  targetId: string
  listingId: string
  rating: number
  comment: string
  isPublic: boolean
  createdAt: Date
  updatedAt: Date
}

export const ReviewService = {
  // Create a new review
  async createReview(reviewData: {
    transactionId: string
    reviewerId: string
    targetId: string
    listingId: string
    rating: number
    comment: string
    isPublic: boolean
  }): Promise<Review> {
    // Validate rating
    if (reviewData.rating < 1 || reviewData.rating > 5) {
      throw new Error("Rating must be between 1 and 5")
    }

    // Check if review already exists
    const existingReview = await this.getReviewByTransactionAndReviewer(reviewData.transactionId, reviewData.reviewerId)

    if (existingReview) {
      throw new Error("You have already reviewed this transaction")
    }

    // Create review
    const review: Review = {
      id: uuidv4(),
      ...reviewData,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await db.collection("reviews").doc(review.id).set(review)

    // Update user rating
    await UserService.updateUserRating(reviewData.targetId, reviewData.rating)

    // Send notification
    await NotificationService.createNotification({
      userId: reviewData.targetId,
      type: NotificationType.SYSTEM,
      title: "New Review",
      message: `You've received a ${reviewData.rating}-star review.`,
      data: { reviewId: review.id, transactionId: reviewData.transactionId },
    })

    return review
  },

  // Get review by ID
  async getReviewById(reviewId: string): Promise<Review | null> {
    const doc = await db.collection("reviews").doc(reviewId).get()

    if (!doc.exists) {
      return null
    }

    return doc.data() as Review
  },

  // Get review by transaction and reviewer
  async getReviewByTransactionAndReviewer(transactionId: string, reviewerId: string): Promise<Review | null> {
    const snapshot = await db
      .collection("reviews")
      .where("transactionId", "==", transactionId)
      .where("reviewerId", "==", reviewerId)
      .limit(1)
      .get()

    if (snapshot.empty) {
      return null
    }

    return snapshot.docs[0].data() as Review
  },

  // Get reviews for a user
  async getUserReviews(userId: string, limit = 10, offset = 0): Promise<Review[]> {
    const snapshot = await db
      .collection("reviews")
      .where("targetId", "==", userId)
      .where("isPublic", "==", true)
      .orderBy("createdAt", "desc")
      .limit(limit)
      .offset(offset)
      .get()

    return snapshot.docs.map((doc) => doc.data() as Review)
  },

  // Get reviews by a user
  async getReviewsByUser(userId: string, limit = 10, offset = 0): Promise<Review[]> {
    const snapshot = await db
      .collection("reviews")
      .where("reviewerId", "==", userId)
      .orderBy("createdAt", "desc")
      .limit(limit)
      .offset(offset)
      .get()

    return snapshot.docs.map((doc) => doc.data() as Review)
  },

  // Update a review
  async updateReview(reviewId: string, updates: Partial<Review>): Promise<Review> {
    const review = await this.getReviewById(reviewId)

    if (!review) {
      throw new Error("Review not found")
    }

    // Only allow updating comment and isPublic
    const allowedUpdates: Partial<Review> = {}

    if (updates.comment !== undefined) {
      allowedUpdates.comment = updates.comment
    }

    if (updates.isPublic !== undefined) {
      allowedUpdates.isPublic = updates.isPublic
    }

    // Update review
    const updatedReview = {
      ...review,
      ...allowedUpdates,
      updatedAt: new Date(),
    }

    await db.collection("reviews").doc(reviewId).update(updatedReview)

    return updatedReview
  },

  // Delete a review
  async deleteReview(reviewId: string): Promise<void> {
    const review = await this.getReviewById(reviewId)

    if (!review) {
      throw new Error("Review not found")
    }

    await db.collection("reviews").doc(reviewId).delete()

    // Recalculate user rating
    // This is a simplified approach - in a real app, you'd need to recalculate the average
    const userReviews = await this.getUserReviews(review.targetId, 100)

    if (userReviews.length > 0) {
      const totalRating = userReviews.reduce((sum, r) => sum + r.rating, 0)
      const averageRating = totalRating / userReviews.length

      await db.collection("users").doc(review.targetId).update({
        rating: averageRating,
        ratingCount: userReviews.length,
      })
    } else {
      // No reviews left
      await db.collection("users").doc(review.targetId).update({
        rating: 0,
        ratingCount: 0,
      })
    }
  },

  // Get review statistics for a user
  async getUserReviewStats(userId: string): Promise<{
    averageRating: number
    totalReviews: number
    ratingDistribution: Record<number, number>
  }> {
    const snapshot = await db.collection("reviews").where("targetId", "==", userId).where("isPublic", "==", true).get()

    const reviews = snapshot.docs.map((doc) => doc.data() as Review)

    if (reviews.length === 0) {
      return {
        averageRating: 0,
        totalReviews: 0,
        ratingDistribution: {
          1: 0,
          2: 0,
          3: 0,
          4: 0,
          5: 0,
        },
      }
    }

    // Calculate average rating
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0)
    const averageRating = totalRating / reviews.length

    // Calculate rating distribution
    const ratingDistribution: Record<number, number> = {
      1: 0,
      2: 0,
      3: 0,
      4: 0,
      5: 0,
    }

    reviews.forEach((review) => {
      ratingDistribution[review.rating]++
    })

    return {
      averageRating,
      totalReviews: reviews.length,
      ratingDistribution,
    }
  },
}
