import { ElasticsearchService } from "./elasticsearch"
import { RedisCacheService } from "./redis-cache"
import { db } from "../index"
import { v4 as uuidv4 } from "uuid"

// Unified search service that combines functionality from multiple search-related services
export class SearchService {
  // Cache TTL in seconds
  private static CACHE_TTL = {
    searchResults: 300, // 5 minutes
    suggestions: 600, // 10 minutes
    savedSearches: 3600, // 1 hour
  }

  /**
   * Search listings with advanced filtering and caching
   */
  static async searchListings(params: {
    query?: string
    filters?: any
    sort?: { field: string; order: string }
    page?: number
    limit?: number
    userId?: string | null
  }) {
    const { query, filters = {}, sort, page = 1, limit = 10, userId = null } = params

    // Generate cache key based on search parameters
    const cacheKey = `search:${JSON.stringify({ query, filters, sort, page, limit })}`

    // Try to get from cache first
    const cachedResults = await RedisCacheService.get(cacheKey)
    if (cachedResults) {
      return JSON.parse(cachedResults)
    }

    // Generate search ID for analytics
    const searchId = uuidv4()

    // Execute search
    const results = await ElasticsearchService.searchListings({
      query,
      filters,
      sort,
      page,
      limit,
      userId,
      searchId,
    })

    // Record search for analytics if user is logged in
    if (userId) {
      await this.recordSearch({
        userId,
        searchId,
        query: query || "",
        filters,
        resultCount: results.total,
        timestamp: new Date(),
      })
    }

    // Cache results
    await RedisCacheService.set(cacheKey, JSON.stringify(results), this.CACHE_TTL.searchResults)

    return results
  }

  /**
   * Get search suggestions
   */
  static async getSuggestions(query: string, userId: string | null = null) {
    if (!query || query.length < 2) {
      return []
    }

    // Generate cache key
    const cacheKey = `suggestions:${query.toLowerCase()}`

    // Try to get from cache first
    const cachedSuggestions = await RedisCacheService.get(cacheKey)
    if (cachedSuggestions) {
      return JSON.parse(cachedSuggestions)
    }

    // Get suggestions from Elasticsearch
    const suggestions = await ElasticsearchService.getSuggestions(query, userId)

    // Cache suggestions
    await RedisCacheService.set(cacheKey, JSON.stringify(suggestions), this.CACHE_TTL.suggestions)

    return suggestions
  }

  /**
   * Record search for analytics
   */
  static async recordSearch(searchData: {
    userId: string
    searchId: string
    query: string
    filters: any
    resultCount: number
    timestamp: Date
  }) {
    try {
      await db.collection("searchAnalytics").add(searchData)
    } catch (error) {
      console.error("Error recording search:", error)
    }
  }

  /**
   * Get user's saved searches
   */
  static async getSavedSearches(userId: string) {
    try {
      const snapshot = await db
        .collection("savedSearches")
        .where("userId", "==", userId)
        .orderBy("createdAt", "desc")
        .get()

      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
    } catch (error) {
      console.error("Error getting saved searches:", error)
      return []
    }
  }

  /**
   * Save a search
   */
  static async saveSearch(searchData: {
    userId: string
    name: string
    query: string
    filters: any
    notificationsEnabled: boolean
  }) {
    try {
      const { userId, name, query, filters, notificationsEnabled } = searchData

      const docRef = await db.collection("savedSearches").add({
        userId,
        name,
        query,
        filters,
        notificationsEnabled,
        createdAt: new Date(),
        lastRunAt: new Date(),
        lastResultCount: 0,
      })

      return {
        id: docRef.id,
        ...searchData,
        createdAt: new Date(),
        lastRunAt: new Date(),
        lastResultCount: 0,
      }
    } catch (error) {
      console.error("Error saving search:", error)
      throw error
    }
  }

  /**
   * Delete a saved search
   */
  static async deleteSavedSearch(searchId: string, userId: string) {
    try {
      // Verify ownership
      const searchDoc = await db.collection("savedSearches").doc(searchId).get()

      if (!searchDoc.exists || searchDoc.data()?.userId !== userId) {
        throw new Error("Search not found or unauthorized")
      }

      await db.collection("savedSearches").doc(searchId).delete()
      return { success: true }
    } catch (error) {
      console.error("Error deleting saved search:", error)
      throw error
    }
  }

  /**
   * Update saved search notification settings
   */
  static async updateSearchNotifications(searchId: string, userId: string, enabled: boolean) {
    try {
      // Verify ownership
      const searchDoc = await db.collection("savedSearches").doc(searchId).get()

      if (!searchDoc.exists || searchDoc.data()?.userId !== userId) {
        throw new Error("Search not found or unauthorized")
      }

      await db.collection("savedSearches").doc(searchId).update({
        notificationsEnabled: enabled,
      })

      return { success: true, notificationsEnabled: enabled }
    } catch (error) {
      console.error("Error updating search notifications:", error)
      throw error
    }
  }

  /**
   * Run saved searches to check for new listings
   */
  static async runSavedSearches() {
    try {
      // Get all saved searches with notifications enabled
      const snapshot = await db.collection("savedSearches").where("notificationsEnabled", "==", true).get()

      const searches = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      for (const search of searches) {
        await this.checkForNewListings(search)
      }

      return { success: true, processedCount: searches.length }
    } catch (error) {
      console.error("Error running saved searches:", error)
      throw error
    }
  }

  /**
   * Check for new listings for a saved search
   */
  private static async checkForNewListings(search: any) {
    try {
      // Get the last run timestamp
      const lastRunAt = search.lastRunAt?.toDate() || new Date(0)

      // Search for listings created after the last run
      const results = await ElasticsearchService.searchListings({
        query: search.query,
        filters: {
          ...search.filters,
          createdAfter: lastRunAt,
        },
        limit: 10,
      })

      // If new listings found, send notification
      if (results.results.length > 0) {
        await this.sendNewListingsNotification(search, results.results)
      }

      // Update last run timestamp and result count
      await db.collection("savedSearches").doc(search.id).update({
        lastRunAt: new Date(),
        lastResultCount: results.total,
      })

      return { success: true, newListingsCount: results.results.length }
    } catch (error) {
      console.error(`Error checking for new listings for search ${search.id}:`, error)
      return { success: false, error }
    }
  }

  /**
   * Send notification for new listings
   */
  private static async sendNewListingsNotification(search: any, newListings: any[]) {
    try {
      // Create notification
      await db.collection("notifications").add({
        userId: search.userId,
        type: "new_listings",
        title: `New listings for "${search.name}"`,
        message: `Found ${newListings.length} new listings matching your saved search.`,
        data: {
          searchId: search.id,
          searchName: search.name,
          listingCount: newListings.length,
          previewListings: newListings.slice(0, 3).map((listing) => ({
            id: listing.id,
            title: listing.title,
            price: listing.price,
            image: listing.media?.[0]?.url,
          })),
        },
        read: false,
        createdAt: new Date(),
      })

      return { success: true }
    } catch (error) {
      console.error("Error sending new listings notification:", error)
      return { success: false, error }
    }
  }
}
