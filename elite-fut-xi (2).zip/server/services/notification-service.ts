import { db } from "../index"
import admin from "firebase-admin"
import { UserService } from "./user-service"

export interface Notification {
  id?: string
  userId: string
  type: NotificationType
  title: string
  message: string
  data?: any
  read: boolean
  createdAt: Date
}

export enum NotificationType {
  NEW_MESSAGE = "new_message",
  LISTING_SOLD = "listing_sold",
  PRICE_DROP = "price_drop",
  OFFER_RECEIVED = "offer_received",
  OFFER_ACCEPTED = "offer_accepted",
  OFFER_REJECTED = "offer_rejected",
  PAYMENT_RECEIVED = "payment_received",
  LISTING_EXPIRED = "listing_expired",
  ACCOUNT_VERIFIED = "account_verified",
  SYSTEM = "system",
}

export const NotificationService = {
  // Create a new notification
  async createNotification(notification: Omit<Notification, "id" | "createdAt" | "read">): Promise<string> {
    const notificationData: Notification = {
      ...notification,
      read: false,
      createdAt: new Date(),
    }

    const docRef = await db.collection("notifications").add(notificationData)

    // Send push notification if user has FCM token
    try {
      const user = await UserService.getUserById(notification.userId)
      if (user && user.fcmTokens && user.fcmTokens.length > 0) {
        await this.sendPushNotification(user.fcmTokens, notification.title, notification.message, notification.data)
      }
    } catch (error) {
      console.error("Error sending push notification:", error)
    }

    return docRef.id
  },

  // Get notifications for a user
  async getUserNotifications(userId: string, limit = 20, offset = 0): Promise<Notification[]> {
    const snapshot = await db
      .collection("notifications")
      .where("userId", "==", userId)
      .orderBy("createdAt", "desc")
      .limit(limit)
      .offset(offset)
      .get()

    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Notification[]
  },

  // Get unread notification count
  async getUnreadCount(userId: string): Promise<number> {
    const snapshot = await db
      .collection("notifications")
      .where("userId", "==", userId)
      .where("read", "==", false)
      .count()
      .get()

    return snapshot.data().count
  },

  // Mark notification as read
  async markAsRead(notificationId: string): Promise<void> {
    await db.collection("notifications").doc(notificationId).update({
      read: true,
    })
  },

  // Mark all notifications as read
  async markAllAsRead(userId: string): Promise<void> {
    const batch = db.batch()
    const snapshot = await db.collection("notifications").where("userId", "==", userId).where("read", "==", false).get()

    snapshot.docs.forEach((doc) => {
      batch.update(doc.ref, { read: true })
    })

    await batch.commit()
  },

  // Delete a notification
  async deleteNotification(notificationId: string): Promise<void> {
    await db.collection("notifications").doc(notificationId).delete()
  },

  // Send push notification
  async sendPushNotification(tokens: string[], title: string, body: string, data: any = {}): Promise<void> {
    const message: admin.messaging.MulticastMessage = {
      tokens,
      notification: {
        title,
        body,
      },
      data: data ? JSON.parse(JSON.stringify(data)) : {},
      android: {
        priority: "high",
        notification: {
          sound: "default",
          clickAction: "FLUTTER_NOTIFICATION_CLICK",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
          },
        },
      },
      webpush: {
        headers: {
          Urgency: "high",
        },
        notification: {
          icon: "/icons/icon-192x192.png",
        },
      },
    }

    try {
      const response = await admin.messaging().sendMulticast(message)
      console.log(`${response.successCount} messages were sent successfully`)
    } catch (error) {
      console.error("Error sending push notification:", error)
    }
  },
}
