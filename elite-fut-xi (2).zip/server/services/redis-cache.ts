import { createClient } from "redis"

// Initialize Redis client
const redisClient = createClient({
  url: process.env.REDIS_URL,
  socket: {
    reconnectStrategy: (retries) => Math.min(retries * 50, 1000),
  },
})

redisClient.on("error", (err) => console.error("Redis Client Error", err))
redisClient.connect().catch(console.error)

// Cache TTL in seconds
const CACHE_TTL = {
  SEARCH_RESULTS: 60 * 5, // 5 minutes
  SUGGESTIONS: 60 * 10, // 10 minutes
  SIMILAR_LISTINGS: 60 * 15, // 15 minutes
  POPULAR_SEARCHES: 60 * 30, // 30 minutes
  USER_PREFERENCES: 60 * 60 * 24, // 24 hours
}

export const RedisCacheService = {
  // Set cache with expiration
  async set(key: string, value: any, ttl = 300): Promise<void> {
    try {
      await redisClient.set(key, JSON.stringify(value), { EX: ttl })
    } catch (error) {
      console.error("Redis set error:", error)
      // Fail gracefully - don't throw error if cache fails
    }
  },

  // Get from cache
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await redisClient.get(key)
      return value ? JSON.parse(value) as T : null
    } catch (error) {
      console.error("Redis get error:", error)
      return null
    }
  },

  // Delete from cache
  async del(key: string): Promise<void> {
    try {
      await redisClient.del(key)
    } catch (error) {
      console.error("Redis del error:", error)
    }
  },

  // Delete multiple keys by pattern
  async delByPattern(pattern: string): Promise<void> {
    try {
      const keys = await redisClient.keys(pattern)
      if (keys.length > 0) {
        await redisClient.del(keys)
      }
    } catch (error) {
      console.error("Redis delByPattern error:", error)
    }
  },

  // Cache search results
  async cacheSearchResults(
    query: string | null,
    filters: any,
    sort: any,
    page: number,
    limit: number,
    results: any
  ): Promise<void> {
    const cacheKey = this.generateSearchCacheKey(query, filters, sort, page, limit)
    await this.set(cacheKey, results, CACHE_TTL.SEARCH_RESULTS)
  },

  // Get cached search results
  async getCachedSearchResults(
    query: string | null,
    filters: any,
    sort: any,
    page: number,
    limit: number
  ): Promise<any | null> {
    const cacheKey = this.generateSearchCacheKey(query, filters, sort, page, limit)
    return await this.get(cacheKey)
  },

  // Cache search suggestions
  async cacheSuggestions(query: string, suggestions: any): Promise<void> {
    const cacheKey = `suggestions:${query.toLowerCase()}`
    await this.set(cacheKey, suggestions, CACHE_TTL.SUGGESTIONS)
  },

  // Get cached suggestions
  async getCachedSuggestions(query: string): Promise<any | null> {
    const cacheKey = `suggestions:${query.toLowerCase()}`
    return await this.get(cacheKey)
  },

  // Cache similar listings
  async cacheSimilarListings(listingId: string, limit: number, results: any): Promise<void> {
    const cacheKey = `similar:${listingId}:${limit}`
    await this.set(cacheKey, results, CACHE_TTL.SIMILAR_LISTINGS)
  },

  // Get cached similar listings
  async getCachedSimilarListings(listingId: string, limit: number): Promise<any | null> {
    const cacheKey = `similar:${listingId}:${limit}`
    return await this.get(cacheKey)
  },

  // Cache popular searches
  async cachePopularSearches(days: number, limit: number, results: any): Promise<void> {
    const cacheKey = `popular_searches:${days}:${limit}`
    await this.set(cacheKey, results, CACHE_TTL.POPULAR_SEARCHES)
  },

  // Get cached popular searches
  async getCachedPopularSearches(days: number, limit: number): Promise<any | null> {
    const cacheKey = `popular_searches:${days}:${limit}`
    return await this.get(cacheKey)
  },

  // Cache user preferences
  async cacheUserPreferences(userId: string, preferences: any): Promise<void> {
    const cacheKey = `user_preferences:${userId}`
    await this.set(cacheKey, preferences, CACHE_TTL.USER_PREFERENCES)
  },

  // Get cached user preferences
  async getCachedUserPreferences(userId: string): Promise<any | null> {
    const cacheKey = `user_preferences:${userId}`
    return await this.get(cacheKey)
  },

  // Invalidate listing-related caches when a listing is updated
  async invalidateListingCaches(listingId: string): Promise<void> {
    // Invalidate similar listings cache
    await this.delByPattern(`similar:${listingId}:*`)
    
    // Invalidate search results cache (conservatively)
    await this.delByPattern(`search:*`)
  },

  // Invalidate user-related caches when user preferences change
  async invalidateUserCaches(userId: string): Promise<void> {
    await this.del(`user_preferences:${userId}`)
  },

  // Generate a cache key for search results
  generateSearchCacheKey(
    query: string | null,
    filters: any,
    sort: any,
    page: number,
    limit: number
  ): string {
    // Create a deterministic string representation of filters and sort
    const filtersStr = JSON.stringify(filters || {})
    const sortStr = JSON.stringify(sort || {})
    
    // Create a hash of the search parameters
    const searchHash = this.hashCode(`${query || ""}|${filtersStr}|${sortStr}|${page}|${limit}`)
    
    return `search:${searchHash}`
  },

  // Simple string hash function
  private hashCode(str: string): string {
    let hash = 0
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i)
      hash = (hash << 5) - hash + char
      hash = hash & hash // Convert to 32bit integer
    }
    return hash.toString(16) // Convert to hex
  },

  // Check if Redis is connected
  async isConnected(): Promise<boolean> {
    try {
      await redisClient.ping()
      return true
    } catch (error) {
      return false
    }
  },
}
