import { EnhancedElasticsearchService } from "./elasticsearch-enhanced"
import { RedisCacheService } from "./redis-cache"
import { SearchAnalyticsService } from "./searchAnalytics"

export const CachedSearchService = {
  // Search listings with caching
  async searchListings(params: {
    query?: string
    filters?: any
    sort?: { field: string; order: string }
    page?: number
    limit?: number
    userId?: string | null
    searchId?: string
    bypassCache?: boolean
  }) {
    const {
      query,
      filters = {},
      sort,
      page = 1,
      limit = 10,
      userId = null,
      searchId = null,
      bypassCache = false,
    } = params

    // Try to get from cache if not bypassing
    if (!bypassCache) {
      const cachedResults = await RedisCacheService.getCachedSearchResults(query || null, filters, sort, page, limit)
      if (cachedResults) {
        console.log("Cache hit for search results")
        return cachedResults
      }
    }

    // Get user preferences if userId is provided
    let userPreferences = null
    if (userId) {
      // Try to get from cache first
      userPreferences = await RedisCacheService.getCachedUserPreferences(userId)

      if (!userPreferences) {
        userPreferences = await SearchAnalyticsService.getUserPreferences(userId)

        // Cache user preferences
        if (userPreferences) {
          await RedisCacheService.cacheUserPreferences(userId, userPreferences)
        }
      }
    }

    // Perform search with Elasticsearch
    const results = await EnhancedElasticsearchService.searchListings({
      query,
      filters,
      sort,
      page,
      limit,
      userId,
      searchId,
      userPreferences,
    })

    // Cache results
    await RedisCacheService.cacheSearchResults(query || null, filters, sort, page, limit, results)

    return results
  },

  // Get search suggestions with caching
  async getSuggestions(query: string, userId: string | null = null) {
    // Try to get from cache
    const cachedSuggestions = await RedisCacheService.getCachedSuggestions(query)
    if (cachedSuggestions) {
      console.log("Cache hit for suggestions")
      return cachedSuggestions
    }

    // Get from Elasticsearch
    const suggestions = await EnhancedElasticsearchService.getSuggestions(query, userId)

    // Cache suggestions
    await RedisCacheService.cacheSuggestions(query, suggestions)

    return suggestions
  },

  // Get similar listings with caching
  async getSimilarListings(listingId: string, limit = 6, userId: string | null = null) {
    // Try to get from cache
    const cachedSimilar = await RedisCacheService.getCachedSimilarListings(listingId, limit)
    if (cachedSimilar) {
      console.log("Cache hit for similar listings")
      return cachedSimilar
    }

    // Get from Elasticsearch
    const similarListings = await EnhancedElasticsearchService.getSimilarListings(listingId, limit, userId)

    // Cache similar listings
    await RedisCacheService.cacheSimilarListings(listingId, limit, similarListings)

    return similarListings
  },

  // Invalidate caches when a listing is updated
  async invalidateListingCaches(listingId: string) {
    await RedisCacheService.invalidateListingCaches(listingId)
  },

  // Invalidate user caches when preferences change
  async invalidateUserCaches(userId: string) {
    await RedisCacheService.invalidateUserCaches(userId)
  },

  // Get popular searches with caching
  async getPopularSearches(days = 7, limit = 10) {
    // Try to get from cache
    const cachedPopular = await RedisCacheService.getCachedPopularSearches(days, limit)
    if (cachedPopular) {
      console.log("Cache hit for popular searches")
      return cachedPopular
    }

    // Get from analytics service
    const popularSearches = await SearchAnalyticsService.getPopularSearches(days, limit)

    // Cache popular searches
    await RedisCacheService.cachePopularSearches(days, limit, popularSearches)

    return popularSearches
  },
}
