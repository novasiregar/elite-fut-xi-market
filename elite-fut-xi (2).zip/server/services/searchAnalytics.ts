import { db } from "../index"
import { RedisCacheService } from "./redis-cache"

export interface SearchEvent {
  userId: string | null
  searchId: string
  query: string
  filters: any
  timestamp: Date
  resultCount: number
  source: "text" | "visual" | "voice" | "recommendation"
  sessionId?: string
  deviceInfo?: {
    type: string
    browser: string
    os: string
  }
  location?: {
    country?: string
    region?: string
  }
}

export interface SearchClickEvent {
  userId: string | null
  searchId: string
  listingId: string
  position: number
  timestamp: Date
  sessionId?: string
  timeToClick?: number // Time in ms from search to click
}

export interface SearchResultsEvent {
  searchId: string
  userId: string | null
  resultIds: string[]
  scores: number[]
  total: number
  timestamp?: Date
}

export interface SearchConversionEvent {
  userId: string | null
  searchId: string
  listingId: string
  conversionType: "message" | "favorite" | "purchase"
  timestamp: Date
  value?: number
}

export interface UserSearchPreferences {
  categories: string[]
  tags: string[]
  players: string[]
  priceRange: {
    min: number
    max: number
  }
  platforms: string[]
}

export const SearchAnalyticsService = {
  // Record a search event
  async recordSearch(event: SearchEvent): Promise<string> {
    const searchRef = await db.collection("searchAnalytics").add({
      ...event,
      timestamp: event.timestamp || new Date(),
    })

    return searchRef.id
  },

  // Record search results
  async recordSearchResults(event: SearchResultsEvent): Promise<void> {
    await db.collection("searchResultsAnalytics").add({
      ...event,
      timestamp: event.timestamp || new Date(),
    })
  },

  // Record a click on search results
  async recordClick(event: SearchClickEvent): Promise<void> {
    await db.collection("searchClickAnalytics").add({
      ...event,
      timestamp: event.timestamp || new Date(),
    })
  },

  // Record a conversion from search
  async recordConversion(event: SearchConversionEvent): Promise<void> {
    await db.collection("searchConversionAnalytics").add({
      ...event,
      timestamp: event.timestamp || new Date(),
    })
  },

  // Get popular searches in the last N days
  async getPopularSearches(days = 7, limit = 10): Promise<any[]> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const snapshot = await db.collection("searchAnalytics").where("timestamp", ">=", startDate).get()

    const searches = snapshot.docs.map((doc) => doc.data())

    // Group by query and count
    const grouped = searches.reduce((acc, search) => {
      const query = search.query
      if (!query) return acc

      if (!acc[query]) {
        acc[query] = { query, count: 0 }
      }

      acc[query].count++
      return acc
    }, {})

    // Convert to array and sort
    return Object.values(grouped)
      .sort((a: any, b: any) => b.count - a.count)
      .slice(0, limit)
  },

  // Get search conversion rate (searches that led to clicks)
  async getSearchConversionRate(days = 7): Promise<number> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const searchesSnapshot = await db.collection("searchAnalytics").where("timestamp", ">=", startDate).get()

    const clicksSnapshot = await db.collection("searchClickAnalytics").where("timestamp", ">=", startDate).get()

    const searches = searchesSnapshot.docs.map((doc) => doc.data())
    const clicks = clicksSnapshot.docs.map((doc) => doc.data())

    // Count unique search IDs
    const uniqueSearchIds = new Set(searches.map((s) => s.searchId))

    // Count unique search IDs that led to clicks
    const searchIdsWithClicks = new Set(clicks.map((c) => c.searchId))

    if (uniqueSearchIds.size === 0) return 0

    return searchIdsWithClicks.size / uniqueSearchIds.size
  },

  // Get search sources distribution
  async getSearchSourcesDistribution(days = 7): Promise<any[]> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const snapshot = await db.collection("searchAnalytics").where("timestamp", ">=", startDate).get()

    const searches = snapshot.docs.map((doc) => doc.data())

    // Group by source and count
    const sourceCount: Record<string, number> = {}
    searches.forEach((search) => {
      const source = search.source || "text"
      sourceCount[source] = (sourceCount[source] || 0) + 1
    })

    // Convert to array format for charts
    return Object.entries(sourceCount).map(([name, value]) => ({
      name,
      value,
    }))
  },

  // Get average click position
  async getAverageClickPosition(days = 7): Promise<number> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const snapshot = await db.collection("searchClickAnalytics").where("timestamp", ">=", startDate).get()

    const clicks = snapshot.docs.map((doc) => doc.data())

    if (clicks.length === 0) return 0

    const totalPosition = clicks.reduce((sum, click) => sum + click.position, 0)
    return totalPosition / clicks.length
  },

  // Get click-through rate by position
  async getClickThroughRateByPosition(days = 7): Promise<any[]> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const resultsSnapshot = await db.collection("searchResultsAnalytics").where("timestamp", ">=", startDate).get()
    const clicksSnapshot = await db.collection("searchClickAnalytics").where("timestamp", ">=", startDate).get()

    const results = resultsSnapshot.docs.map((doc) => doc.data())
    const clicks = clicksSnapshot.docs.map((doc) => doc.data())

    // Group results by search ID
    const resultsBySearch: Record<string, string[]> = {}
    results.forEach((result) => {
      resultsBySearch[result.searchId] = result.resultIds
    })

    // Count impressions and clicks by position
    const impressionsByPosition: Record<number, number> = {}
    const clicksByPosition: Record<number, number> = {}

    // Count impressions
    Object.values(resultsBySearch).forEach((resultIds) => {
      resultIds.forEach((_, index) => {
        const position = index + 1
        impressionsByPosition[position] = (impressionsByPosition[position] || 0) + 1
      })
    })

    // Count clicks
    clicks.forEach((click) => {
      const position = click.position
      clicksByPosition[position] = (clicksByPosition[position] || 0) + 1
    })

    // Calculate CTR by position
    const ctrByPosition = []
    for (let position = 1; position <= 10; position++) {
      const impressions = impressionsByPosition[position] || 0
      const clicks = clicksByPosition[position] || 0
      const ctr = impressions > 0 ? clicks / impressions : 0

      ctrByPosition.push({
        position,
        impressions,
        clicks,
        ctr,
      })
    }

    return ctrByPosition
  },

  // Get user search preferences
  async getUserPreferences(userId: string): Promise<UserSearchPreferences | null> {
    // Try to get from cache first
    const cachedPreferences = await RedisCacheService.getCachedUserPreferences(userId)
    if (cachedPreferences) {
      return cachedPreferences
    }

    // Get user's search history
    const searchSnapshot = await db
      .collection("searchAnalytics")
      .where("userId", "==", userId)
      .orderBy("timestamp", "desc")
      .limit(100)
      .get()

    // Get user's click history
    const clickSnapshot = await db
      .collection("searchClickAnalytics")
      .where("userId", "==", userId)
      .orderBy("timestamp", "desc")
      .limit(100)
      .get()

    const searches = searchSnapshot.docs.map((doc) => doc.data())
    const clicks = clickSnapshot.docs.map((doc) => doc.data())

    if (searches.length === 0 && clicks.length === 0) {
      return null
    }

    // Extract categories, tags, and players from searches
    const categoryCount: Record<string, number> = {}
    const tagCount: Record<string, number> = {}
    const playerCount: Record<string, number> = {}
    const priceRanges: number[] = []
    const platformCount: Record<string, number> = {}

    // Process search filters
    searches.forEach((search) => {
      const filters = search.filters || {}

      // Categories
      if (filters.category) {
        const categories = Array.isArray(filters.category) ? filters.category : [filters.category]
        categories.forEach((category: string) => {
          categoryCount[category] = (categoryCount[category] || 0) + 1
        })
      }

      // Tags
      if (filters.tags) {
        const tags = Array.isArray(filters.tags) ? filters.tags : [filters.tags]
        tags.forEach((tag: string) => {
          tagCount[tag] = (tagCount[tag] || 0) + 1
        })
      }

      // Players
      if (filters.topPlayers) {
        const players = Array.isArray(filters.topPlayers) ? filters.topPlayers : [filters.topPlayers]
        players.forEach((player: string) => {
          playerCount[player] = (playerCount[player] || 0) + 1
        })
      }

      // Price range
      if (filters.minPrice !== undefined && filters.maxPrice !== undefined) {
        priceRanges.push(filters.minPrice)
        priceRanges.push(filters.maxPrice)
      }

      // Platform
      if (filters.platform) {
        const platforms = Array.isArray(filters.platform) ? filters.platform : [filters.platform]
        platforms.forEach((platform: string) => {
          platformCount[platform] = (platformCount[platform] || 0) + 1
        })
      }
    })

    // Get listings that user clicked on
    const clickedListingIds = clicks.map((click) => click.listingId)

    if (clickedListingIds.length > 0) {
      // Get listing details
      const listingSnapshot = await db
        .collection("listings")
        .where("id", "in", clickedListingIds.slice(0, 10)) // Firestore "in" query limited to 10 items
        .get()

      const clickedListings = listingSnapshot.docs.map((doc) => doc.data())

      // Extract preferences from clicked listings
      clickedListings.forEach((listing) => {
        // Category
        if (listing.category) {
          categoryCount[listing.category] = (categoryCount[listing.category] || 0) + 2 // Higher weight for clicks
        }

        // Tags
        if (listing.tags && Array.isArray(listing.tags)) {
          listing.tags.forEach((tag: string) => {
            tagCount[tag] = (tagCount[tag] || 0) + 2 // Higher weight for clicks
          })
        }

        // Top players
        if (listing.accountDetails?.topPlayers && Array.isArray(listing.accountDetails.topPlayers)) {
          listing.accountDetails.topPlayers.forEach((player: string) => {
            playerCount[player] = (playerCount[player] || 0) + 2 // Higher weight for clicks
          })
        }

        // Price
        if (listing.price) {
          priceRanges.push(listing.price)
        }

        // Platform
        if (listing.accountDetails?.platform) {
          platformCount[listing.accountDetails.platform] = (platformCount[listing.accountDetails.platform] || 0) + 2 // Higher weight for clicks
        }
      })
    }

    // Sort and get top preferences
    const topCategories = Object.entries(categoryCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([category]) => category)

    const topTags = Object.entries(tagCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([tag]) => tag)

    const topPlayers = Object.entries(playerCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([player]) => player)

    const topPlatforms = Object.entries(platformCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([platform]) => platform)

    // Calculate price range preference
    let minPrice = 0
    let maxPrice = 1000000 // Default high value

    if (priceRanges.length > 0) {
      // Remove outliers (values outside 1.5 * IQR)
      const sortedPrices = [...priceRanges].sort((a, b) => a - b)
      const q1Index = Math.floor(sortedPrices.length * 0.25)
      const q3Index = Math.floor(sortedPrices.length * 0.75)
      const q1 = sortedPrices[q1Index]
      const q3 = sortedPrices[q3Index]
      const iqr = q3 - q1
      const lowerBound = q1 - 1.5 * iqr
      const upperBound = q3 + 1.5 * iqr

      const filteredPrices = sortedPrices.filter((price) => price >= lowerBound && price <= upperBound)

      if (filteredPrices.length > 0) {
        minPrice = Math.max(0, Math.floor(filteredPrices[0] * 0.8)) // 20% below minimum
        maxPrice = Math.ceil(filteredPrices[filteredPrices.length - 1] * 1.2) // 20% above maximum
      }
    }

    const preferences: UserSearchPreferences = {
      categories: topCategories,
      tags: topTags,
      players: topPlayers,
      priceRange: {
        min: minPrice,
        max: maxPrice,
      },
      platforms: topPlatforms,
    }

    // Cache the preferences
    await RedisCacheService.cacheUserPreferences(userId, preferences)

    return preferences
  },

  // Get search performance metrics
  async getSearchPerformanceMetrics(days = 7): Promise<any> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const searchSnapshot = await db.collection("searchAnalytics").where("timestamp", ">=", startDate).get()
    const clickSnapshot = await db.collection("searchClickAnalytics").where("timestamp", ">=", startDate).get()
    const conversionSnapshot = await db
      .collection("searchConversionAnalytics")
      .where("timestamp", ">=", startDate)
      .get()

    const searches = searchSnapshot.docs.map((doc) => doc.data())
    const clicks = clickSnapshot.docs.map((doc) => doc.data())
    const conversions = conversionSnapshot.docs.map((doc) => doc.data())

    // Calculate metrics
    const totalSearches = searches.length
    const uniqueSearches = new Set(searches.map((s) => s.query.toLowerCase().trim())).size
    const totalClicks = clicks.length
    const totalConversions = conversions.length

    // Click-through rate
    const ctr = totalSearches > 0 ? totalClicks / totalSearches : 0

    // Conversion rate from search
    const conversionRate = totalClicks > 0 ? totalConversions / totalClicks : 0

    // Average time to click
    const clickTimes = clicks.filter((c) => c.timeToClick).map((c) => c.timeToClick)
    const avgTimeToClick =
      clickTimes.length > 0 ? clickTimes.reduce((sum, time) => sum + time, 0) / clickTimes.length : 0

    // Zero results rate
    const zeroResultSearches = searches.filter((s) => s.resultCount === 0).length
    const zeroResultRate = totalSearches > 0 ? zeroResultSearches / totalSearches : 0

    // Search abandonment rate (searches without clicks)
    const searchIdsWithClicks = new Set(clicks.map((c) => c.searchId))
    const searchesWithoutClicks = searches.filter((s) => !searchIdsWithClicks.has(s.searchId)).length
    const abandonmentRate = totalSearches > 0 ? searchesWithoutClicks / totalSearches : 0

    return {
      totalSearches,
      uniqueSearches,
      totalClicks,
      totalConversions,
      ctr,
      conversionRate,
      avgTimeToClick,
      zeroResultRate,
      abandonmentRate,
    }
  },

  // Get search trends over time
  async getSearchTrends(days = 30, interval = "day"): Promise<any[]> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const searchSnapshot = await db.collection("searchAnalytics").where("timestamp", ">=", startDate).get()
    const searches = searchSnapshot.docs.map((doc) => doc.data())

    // Group by time interval
    const trends: Record<string, { date: string; count: number }> = {}

    searches.forEach((search) => {
      const date = new Date(search.timestamp)
      let key: string

      if (interval === "hour") {
        key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:00`
      } else if (interval === "day") {
        key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`
      } else if (interval === "week") {
        // Get the first day of the week (Sunday)
        const firstDay = new Date(date)
        const day = date.getDay()
        firstDay.setDate(date.getDate() - day)
        key = `${firstDay.getFullYear()}-${firstDay.getMonth() + 1}-${firstDay.getDate()}`
      } else {
        // month
        key = `${date.getFullYear()}-${date.getMonth() + 1}`
      }

      if (!trends[key]) {
        trends[key] = { date: key, count: 0 }
      }

      trends[key].count++
    })

    // Convert to array and sort by date
    return Object.values(trends).sort((a, b) => a.date.localeCompare(b.date))
  },
}
