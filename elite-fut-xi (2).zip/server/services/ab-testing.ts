import { db } from "../index"

// Test variants
export enum SearchVariant {
  CONTROL = "control",
  TEST_A = "test_a",
  TEST_B = "test_b",
}

// Test types
export enum TestType {
  SEARCH_UI = "search_ui",
  RELEVANCE = "relevance",
  SUGGESTIONS = "suggestions",
}

interface ABTest {
  id: string
  name: string
  description: string
  type: TestType
  variants: SearchVariant[]
  trafficAllocation: number // 0-1, percentage of traffic to include in test
  variantWeights: Record<SearchVariant, number> // Weights for each variant
  startDate: Date
  endDate: Date | null
  isActive: boolean
  metrics: string[] // Metrics to track for this test
}

interface UserVariantAssignment {
  userId: string
  testId: string
  variant: SearchVariant
  assignedAt: Date
}

export const ABTestingService = {
  // Get active tests
  async getActiveTests(): Promise<ABTest[]> {
    const now = new Date()
    const snapshot = await db
      .collection("abTests")
      .where("isActive", "==", true)
      .where("startDate", "<=", now)
      .where("endDate", ">", now)
      .get()

    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as ABTest[]
  },

  // Get test by ID
  async getTestById(testId: string): Promise<ABTest | null> {
    const doc = await db.collection("abTests").doc(testId).get()
    if (!doc.exists) return null
    return {
      id: doc.id,
      ...doc.data(),
    } as ABTest
  },

  // Create a new test
  async createTest(test: Omit<ABTest, "id">): Promise<string> {
    const docRef = await db.collection("abTests").add(test)
    return docRef.id
  },

  // Update a test
  async updateTest(testId: string, updates: Partial<ABTest>): Promise<void> {
    await db.collection("abTests").doc(testId).update(updates)
  },

  // Delete a test
  async deleteTest(testId: string): Promise<void> {
    await db.collection("abTests").doc(testId).delete()
  },

  // Assign a user to a variant for a test
  async assignUserToVariant(userId: string, testId: string, test: ABTest): Promise<SearchVariant> {
    // Check if user is already assigned
    const assignmentDoc = await db
      .collection("abTestAssignments")
      .where("userId", "==", userId)
      .where("testId", "==", testId)
      .limit(1)
      .get()

    if (!assignmentDoc.empty) {
      // User already assigned, return existing variant
      return assignmentDoc.docs[0].data().variant as SearchVariant
    }

    // Determine if user should be included in test based on traffic allocation
    const shouldInclude = Math.random() < test.trafficAllocation

    if (!shouldInclude) {
      // User not included in test, assign to control
      const assignment: UserVariantAssignment = {
        userId,
        testId,
        variant: SearchVariant.CONTROL,
        assignedAt: new Date(),
      }

      await db.collection("abTestAssignments").add(assignment)
      return SearchVariant.CONTROL
    }

    // Assign user to a variant based on weights
    const variant = this.selectVariantByWeight(test.variantWeights)

    const assignment: UserVariantAssignment = {
      userId,
      testId,
      variant,
      assignedAt: new Date(),
    }

    await db.collection("abTestAssignments").add(assignment)
    return variant
  },

  // Get user's variant for a test
  async getUserVariant(userId: string, testId: string): Promise<SearchVariant | null> {
    const snapshot = await db
      .collection("abTestAssignments")
      .where("userId", "==", userId)
      .where("testId", "==", testId)
      .limit(1)
      .get()

    if (snapshot.empty) return null
    return snapshot.docs[0].data().variant as SearchVariant
  },

  // Get all variants for a user
  async getUserVariants(userId: string): Promise<Record<string, SearchVariant>> {
    const snapshot = await db.collection("abTestAssignments").where("userId", "==", userId).get()

    const variants: Record<string, SearchVariant> = {}
    snapshot.forEach((doc) => {
      const data = doc.data() as UserVariantAssignment
      variants[data.testId] = data.variant
    })

    return variants
  },

  // Track an event for a test
  async trackEvent(
    userId: string,
    testId: string,
    variant: SearchVariant,
    eventName: string,
    eventData: any = {},
  ): Promise<void> {
    await db.collection("abTestEvents").add({
      userId,
      testId,
      variant,
      eventName,
      eventData,
      timestamp: new Date(),
    })
  },

  // Get test results
  async getTestResults(testId: string): Promise<any> {
    const test = await this.getTestById(testId)
    if (!test) throw new Error("Test not found")

    const results: Record<string, Record<SearchVariant, number>> = {}

    // Initialize results object with metrics
    test.metrics.forEach((metric) => {
      results[metric] = {
        [SearchVariant.CONTROL]: 0,
        [SearchVariant.TEST_A]: 0,
        [SearchVariant.TEST_B]: 0,
      }
    })

    // Get all events for this test
    const eventsSnapshot = await db.collection("abTestEvents").where("testId", "==", testId).get()

    // Count events by variant and metric
    eventsSnapshot.forEach((doc) => {
      const event = doc.data()
      const { variant, eventName } = event

      if (test.metrics.includes(eventName)) {
        results[eventName][variant as SearchVariant]++
      }
    })

    // Get user counts by variant
    const userCountsByVariant: Record<SearchVariant, number> = {
      [SearchVariant.CONTROL]: 0,
      [SearchVariant.TEST_A]: 0,
      [SearchVariant.TEST_B]: 0,
    }

    const assignmentsSnapshot = await db.collection("abTestAssignments").where("testId", "==", testId).get()

    assignmentsSnapshot.forEach((doc) => {
      const assignment = doc.data() as UserVariantAssignment
      userCountsByVariant[assignment.variant]++
    })

    return {
      metrics: results,
      userCounts: userCountsByVariant,
    }
  },

  // Helper to select a variant based on weights
  selectVariantByWeight(weights: Record<SearchVariant, number>): SearchVariant {
    const variants = Object.keys(weights) as SearchVariant[]
    const weightValues = variants.map((v) => weights[v])

    // Calculate total weight
    const totalWeight = weightValues.reduce((sum, weight) => sum + weight, 0)

    // Generate random value between 0 and total weight
    const random = Math.random() * totalWeight

    // Find the variant that corresponds to the random value
    let cumulativeWeight = 0
    for (let i = 0; i < variants.length; i++) {
      cumulativeWeight += weightValues[i]
      if (random < cumulativeWeight) {
        return variants[i]
      }
    }

    // Fallback to control
    return SearchVariant.CONTROL
  },
}
