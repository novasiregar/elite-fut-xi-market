import { Client } from "@elastic/elasticsearch"
import type { Listing } from "../models/listing"
import { SearchAnalyticsService } from "./searchAnalytics"

// Initialize Elasticsearch client
const client = new Client({
  node: process.env.ELASTICSEARCH_URL,
  auth: {
    username: process.env.ELASTICSEARCH_USERNAME || "",
    password: process.env.ELASTICSEARCH_PASSWORD || "",
  },
})

const INDEX_NAME = "listings"

// Relevance configuration
const RELEVANCE_CONFIG = {
  // Field boosting weights
  fieldWeights: {
    title: 3.5,
    description: 1.5,
    sellerName: 1.0,
    tags: 2.5,
    "accountDetails.topPlayers": 3.0,
    category: 2.0,
  },
  // Recency boost (in days)
  recencyBoost: {
    enabled: true,
    decayScale: "30d",
    decayOffset: "7d",
    weight: 1.5,
  },
  // Popularity boost
  popularityBoost: {
    enabled: true,
    viewCountWeight: 0.5,
    favoriteCountWeight: 1.0,
    weight: 1.0,
  },
  // Featured boost
  featuredBoost: {
    enabled: true,
    weight: 2.0,
  },
  // Verified seller boost
  verifiedSellerBoost: {
    enabled: true,
    weight: 1.5,
  },
  // Minimum should match
  minimumShouldMatch: "70%",
  // Fuzziness configuration
  fuzziness: {
    enabled: true,
    auto: "1,3",
    maxExpansions: 50,
  },
}

export const EnhancedElasticsearchService = {
  // Initialize index with proper mappings
  async initializeIndex() {
    const indexExists = await client.indices.exists({ index: INDEX_NAME })

    if (!indexExists) {
      await client.indices.create({
        index: INDEX_NAME,
        body: {
          settings: {
            analysis: {
              analyzer: {
                custom_analyzer: {
                  type: "custom",
                  tokenizer: "standard",
                  filter: ["lowercase", "asciifolding", "word_delimiter", "english_stemmer", "synonym_filter"],
                },
                autocomplete_analyzer: {
                  type: "custom",
                  tokenizer: "autocomplete_tokenizer",
                  filter: ["lowercase", "asciifolding"],
                },
                search_analyzer: {
                  type: "custom",
                  tokenizer: "standard",
                  filter: ["lowercase", "asciifolding", "english_stemmer", "synonym_filter"],
                },
              },
              tokenizer: {
                autocomplete_tokenizer: {
                  type: "edge_ngram",
                  min_gram: 2,
                  max_gram: 20,
                  token_chars: ["letter", "digit"],
                },
              },
              filter: {
                english_stemmer: {
                  type: "stemmer",
                  language: "english",
                },
                synonym_filter: {
                  type: "synonym",
                  synonyms: [
                    "fifa, ea fc, football, soccer",
                    "account, profile, team",
                    "player, footballer, star",
                    "coins, points, currency, money",
                    "ultimate team, fut, ut",
                    "ronaldo, cr7",
                    "messi, leo, lionel",
                    "mbappe, kylian",
                    "neymar, jr",
                    "haaland, erling",
                  ],
                },
              },
            },
            // Increase the number of fields for better query performance
            "mapping.total_fields.limit": 2000,
            // Optimize for search speed
            "index.number_of_shards": 1,
            "index.number_of_replicas": 1,
            // Refresh interval for near real-time search
            "index.refresh_interval": "1s",
          },
          mappings: {
            properties: {
              title: {
                type: "text",
                analyzer: "custom_analyzer",
                search_analyzer: "search_analyzer",
                fields: {
                  keyword: { type: "keyword" },
                  autocomplete: {
                    type: "text",
                    analyzer: "autocomplete_analyzer",
                    search_analyzer: "search_analyzer",
                  },
                },
              },
              description: {
                type: "text",
                analyzer: "custom_analyzer",
                search_analyzer: "search_analyzer",
              },
              price: { type: "integer" },
              sellerId: { type: "keyword" },
              sellerName: {
                type: "text",
                fields: {
                  keyword: { type: "keyword" },
                },
              },
              sellerVerified: { type: "boolean" },
              tags: {
                type: "text",
                analyzer: "custom_analyzer",
                fields: {
                  keyword: { type: "keyword" },
                },
              },
              status: { type: "keyword" },
              featured: { type: "boolean" },
              createdAt: { type: "date" },
              updatedAt: { type: "date" },
              viewCount: { type: "integer" },
              favoriteCount: { type: "integer" },
              rating: { type: "float" },
              category: {
                type: "text",
                fields: {
                  keyword: { type: "keyword" },
                },
              },
              accountDetails: {
                properties: {
                  level: { type: "integer" },
                  playerCount: { type: "integer" },
                  teamRating: { type: "integer" },
                  topPlayers: {
                    type: "text",
                    analyzer: "custom_analyzer",
                    fields: {
                      keyword: { type: "keyword" },
                    },
                  },
                  division: { type: "keyword" },
                  coins: { type: "integer" },
                  platform: { type: "keyword" },
                },
              },
              media: {
                properties: {
                  url: { type: "keyword" },
                  type: { type: "keyword" },
                },
              },
            },
          },
        },
      })
      console.log("Elasticsearch index created with enhanced mappings")
    }
  },

  // Index a single listing
  async indexListing(listing: Listing) {
    await client.index({
      index: INDEX_NAME,
      id: listing.id,
      document: {
        ...listing,
        // Ensure dates are in ISO format
        createdAt: listing.createdAt instanceof Date ? listing.createdAt.toISOString() : listing.createdAt,
        updatedAt: listing.updatedAt instanceof Date ? listing.updatedAt.toISOString() : listing.updatedAt,
      },
    })
  },

  // Bulk index multiple listings
  async bulkIndexListings(listings: Listing[]) {
    const operations = listings.flatMap((listing) => [
      { index: { _index: INDEX_NAME, _id: listing.id } },
      {
        ...listing,
        createdAt: listing.createdAt instanceof Date ? listing.createdAt.toISOString() : listing.createdAt,
        updatedAt: listing.updatedAt instanceof Date ? listing.updatedAt.toISOString() : listing.updatedAt,
      },
    ])

    await client.bulk({ operations })
  },

  // Remove a listing from the index
  async removeListing(listingId: string) {
    await client.delete({
      index: INDEX_NAME,
      id: listingId,
    })
  },

  // Update a listing in the index
  async updateListing(listingId: string, updates: Partial<Listing>) {
    await client.update({
      index: INDEX_NAME,
      id: listingId,
      doc: updates,
    })
  },

  // Enhanced search with improved relevance
  async searchListings(params: {
    query?: string
    filters?: any
    sort?: { field: string; order: string }
    page?: number
    limit?: number
    userId?: string | null
    searchId?: string
    userPreferences?: any
  }) {
    const {
      query,
      filters = {},
      sort,
      page = 1,
      limit = 10,
      userId = null,
      searchId = null,
      userPreferences = null,
    } = params

    // Build query
    const must: any[] = []
    const should: any[] = []
    const filter: any[] = []
    const mustNot: any[] = []

    // Text search with improved relevance
    if (query) {
      // Multi-match query with field boosting
      must.push({
        multi_match: {
          query,
          fields: Object.entries(RELEVANCE_CONFIG.fieldWeights).map(([field, boost]) => `${field}^${boost}`),
          type: "best_fields",
          minimum_should_match: RELEVANCE_CONFIG.minimumShouldMatch,
          ...(RELEVANCE_CONFIG.fuzziness.enabled
            ? { fuzziness: RELEVANCE_CONFIG.fuzziness.auto, max_expansions: RELEVANCE_CONFIG.fuzziness.maxExpansions }
            : {}),
        },
      })

      // Add phrase matches for exact matches with higher boost
      should.push({
        multi_match: {
          query,
          fields: ["title^5", "description^2", "accountDetails.topPlayers^4"],
          type: "phrase",
          boost: 3,
        },
      })

      // Add prefix matches for partial word matches
      should.push({
        multi_match: {
          query,
          fields: ["title.autocomplete^2", "tags^1.5"],
          type: "bool_prefix",
          boost: 1.5,
        },
      })
    }

    // Only active listings
    filter.push({ term: { status: "active" } })

    // Apply filters
    if (filters.minPrice) {
      filter.push({ range: { price: { gte: filters.minPrice } } })
    }

    if (filters.maxPrice) {
      filter.push({ range: { price: { lte: filters.maxPrice } } })
    }

    if (filters.category && filters.category.length) {
      if (Array.isArray(filters.category)) {
        filter.push({ terms: { "category.keyword": filters.category } })
      } else {
        filter.push({ term: { "category.keyword": filters.category } })
      }
    }

    if (filters.tags && filters.tags.length) {
      if (Array.isArray(filters.tags)) {
        filter.push({ terms: { "tags.keyword": filters.tags } })
      } else {
        filter.push({ term: { "tags.keyword": filters.tags } })
      }
    }

    if (filters.rating) {
      filter.push({ range: { rating: { gte: filters.rating } } })
    }

    if (filters.featured !== undefined) {
      filter.push({ term: { featured: filters.featured } })
    }

    if (filters.verified !== undefined) {
      filter.push({ term: { sellerVerified: filters.verified } })
    }

    if (filters.platform) {
      filter.push({ term: { "accountDetails.platform": filters.platform } })
    }

    if (filters.minTeamRating) {
      filter.push({ range: { "accountDetails.teamRating": { gte: filters.minTeamRating } } })
    }

    if (filters.division) {
      filter.push({ term: { "accountDetails.division": filters.division } })
    }

    if (filters.minCoins) {
      filter.push({ range: { "accountDetails.coins": { gte: filters.minCoins } } })
    }

    if (filters.topPlayers && filters.topPlayers.length) {
      const topPlayersQuery = filters.topPlayers.map((player: string) => ({
        match: { "accountDetails.topPlayers": player },
      }))

      filter.push({
        bool: {
          should: topPlayersQuery,
          minimum_should_match: 1,
        },
      })
    }

    // Exclude listings by the current user if specified
    if (filters.excludeCurrentUser && userId) {
      mustNot.push({ term: { sellerId: userId } })
    }

    // Apply function score for boosting
    const functionScores: any[] = []

    // Recency boost
    if (RELEVANCE_CONFIG.recencyBoost.enabled) {
      functionScores.push({
        gauss: {
          createdAt: {
            scale: RELEVANCE_CONFIG.recencyBoost.decayScale,
            offset: RELEVANCE_CONFIG.recencyBoost.decayOffset,
            decay: 0.5,
          },
        },
        weight: RELEVANCE_CONFIG.recencyBoost.weight,
      })
    }

    // Popularity boost
    if (RELEVANCE_CONFIG.popularityBoost.enabled) {
      functionScores.push({
        field_value_factor: {
          field: "viewCount",
          factor: RELEVANCE_CONFIG.popularityBoost.viewCountWeight,
          modifier: "log1p",
          missing: 0,
        },
        weight: RELEVANCE_CONFIG.popularityBoost.weight,
      })

      functionScores.push({
        field_value_factor: {
          field: "favoriteCount",
          factor: RELEVANCE_CONFIG.popularityBoost.favoriteCountWeight,
          modifier: "log1p",
          missing: 0,
        },
        weight: RELEVANCE_CONFIG.popularityBoost.weight,
      })
    }

    // Featured boost
    if (RELEVANCE_CONFIG.featuredBoost.enabled) {
      functionScores.push({
        filter: { term: { featured: true } },
        weight: RELEVANCE_CONFIG.featuredBoost.weight,
      })
    }

    // Verified seller boost
    if (RELEVANCE_CONFIG.verifiedSellerBoost.enabled) {
      functionScores.push({
        filter: { term: { sellerVerified: true } },
        weight: RELEVANCE_CONFIG.verifiedSellerBoost.weight,
      })
    }

    // User preferences boost (if available)
    if (userPreferences) {
      // Boost by preferred price range
      if (userPreferences.priceRange) {
        const { min, max } = userPreferences.priceRange
        if (min !== undefined && max !== undefined) {
          functionScores.push({
            gauss: {
              price: {
                origin: (min + max) / 2,
                scale: (max - min) / 2,
                decay: 0.5,
              },
            },
            weight: 1.0,
          })
        }
      }

      // Boost by preferred categories
      if (userPreferences.categories && userPreferences.categories.length) {
        userPreferences.categories.forEach((category: string) => {
          functionScores.push({
            filter: { term: { "category.keyword": category } },
            weight: 1.2,
          })
        })
      }

      // Boost by preferred players
      if (userPreferences.players && userPreferences.players.length) {
        userPreferences.players.forEach((player: string) => {
          functionScores.push({
            filter: { match: { "accountDetails.topPlayers": player } },
            weight: 1.5,
          })
        })
      }
    }

    // Build sort
    const sortOptions: any[] = []
    if (sort) {
      sortOptions.push({ [sort.field]: { order: sort.order } })
    } else {
      // Default sort by relevance (if query provided) or recency
      if (query) {
        sortOptions.push({ _score: { order: "desc" } })
      }
      sortOptions.push({ createdAt: { order: "desc" } })
    }

    // Build the final query
    let finalQuery: any = {
      bool: {
        must,
        should,
        filter,
        must_not: mustNot,
      },
    }

    // Apply function score if we have any scoring functions
    if (functionScores.length > 0) {
      finalQuery = {
        function_score: {
          query: finalQuery,
          functions: functionScores,
          score_mode: "sum",
          boost_mode: "multiply",
        },
      }
    }

    // Execute search
    const response = await client.search({
      index: INDEX_NAME,
      body: {
        query: finalQuery,
        sort: sortOptions,
        from: (page - 1) * limit,
        size: limit,
        // Track total hits accurately
        track_total_hits: true,
        // Highlight matching terms
        highlight: {
          fields: {
            title: {},
            description: { fragment_size: 150, number_of_fragments: 3 },
            "accountDetails.topPlayers": {},
          },
          pre_tags: ["<strong>"],
          post_tags: ["</strong>"],
        },
        // Aggregations for faceted search
        aggs: {
          price_range: {
            stats: {
              field: "price",
            },
          },
          categories: {
            terms: {
              field: "category.keyword",
              size: 20,
            },
          },
          tags: {
            terms: {
              field: "tags.keyword",
              size: 30,
            },
          },
          platforms: {
            terms: {
              field: "accountDetails.platform",
              size: 10,
            },
          },
          team_rating: {
            histogram: {
              field: "accountDetails.teamRating",
              interval: 5,
              min_doc_count: 1,
            },
          },
          divisions: {
            terms: {
              field: "accountDetails.division",
              size: 10,
            },
          },
          top_players: {
            terms: {
              field: "accountDetails.topPlayers.keyword",
              size: 20,
            },
          },
        },
      },
    })

    // Format response
    const hits = response.hits.hits
    const total = response.hits.total as { value: number }

    // Record search results for analytics if searchId is provided
    if (searchId && userId) {
      try {
        await SearchAnalyticsService.recordSearchResults({
          searchId,
          userId,
          resultIds: hits.map((hit) => hit._id),
          scores: hits.map((hit) => hit._score || 0),
          total: total.value,
        })
      } catch (error) {
        console.error("Error recording search results:", error)
      }
    }

    return {
      results: hits.map((hit) => ({
        ...hit._source,
        id: hit._id,
        score: hit._score,
        highlights: hit.highlight,
      })) as (Listing & { score: number; highlights?: any })[],
      total: total.value,
      page,
      totalPages: Math.ceil(total.value / limit),
      aggregations: {
        priceRange: {
          min: response.aggregations?.price_range.min,
          max: response.aggregations?.price_range.max,
        },
        categories: response.aggregations?.categories.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
        tags: response.aggregations?.tags.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
        platforms: response.aggregations?.platforms.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
        teamRating: response.aggregations?.team_rating.buckets.map((bucket) => ({
          key: bucket.key as number,
          count: bucket.doc_count,
        })),
        divisions: response.aggregations?.divisions.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
        topPlayers: response.aggregations?.top_players.buckets.map((bucket) => ({
          key: bucket.key as string,
          count: bucket.doc_count,
        })),
      },
    }
  },

  // Get search suggestions with improved relevance
  async getSuggestions(query: string, userId: string | null = null) {
    // Get user preferences if userId is provided
    let userPreferences = null
    if (userId) {
      try {
        userPreferences = await SearchAnalyticsService.getUserPreferences(userId)
      } catch (error) {
        console.error("Error fetching user preferences:", error)
      }
    }

    const response = await client.search({
      index: INDEX_NAME,
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              {
                multi_match: {
                  query,
                  fields: ["title.autocomplete^3", "tags^2", "category^2", "accountDetails.topPlayers^2.5"],
                  type: "bool_prefix",
                  fuzziness: "AUTO",
                },
              },
              { term: { status: "active" } },
            ],
          },
        },
        aggs: {
          title_suggestions: {
            terms: {
              field: "title.keyword",
              size: 5,
              order: { _count: "desc" },
            },
          },
          category_suggestions: {
            terms: {
              field: "category.keyword",
              size: 3,
            },
          },
          tag_suggestions: {
            terms: {
              field: "tags.keyword",
              size: 5,
            },
          },
          player_suggestions: {
            terms: {
              field: "accountDetails.topPlayers.keyword",
              size: 5,
            },
          },
        },
      },
    })

    const suggestions: Array<{ text: string; type: string; count: number }> = []

    // Process title suggestions
    response.aggregations?.title_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "query",
        count: bucket.doc_count,
      })
    })

    // Process category suggestions
    response.aggregations?.category_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "category",
        count: bucket.doc_count,
      })
    })

    // Process tag suggestions
    response.aggregations?.tag_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "tag",
        count: bucket.doc_count,
      })
    })

    // Process player suggestions
    response.aggregations?.player_suggestions.buckets.forEach((bucket) => {
      suggestions.push({
        text: bucket.key as string,
        type: "player",
        count: bucket.doc_count,
      })
    })

    // If user preferences are available, boost suggestions that match user preferences
    if (userPreferences) {
      suggestions.forEach((suggestion) => {
        if (
          suggestion.type === "category" &&
          userPreferences.categories &&
          userPreferences.categories.includes(suggestion.text)
        ) {
          suggestion.count = suggestion.count * 1.5 // Boost by 50%
        }

        if (
          suggestion.type === "player" &&
          userPreferences.players &&
          userPreferences.players.includes(suggestion.text)
        ) {
          suggestion.count = suggestion.count * 2 // Boost by 100%
        }
      })

      // Re-sort by count
      suggestions.sort((a, b) => b.count - a.count)
    }

    return suggestions
  },

  // Get similar listings with improved relevance
  async getSimilarListings(listingId: string, limit = 6, userId: string | null = null) {
    // First get the source listing
    const listing = await client.get({
      index: INDEX_NAME,
      id: listingId,
    })

    if (!listing.found) {
      throw new Error("Listing not found")
    }

    const source = listing._source as Listing

    // Get user preferences if userId is provided
    let userPreferences = null
    if (userId) {
      try {
        userPreferences = await SearchAnalyticsService.getUserPreferences(userId)
      } catch (error) {
        console.error("Error fetching user preferences:", error)
      }
    }

    // Build function scores for boosting
    const functionScores: any[] = []

    // Recency boost
    if (RELEVANCE_CONFIG.recencyBoost.enabled) {
      functionScores.push({
        gauss: {
          createdAt: {
            scale: RELEVANCE_CONFIG.recencyBoost.decayScale,
            offset: RELEVANCE_CONFIG.recencyBoost.decayOffset,
            decay: 0.5,
          },
        },
        weight: RELEVANCE_CONFIG.recencyBoost.weight,
      })
    }

    // Popularity boost
    if (RELEVANCE_CONFIG.popularityBoost.enabled) {
      functionScores.push({
        field_value_factor: {
          field: "viewCount",
          factor: RELEVANCE_CONFIG.popularityBoost.viewCountWeight,
          modifier: "log1p",
          missing: 0,
        },
        weight: RELEVANCE_CONFIG.popularityBoost.weight,
      })

      functionScores.push({
        field_value_factor: {
          field: "favoriteCount",
          factor: RELEVANCE_CONFIG.popularityBoost.favoriteCountWeight,
          modifier: "log1p",
          missing: 0,
        },
        weight: RELEVANCE_CONFIG.popularityBoost.weight,
      })
    }

    // Featured boost
    if (RELEVANCE_CONFIG.featuredBoost.enabled) {
      functionScores.push({
        filter: { term: { featured: true } },
        weight: RELEVANCE_CONFIG.featuredBoost.weight,
      })
    }

    // Verified seller boost
    if (RELEVANCE_CONFIG.verifiedSellerBoost.enabled) {
      functionScores.push({
        filter: { term: { sellerVerified: true } },
        weight: RELEVANCE_CONFIG.verifiedSellerBoost.weight,
      })
    }

    // Price similarity boost (prefer listings with similar price)
    functionScores.push({
      gauss: {
        price: {
          origin: source.price,
          scale: source.price * 0.3, // 30% price range
          decay: 0.5,
        },
      },
      weight: 1.2,
    })

    // User preferences boost (if available)
    if (userPreferences) {
      // Boost by preferred categories
      if (userPreferences.categories && userPreferences.categories.length) {
        userPreferences.categories.forEach((category: string) => {
          functionScores.push({
            filter: { term: { "category.keyword": category } },
            weight: 1.2,
          })
        })
      }

      // Boost by preferred players
      if (userPreferences.players && userPreferences.players.length) {
        userPreferences.players.forEach((player: string) => {
          functionScores.push({
            filter: { match: { "accountDetails.topPlayers": player } },
            weight: 1.5,
          })
        })
      }
    }

    // Find similar listings with improved relevance
    const response = await client.search({
      index: INDEX_NAME,
      body: {
        query: {
          function_score: {
            query: {
              bool: {
                must: [
                  {
                    more_like_this: {
                      fields: ["title^3", "description^1.5", "tags^2", "category^2", "accountDetails.topPlayers^3"],
                      like: [
                        {
                          _index: INDEX_NAME,
                          _id: listingId,
                        },
                      ],
                      min_term_freq: 1,
                      max_query_terms: 12,
                      min_doc_freq: 1,
                      minimum_should_match: "60%",
                    },
                  },
                  { term: { status: "active" } },
                ],
                must_not: [
                  { term: { _id: listingId } },
                  // Exclude listings by the same seller for more diversity
                  { term: { sellerId: source.sellerId } },
                ],
                // Boost listings in the same category
                should: [
                  {
                    term: {
                      "category.keyword": {
                        value: source.category,
                        boost: 1.5,
                      },
                    },
                  },
                  // Boost listings with similar team rating
                  ...(source.accountDetails?.teamRating
                    ? [
                        {
                          range: {
                            "accountDetails.teamRating": {
                              gte: source.accountDetails.teamRating - 5,
                              lte: source.accountDetails.teamRating + 5,
                              boost: 1.3,
                            },
                          },
                        },
                      ]
                    : []),
                  // Boost listings with similar top players
                  ...(source.accountDetails?.topPlayers
                    ? source.accountDetails.topPlayers.map((player: string) => ({
                        match: {
                          "accountDetails.topPlayers": {
                            query: player,
                            boost: 2.0,
                          },
                        },
                      }))
                    : []),
                ],
              },
            },
            functions: functionScores,
            score_mode: "sum",
            boost_mode: "multiply",
          },
        },
        size: limit,
        // Highlight matching terms
        highlight: {
          fields: {
            title: {},
            "accountDetails.topPlayers": {},
          },
          pre_tags: ["<strong>"],
          post_tags: ["</strong>"],
        },
      },
    })

    return response.hits.hits.map((hit) => ({
      ...hit._source,
      id: hit._id,
      score: hit._score,
      highlights: hit.highlight,
    })) as (Listing & { score: number; highlights?: any })[]
  },

  // Get relevance configuration
  getRelevanceConfig() {
    return { ...RELEVANCE_CONFIG }
  },

  // Update relevance configuration
  updateRelevanceConfig(newConfig: Partial<typeof RELEVANCE_CONFIG>) {
    Object.assign(RELEVANCE_CONFIG, newConfig)
    return { ...RELEVANCE_CONFIG }
  },
}
