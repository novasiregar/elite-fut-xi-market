import { db } from "../index"
import { FieldValue } from "firebase-admin/firestore"
import { NotificationService } from "./notification-service"

export enum EscrowReleaseType {
  AUTOMATIC = "automatic",
  BUYER_CONFIRMED = "buyer_confirmed",
  ADMIN_INTERVENTION = "admin_intervention",
  DISPUTE_RESOLVED = "dispute_resolved",
  TIMED_RELEASE = "timed_release",
}

export class EnhancedEscrowService {
  // Create escrow for a transaction
  static async createEscrow(transactionId: string, amount: number, sellerId: string) {
    const escrowData = {
      transactionId,
      amount,
      sellerId,
      status: "active",
      createdAt: FieldValue.serverTimestamp(),
      releaseDate: null, // Will be set if using timed release
      releaseType: null,
      releasedAt: null,
      lastUpdated: FieldValue.serverTimestamp(),
    }

    await db.collection("escrows").doc(transactionId).set(escrowData)

    // Set up timed release (e.g., 3 days)
    await this.setupTimedRelease(transactionId, 3)

    return escrowData
  }

  // Set up timed release for escrow
  static async setupTimedRelease(transactionId: string, daysToRelease: number) {
    const releaseDate = new Date()
    releaseDate.setDate(releaseDate.getDate() + daysToRelease)

    await db.collection("escrows").doc(transactionId).update({
      releaseDate: releaseDate,
      lastUpdated: FieldValue.serverTimestamp(),
    })

    // In a production environment, you would use a task queue or scheduler
    // For Firebase, you could use Cloud Functions with scheduled triggers
    // This is a simplified example
    console.log(`Scheduled release for transaction ${transactionId} on ${releaseDate}`)
  }

  // Release funds to seller
  static async releaseFunds(transactionId: string, releaseType: EscrowReleaseType) {
    const escrowRef = db.collection("escrows").doc(transactionId)
    const escrowDoc = await escrowRef.get()

    if (!escrowDoc.exists) {
      throw new Error("Escrow not found")
    }

    const escrowData = escrowDoc.data()

    if (escrowData.status !== "active") {
      throw new Error(`Cannot release funds. Escrow status is ${escrowData.status}`)
    }

    // Update escrow status
    await escrowRef.update({
      status: "released",
      releaseType,
      releasedAt: FieldValue.serverTimestamp(),
      lastUpdated: FieldValue.serverTimestamp(),
    })

    // Update seller balance
    await db
      .collection("users")
      .doc(escrowData.sellerId)
      .update({
        balance: FieldValue.increment(escrowData.amount),
        lastUpdated: FieldValue.serverTimestamp(),
      })

    // Update transaction status
    await db
      .collection("transactions")
      .doc(transactionId)
      .update({
        status: "completed",
        timeline: FieldValue.arrayUnion({
          status: "completed",
          timestamp: FieldValue.serverTimestamp(),
          note: `Funds released to seller via ${releaseType}`,
        }),
        updatedAt: FieldValue.serverTimestamp(),
      })

    // Notify seller
    await NotificationService.createNotification({
      userId: escrowData.sellerId,
      type: "payment_received",
      title: "Payment Received",
      message: `Your payment of Rp ${escrowData.amount.toLocaleString()} has been released to your account.`,
      data: { transactionId },
    })

    return { success: true, releaseType }
  }

  // Process timed releases (would be called by a scheduled function)
  static async processTimedReleases() {
    const now = new Date()

    // Find escrows that are due for release
    const snapshot = await db
      .collection("escrows")
      .where("status", "==", "active")
      .where("releaseDate", "<=", now)
      .get()

    const results = []

    for (const doc of snapshot.docs) {
      try {
        const result = await this.releaseFunds(doc.id, EscrowReleaseType.TIMED_RELEASE)
        results.push({ id: doc.id, result })
      } catch (error) {
        results.push({ id: doc.id, error: error.message })
      }
    }

    return results
  }

  // Handle dispute resolution
  static async resolveDispute(transactionId: string, winningParty: "buyer" | "seller", adminId: string) {
    const escrowRef = db.collection("escrows").doc(transactionId)
    const escrowDoc = await escrowRef.get()

    if (!escrowDoc.exists) {
      throw new Error("Escrow not found")
    }

    const escrowData = escrowDoc.data()
    const transactionRef = db.collection("transactions").doc(transactionId)
    const transactionDoc = await transactionRef.get()
    const transactionData = transactionDoc.data()

    if (winningParty === "seller") {
      // Release funds to seller
      await this.releaseFunds(transactionId, EscrowReleaseType.DISPUTE_RESOLVED)

      // Update dispute record
      await db.collection("disputes").doc(transactionId).update({
        status: "resolved",
        resolution: "seller",
        resolvedBy: adminId,
        resolvedAt: FieldValue.serverTimestamp(),
      })

      // Notify both parties
      await NotificationService.createNotification({
        userId: escrowData.sellerId,
        type: "dispute_resolved",
        title: "Dispute Resolved in Your Favor",
        message: `The dispute for transaction ${transactionId} has been resolved in your favor.`,
        data: { transactionId },
      })

      await NotificationService.createNotification({
        userId: transactionData.buyerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: `The dispute for transaction ${transactionId} has been resolved in favor of the seller.`,
        data: { transactionId },
      })
    } else {
      // Refund buyer
      await escrowRef.update({
        status: "refunded",
        releaseType: EscrowReleaseType.DISPUTE_RESOLVED,
        releasedAt: FieldValue.serverTimestamp(),
        lastUpdated: FieldValue.serverTimestamp(),
      })

      // Update transaction status
      await transactionRef.update({
        status: "refunded",
        timeline: FieldValue.arrayUnion({
          status: "refunded",
          timestamp: FieldValue.serverTimestamp(),
          note: "Refunded to buyer after dispute resolution",
        }),
        updatedAt: FieldValue.serverTimestamp(),
      })

      // Update dispute record
      await db.collection("disputes").doc(transactionId).update({
        status: "resolved",
        resolution: "buyer",
        resolvedBy: adminId,
        resolvedAt: FieldValue.serverTimestamp(),
      })

      // Notify both parties
      await NotificationService.createNotification({
        userId: transactionData.buyerId,
        type: "dispute_resolved",
        title: "Dispute Resolved in Your Favor",
        message: `The dispute for transaction ${transactionId} has been resolved in your favor. A refund has been issued.`,
        data: { transactionId },
      })

      await NotificationService.createNotification({
        userId: escrowData.sellerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: `The dispute for transaction ${transactionId} has been resolved in favor of the buyer.`,
        data: { transactionId },
      })
    }

    return { success: true, resolution: winningParty }
  }
}
