import { db } from "../index"
import { FieldValue } from "firebase-admin/firestore"
import { NotificationService } from "./notification-service"
import { v4 as uuidv4 } from "uuid"

export enum DisputeStatus {
  OPEN = "open",
  UNDER_REVIEW = "under_review",
  WAITING_FOR_BUYER = "waiting_for_buyer",
  WAITING_FOR_SELLER = "waiting_for_seller",
  RESOLVED = "resolved",
  CLOSED = "closed",
}

export enum DisputeResolution {
  BUYER_FAVOR = "buyer_favor",
  SELLER_FAVOR = "seller_favor",
  COMPROMISE = "compromise",
  NO_RESOLUTION = "no_resolution",
}

export class DisputeService {
  // Create a new dispute
  static async createDispute(transactionId: string, initiatedBy: string, reason: string, details: string) {
    // Get transaction details
    const transactionDoc = await db.collection("transactions").doc(transactionId).get()

    if (!transactionDoc.exists) {
      throw new Error("Transaction not found")
    }

    const transaction = transactionDoc.data()

    // Verify user is buyer or seller
    if (transaction.buyerId !== initiatedBy && transaction.sellerId !== initiatedBy) {
      throw new Error("Only the buyer or seller can open a dispute")
    }

    // Check if dispute already exists
    const existingDisputeSnapshot = await db
      .collection("disputes")
      .where("transactionId", "==", transactionId)
      .limit(1)
      .get()

    if (!existingDisputeSnapshot.empty) {
      throw new Error("A dispute already exists for this transaction")
    }

    const disputeId = uuidv4()

    const disputeData = {
      id: disputeId,
      transactionId,
      initiatedBy,
      reason,
      details,
      status: DisputeStatus.OPEN,
      resolution: null,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      assignedAdmin: null,
      messages: [
        {
          id: uuidv4(),
          userId: initiatedBy,
          message: details,
          timestamp: FieldValue.serverTimestamp(),
          attachments: [],
        },
      ],
      evidence: [],
      timeline: [
        {
          status: DisputeStatus.OPEN,
          timestamp: FieldValue.serverTimestamp(),
          note: `Dispute opened by ${initiatedBy === transaction.buyerId ? "buyer" : "seller"}`,
        },
      ],
    }

    // Create dispute document
    await db.collection("disputes").doc(disputeId).set(disputeData)

    // Update transaction status
    await db
      .collection("transactions")
      .doc(transactionId)
      .update({
        status: "disputed",
        disputeId,
        updatedAt: FieldValue.serverTimestamp(),
        timeline: FieldValue.arrayUnion({
          status: "disputed",
          timestamp: FieldValue.serverTimestamp(),
          note: `Dispute opened by ${initiatedBy === transaction.buyerId ? "buyer" : "seller"}`,
        }),
      })

    // Notify other party
    const otherPartyId = initiatedBy === transaction.buyerId ? transaction.sellerId : transaction.buyerId

    await NotificationService.createNotification({
      userId: otherPartyId,
      type: "dispute_opened",
      title: "Dispute Opened",
      message: `A dispute has been opened for transaction "${transaction.listingTitle}"`,
      data: { transactionId, disputeId },
    })

    // Notify admins
    await db.collection("admin_notifications").add({
      type: "new_dispute",
      title: "New Dispute",
      message: `A new dispute has been opened for transaction ${transactionId}`,
      data: { transactionId, disputeId },
      createdAt: FieldValue.serverTimestamp(),
    })

    return { disputeId, status: DisputeStatus.OPEN }
  }

  // Add message to dispute
  static async addMessage(disputeId: string, userId: string, message: string, attachments: string[] = []) {
    const disputeRef = db.collection("disputes").doc(disputeId)
    const disputeDoc = await disputeRef.get()

    if (!disputeDoc.exists) {
      throw new Error("Dispute not found")
    }

    const dispute = disputeDoc.data()
    const transaction = await db.collection("transactions").doc(dispute.transactionId).get()
    const transactionData = transaction.data()

    // Verify user is buyer, seller, or admin
    const isAdmin = await this.isUserAdmin(userId)

    if (transactionData.buyerId !== userId && transactionData.sellerId !== userId && !isAdmin) {
      throw new Error("You don't have permission to add messages to this dispute")
    }

    const messageData = {
      id: uuidv4(),
      userId,
      message,
      timestamp: FieldValue.serverTimestamp(),
      attachments,
    }

    // Add message to dispute
    await disputeRef.update({
      messages: FieldValue.arrayUnion(messageData),
      updatedAt: FieldValue.serverTimestamp(),
    })

    // If admin is responding, update status
    if (isAdmin) {
      await this.updateDisputeStatus(disputeId, DisputeStatus.UNDER_REVIEW, userId, "Admin responded to dispute")
    }

    // Notify other parties
    if (isAdmin) {
      // Notify both buyer and seller
      await NotificationService.createNotification({
        userId: transactionData.buyerId,
        type: "dispute_message",
        title: "New Message in Dispute",
        message: "An admin has responded to your dispute",
        data: { disputeId, transactionId: dispute.transactionId },
      })

      await NotificationService.createNotification({
        userId: transactionData.sellerId,
        type: "dispute_message",
        title: "New Message in Dispute",
        message: "An admin has responded to your dispute",
        data: { disputeId, transactionId: dispute.transactionId },
      })
    } else {
      // Notify the other party (buyer or seller)
      const otherPartyId = userId === transactionData.buyerId ? transactionData.sellerId : transactionData.buyerId

      await NotificationService.createNotification({
        userId: otherPartyId,
        type: "dispute_message",
        title: "New Message in Dispute",
        message: `${userId === transactionData.buyerId ? "Buyer" : "Seller"} has responded to the dispute`,
        data: { disputeId, transactionId: dispute.transactionId },
      })

      // Notify admins
      await db.collection("admin_notifications").add({
        type: "dispute_message",
        title: "New Dispute Message",
        message: `New message in dispute ${disputeId}`,
        data: { disputeId, transactionId: dispute.transactionId },
        createdAt: FieldValue.serverTimestamp(),
      })
    }

    return messageData
  }

  // Add evidence to dispute
  static async addEvidence(
    disputeId: string,
    userId: string,
    evidenceType: string,
    description: string,
    fileUrl: string,
  ) {
    const disputeRef = db.collection("disputes").doc(disputeId)
    const disputeDoc = await disputeRef.get()

    if (!disputeDoc.exists) {
      throw new Error("Dispute not found")
    }

    const dispute = disputeDoc.data()
    const transaction = await db.collection("transactions").doc(dispute.transactionId).get()
    const transactionData = transaction.data()

    // Verify user is buyer or seller
    if (transactionData.buyerId !== userId && transactionData.sellerId !== userId) {
      throw new Error("You don't have permission to add evidence to this dispute")
    }

    const evidenceData = {
      id: uuidv4(),
      userId,
      evidenceType,
      description,
      fileUrl,
      submittedAt: FieldValue.serverTimestamp(),
    }

    // Add evidence to dispute
    await disputeRef.update({
      evidence: FieldValue.arrayUnion(evidenceData),
      updatedAt: FieldValue.serverTimestamp(),
      timeline: FieldValue.arrayUnion({
        status: dispute.status,
        timestamp: FieldValue.serverTimestamp(),
        note: `${userId === transactionData.buyerId ? "Buyer" : "Seller"} added evidence: ${evidenceType}`,
      }),
    })

    // Notify other party and admins
    const otherPartyId = userId === transactionData.buyerId ? transactionData.sellerId : transactionData.buyerId

    await NotificationService.createNotification({
      userId: otherPartyId,
      type: "dispute_evidence",
      title: "New Evidence in Dispute",
      message: `${userId === transactionData.buyerId ? "Buyer" : "Seller"} has added evidence to the dispute`,
      data: { disputeId, transactionId: dispute.transactionId },
    })

    // Notify admins
    await db.collection("admin_notifications").add({
      type: "dispute_evidence",
      title: "New Dispute Evidence",
      message: `New evidence added to dispute ${disputeId}`,
      data: { disputeId, transactionId: dispute.transactionId },
      createdAt: FieldValue.serverTimestamp(),
    })

    return evidenceData
  }

  // Update dispute status
  static async updateDisputeStatus(disputeId: string, status: DisputeStatus, updatedBy: string, note: string) {
    const disputeRef = db.collection("disputes").doc(disputeId)
    const disputeDoc = await disputeRef.get()

    if (!disputeDoc.exists) {
      throw new Error("Dispute not found")
    }

    // Update dispute status
    await disputeRef.update({
      status,
      updatedAt: FieldValue.serverTimestamp(),
      timeline: FieldValue.arrayUnion({
        status,
        timestamp: FieldValue.serverTimestamp(),
        note,
        updatedBy,
      }),
    })

    return { success: true, status }
  }

  // Resolve dispute
  static async resolveDispute(disputeId: string, adminId: string, resolution: DisputeResolution, notes: string) {
    // Verify user is admin
    const isAdmin = await this.isUserAdmin(adminId)

    if (!isAdmin) {
      throw new Error("Only admins can resolve disputes")
    }

    const disputeRef = db.collection("disputes").doc(disputeId)
    const disputeDoc = await disputeRef.get()

    if (!disputeDoc.exists) {
      throw new Error("Dispute not found")
    }

    const dispute = disputeDoc.data()
    const transactionId = dispute.transactionId

    // Update dispute status
    await disputeRef.update({
      status: DisputeStatus.RESOLVED,
      resolution,
      resolvedBy: adminId,
      resolvedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      timeline: FieldValue.arrayUnion({
        status: DisputeStatus.RESOLVED,
        timestamp: FieldValue.serverTimestamp(),
        note: `Dispute resolved by admin: ${resolution}`,
        updatedBy: adminId,
      }),
    })

    // Get transaction details
    const transactionDoc = await db.collection("transactions").doc(transactionId).get()
    const transaction = transactionDoc.data()

    // Handle resolution based on outcome
    if (resolution === DisputeResolution.BUYER_FAVOR) {
      // Refund buyer
      await db
        .collection("transactions")
        .doc(transactionId)
        .update({
          status: "refunded",
          updatedAt: FieldValue.serverTimestamp(),
          timeline: FieldValue.arrayUnion({
            status: "refunded",
            timestamp: FieldValue.serverTimestamp(),
            note: "Transaction refunded after dispute resolution",
          }),
        })

      // Notify buyer and seller
      await NotificationService.createNotification({
        userId: transaction.buyerId,
        type: "dispute_resolved",
        title: "Dispute Resolved in Your Favor",
        message: "The dispute has been resolved in your favor. You will receive a refund.",
        data: { disputeId, transactionId },
      })

      await NotificationService.createNotification({
        userId: transaction.sellerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: "The dispute has been resolved in favor of the buyer.",
        data: { disputeId, transactionId },
      })
    } else if (resolution === DisputeResolution.SELLER_FAVOR) {
      // Release funds to seller
      await db
        .collection("transactions")
        .doc(transactionId)
        .update({
          status: "completed",
          updatedAt: FieldValue.serverTimestamp(),
          timeline: FieldValue.arrayUnion({
            status: "completed",
            timestamp: FieldValue.serverTimestamp(),
            note: "Transaction completed after dispute resolution",
          }),
        })

      // Notify buyer and seller
      await NotificationService.createNotification({
        userId: transaction.sellerId,
        type: "dispute_resolved",
        title: "Dispute Resolved in Your Favor",
        message: "The dispute has been resolved in your favor. Funds will be released to you.",
        data: { disputeId, transactionId },
      })

      await NotificationService.createNotification({
        userId: transaction.buyerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: "The dispute has been resolved in favor of the seller.",
        data: { disputeId, transactionId },
      })
    } else if (resolution === DisputeResolution.COMPROMISE) {
      // Handle compromise (partial refund, etc.)
      // This would require additional implementation based on your business logic

      // Notify both parties
      await NotificationService.createNotification({
        userId: transaction.buyerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: "The dispute has been resolved with a compromise solution.",
        data: { disputeId, transactionId },
      })

      await NotificationService.createNotification({
        userId: transaction.sellerId,
        type: "dispute_resolved",
        title: "Dispute Resolution",
        message: "The dispute has been resolved with a compromise solution.",
        data: { disputeId, transactionId },
      })
    }

    return { success: true, resolution }
  }

  // Helper method to check if user is admin
  static async isUserAdmin(userId: string) {
    const userDoc = await db.collection("users").doc(userId).get()

    if (!userDoc.exists) {
      return false
    }

    const userData = userDoc.data()
    return userData.isAdmin === true
  }

  // Get dispute by ID
  static async getDispute(disputeId: string, userId: string) {
    const disputeDoc = await db.collection("disputes").doc(disputeId).get()

    if (!disputeDoc.exists) {
      throw new Error("Dispute not found")
    }

    const dispute = disputeDoc.data()
    const transactionDoc = await db.collection("transactions").doc(dispute.transactionId).get()
    const transaction = transactionDoc.data()

    // Verify user is buyer, seller, or admin
    const isAdmin = await this.isUserAdmin(userId)

    if (transaction.buyerId !== userId && transaction.sellerId !== userId && !isAdmin) {
      throw new Error("You don't have permission to view this dispute")
    }

    // Format timestamps
    if (dispute.createdAt) {
      dispute.createdAt = dispute.createdAt.toDate().toISOString()
    }
    if (dispute.updatedAt) {
      dispute.updatedAt = dispute.updatedAt.toDate().toISOString()
    }
    if (dispute.resolvedAt) {
      dispute.resolvedAt = dispute.resolvedAt.toDate().toISOString()
    }

    // Format message timestamps
    if (dispute.messages) {
      dispute.messages = dispute.messages.map((message: any) => ({
        ...message,
        timestamp: message.timestamp ? message.timestamp.toDate().toISOString() : null,
      }))
    }

    // Format timeline timestamps
    if (dispute.timeline) {
      dispute.timeline = dispute.timeline.map((event: any) => ({
        ...event,
        timestamp: event.timestamp ? event.timestamp.toDate().toISOString() : null,
      }))
    }

    // Format evidence timestamps
    if (dispute.evidence) {
      dispute.evidence = dispute.evidence.map((evidence: any) => ({
        ...evidence,
        submittedAt: evidence.submittedAt ? evidence.submittedAt.toDate().toISOString() : null,
      }))
    }

    return dispute
  }
}
