import { db } from "../index"
import { v4 as uuidv4 } from "uuid"
import { NotificationService, NotificationType } from "./notification-service"
import { TransactionService } from "./transaction-service"
import { ListingService } from "./listing-service"
import { UserService } from "./user-service"
import { EscrowService } from "./escrow-service"

export enum PaymentStatus {
  PENDING = "pending",
  PROCESSING = "processing",
  COMPLETED = "completed",
  FAILED = "failed",
  REFUNDED = "refunded",
  DISPUTED = "disputed",
}

export enum PaymentMethod {
  CREDIT_CARD = "credit_card",
  PAYPAL = "paypal",
  BANK_TRANSFER = "bank_transfer",
  CRYPTO = "crypto",
  PLATFORM_BALANCE = "platform_balance",
}

export interface Payment {
  id: string
  transactionId: string
  buyerId: string
  sellerId: string
  listingId: string
  amount: number
  fee: number
  netAmount: number
  currency: string
  method: PaymentMethod
  status: PaymentStatus
  gatewayId?: string
  gatewayData?: any
  createdAt: Date
  updatedAt: Date
}

export const PaymentService = {
  // Create a new payment
  async createPayment(
    transactionId: string,
    buyerId: string,
    sellerId: string,
    listingId: string,
    amount: number,
    method: PaymentMethod,
  ): Promise<Payment> {
    // Calculate platform fee (5%)
    const fee = Math.round(amount * 0.05)
    const netAmount = amount - fee

    const payment: Payment = {
      id: uuidv4(),
      transactionId,
      buyerId,
      sellerId,
      listingId,
      amount,
      fee,
      netAmount,
      currency: "USD", // Default currency
      method,
      status: PaymentStatus.PENDING,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await db.collection("payments").doc(payment.id).set(payment)

    // Update transaction status
    await TransactionService.updateTransactionStatus(transactionId, "payment_pending")

    return payment
  },

  // Process payment with payment gateway
  async processPayment(paymentId: string, paymentDetails: any): Promise<Payment> {
    const paymentDoc = await db.collection("payments").doc(paymentId).get()

    if (!paymentDoc.exists) {
      throw new Error("Payment not found")
    }

    const payment = paymentDoc.data() as Payment

    // Update payment status
    payment.status = PaymentStatus.PROCESSING
    payment.updatedAt = new Date()

    // Process payment with appropriate gateway based on method
    try {
      let gatewayResponse

      switch (payment.method) {
        case PaymentMethod.CREDIT_CARD:
          gatewayResponse = await this.processCreditCardPayment(payment, paymentDetails)
          break
        case PaymentMethod.PAYPAL:
          gatewayResponse = await this.processPayPalPayment(payment, paymentDetails)
          break
        case PaymentMethod.PLATFORM_BALANCE:
          gatewayResponse = await this.processPlatformBalancePayment(payment)
          break
        default:
          throw new Error(`Payment method ${payment.method} not supported`)
      }

      // Update payment with gateway response
      payment.gatewayId = gatewayResponse.id
      payment.gatewayData = gatewayResponse.data
      payment.status = PaymentStatus.COMPLETED

      // Move funds to escrow
      await EscrowService.createEscrow(payment.id, payment.sellerId, payment.netAmount)

      // Update transaction status
      await TransactionService.updateTransactionStatus(payment.transactionId, "payment_completed")

      // Mark listing as sold
      await ListingService.updateListingStatus(payment.listingId, "sold")

      // Send notifications
      await NotificationService.createNotification({
        userId: payment.buyerId,
        type: NotificationType.PAYMENT_RECEIVED,
        title: "Payment Successful",
        message: `Your payment of $${(payment.amount / 100).toFixed(2)} has been processed successfully.`,
        data: { paymentId: payment.id, transactionId: payment.transactionId },
      })

      await NotificationService.createNotification({
        userId: payment.sellerId,
        type: NotificationType.PAYMENT_RECEIVED,
        title: "Payment Received",
        message: `You've received a payment of $${(payment.netAmount / 100).toFixed(2)} for your listing.`,
        data: { paymentId: payment.id, transactionId: payment.transactionId },
      })
    } catch (error) {
      console.error("Payment processing error:", error)

      payment.status = PaymentStatus.FAILED
      payment.gatewayData = { error: error.message }

      // Update transaction status
      await TransactionService.updateTransactionStatus(payment.transactionId, "payment_failed")

      // Send notification
      await NotificationService.createNotification({
        userId: payment.buyerId,
        type: NotificationType.SYSTEM,
        title: "Payment Failed",
        message: `Your payment of $${(payment.amount / 100).toFixed(2)} could not be processed. Please try again.`,
        data: { paymentId: payment.id, transactionId: payment.transactionId },
      })
    }

    // Save updated payment
    await db.collection("payments").doc(payment.id).update(payment)

    return payment
  },

  // Process credit card payment
  async processCreditCardPayment(payment: Payment, paymentDetails: any): Promise<any> {
    // In a real implementation, this would integrate with a payment gateway like Stripe
    // For now, we'll simulate a successful payment

    // Validate payment details
    if (!paymentDetails.cardNumber || !paymentDetails.expiryDate || !paymentDetails.cvv) {
      throw new Error("Invalid card details")
    }

    // Simulate payment processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Return simulated gateway response
    return {
      id: `cc_${uuidv4()}`,
      data: {
        status: "succeeded",
        amount: payment.amount,
        currency: payment.currency,
        last4: paymentDetails.cardNumber.slice(-4),
        processingTime: new Date().toISOString(),
      },
    }
  },

  // Process PayPal payment
  async processPayPalPayment(payment: Payment, paymentDetails: any): Promise<any> {
    // In a real implementation, this would integrate with PayPal API
    // For now, we'll simulate a successful payment

    // Validate payment details
    if (!paymentDetails.paypalEmail) {
      throw new Error("Invalid PayPal details")
    }

    // Simulate payment processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Return simulated gateway response
    return {
      id: `pp_${uuidv4()}`,
      data: {
        status: "completed",
        amount: payment.amount,
        currency: payment.currency,
        email: paymentDetails.paypalEmail,
        processingTime: new Date().toISOString(),
      },
    }
  },

  // Process platform balance payment
  async processPlatformBalancePayment(payment: Payment): Promise<any> {
    // Check if buyer has sufficient balance
    const buyer = await UserService.getUserById(payment.buyerId)

    if (!buyer) {
      throw new Error("Buyer not found")
    }

    if (!buyer.balance || buyer.balance < payment.amount) {
      throw new Error("Insufficient balance")
    }

    // Deduct from buyer's balance
    await UserService.updateUserBalance(payment.buyerId, -payment.amount)

    // Return simulated gateway response
    return {
      id: `bal_${uuidv4()}`,
      data: {
        status: "completed",
        amount: payment.amount,
        currency: payment.currency,
        processingTime: new Date().toISOString(),
      },
    }
  },

  // Get payment by ID
  async getPaymentById(paymentId: string): Promise<Payment | null> {
    const doc = await db.collection("payments").doc(paymentId).get()

    if (!doc.exists) {
      return null
    }

    return doc.data() as Payment
  },

  // Get payments for a transaction
  async getPaymentsByTransactionId(transactionId: string): Promise<Payment[]> {
    const snapshot = await db
      .collection("payments")
      .where("transactionId", "==", transactionId)
      .orderBy("createdAt", "desc")
      .get()

    return snapshot.docs.map((doc) => doc.data() as Payment)
  },

  // Get payments for a user (as buyer)
  async getUserPaymentsAsBuyer(userId: string, limit = 10, offset = 0): Promise<Payment[]> {
    const snapshot = await db
      .collection("payments")
      .where("buyerId", "==", userId)
      .orderBy("createdAt", "desc")
      .limit(limit)
      .offset(offset)
      .get()

    return snapshot.docs.map((doc) => doc.data() as Payment)
  },

  // Get payments for a user (as seller)
  async getUserPaymentsAsSeller(userId: string, limit = 10, offset = 0): Promise<Payment[]> {
    const snapshot = await db
      .collection("payments")
      .where("sellerId", "==", userId)
      .orderBy("createdAt", "desc")
      .limit(limit)
      .offset(offset)
      .get()

    return snapshot.docs.map((doc) => doc.data() as Payment)
  },

  // Issue refund
  async issueRefund(paymentId: string, reason: string): Promise<Payment> {
    const payment = await this.getPaymentById(paymentId)

    if (!payment) {
      throw new Error("Payment not found")
    }

    if (payment.status !== PaymentStatus.COMPLETED) {
      throw new Error("Only completed payments can be refunded")
    }

    // Process refund with payment gateway
    try {
      // In a real implementation, this would call the payment gateway's refund API
      // For now, we'll simulate a successful refund

      // Update payment status
      payment.status = PaymentStatus.REFUNDED
      payment.updatedAt = new Date()
      payment.gatewayData = {
        ...payment.gatewayData,
        refund: {
          id: `ref_${uuidv4()}`,
          reason,
          amount: payment.amount,
          processingTime: new Date().toISOString(),
        },
      }

      // Release funds from escrow
      await EscrowService.releaseEscrow(paymentId, "refunded")

      // Update transaction status
      await TransactionService.updateTransactionStatus(payment.transactionId, "refunded")

      // Return listing to active status
      await ListingService.updateListingStatus(payment.listingId, "active")

      // Send notifications
      await NotificationService.createNotification({
        userId: payment.buyerId,
        type: NotificationType.SYSTEM,
        title: "Refund Issued",
        message: `Your refund of $${(payment.amount / 100).toFixed(2)} has been processed.`,
        data: { paymentId: payment.id, transactionId: payment.transactionId },
      })

      await NotificationService.createNotification({
        userId: payment.sellerId,
        type: NotificationType.SYSTEM,
        title: "Refund Issued",
        message: `A refund of $${(payment.amount / 100).toFixed(2)} has been issued to the buyer.`,
        data: { paymentId: payment.id, transactionId: payment.transactionId },
      })

      // Save updated payment
      await db.collection("payments").doc(payment.id).update(payment)

      return payment
    } catch (error) {
      console.error("Refund processing error:", error)
      throw error
    }
  },

  // Handle payment dispute
  async handleDispute(paymentId: string, disputeDetails: any): Promise<Payment> {
    const payment = await this.getPaymentById(paymentId)

    if (!payment) {
      throw new Error("Payment not found")
    }

    // Update payment status
    payment.status = PaymentStatus.DISPUTED
    payment.updatedAt = new Date()
    payment.gatewayData = {
      ...payment.gatewayData,
      dispute: {
        id: `disp_${uuidv4()}`,
        details: disputeDetails,
        status: "pending",
        createdAt: new Date().toISOString(),
      },
    }

    // Update transaction status
    await TransactionService.updateTransactionStatus(payment.transactionId, "disputed")

    // Send notifications
    await NotificationService.createNotification({
      userId: payment.buyerId,
      type: NotificationType.SYSTEM,
      title: "Dispute Filed",
      message: "Your dispute has been filed and is under review.",
      data: { paymentId: payment.id, transactionId: payment.transactionId },
    })

    await NotificationService.createNotification({
      userId: payment.sellerId,
      type: NotificationType.SYSTEM,
      title: "Dispute Filed",
      message: "A dispute has been filed for this transaction and is under review.",
      data: { paymentId: payment.id, transactionId: payment.transactionId },
    })

    // Save updated payment
    await db.collection("payments").doc(payment.id).update(payment)

    return payment
  },
}
