import { db } from "../index"
import { ElasticsearchService } from "./elasticsearch"
import type { Listing } from "../models/listing"
import { Timestamp } from "firebase-admin/firestore"

interface UserAction {
  userId: string
  listingId: string
  action: "view" | "favorite" | "message" | "purchase"
  timestamp: Timestamp
}

interface UserProfile {
  recentCategories: Map<string, number>
  recentTags: Map<string, number>
  priceRange: {
    min: number
    max: number
    avg: number
  }
  favoriteTeams: string[]
  favoritePlayers: string[]
}

export const RecommendationService = {
  // Get personalized recommendations for a user
  async getPersonalizedRecommendations(userId: string, limit = 10, context?: string): Promise<Listing[]> {
    // Build user profile based on their activity
    const userProfile = await this.buildUserProfile(userId)

    // If we don't have enough data for this user, fall back to popular items
    if (!userProfile) {
      return this.getPopularListings(limit)
    }

    // Build query based on user profile
    const must: any[] = []
    const should: any[] = []
    const filter: any[] = []

    // Only active listings
    filter.push({ term: { status: "active" } })

    // Context-aware filtering
    if (context === "homepage") {
      // For homepage, mix of personalized and trending
      should.push(
        ...this.buildCategoryBoosts(userProfile.recentCategories),
        ...this.buildTagBoosts(userProfile.recentTags),
      )
    } else if (context === "similar") {
      // For "similar items" section, focus more on category match
      must.push(...this.buildCategoryBoosts(userProfile.recentCategories, 0.8))
      should.push(...this.buildTagBoosts(userProfile.recentTags))
    } else {
      // Default personalization
      should.push(
        ...this.buildCategoryBoosts(userProfile.recentCategories),
        ...this.buildTagBoosts(userProfile.recentTags),
        ...this.buildPlayerBoosts(userProfile.favoritePlayers),
      )
    }

    // Price range preference (with some flexibility)
    const minPrice = Math.max(0, userProfile.priceRange.min * 0.7)
    const maxPrice = userProfile.priceRange.max * 1.3

    if (minPrice > 0 && maxPrice > minPrice) {
      filter.push({
        range: {
          price: {
            gte: minPrice,
            lte: maxPrice,
          },
        },
      })
    }

    // Get recently viewed items to exclude
    const recentlyViewed = await this.getRecentlyViewedListings(userId, 20)
    const mustNot = recentlyViewed.map((id) => ({ term: { _id: id } }))

    // Execute search with Elasticsearch
    const response = await ElasticsearchService.client.search({
      index: "listings",
      body: {
        query: {
          bool: {
            must,
            should,
            filter,
            must_not: mustNot,
            minimum_should_match: should.length > 0 ? 1 : 0,
          },
        },
        size: limit,
      },
    })

    // Format results
    return response.hits.hits.map((hit) => ({
      ...hit._source,
      id: hit._id,
    })) as Listing[]
  },

  // Build user profile based on their activity
  async buildUserProfile(userId: string): Promise<UserProfile | null> {
    // Get user actions from the last 30 days
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const actionsSnapshot = await db
      .collection("userActions")
      .where("userId", "==", userId)
      .where("timestamp", ">=", Timestamp.fromDate(thirtyDaysAgo))
      .orderBy("timestamp", "desc")
      .limit(100)
      .get()

    if (actionsSnapshot.empty) {
      return null
    }

    const actions: UserAction[] = []
    actionsSnapshot.forEach((doc) => {
      actions.push(doc.data() as UserAction)
    })

    // Get the listings associated with these actions
    const listingIds = [...new Set(actions.map((action) => action.listingId))]
    const listings: Listing[] = []

    // Batch get listings
    const chunks = this.chunkArray(listingIds, 10)
    for (const chunk of chunks) {
      const listingsSnapshot = await db.collection("listings").where("__name__", "in", chunk).get()

      listingsSnapshot.forEach((doc) => {
        listings.push({
          id: doc.id,
          ...doc.data(),
        } as Listing)
      })
    }

    // Build profile based on user actions and associated listings
    const recentCategories = new Map<string, number>()
    const recentTags = new Map<string, number>()
    const prices: number[] = []
    const teams = new Set<string>()
    const players = new Set<string>()

    // Weight actions by type and recency
    actions.forEach((action, index) => {
      const listing = listings.find((l) => l.id === action.listingId)
      if (!listing) return

      // Calculate weight based on action type and recency
      let weight = 1

      // Action type weight
      switch (action.action) {
        case "purchase":
          weight = 5
          break
        case "favorite":
          weight = 3
          break
        case "message":
          weight = 2
          break
        case "view":
          weight = 1
          break
      }

      // Recency weight (more recent = higher weight)
      const recencyWeight = 1 - (index / actions.length) * 0.5
      weight *= recencyWeight

      // Update category weights
      if (listing.category) {
        const currentWeight = recentCategories.get(listing.category) || 0
        recentCategories.set(listing.category, currentWeight + weight)
      }

      // Update tag weights
      if (listing.tags) {
        listing.tags.forEach((tag) => {
          const currentWeight = recentTags.get(tag) || 0
          recentTags.set(tag, currentWeight + weight)
        })
      }

      // Track prices
      prices.push(listing.price)

      // Track teams and players
      if (listing.accountDetails) {
        if (listing.accountDetails.team) {
          teams.add(listing.accountDetails.team)
        }

        if (listing.accountDetails.topPlayers && Array.isArray(listing.accountDetails.topPlayers)) {
          listing.accountDetails.topPlayers.forEach((player) => players.add(player))
        }
      }
    })

    // Calculate price statistics
    const priceRange = {
      min: Math.min(...prices),
      max: Math.max(...prices),
      avg: prices.reduce((sum, price) => sum + price, 0) / prices.length,
    }

    return {
      recentCategories,
      recentTags,
      priceRange,
      favoriteTeams: Array.from(teams),
      favoritePlayers: Array.from(players),
    }
  },

  // Get recently viewed listings for a user
  async getRecentlyViewedListings(userId: string, limit = 20): Promise<string[]> {
    const viewsSnapshot = await db
      .collection("userActions")
      .where("userId", "==", userId)
      .where("action", "==", "view")
      .orderBy("timestamp", "desc")
      .limit(limit)
      .get()

    const listingIds: string[] = []
    viewsSnapshot.forEach((doc) => {
      listingIds.push(doc.data().listingId)
    })

    return listingIds
  },

  // Get popular listings
  async getPopularListings(limit = 10): Promise<Listing[]> {
    const response = await ElasticsearchService.client.search({
      index: "listings",
      body: {
        query: {
          bool: {
            must: [{ term: { status: "active" } }],
          },
        },
        sort: [{ viewCount: { order: "desc" } }, { favoriteCount: { order: "desc" } }],
        size: limit,
      },
    })

    return response.hits.hits.map((hit) => ({
      ...hit._source,
      id: hit._id,
    })) as Listing[]
  },

  // Build category boost queries
  buildCategoryBoosts(categories: Map<string, number>, multiplier = 1): any[] {
    const boosts: any[] = []

    // Sort categories by weight
    const sortedCategories = [...categories.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)

    sortedCategories.forEach(([category, weight]) => {
      boosts.push({
        term: {
          category: {
            value: category,
            boost: weight * multiplier,
          },
        },
      })
    })

    return boosts
  },

  // Build tag boost queries
  buildTagBoosts(tags: Map<string, number>, multiplier = 1): any[] {
    const boosts: any[] = []

    // Sort tags by weight
    const sortedTags = [...tags.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10)

    sortedTags.forEach(([tag, weight]) => {
      boosts.push({
        term: {
          tags: {
            value: tag,
            boost: weight * multiplier,
          },
        },
      })
    })

    return boosts
  },

  // Build player boost queries
  buildPlayerBoosts(players: string[], multiplier = 1.5): any[] {
    return players.slice(0, 5).map((player) => ({
      term: {
        "accountDetails.topPlayers": {
          value: player,
          boost: multiplier,
        },
      },
    }))
  },

  // Utility to chunk array for batched operations
  chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = []
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size))
    }
    return chunks
  },
}
