import { db } from "../index"
import { v4 as uuidv4 } from "uuid"
import { UserService } from "./user-service"
import { NotificationService, NotificationType } from "./notification-service"

export enum EscrowStatus {
  PENDING = "pending",
  RELEASED = "released",
  REFUNDED = "refunded",
  DISPUTED = "disputed",
}

export interface Escrow {
  id: string
  paymentId: string
  sellerId: string
  amount: number
  status: EscrowStatus
  releaseDate: Date | null
  createdAt: Date
  updatedAt: Date
}

export const EscrowService = {
  // Create a new escrow
  async createEscrow(paymentId: string, sellerId: string, amount: number): Promise<Escrow> {
    // Calculate release date (3 days from now)
    const releaseDate = new Date()
    releaseDate.setDate(releaseDate.getDate() + 3)

    const escrow: Escrow = {
      id: uuidv4(),
      paymentId,
      sellerId,
      amount,
      status: EscrowStatus.PENDING,
      releaseDate,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await db.collection("escrows").doc(escrow.id).set(escrow)

    // Schedule automatic release
    this.scheduleEscrowRelease(escrow.id, releaseDate)

    return escrow
  },

  // Release funds from escrow to seller
  async releaseEscrow(paymentId: string, reason = "completed"): Promise<Escrow | null> {
    const snapshot = await db
      .collection("escrows")
      .where("paymentId", "==", paymentId)
      .where("status", "==", EscrowStatus.PENDING)
      .limit(1)
      .get()

    if (snapshot.empty) {
      return null
    }

    const escrowDoc = snapshot.docs[0]
    const escrow = escrowDoc.data() as Escrow

    // Update escrow status
    escrow.status = reason === "refunded" ? EscrowStatus.REFUNDED : EscrowStatus.RELEASED
    escrow.updatedAt = new Date()

    await escrowDoc.ref.update(escrow)

    // If released to seller, add funds to seller's balance
    if (escrow.status === EscrowStatus.RELEASED) {
      await UserService.updateUserBalance(escrow.sellerId, escrow.amount)

      // Notify seller
      await NotificationService.createNotification({
        userId: escrow.sellerId,
        type: NotificationType.PAYMENT_RECEIVED,
        title: "Funds Released",
        message: `$${(escrow.amount / 100).toFixed(2)} has been added to your balance.`,
        data: { escrowId: escrow.id, paymentId: escrow.paymentId },
      })
    }

    return escrow
  },

  // Get escrow by payment ID
  async getEscrowByPaymentId(paymentId: string): Promise<Escrow | null> {
    const snapshot = await db.collection("escrows").where("paymentId", "==", paymentId).limit(1).get()

    if (snapshot.empty) {
      return null
    }

    return snapshot.docs[0].data() as Escrow
  },

  // Get escrows for a seller
  async getSellerEscrows(sellerId: string, status?: EscrowStatus): Promise<Escrow[]> {
    let query = db.collection("escrows").where("sellerId", "==", sellerId)

    if (status) {
      query = query.where("status", "==", status)
    }

    const snapshot = await query.orderBy("createdAt", "desc").get()

    return snapshot.docs.map((doc) => doc.data() as Escrow)
  },

  // Schedule automatic release of escrow
  async scheduleEscrowRelease(escrowId: string, releaseDate: Date): Promise<void> {
    // In a production environment, this would use a task queue or scheduler
    // For now, we'll simulate it with a setTimeout

    const now = new Date()
    const delay = releaseDate.getTime() - now.getTime()

    if (delay <= 0) {
      // Release immediately if release date is in the past
      await this.processScheduledRelease(escrowId)
      return
    }

    // Schedule release
    setTimeout(async () => {
      await this.processScheduledRelease(escrowId)
    }, delay)
  },

  // Process scheduled release
  async processScheduledRelease(escrowId: string): Promise<void> {
    try {
      const escrowDoc = await db.collection("escrows").doc(escrowId).get()

      if (!escrowDoc.exists) {
        console.error(`Escrow ${escrowId} not found for scheduled release`)
        return
      }

      const escrow = escrowDoc.data() as Escrow

      // Only release if still pending
      if (escrow.status === EscrowStatus.PENDING) {
        // Update escrow status
        escrow.status = EscrowStatus.RELEASED
        escrow.updatedAt = new Date()

        await escrowDoc.ref.update(escrow)

        // Add funds to seller's balance
        await UserService.updateUserBalance(escrow.sellerId, escrow.amount)

        // Notify seller
        await NotificationService.createNotification({
          userId: escrow.sellerId,
          type: NotificationType.PAYMENT_RECEIVED,
          title: "Funds Released",
          message: `$${(escrow.amount / 100).toFixed(2)} has been added to your balance.`,
          data: { escrowId: escrow.id, paymentId: escrow.paymentId },
        })
      }
    } catch (error) {
      console.error("Error processing scheduled escrow release:", error)
    }
  },

  // Dispute escrow
  async disputeEscrow(paymentId: string, disputeDetails: any): Promise<Escrow | null> {
    const escrow = await this.getEscrowByPaymentId(paymentId)

    if (!escrow || escrow.status !== EscrowStatus.PENDING) {
      return null
    }

    // Update escrow status
    escrow.status = EscrowStatus.DISPUTED
    escrow.updatedAt = new Date()

    await db.collection("escrows").doc(escrow.id).update(escrow)

    // Store dispute details
    await db.collection("disputes").add({
      escrowId: escrow.id,
      paymentId,
      details: disputeDetails,
      status: "pending",
      createdAt: new Date(),
    })

    return escrow
  },
}
