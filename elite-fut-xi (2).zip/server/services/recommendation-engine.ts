import { db } from "../index"
import { ElasticsearchService } from "./elasticsearch"
import { RedisCacheService } from "./redis-cache"
import type { Listing } from "../models/listing"
import { UserService } from "./user-service"

interface RecommendationContext {
  userId?: string
  listingId?: string
  viewedListings?: string[]
  searchTerms?: string[]
  categories?: string[]
  priceRange?: { min: number; max: number }
  location?: string
  context?: "homepage" | "listing-detail" | "search-results" | "profile"
}

export class RecommendationEngine {
  // Cache TTL in seconds
  private static CACHE_TTL = {
    personalizedRecommendations: 3600, // 1 hour
    similarListings: 86400, // 24 hours
    popularListings: 1800, // 30 minutes
    trendingListings: 3600, // 1 hour
  }

  /**
   * Get personalized recommendations for a user
   */
  static async getPersonalizedRecommendations(
    userId: string,
    limit = 10,
    context: RecommendationContext = {},
  ): Promise<Listing[]> {
    // Try to get from cache first
    const cacheKey = `recommendations:user:${userId}:${context.context || "general"}:${limit}`
    const cachedRecommendations = await RedisCacheService.get(cacheKey)

    if (cachedRecommendations) {
      console.log("Returning cached personalized recommendations")
      return JSON.parse(cachedRecommendations)
    }

    try {
      // Get user profile and preferences
      const user = await UserService.getUserById(userId)
      if (!user) {
        return this.getPopularListings(limit)
      }

      // Get user's recent activity
      const userActivity = await this.getUserActivity(userId)

      // Build recommendation query based on user profile and activity
      const query = this.buildPersonalizedQuery(user, userActivity, context)

      // Execute search with Elasticsearch
      const results = await ElasticsearchService.searchListings(query)

      // Cache the results
      await RedisCacheService.set(cacheKey, JSON.stringify(results.results), this.CACHE_TTL.personalizedRecommendations)

      return results.results
    } catch (error) {
      console.error("Error getting personalized recommendations:", error)
      // Fallback to popular listings
      return this.getPopularListings(limit)
    }
  }

  /**
   * Get similar listings based on a specific listing
   */
  static async getSimilarListings(listingId: string, limit = 6): Promise<Listing[]> {
    // Try to get from cache first
    const cacheKey = `recommendations:similar:${listingId}:${limit}`
    const cachedRecommendations = await RedisCacheService.get(cacheKey)

    if (cachedRecommendations) {
      console.log("Returning cached similar listings")
      return JSON.parse(cachedRecommendations)
    }

    try {
      // Get the source listing
      const listingSnapshot = await db.collection("listings").doc(listingId).get()
      if (!listingSnapshot.exists) {
        throw new Error("Listing not found")
      }

      const listing = { id: listingSnapshot.id, ...listingSnapshot.data() } as Listing

      // Get similar listings using Elasticsearch's more_like_this query
      const results = await ElasticsearchService.getSimilarListings(listingId, limit)

      // Cache the results
      await RedisCacheService.set(cacheKey, JSON.stringify(results), this.CACHE_TTL.similarListings)

      return results
    } catch (error) {
      console.error("Error getting similar listings:", error)
      // Fallback to popular listings in the same category
      return this.getPopularListingsByCategory(listingId, limit)
    }
  }

  /**
   * Get popular listings (fallback recommendation)
   */
  static async getPopularListings(limit = 10): Promise<Listing[]> {
    // Try to get from cache first
    const cacheKey = `recommendations:popular:${limit}`
    const cachedRecommendations = await RedisCacheService.get(cacheKey)

    if (cachedRecommendations) {
      console.log("Returning cached popular listings")
      return JSON.parse(cachedRecommendations)
    }

    try {
      // Query for popular listings based on view count and favorite count
      const results = await ElasticsearchService.searchListings({
        sort: { field: "viewCount", order: "desc" },
        filters: { status: "active" },
        limit,
      })

      // Cache the results
      await RedisCacheService.set(cacheKey, JSON.stringify(results.results), this.CACHE_TTL.popularListings)

      return results.results
    } catch (error) {
      console.error("Error getting popular listings:", error)
      // Fallback to recent listings
      return this.getRecentListings(limit)
    }
  }

  /**
   * Get trending listings based on recent activity
   */
  static async getTrendingListings(limit = 10): Promise<Listing[]> {
    // Try to get from cache first
    const cacheKey = `recommendations:trending:${limit}`
    const cachedRecommendations = await RedisCacheService.get(cacheKey)

    if (cachedRecommendations) {
      console.log("Returning cached trending listings")
      return JSON.parse(cachedRecommendations)
    }

    try {
      // Get recent user actions (views, favorites, etc.)
      const actionsSnapshot = await db.collection("userActions").orderBy("timestamp", "desc").limit(500).get()

      // Count actions per listing
      const listingActionCounts: Record<string, number> = {}
      actionsSnapshot.forEach((doc) => {
        const action = doc.data()
        if (action.listingId) {
          listingActionCounts[action.listingId] = (listingActionCounts[action.listingId] || 0) + 1
        }
      })

      // Sort listings by action count
      const trendingListingIds = Object.entries(listingActionCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit * 2) // Get more than needed in case some are inactive
        .map(([id]) => id)

      // Get the actual listings
      const listingsSnapshot = await db
        .collection("listings")
        .where("status", "==", "active")
        .where("__name__", "in", trendingListingIds.slice(0, 10))
        .limit(limit)
        .get()

      const listings = listingsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Listing[]

      // Cache the results
      await RedisCacheService.set(cacheKey, JSON.stringify(listings), this.CACHE_TTL.trendingListings)

      return listings
    } catch (error) {
      console.error("Error getting trending listings:", error)
      // Fallback to popular listings
      return this.getPopularListings(limit)
    }
  }

  /**
   * Get recent listings
   */
  private static async getRecentListings(limit = 10): Promise<Listing[]> {
    try {
      const listingsSnapshot = await db
        .collection("listings")
        .where("status", "==", "active")
        .orderBy("createdAt", "desc")
        .limit(limit)
        .get()

      return listingsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Listing[]
    } catch (error) {
      console.error("Error getting recent listings:", error)
      return []
    }
  }

  /**
   * Get popular listings in a specific category
   */
  private static async getPopularListingsByCategory(listingId: string, limit = 6): Promise<Listing[]> {
    try {
      // Get the category of the source listing
      const listingSnapshot = await db.collection("listings").doc(listingId).get()
      if (!listingSnapshot.exists) {
        return this.getPopularListings(limit)
      }

      const listing = listingSnapshot.data() as Listing
      const category = listing.category

      if (!category) {
        return this.getPopularListings(limit)
      }

      // Get popular listings in the same category
      const results = await ElasticsearchService.searchListings({
        filters: {
          category,
          status: "active",
        },
        sort: { field: "viewCount", order: "desc" },
        limit,
      })

      return results.results
    } catch (error) {
      console.error("Error getting popular listings by category:", error)
      return this.getPopularListings(limit)
    }
  }

  /**
   * Get user's recent activity
   */
  private static async getUserActivity(userId: string) {
    try {
      // Get user's recent views
      const viewsSnapshot = await db
        .collection("userActions")
        .where("userId", "==", userId)
        .where("action", "==", "view")
        .orderBy("timestamp", "desc")
        .limit(50)
        .get()

      // Get user's recent searches
      const searchesSnapshot = await db
        .collection("searchAnalytics")
        .where("userId", "==", userId)
        .orderBy("timestamp", "desc")
        .limit(20)
        .get()

      // Get user's favorites
      const favoritesSnapshot = await db
        .collection("userActions")
        .where("userId", "==", userId)
        .where("action", "==", "favorite")
        .orderBy("timestamp", "desc")
        .limit(20)
        .get()

      return {
        viewedListings: viewsSnapshot.docs.map((doc) => doc.data().listingId),
        searches: searchesSnapshot.docs.map((doc) => doc.data()),
        favoriteListings: favoritesSnapshot.docs.map((doc) => doc.data().listingId),
      }
    } catch (error) {
      console.error("Error getting user activity:", error)
      return {
        viewedListings: [],
        searches: [],
        favoriteListings: [],
      }
    }
  }

  /**
   * Build personalized query based on user profile and activity
   */
  private static buildPersonalizedQuery(user: any, activity: any, context: RecommendationContext) {
    // Extract search terms from recent searches
    const searchTerms = activity.searches
      .map((search: any) => search.query)
      .filter((query: string) => query && query.length > 0)

    // Extract categories from viewed and favorited listings
    const listingIds = [...activity.viewedListings, ...activity.favoriteListings]

    // Build query
    const query: any = {
      filters: {
        status: "active",
        excludeListings: activity.viewedListings.slice(0, 20), // Exclude recently viewed
      },
      limit: context.limit || 10,
    }

    // Add search terms if available
    if (searchTerms.length > 0) {
      query.query = searchTerms.join(" ")
    }

    // Add context-specific parameters
    if (context.context === "listing-detail" && context.listingId) {
      query.similarTo = context.listingId
    }

    if (context.categories && context.categories.length > 0) {
      query.filters.category = context.categories
    }

    if (context.priceRange) {
      query.filters.minPrice = context.priceRange.min
      query.filters.maxPrice = context.priceRange.max
    }

    return query
  }

  /**
   * Record user action for future recommendations
   */
  static async recordUserAction(
    userId: string,
    action: "view" | "favorite" | "purchase" | "search",
    data: { listingId?: string; searchQuery?: string; category?: string },
  ) {
    try {
      await db.collection("userActions").add({
        userId,
        action,
        ...data,
        timestamp: new Date(),
      })

      // Invalidate relevant caches
      if (userId) {
        await RedisCacheService.delete(`recommendations:user:${userId}:*`)
      }

      if (data.listingId) {
        await RedisCacheService.delete(`recommendations:similar:${data.listingId}:*`)
      }
    } catch (error) {
      console.error("Error recording user action:", error)
    }
  }
}
