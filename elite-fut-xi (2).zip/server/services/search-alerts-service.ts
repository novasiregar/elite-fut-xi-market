import { db } from "../index"
import { ElasticsearchService } from "./elasticsearch"
import { NotificationService, NotificationType } from "./notification-service"
import { UserService } from "./user-service"

export class SearchAlertsService {
  /**
   * Process saved searches and send notifications for new matching listings
   */
  static async processSearchAlerts() {
    try {
      console.log("Processing search alerts...")

      // Get all saved searches with notifications enabled
      const savedSearchesSnapshot = await db.collection("savedSearches").where("notificationsEnabled", "==", true).get()

      console.log(`Found ${savedSearchesSnapshot.size} saved searches with notifications enabled`)

      // Process each saved search
      for (const doc of savedSearchesSnapshot.docs) {
        const savedSearch = doc.data()
        const savedSearchId = doc.id

        // Get the last notification time
        const lastNotified = savedSearch.lastNotified ? new Date(savedSearch.lastNotified) : new Date(0) // Beginning of time if never notified

        // Build Elasticsearch query
        const query: any = {}

        if (savedSearch.query) {
          query.query = savedSearch.query
        }

        if (savedSearch.filters) {
          query.filters = savedSearch.filters
        }

        // Only get listings created after the last notification
        query.filters = {
          ...query.filters,
          createdAfter: lastNotified.toISOString(),
          status: "active",
        }

        // Execute search
        const results = await ElasticsearchService.searchListings(query)

        // If there are new listings, send a notification
        if (results.results.length > 0) {
          console.log(`Found ${results.results.length} new listings for saved search ${savedSearchId}`)

          // Get user
          const user = await UserService.getUserById(savedSearch.userId)

          if (!user) {
            console.error(`User ${savedSearch.userId} not found`)
            continue
          }

          // Create notification
          await NotificationService.createNotification({
            userId: savedSearch.userId,
            type: NotificationType.SAVED_SEARCH_MATCH,
            title: "New listings match your saved search",
            message: `${results.results.length} new listings match your saved search "${savedSearch.name}"`,
            data: {
              savedSearchId,
              resultCount: results.results.length,
              previewListings: results.results.slice(0, 3).map((listing) => ({
                id: listing.id,
                title: listing.title,
                price: listing.price,
                imageUrl: listing.media?.[0]?.url,
              })),
            },
          })

          // Update last notified time
          await db
            .collection("savedSearches")
            .doc(savedSearchId)
            .update({
              lastNotified: new Date().toISOString(),
              resultCount: savedSearch.resultCount + results.results.length,
            })
        } else {
          console.log(`No new listings for saved search ${savedSearchId}`)
        }
      }

      console.log("Finished processing search alerts")
    } catch (error) {
      console.error("Error processing search alerts:", error)
    }
  }
}
