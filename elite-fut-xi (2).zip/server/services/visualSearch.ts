import { ImageAnnotatorClient } from "@google-cloud/vision"
import { v4 as uuidv4 } from "uuid"
import { ElasticsearchService } from "./elasticsearch"
import { db, storage } from "../index"
import type { Listing } from "../models/listing"

// Initialize Google Cloud Vision client
const visionClient = new ImageAnnotatorClient()

interface DetectedObject {
  name: string
  score: number
  boundingBox: {
    x: number
    y: number
    width: number
    height: number
  }
}

interface VisualSearchResult {
  results: Listing[]
  detectedObjects: DetectedObject[]
}

export const VisualSearchService = {
  // Search by image
  async searchByImage(imageBuffer: Buffer, limit = 12): Promise<VisualSearchResult> {
    // Upload image to temporary storage
    const fileName = `temp/visual-search/${uuidv4()}.jpg`
    const bucket = storage.bucket()
    const file = bucket.file(fileName)

    await file.save(imageBuffer, {
      metadata: {
        contentType: "image/jpeg",
      },
    })

    // Make file publicly accessible (temporary)
    await file.makePublic()

    const imageUrl = `https://storage.googleapis.com/${bucket.name}/${fileName}`

    try {
      // Analyze image with Google Cloud Vision
      const [result] = await visionClient.annotateImage({
        image: { source: { imageUri: imageUrl } },
        features: [
          { type: "LABEL_DETECTION", maxResults: 10 },
          { type: "LOGO_DETECTION", maxResults: 5 },
          { type: "OBJECT_LOCALIZATION", maxResults: 10 },
          { type: "TEXT_DETECTION" },
        ],
      })

      // Extract detected objects, labels, logos, and text
      const detectedObjects: DetectedObject[] = []
      const searchTerms: string[] = []
      const boostTerms: Map<string, number> = new Map()

      // Process labels
      if (result.labelAnnotations) {
        result.labelAnnotations.forEach((label) => {
          if (label.description && label.score && label.score > 0.7) {
            searchTerms.push(label.description)
            boostTerms.set(label.description.toLowerCase(), label.score)
          }
        })
      }

      // Process logos (higher confidence for FIFA, EA, etc.)
      if (result.logoAnnotations) {
        result.logoAnnotations.forEach((logo) => {
          if (logo.description) {
            searchTerms.push(logo.description)
            boostTerms.set(logo.description.toLowerCase(), 2) // Higher weight for logos
          }
        })
      }

      // Process localized objects
      if (result.localizedObjectAnnotations) {
        result.localizedObjectAnnotations.forEach((object) => {
          if (object.name && object.score) {
            searchTerms.push(object.name)

            // Add to detected objects for UI highlighting
            if (object.boundingPoly && object.boundingPoly.normalizedVertices) {
              const vertices = object.boundingPoly.normalizedVertices

              if (vertices.length >= 4) {
                // Calculate bounding box from normalized vertices
                const minX = Math.min(...vertices.map((v) => v.x || 0))
                const minY = Math.min(...vertices.map((v) => v.y || 0))
                const maxX = Math.max(...vertices.map((v) => v.x || 0))
                const maxY = Math.max(...vertices.map((v) => v.y || 0))

                detectedObjects.push({
                  name: object.name,
                  score: object.score,
                  boundingBox: {
                    x: minX,
                    y: minY,
                    width: maxX - minX,
                    height: maxY - minY,
                  },
                })
              }
            }
          }
        })
      }

      // Process text (useful for player names, team names, etc.)
      if (result.textAnnotations && result.textAnnotations.length > 0) {
        // Skip the first one which is the entire text
        const textAnnotations = result.textAnnotations.slice(1)

        // Extract potential player names, team names, or relevant terms
        const potentialTerms = textAnnotations
          .map((annotation) => annotation.description)
          .filter((text) => text && text.length > 3) // Filter out short text

        // Check against known player/team names in our database
        const relevantTerms = await this.filterRelevantTerms(potentialTerms)

        relevantTerms.forEach((term) => {
          searchTerms.push(term)
          boostTerms.set(term.toLowerCase(), 1.5) // Higher weight for recognized names
        })
      }

      // If we have FIFA-specific terms, boost them
      const fifaTerms = ["fifa", "fut", "ultimate team", "ea sports"]
      fifaTerms.forEach((term) => {
        if (searchTerms.some((t) => t.toLowerCase().includes(term))) {
          boostTerms.set(term, 2)
        }
      })

      // Build Elasticsearch query
      const should: any[] = []

      // Add text search
      if (searchTerms.length > 0) {
        should.push({
          multi_match: {
            query: searchTerms.join(" "),
            fields: ["title^3", "description^2", "tags^2", "accountDetails.topPlayers^2"],
            type: "best_fields",
            fuzziness: "AUTO",
          },
        })
      }

      // Add boosted terms
      boostTerms.forEach((boost, term) => {
        should.push({
          term: {
            title: {
              value: term,
              boost: boost * 3,
            },
          },
        })

        should.push({
          term: {
            tags: {
              value: term,
              boost: boost * 2,
            },
          },
        })

        should.push({
          term: {
            "accountDetails.topPlayers": {
              value: term,
              boost: boost * 2.5,
            },
          },
        })
      })

      // Execute search
      const response = await ElasticsearchService.client.search({
        index: "listings",
        body: {
          query: {
            bool: {
              must: [{ term: { status: "active" } }],
              should,
              minimum_should_match: 1,
            },
          },
          size: limit,
        },
      })

      // Format results
      const listings = response.hits.hits.map((hit) => ({
        ...hit._source,
        id: hit._id,
        score: hit._score,
      })) as Listing[]

      return {
        results: listings,
        detectedObjects,
      }
    } finally {
      // Clean up temporary file
      await file.delete().catch((err) => console.error("Error deleting temp file:", err))
    }
  },

  // Filter text annotations against known player/team names
  async filterRelevantTerms(terms: string[]): Promise<string[]> {
    // This would ideally check against a database of known player names, team names, etc.
    // For simplicity, we'll use a basic approach here

    // Convert terms to lowercase for comparison
    const normalizedTerms = terms.map((term) => term.toLowerCase())

    // Get common FIFA terms from our database
    const termsSnapshot = await db.collection("metadata").doc("searchTerms").get()
    const knownTerms: Record<string, number> = termsSnapshot.exists ? termsSnapshot.data()?.terms || {} : {}

    // Filter terms that match known terms
    const relevantTerms: string[] = []

    normalizedTerms.forEach((term) => {
      // Check for exact matches
      if (knownTerms[term]) {
        relevantTerms.push(term)
        return
      }

      // Check for partial matches (for player names, etc.)
      for (const knownTerm in knownTerms) {
        if (knownTerm.includes(term) || term.includes(knownTerm)) {
          relevantTerms.push(term)
          break
        }
      }
    })

    return relevantTerms
  },
}
