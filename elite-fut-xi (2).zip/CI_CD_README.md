# CI/CD Pipeline for ELITE FUT XI Market

This document describes the Continuous Integration and Continuous Deployment (CI/CD) pipeline for the ELITE FUT XI Market application.

## Overview

Our CI/CD pipeline automates the testing, building, and deployment of the application to ensure high quality and reliability. The pipeline is implemented using GitHub Actions and consists of the following stages:

1. **Lint and Test**: Runs code linting and automated tests
2. **Build**: Builds the application for deployment
3. **Deploy to Staging**: Deploys the application to the staging environment (from the `develop` branch)
4. **Deploy to Production**: Deploys the application to the production environment (from the `main` branch)

## Workflow Diagram

\`\`\`
[Code Push/PR] → [Lint & Test] → [Build] → [Deploy to Staging/Production]
                      ↓
                 [Notifications]
\`\`\`

## Environments

- **Staging**: https://staging.elitefutxi.com
  - Deployed from the `develop` branch
  - Used for testing new features before they go to production
  - Less restrictive resource limits

- **Production**: https://elitefutxi.com
  - Deployed from the `main` branch
  - The live environment used by customers
  - Optimized for performance and reliability

## GitHub Actions Workflow

The CI/CD pipeline is defined in `.github/workflows/main.yml` and includes:

- **Lint and Test**: Runs ESLint for code quality and Jest for unit tests
- **Build**: Builds the Next.js application
- **Deploy to Staging**: Deploys to Google App Engine staging environment
- **Deploy to Production**: Deploys to Google App Engine production environment

## Quality Gates

The pipeline includes several quality gates to ensure code quality:

- **Linting**: Ensures code follows style guidelines
- **Type Checking**: Verifies TypeScript types
- **Unit Tests**: Tests individual components and functions
- **Coverage Thresholds**: Ensures adequate test coverage
- **Lighthouse CI**: Checks performance, accessibility, and best practices

## Secrets and Environment Variables

The pipeline uses the following secrets:

- `GCP_SA_KEY`: Google Cloud service account key
- `GCP_PROJECT_ID`: Google Cloud project ID
- `NEXT_PUBLIC_FIREBASE_*`: Firebase configuration
- `ELASTICSEARCH_*`: Elasticsearch configuration
- `REDIS_URL`: Redis connection string
- `SLACK_WEBHOOK`: Webhook for Slack notifications

## Deployment Process

1. Code is pushed to a branch or a pull request is created
2. GitHub Actions runs the lint and test workflow
3. If tests pass and the code is pushed to `develop` or `main`, the build workflow runs
4. Based on the branch, the code is deployed to staging or production
5. Notifications are sent upon successful deployment

## Monitoring and Rollbacks

- Deployments are monitored using Google Cloud Monitoring
- Rollbacks can be performed through the Google Cloud Console or by redeploying a previous version

## Local Development vs CI Environment

The CI environment closely mirrors the production environment but with the following differences:

- Uses Docker containers for services
- Runs with minimal resources
- Uses test databases and credentials

## Adding New Tests

When adding new features, make sure to:

1. Add unit tests in the `__tests__` directory
2. Add end-to-end tests in the `cypress/e2e` directory
3. Ensure all tests pass locally before pushing

## Troubleshooting

If the CI/CD pipeline fails:

1. Check the GitHub Actions logs for error messages
2. Verify that all tests pass locally
3. Ensure all environment variables are properly set
4. Check for dependency issues or version conflicts
