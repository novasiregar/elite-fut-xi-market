"use client"

// Types of haptic feedback
export enum HapticType {
  LIGHT = "light",
  MEDIUM = "medium",
  HEAVY = "heavy",
  SUCCESS = "success",
  WARNING = "warning",
  ERROR = "error",
  SELECTION = "selection",
}

// Check if the device supports vibration
const hasVibration = () => {
  return typeof window !== "undefined" && "vibrate" in navigator
}

// Vibration patterns (in milliseconds)
const PATTERNS = {
  [HapticType.LIGHT]: [10],
  [HapticType.MEDIUM]: [30],
  [HapticType.HEAVY]: [50],
  [HapticType.SUCCESS]: [10, 30, 10],
  [HapticType.WARNING]: [30, 50, 30],
  [HapticType.ERROR]: [50, 30, 50, 30, 50],
  [HapticType.SELECTION]: [5],
}

// Trigger haptic feedback
export const triggerHaptic = (type: HapticType = HapticType.LIGHT) => {
  if (!hasVibration()) return

  try {
    navigator.vibrate(PATTERNS[type])
  } catch (error) {
    console.error("Haptic feedback error:", error)
  }
}

// Haptic feedback with sound
export const triggerHapticWithSound = (type: HapticType = HapticType.LIGHT, volume = 0.1) => {
  triggerHaptic(type)

  // Add sound feedback
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    // Set sound properties based on haptic type
    switch (type) {
      case HapticType.SUCCESS:
        oscillator.type = "sine"
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime) // A5
        oscillator.frequency.exponentialRampToValueAtTime(1760, audioContext.currentTime + 0.1) // A6
        gainNode.gain.setValueAtTime(volume, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        oscillator.start()
        oscillator.stop(audioContext.currentTime + 0.2)
        break

      case HapticType.ERROR:
        oscillator.type = "sawtooth"
        oscillator.frequency.setValueAtTime(220, audioContext.currentTime) // A3
        oscillator.frequency.exponentialRampToValueAtTime(110, audioContext.currentTime + 0.2) // A2
        gainNode.gain.setValueAtTime(volume, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3)
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        oscillator.start()
        oscillator.stop(audioContext.currentTime + 0.3)
        break

      case HapticType.WARNING:
        oscillator.type = "triangle"
        oscillator.frequency.setValueAtTime(440, audioContext.currentTime) // A4
        gainNode.gain.setValueAtTime(volume, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        oscillator.start()
        oscillator.stop(audioContext.currentTime + 0.2)
        break

      default:
        oscillator.type = "sine"
        oscillator.frequency.setValueAtTime(440, audioContext.currentTime) // A4
        gainNode.gain.setValueAtTime(volume * 0.5, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        oscillator.start()
        oscillator.stop(audioContext.currentTime + 0.1)
    }
  } catch (error) {
    console.error("Audio feedback error:", error)
  }
}

// Create a context for haptic settings
import { createContext, useContext, useState, type ReactNode } from "react"

interface HapticContextType {
  enabled: boolean
  toggleHaptic: () => void
  trigger: (type?: HapticType) => void
  triggerWithSound: (type?: HapticType, volume?: number) => void
}

const HapticContext = createContext<HapticContextType>({
  enabled: true,
  toggleHaptic: () => {},
  trigger: () => {},
  triggerWithSound: () => {},
})

export const HapticProvider = ({ children }: { children: ReactNode }) => {
  const [enabled, setEnabled] = useState(true)

  const toggleHaptic = () => {
    setEnabled((prev) => !prev)
  }

  const trigger = (type?: HapticType) => {
    if (enabled) {
      triggerHaptic(type)
    }
  }

  const triggerWithSound = (type?: HapticType, volume?: number) => {
    if (enabled) {
      triggerHapticWithSound(type, volume)
    }
  }

  return (
    <HapticContext.Provider value={{ enabled, toggleHaptic, trigger, triggerWithSound }}>
      {children}
    </HapticContext.Provider>
  )
}

export const useHaptic = () => useContext(HapticContext)
