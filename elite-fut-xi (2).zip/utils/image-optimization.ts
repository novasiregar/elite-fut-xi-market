export type OptimizedImage = {
  src: string
  blurDataURL?: string
  width?: number
  height?: number
  type?: string
  size?: number
}

/**
 * Generates optimized image data including blur placeholders
 * Client-side compatible version
 */
export async function getOptimizedImage(src: string): Promise<OptimizedImage> {
  try {
    // For client-side, we can only return the source
    return {
      src,
      blurDataURL: "",
    }
  } catch (error) {
    console.error("Error optimizing image:", error)
    // Return original source without optimization as fallback
    return {
      src,
      blurDataURL: "",
    }
  }
}

/**
 * Batch process multiple images
 */
export async function getOptimizedImages(sources: string[]): Promise<OptimizedImage[]> {
  return Promise.all(sources.map((src) => getOptimizedImage(src)))
}

/**
 * Generate responsive image srcSet based on width
 */
export function generateSrcSet(src: string, width: number): string {
  if (!src.startsWith("http") || !width) return ""

  const sizes = [0.25, 0.5, 0.75, 1, 1.5, 2].map((scale) => Math.round(width * scale))

  // For Firebase Storage URLs, we can add width parameters
  if (src.includes("firebasestorage.googleapis.com")) {
    return sizes.map((size) => `${src}&width=${size} ${size}w`).join(", ")
  }

  // For other URLs, we'd need a proper image resizing service
  return ""
}
