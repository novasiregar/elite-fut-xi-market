// Deep linking utility for ELITE FUT XI Market

// Define the structure of deep link parameters
interface DeepLinkParams {
  [key: string]: string
}

// Define the structure of a deep link configuration
interface DeepLinkConfig {
  route: string
  params?: DeepLinkParams
}

// Base URL for the app
const APP_BASE_URL = "https://elitefutxi.market"
const APP_SCHEME = "elitefutxi://"

/**
 * Generate a deep link URL for the app
 * @param config Deep link configuration
 * @param useAppScheme Whether to use the app scheme (for native app) or web URL
 * @returns Deep link URL
 */
export function generateDeepLink(config: DeepLinkConfig, useAppScheme = false): string {
  const { route, params = {} } = config

  // Start with the base
  const base = useAppScheme ? APP_SCHEME : APP_BASE_URL

  // Build the URL
  let url = `${base}${route.startsWith("/") ? route.substring(1) : route}`

  // Add query parameters if any
  if (Object.keys(params).length > 0) {
    const queryString = Object.entries(params)
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join("&")

    url += `?${queryString}`
  }

  return url
}

/**
 * Parse a deep link URL to extract route and parameters
 * @param url Deep link URL
 * @returns Parsed deep link configuration
 */
export function parseDeepLink(url: string): DeepLinkConfig | null {
  try {
    // Handle both app scheme and web URLs
    let processedUrl = url

    if (url.startsWith(APP_SCHEME)) {
      // Convert app scheme URL to web URL for parsing
      processedUrl = url.replace(APP_SCHEME, "https://")
    }

    const urlObj = new URL(processedUrl)
    const route = urlObj.pathname

    // Extract query parameters
    const params: DeepLinkParams = {}
    urlObj.searchParams.forEach((value, key) => {
      params[key] = value
    })

    return { route, params }
  } catch (error) {
    console.error("Failed to parse deep link:", error)
    return null
  }
}

/**
 * Handle incoming deep links
 * @param url Deep link URL
 * @returns Whether the deep link was handled successfully
 */
export function handleDeepLink(url: string): boolean {
  const parsedLink = parseDeepLink(url)

  if (!parsedLink) {
    return false
  }

  // Here you would typically navigate to the appropriate route
  // This is a placeholder for the actual implementation
  console.log("Handling deep link:", parsedLink)

  // Return true to indicate the deep link was handled
  return true
}

/**
 * Generate a sharing message with deep link
 * @param config Deep link configuration
 * @param message Optional message to include
 * @returns Sharing message with deep link
 */
export function generateShareMessage(config: DeepLinkConfig, message?: string): string {
  const deepLink = generateDeepLink(config)

  if (message) {
    return `${message}\n\n${deepLink}`
  }

  return deepLink
}

/**
 * Share content with a deep link
 * @param config Deep link configuration
 * @param title Title for the share dialog
 * @param message Message to share
 * @returns Promise that resolves when sharing is complete
 */
export async function shareWithDeepLink(config: DeepLinkConfig, title: string, message?: string): Promise<boolean> {
  try {
    if (navigator.share) {
      // Use Web Share API if available
      await navigator.share({
        title,
        text: message || "",
        url: generateDeepLink(config),
      })
      return true
    } else {
      // Fallback to clipboard
      const shareText = generateShareMessage(config, message)
      await navigator.clipboard.writeText(shareText)
      return true
    }
  } catch (error) {
    console.error("Failed to share:", error)
    return false
  }
}

/**
 * Register deep link handlers
 * This should be called in a client component, typically at the app root
 */
export function registerDeepLinkHandlers(): void {
  if (typeof window === "undefined") {
    return
  }

  // Handle deep links when the app is already running
  window.addEventListener("popstate", () => {
    const url = window.location.href
    handleDeepLink(url)
  })

  // Handle initial deep link if present
  const initialUrl = window.location.href
  if (initialUrl) {
    handleDeepLink(initialUrl)
  }
}
