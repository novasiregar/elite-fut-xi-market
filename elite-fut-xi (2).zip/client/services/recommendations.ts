import { api } from "./auth"
import type { Listing } from "./listings"

export interface RecommendationParams {
  context?: "homepage" | "listing-detail" | "search-results" | "profile"
  listingId?: string
  categories?: string[]
  priceRange?: { min: number; max: number }
  limit?: number
}

export const RecommendationService = {
  // Get personalized recommendations
  async getPersonalizedRecommendations(params: RecommendationParams = {}): Promise<Listing[]> {
    try {
      // Build query parameters
      const queryParams = new URLSearchParams()

      if (params.context) {
        queryParams.append("context", params.context)
      }

      if (params.listingId) {
        queryParams.append("listingId", params.listingId)
      }

      if (params.categories && params.categories.length > 0) {
        params.categories.forEach((category) => queryParams.append("categories", category))
      }

      if (params.priceRange) {
        queryParams.append("minPrice", params.priceRange.min.toString())
        queryParams.append("maxPrice", params.priceRange.max.toString())
      }

      if (params.limit) {
        queryParams.append("limit", params.limit.toString())
      }

      const response = await api.get(`/recommendations?${queryParams.toString()}`)
      return response.data.recommendations
    } catch (error) {
      console.error("Error getting personalized recommendations:", error)
      throw error
    }
  },

  // Get similar listings
  async getSimilarListings(listingId: string, limit = 6): Promise<Listing[]> {
    try {
      const response = await api.get(`/search/similar/${listingId}?limit=${limit}`)
      return response.data.listings
    } catch (error) {
      console.error("Error getting similar listings:", error)
      throw error
    }
  },

  // Get trending listings
  async getTrendingListings(limit = 10): Promise<Listing[]> {
    try {
      const response = await api.get(`/recommendations/trending?limit=${limit}`)
      return response.data.listings
    } catch (error) {
      console.error("Error getting trending listings:", error)
      throw error
    }
  },

  // Record recommendation click
  async recordRecommendationClick(listingId: string, context?: string): Promise<void> {
    try {
      await api.post("/recommendations/recommendation-click", {
        listingId,
        context: context || "general",
      })
    } catch (error) {
      console.error("Error recording recommendation click:", error)
      // Don't throw here to prevent disrupting user experience
    }
  },
}
