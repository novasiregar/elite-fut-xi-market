// Mock implementation of the ReferralService
export class ReferralService {
  static async getReferralData() {
    // In a real implementation, this would fetch data from your backend
    return {
      referralCode: "ELITE25",
      referralLink: "https://elitefutxi.com/register?ref=ELITE25",
      referralCount: 5,
      pendingReferrals: 2,
      completedReferrals: 3,
      totalEarnings: 150000,
      availableBalance: 100000,
      referralHistory: [
        {
          id: "ref1",
          userId: "user1",
          username: "Dian Sastro",
          date: "2023-05-15",
          status: "completed",
          amount: 50000,
        },
        {
          id: "ref2",
          userId: "user2",
          username: "Rudi Hartono",
          date: "2023-04-28",
          status: "completed",
          amount: 50000,
        },
        {
          id: "ref3",
          userId: "user3",
          username: "Ahmad Rizki",
          date: "2023-05-20",
          status: "pending",
          amount: 50000,
        },
        {
          id: "ref4",
          userId: "user4",
          username: "Budi Santoso",
          date: "2023-05-19",
          status: "pending",
          amount: 50000,
        },
      ],
      rewards: [
        {
          tier: 1,
          requirement: 5,
          bonus: 50000,
        },
        {
          tier: 2,
          requirement: 10,
          bonus: 150000,
        },
        {
          tier: 3,
          requirement: 25,
          bonus: 500000,
        },
      ],
    }
  }

  static async generateReferralCode(userId: string) {
    // In a real implementation, this would generate a unique code on the backend
    return "ELITE" + Math.floor(Math.random() * 1000)
  }

  static async claimReward(rewardId: string) {
    // In a real implementation, this would process the reward claim
    return {
      success: true,
      message: "Reward claimed successfully",
      amount: 50000,
    }
  }

  static async withdrawBalance(amount: number) {
    // In a real implementation, this would process the withdrawal
    return {
      success: true,
      message: "Withdrawal processed successfully",
      transactionId: "txn_" + Math.random().toString(36).substring(2, 15),
    }
  }
}
