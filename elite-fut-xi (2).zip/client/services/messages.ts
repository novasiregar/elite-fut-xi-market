import { api } from "./auth"
import crypto from "crypto"

export interface Conversation {
  id: string
  participants: string[]
  createdAt: string
  updatedAt: string
  lastMessage: string
  lastMessageSentBy: string
  lastMessageTimestamp: string
  listingId?: string
  otherParticipant: {
    id: string
    displayName: string
    avatar: string | null
  }
  unreadCount: number
}

export interface Message {
  id: string
  conversationId: string
  senderId: string
  content: string
  isEncrypted: boolean
  createdAt: string
  read: boolean
}

export const MessageService = {
  // Create a new conversation
  createConversation: async (recipientId: string, initialMessage: string, listingId?: string) => {
    try {
      const response = await api.post("/messages/conversations", {
        recipientId,
        initialMessage,
        listingId,
      })
      return response.data
    } catch (error) {
      console.error("Create conversation error:", error)
      throw error
    }
  },

  // Get all conversations for current user
  getConversations: async () => {
    try {
      const response = await api.get("/messages/conversations")
      return response.data
    } catch (error) {
      console.error("Get conversations error:", error)
      throw error
    }
  },

  // Get messages for a conversation
  getMessages: async (conversationId: string) => {
    try {
      const response = await api.get(`/messages/conversations/${conversationId}`)

      // Decrypt messages if they are encrypted and we have the private key
      const privateKey = localStorage.getItem("privateKey")

      if (privateKey) {
        const messages = response.data.messages

        for (const message of messages) {
          if (message.isEncrypted) {
            try {
              const decrypted = crypto
                .privateDecrypt(
                  {
                    key: privateKey,
                    padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                  },
                  Buffer.from(message.content, "base64"),
                )
                .toString()

              message.content = decrypted
            } catch (e) {
              console.error("Failed to decrypt message:", e)
              message.content = "[Encrypted message - cannot decrypt]"
            }
          }
        }
      }

      return response.data
    } catch (error) {
      console.error("Get messages error:", error)
      throw error
    }
  },

  // Send a message
  sendMessage: async (conversationId: string, message: string) => {
    try {
      const response = await api.post(`/messages/conversations/${conversationId}/messages`, {
        message,
      })
      return response.data
    } catch (error) {
      console.error("Send message error:", error)
      throw error
    }
  },

  // Store private key securely in local storage
  storePrivateKey: (privateKey: string) => {
    localStorage.setItem("privateKey", privateKey)
  },

  // Get private key from local storage
  getPrivateKey: () => {
    return localStorage.getItem("privateKey")
  },

  // Clear private key from local storage
  clearPrivateKey: () => {
    localStorage.removeItem("privateKey")
  },
}
