import { initializeApp } from "firebase/app"
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  GoogleAuthProvider,
  FacebookAuthProvider,
  OAuthProvider,
  signInWithPopup,
  type User,
  onAuthStateChanged,
  linkWithPopup,
} from "firebase/auth"
import { getFirestore, doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import axios from "axios"

// Firebase configuration
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)

// API base URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"

// Set up axios with auth token
export const api = axios.create({
  baseURL: API_URL,
})

// Add auth token to requests
auth.onAuthStateChanged(async (user) => {
  if (user) {
    const token = await user.getIdToken()
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`
  } else {
    delete api.defaults.headers.common["Authorization"]
  }
})

// Auth service
export const AuthService = {
  // Register with email and password
  register: async (email: string, password: string, displayName: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const user = userCredential.user

      // Update profile
      await updateProfile(user, { displayName })

      // Create user document in Firestore
      await setDoc(doc(db, "users", user.uid), {
        email,
        displayName,
        createdAt: serverTimestamp(),
        isVerified: false,
        role: "user",
        profileComplete: false,
      })

      return user
    } catch (error) {
      console.error("Registration error:", error)
      throw error
    }
  },

  // Login with email and password
  login: async (email: string, password: string) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      return userCredential.user
    } catch (error) {
      console.error("Login error:", error)
      throw error
    }
  },

  // Login with Google
  loginWithGoogle: async () => {
    try {
      const provider = new GoogleAuthProvider()
      provider.addScope("email")
      provider.addScope("profile")

      const userCredential = await signInWithPopup(auth, provider)
      const user = userCredential.user

      // Check if user document exists
      const userDoc = await getDoc(doc(db, "users", user.uid))

      if (!userDoc.exists()) {
        // Create user document in Firestore
        await setDoc(doc(db, "users", user.uid), {
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          createdAt: serverTimestamp(),
          isVerified: user.emailVerified,
          role: "user",
          profileComplete: false,
          authProvider: "google",
        })
      }

      return user
    } catch (error) {
      console.error("Google login error:", error)
      throw error
    }
  },

  // Login with Facebook
  loginWithFacebook: async () => {
    try {
      const provider = new FacebookAuthProvider()
      provider.addScope("email")
      provider.addScope("public_profile")

      const userCredential = await signInWithPopup(auth, provider)
      const user = userCredential.user

      // Check if user document exists
      const userDoc = await getDoc(doc(db, "users", user.uid))

      if (!userDoc.exists()) {
        // Create user document in Firestore
        await setDoc(doc(db, "users", user.uid), {
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          createdAt: serverTimestamp(),
          isVerified: user.emailVerified,
          role: "user",
          profileComplete: false,
          authProvider: "facebook",
        })
      }

      return user
    } catch (error) {
      console.error("Facebook login error:", error)
      throw error
    }
  },

  // Login with Discord
  loginWithDiscord: async () => {
    try {
      const provider = new OAuthProvider("discord.com")
      provider.addScope("identify")
      provider.addScope("email")

      const userCredential = await signInWithPopup(auth, provider)
      const user = userCredential.user
      const credential = OAuthProvider.credentialFromResult(userCredential)

      // Check if user document exists
      const userDoc = await getDoc(doc(db, "users", user.uid))

      if (!userDoc.exists()) {
        // Create user document in Firestore
        await setDoc(doc(db, "users", user.uid), {
          email: user.email,
          displayName: user.displayName || user.email?.split("@")[0],
          photoURL: user.photoURL,
          createdAt: serverTimestamp(),
          isVerified: user.emailVerified,
          role: "user",
          profileComplete: false,
          authProvider: "discord",
          discordId: credential?.accessToken ? await getDiscordUserId(credential.accessToken) : null,
        })
      }

      return user
    } catch (error) {
      console.error("Discord login error:", error)
      throw error
    }
  },

  // Link accounts
  linkWithSocialProvider: async (providerName: "google" | "facebook" | "discord") => {
    try {
      const currentUser = auth.currentUser
      if (!currentUser) throw new Error("No user is currently logged in")

      let provider

      switch (providerName) {
        case "google":
          provider = new GoogleAuthProvider()
          provider.addScope("email")
          provider.addScope("profile")
          break
        case "facebook":
          provider = new FacebookAuthProvider()
          provider.addScope("email")
          provider.addScope("public_profile")
          break
        case "discord":
          provider = new OAuthProvider("discord.com")
          provider.addScope("identify")
          provider.addScope("email")
          break
        default:
          throw new Error("Invalid provider")
      }

      const result = await linkWithPopup(currentUser, provider)

      // Update user document
      await setDoc(
        doc(db, "users", currentUser.uid),
        {
          linkedProviders: {
            [providerName]: true,
          },
        },
        { merge: true },
      )

      return result.user
    } catch (error) {
      console.error(`Link with ${providerName} error:`, error)
      throw error
    }
  },

  // Logout
  logout: async () => {
    try {
      await signOut(auth)
    } catch (error) {
      console.error("Logout error:", error)
      throw error
    }
  },

  // Reset password
  resetPassword: async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email)
    } catch (error) {
      console.error("Reset password error:", error)
      throw error
    }
  },

  // Get current user
  getCurrentUser: (): User | null => {
    return auth.currentUser
  },

  // Get user profile from API
  getUserProfile: async () => {
    try {
      const response = await api.get("/auth/profile")
      return response.data
    } catch (error) {
      console.error("Get user profile error:", error)
      throw error
    }
  },

  // Update user profile
  updateUserProfile: async (data: any) => {
    try {
      const response = await api.put("/auth/profile", data)
      return response.data
    } catch (error) {
      console.error("Update user profile error:", error)
      throw error
    }
  },

  // Generate encryption keys for messaging
  generateEncryptionKeys: async () => {
    try {
      const response = await api.post("/auth/generate-keys")
      return response.data
    } catch (error) {
      console.error("Generate encryption keys error:", error)
      throw error
    }
  },

  // Listen for auth state changes
  onAuthStateChanged: (callback: (user: User | null) => void) => {
    return onAuthStateChanged(auth, callback)
  },
}

// Helper function to get Discord user ID from access token
async function getDiscordUserId(accessToken: string): Promise<string | null> {
  try {
    const response = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response.ok) {
      const data = await response.json()
      return data.id
    }
    return null
  } catch (error) {
    console.error("Error fetching Discord user ID:", error)
    return null
  }
}
