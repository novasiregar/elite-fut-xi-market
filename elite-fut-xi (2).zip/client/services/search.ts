import { API_URL } from "@/config"

export interface SearchFilters {
  category?: string
  minPrice?: number
  maxPrice?: number
  priceRange?: [number, number]
  rating?: number
  tags?: string[]
  featured?: boolean
  verified?: boolean
  status?: string
}

export interface SearchSuggestion {
  text: string
  type: "query" | "category" | "tag" | "player"
  count: number
}

export interface SearchResult {
  id: string
  title: string
  price: number
  description?: string
  category: string
  tags: string[]
  media: { type: string; url: string }[]
  seller: {
    id: string
    name: string
    avatar?: string
    verified: boolean
    rating: number
  }
  featured: boolean
  status: string
  createdAt: string
  updatedAt: string
}

export interface SearchResponse {
  results: SearchResult[]
  total: number
  page: number
  limit: number
  totalPages: number
  searchId?: string
}

export interface SavedSearch {
  id: string
  name: string
  query: string
  filters: SearchFilters
  notificationsEnabled: boolean
  createdAt: string
  lastRunAt: string
  lastResultCount: number
}

export class SearchService {
  /**
   * Search listings with filters
   */
  static async searchListings(params: {
    query?: string
    filters?: SearchFilters
    sort?: { field: string; order: string }
    page?: number
    limit?: number
  }): Promise<SearchResponse> {
    try {
      const { query = "", filters = {}, sort, page = 1, limit = 12 } = params

      // Build URL with query parameters
      const url = new URL(`${API_URL}/api/search`)

      // Add query
      if (query) url.searchParams.set("q", query)

      // Add pagination
      url.searchParams.set("page", page.toString())
      url.searchParams.set("limit", limit.toString())

      // Add sorting
      if (sort) {
        url.searchParams.set("sort", sort.field)
        url.searchParams.set("order", sort.order)
      }

      // Add filters
      if (filters.category) url.searchParams.set("category", filters.category)

      // Handle price range
      if (filters.priceRange) {
        url.searchParams.set("minPrice", filters.priceRange[0].toString())
        url.searchParams.set("maxPrice", filters.priceRange[1].toString())
      } else {
        if (filters.minPrice) url.searchParams.set("minPrice", filters.minPrice.toString())
        if (filters.maxPrice) url.searchParams.set("maxPrice", filters.maxPrice.toString())
      }

      // Add rating filter
      if (filters.rating) url.searchParams.set("rating", filters.rating.toString())

      // Add boolean filters
      if (filters.featured !== undefined) url.searchParams.set("featured", filters.featured.toString())
      if (filters.verified !== undefined) url.searchParams.set("verified", filters.verified.toString())

      // Add status filter
      if (filters.status) url.searchParams.set("status", filters.status)

      // Add tags filter
      if (filters.tags && filters.tags.length > 0) {
        url.searchParams.set("tags", filters.tags.join(","))
      }

      // Fetch results
      const response = await fetch(url.toString())

      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error searching listings:", error)
      throw error
    }
  }

  /**
   * Get search suggestions
   */
  static async getSuggestions(query: string): Promise<SearchSuggestion[]> {
    try {
      if (!query || query.length < 2) {
        return []
      }

      const url = new URL(`${API_URL}/api/search/suggestions`)
      url.searchParams.set("q", query)

      const response = await fetch(url.toString())

      if (!response.ok) {
        throw new Error(`Failed to get suggestions: ${response.statusText}`)
      }

      const data = await response.json()
      return data.suggestions || []
    } catch (error) {
      console.error("Error getting suggestions:", error)
      return []
    }
  }

  /**
   * Get saved searches
   */
  static async getSavedSearches(): Promise<SavedSearch[]> {
    try {
      const response = await fetch(`${API_URL}/api/search/saved`)

      if (!response.ok) {
        throw new Error(`Failed to get saved searches: ${response.statusText}`)
      }

      const data = await response.json()
      return data.savedSearches || []
    } catch (error) {
      console.error("Error getting saved searches:", error)
      return []
    }
  }

  /**
   * Save a search
   */
  static async saveSearch(params: {
    name: string
    query: string
    filters: SearchFilters
    notificationsEnabled?: boolean
  }): Promise<SavedSearch> {
    try {
      const response = await fetch(`${API_URL}/api/search/saved`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(params),
      })

      if (!response.ok) {
        throw new Error(`Failed to save search: ${response.statusText}`)
      }

      const data = await response.json()
      return data.savedSearch
    } catch (error) {
      console.error("Error saving search:", error)
      throw error
    }
  }

  /**
   * Delete a saved search
   */
  static async deleteSavedSearch(searchId: string): Promise<{ success: boolean }> {
    try {
      const response = await fetch(`${API_URL}/api/search/saved/${searchId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error(`Failed to delete saved search: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error deleting saved search:", error)
      throw error
    }
  }

  /**
   * Update saved search notification settings
   */
  static async updateSearchNotifications(
    searchId: string,
    enabled: boolean,
  ): Promise<{ success: boolean; notificationsEnabled: boolean }> {
    try {
      const response = await fetch(`${API_URL}/api/search/saved/${searchId}/notifications`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ enabled }),
      })

      if (!response.ok) {
        throw new Error(`Failed to update notifications: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error updating search notifications:", error)
      throw error
    }
  }

  /**
   * Perform visual search
   */
  static async visualSearch(imageFile: File): Promise<SearchResponse> {
    try {
      const formData = new FormData()
      formData.append("image", imageFile)

      const response = await fetch(`${API_URL}/api/search/visual`, {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Visual search failed: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error performing visual search:", error)
      throw error
    }
  }

  /**
   * Get similar listings
   */
  static async getSimilarListings(listingId: string, limit = 6): Promise<SearchResult[]> {
    try {
      const url = new URL(`${API_URL}/api/search/similar/${listingId}`)
      url.searchParams.set("limit", limit.toString())

      const response = await fetch(url.toString())

      if (!response.ok) {
        throw new Error(`Failed to get similar listings: ${response.statusText}`)
      }

      const data = await response.json()
      return data.results || []
    } catch (error) {
      console.error("Error getting similar listings:", error)
      return []
    }
  }
}
