import { api } from "./auth"

export interface Listing {
  id: string
  title: string
  description: string
  price: number
  sellerId: string
  sellerName: string
  sellerVerified: boolean
  media: Array<{
    url: string
    type: "image" | "video"
    fileName: string
  }>
  tags: string[]
  status: "active" | "pending_sale" | "sold" | "inactive"
  featured: boolean
  accountDetails: Record<string, any>
  createdAt: string
  updatedAt: string
  viewCount: number
  favoriteCount: number
}

export interface ListingFilter {
  page?: number
  limit?: number
  sort?: string
  order?: "asc" | "desc"
  minPrice?: number
  maxPrice?: number
  minRating?: number
  featured?: boolean
  verified?: boolean
  search?: string
  tags?: string[]
}

export const ListingService = {
  // Get all listings with filtering
  getListings: async (filters: ListingFilter = {}) => {
    try {
      const queryParams = new URLSearchParams()

      if (filters.page) queryParams.append("page", filters.page.toString())
      if (filters.limit) queryParams.append("limit", filters.limit.toString())
      if (filters.sort) queryParams.append("sort", filters.sort)
      if (filters.order) queryParams.append("order", filters.order)
      if (filters.minPrice) queryParams.append("minPrice", filters.minPrice.toString())
      if (filters.maxPrice) queryParams.append("maxPrice", filters.maxPrice.toString())
      if (filters.minRating) queryParams.append("minRating", filters.minRating.toString())
      if (filters.featured) queryParams.append("featured", filters.featured.toString())
      if (filters.verified) queryParams.append("verified", filters.verified.toString())
      if (filters.search) queryParams.append("search", filters.search)
      if (filters.tags && filters.tags.length > 0) queryParams.append("tags", filters.tags.join(","))

      const response = await api.get(`/listings?${queryParams.toString()}`)
      return response.data
    } catch (error) {
      console.error("Get listings error:", error)
      throw error
    }
  },

  // Get a single listing
  getListing: async (id: string) => {
    try {
      const response = await api.get(`/listings/${id}`)
      return response.data
    } catch (error) {
      console.error("Get listing error:", error)
      throw error
    }
  },

  // Create a new listing
  createListing: async (formData: FormData) => {
    try {
      const response = await api.post("/listings", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      return response.data
    } catch (error) {
      console.error("Create listing error:", error)
      throw error
    }
  },

  // Update a listing
  updateListing: async (id: string, data: Partial<Listing>) => {
    try {
      const response = await api.put(`/listings/${id}`, data)
      return response.data
    } catch (error) {
      console.error("Update listing error:", error)
      throw error
    }
  },

  // Delete a listing
  deleteListing: async (id: string) => {
    try {
      const response = await api.delete(`/listings/${id}`)
      return response.data
    } catch (error) {
      console.error("Delete listing error:", error)
      throw error
    }
  },

  // Add media to a listing
  addMedia: async (id: string, formData: FormData) => {
    try {
      const response = await api.post(`/listings/${id}/media`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      return response.data
    } catch (error) {
      console.error("Add media error:", error)
      throw error
    }
  },

  // Get user's listings
  getUserListings: async (status?: string) => {
    try {
      const queryParams = new URLSearchParams()
      if (status) queryParams.append("status", status)

      const response = await api.get(`/users/listings?${queryParams.toString()}`)
      return response.data
    } catch (error) {
      console.error("Get user listings error:", error)
      throw error
    }
  },
}
