import { api } from "./auth"
import { storage } from "./auth"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"

export const UserService = {
  // Get user profile
  getUserProfile: async () => {
    try {
      const response = await api.get("/auth/profile")
      return response.data
    } catch (error) {
      console.error("Get user profile error:", error)
      throw error
    }
  },

  // Get user by ID
  getUserById: async (userId: string) => {
    try {
      const response = await api.get(`/users/${userId}`)
      return response.data
    } catch (error) {
      console.error("Get user by ID error:", error)
      throw error
    }
  },

  // Update user profile
  updateUserProfile: async (data: FormData) => {
    try {
      const response = await api.put("/auth/profile", data)
      return response.data
    } catch (error) {
      console.error("Update user profile error:", error)
      throw error
    }
  },

  // Upload profile image
  uploadProfileImage: async (file: File) => {
    try {
      const storageRef = ref(storage, `profile-images/${Date.now()}-${file.name}`)
      await uploadBytes(storageRef, file)
      const downloadURL = await getDownloadURL(storageRef)
      return downloadURL
    } catch (error) {
      console.error("Upload profile image error:", error)
      throw error
    }
  },

  // Get user notifications
  getNotifications: async (includeRead = true) => {
    try {
      const response = await api.get(`/users/notifications?includeRead=${includeRead}`)
      return response.data
    } catch (error) {
      console.error("Get notifications error:", error)
      throw error
    }
  },

  // Mark notification as read
  markNotificationAsRead: async (notificationId: string) => {
    try {
      const response = await api.put(`/users/notifications/${notificationId}/read`)
      return response.data
    } catch (error) {
      console.error("Mark notification as read error:", error)
      throw error
    }
  },

  // Mark all notifications as read
  markAllNotificationsAsRead: async () => {
    try {
      const response = await api.put("/users/notifications/read-all")
      return response.data
    } catch (error) {
      console.error("Mark all notifications as read error:", error)
      throw error
    }
  },

  // Create conversation with user
  createConversation: async (userId: string) => {
    try {
      const response = await api.post("/messages/conversations", { recipientId: userId })
      return response.data.conversationId
    } catch (error) {
      console.error("Create conversation error:", error)
      throw error
    }
  },

  // Get seller reviews
  getSellerReviews: async (sellerId: string) => {
    try {
      const response = await api.get(`/users/${sellerId}/reviews`)
      return response.data
    } catch (error) {
      console.error("Get seller reviews error:", error)
      throw error
    }
  },

  // Check if user can review seller
  canReviewSeller: async (sellerId: string) => {
    try {
      const response = await api.get(`/users/${sellerId}/can-review`)
      return response.data.canReview
    } catch (error) {
      console.error("Can review seller error:", error)
      return false
    }
  },

  // Submit seller review
  submitSellerReview: async (sellerId: string, reviewData: { rating: number; comment: string }) => {
    try {
      const response = await api.post(`/users/${sellerId}/reviews`, reviewData)
      return response.data
    } catch (error) {
      console.error("Submit seller review error:", error)
      throw error
    }
  },

  // Mark review as helpful
  markReviewHelpful: async (reviewId: string) => {
    try {
      const response = await api.put(`/users/reviews/${reviewId}/helpful`)
      return response.data
    } catch (error) {
      console.error("Mark review as helpful error:", error)
      throw error
    }
  },

  // Report review
  reportReview: async (reviewId: string) => {
    try {
      const response = await api.post(`/users/reviews/${reviewId}/report`)
      return response.data
    } catch (error) {
      console.error("Report review error:", error)
      throw error
    }
  },

  // Get seller stats
  getSellerStats: async (sellerId: string) => {
    try {
      const response = await api.get(`/users/${sellerId}/stats`)
      return response.data
    } catch (error) {
      console.error("Get seller stats error:", error)

      // For demo purposes, return mock data if API fails
      return {
        totalSales: 42,
        completionRate: 98,
        averageResponseTime: 15,
        disputeRate: 2,
        ratingBreakdown: {
          5: 75,
          4: 15,
          3: 5,
          2: 3,
          1: 2,
        },
        recentActivity: [
          { date: "Jan", sales: 5 },
          { date: "Feb", sales: 8 },
          { date: "Mar", sales: 12 },
          { date: "Apr", sales: 7 },
          { date: "May", sales: 10 },
          { date: "Jun", sales: 15 },
          { date: "Jul", sales: 18 },
        ],
      }
    }
  },
}
