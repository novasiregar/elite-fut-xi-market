export const SellerService = {
  // Get seller dashboard stats
  getStats: async () => {
    try {
      // In a real implementation, this would fetch from Firestore
      // For now, returning mock data
      return {
        totalSales: 45,
        totalRevenue: 22500000,
        salesData: [
          { name: "Jan", sales: 5, revenue: 2500000 },
          { name: "Feb", sales: 8, revenue: 4000000 },
          { name: "Mar", sales: 12, revenue: 6000000 },
          { name: "Apr", sales: 10, revenue: 5000000 },
          { name: "May", sales: 15, revenue: 7500000 },
          { name: "Jun", sales: 20, revenue: 10000000 },
        ],
        categoryData: [
          { name: "Premium", value: 40 },
          { name: "Standard", value: 30 },
          { name: "Budget", value: 20 },
          { name: "Other", value: 10 },
        ],
      }
    } catch (error) {
      console.error("Error fetching seller stats:", error)
      throw error
    }
  },

  // Get seller's listings
  getListings: async () => {
    try {
      // In a real implementation, this would fetch from Firestore
      // For now, returning mock data
      return [
        {
          id: "listing1",
          title: "FIFA 25 Ultimate Team Account",
          price: 1500000,
          image: null,
          status: "active",
          createdAt: new Date().toISOString(),
          viewCount: 120,
          favoriteCount: 15,
          messageCount: 8,
        },
        {
          id: "listing2",
          title: "eFootball 2025 Legend Account",
          price: 2200000,
          image: null,
          status: "pending",
          createdAt: new Date().toISOString(),
          viewCount: 98,
          favoriteCount: 12,
          messageCount: 5,
        },
        {
          id: "listing3",
          title: "FC 25 Pro Account",
          price: 1800000,
          image: null,
          status: "active",
          createdAt: new Date().toISOString(),
          viewCount: 86,
          favoriteCount: 10,
          messageCount: 7,
        },
        {
          id: "listing4",
          title: "FIFA 25 Rare Cards Collection",
          price: 3500000,
          image: null,
          status: "active",
          createdAt: new Date().toISOString(),
          viewCount: 99,
          favoriteCount: 11,
          messageCount: 3,
        },
        {
          id: "listing5",
          title: "eFootball 2025 Starter Account",
          price: 800000,
          image: null,
          status: "active",
          createdAt: new Date().toISOString(),
          viewCount: 85,
          favoriteCount: 9,
          messageCount: 4,
        },
      ]
    } catch (error) {
      console.error("Error fetching seller listings:", error)
      throw error
    }
  },

  // Get seller's transactions
  getTransactions: async () => {
    try {
      // In a real implementation, this would fetch from Firestore
      // For now, returning mock data
      return [
        {
          id: "transaction1",
          title: "FIFA 25 Ultimate Team Account",
          amount: 1500000,
          status: "completed",
          createdAt: new Date().toISOString(),
        },
        {
          id: "transaction2",
          title: "eFootball 2025 Legend Account",
          amount: 2200000,
          status: "pending",
          createdAt: new Date().toISOString(),
        },
        {
          id: "transaction3",
          title: "FC 25 Pro Account",
          amount: 1800000,
          status: "completed",
          createdAt: new Date().toISOString(),
        },
        {
          id: "transaction4",
          title: "FIFA 25 Rare Cards Collection",
          amount: 3500000,
          status: "completed",
          createdAt: new Date().toISOString(),
        },
        {
          id: "transaction5",
          title: "eFootball 2025 Starter Account",
          amount: 800000,
          status: "disputed",
          createdAt: new Date().toISOString(),
        },
      ]
    } catch (error) {
      console.error("Error fetching seller transactions:", error)
      throw error
    }
  },

  // Create a new listing
  createListing: async (listingData) => {
    try {
      // In a real implementation, this would create a new listing in Firestore
      console.log("Creating listing:", listingData)
      return {
        id: "new-listing-id",
        ...listingData,
        createdAt: new Date().toISOString(),
        status: "pending",
        viewCount: 0,
        favoriteCount: 0,
        messageCount: 0,
      }
    } catch (error) {
      console.error("Error creating listing:", error)
      throw error
    }
  },

  // Update an existing listing
  updateListing: async (listingId, updates) => {
    try {
      // In a real implementation, this would update the listing in Firestore
      console.log(`Updating listing ${listingId} with:`, updates)
      return { success: true }
    } catch (error) {
      console.error("Error updating listing:", error)
      throw error
    }
  },

  // Delete a listing
  deleteListing: async (listingId) => {
    try {
      // In a real implementation, this would delete the listing from Firestore
      console.log(`Deleting listing ${listingId}`)
      return { success: true }
    } catch (error) {
      console.error("Error deleting listing:", error)
      throw error
    }
  },

  // Get seller performance metrics
  getPerformanceMetrics: async () => {
    try {
      // In a real implementation, this would fetch metrics from Firestore or analytics
      return {
        conversionRate: 12.5, // percentage
        responseTime: 2.5, // hours
        completionRate: 95, // percentage
        repeatBuyers: 18, // percentage
        averageRating: 4.8, // out of 5
      }
    } catch (error) {
      console.error("Error fetching seller performance metrics:", error)
      throw error
    }
  },
}
