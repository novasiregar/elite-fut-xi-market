import { onMessage } from "firebase/messaging"
import { db, auth } from "./auth"
import { doc, setDoc, serverTimestamp } from "firebase/firestore"

// Initialize Firebase Cloud Messaging
let messaging: any = null

// Initialize FCM if browser supports it
export const initializeMessaging = async () => {
  try {
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      const { getMessaging, getToken, onMessage } = await import("firebase/messaging")

      messaging = getMessaging()

      // Request permission
      const permission = await Notification.requestPermission()

      if (permission === "granted") {
        // Get FCM token
        const currentToken = await getToken(messaging, {
          vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY,
        })

        if (currentToken) {
          // Save the token to the user's document
          const user = auth.currentUser
          if (user) {
            await saveTokenToDatabase(currentToken)
          }

          return currentToken
        } else {
          console.log("No registration token available. Request permission to generate one.")
        }
      } else {
        console.log("Notification permission denied.")
      }
    }
  } catch (error) {
    console.error("Error initializing messaging:", error)
  }

  return null
}

// Save FCM token to Firestore
const saveTokenToDatabase = async (token: string) => {
  try {
    const user = auth.currentUser
    if (!user) return

    const tokenRef = doc(db, "fcmTokens", user.uid)

    await setDoc(
      tokenRef,
      {
        token,
        device: getDeviceInfo(),
        updatedAt: serverTimestamp(),
      },
      { merge: true },
    )

    console.log("FCM Token saved to database")
  } catch (error) {
    console.error("Error saving token to database:", error)
  }
}

// Get device info for token management
const getDeviceInfo = () => {
  const userAgent = navigator.userAgent
  const platform = navigator.platform

  return {
    userAgent,
    platform,
    browser: getBrowser(),
    os: getOS(),
  }
}

// Helper to detect browser
const getBrowser = () => {
  const userAgent = navigator.userAgent

  if (userAgent.indexOf("Chrome") > -1) return "Chrome"
  if (userAgent.indexOf("Safari") > -1) return "Safari"
  if (userAgent.indexOf("Firefox") > -1) return "Firefox"
  if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) return "IE"
  if (userAgent.indexOf("Edge") > -1) return "Edge"

  return "Unknown"
}

// Helper to detect OS
const getOS = () => {
  const userAgent = navigator.userAgent

  if (userAgent.indexOf("Windows") > -1) return "Windows"
  if (userAgent.indexOf("Mac") > -1) return "MacOS"
  if (userAgent.indexOf("Linux") > -1) return "Linux"
  if (userAgent.indexOf("Android") > -1) return "Android"
  if (userAgent.indexOf("iOS") > -1 || /iPhone|iPad|iPod/.test(userAgent)) return "iOS"

  return "Unknown"
}

// Listen for FCM messages
export const onForegroundMessage = (callback: (payload: any) => void) => {
  if (!messaging) return () => {}

  return onMessage(messaging, (payload) => {
    console.log("Message received in foreground:", payload)
    callback(payload)
  })
}

// Notification service
export const NotificationService = {
  // Initialize messaging and request permission
  initialize: async () => {
    return await initializeMessaging()
  },

  // Listen for foreground messages
  onForegroundMessage,

  // Display a notification
  displayNotification: (title: string, options: NotificationOptions) => {
    if (Notification.permission === "granted") {
      navigator.serviceWorker.ready.then((registration) => {
        registration.showNotification(title, options)
      })
    }
  },
}
