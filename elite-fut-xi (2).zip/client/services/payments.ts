import { api } from "./auth"

export enum PaymentStatus {
  PENDING = "pending",
  PROCESSING = "processing",
  COMPLETED = "completed",
  FAILED = "failed",
  EXPIRED = "expired",
  REFUNDED = "refunded",
}

export interface PaymentDetails {
  qrCode?: string
  deepLink?: string
  phoneNumber?: string
  bankAccounts?: Array<{
    bank: string
    accountNumber: string
    accountName: string
  }>
  amount: number
  reference: string
  expiresAt: string
}

export interface Payment {
  transactionId: string
  paymentReference: string
  amount: number
  buyerId: string
  sellerId: string
  paymentMethod: string
  status: PaymentStatus
  paymentDetails?: PaymentDetails
  createdAt: string
  updatedAt: string
  completedAt?: string
}

export const PaymentService = {
  // Initialize payment for a transaction
  initializePayment: async (transactionId: string, paymentMethod: string) => {
    try {
      const response = await api.post("/payments/initialize", {
        transactionId,
        paymentMethod,
      })
      return response.data
    } catch (error) {
      console.error("Initialize payment error:", error)
      throw error
    }
  },

  // Check payment status
  checkPaymentStatus: async (reference: string) => {
    try {
      const response = await api.get(`/payments/status/${reference}`)
      return response.data
    } catch (error) {
      console.error("Check payment status error:", error)
      throw error
    }
  },

  // Verify payment
  verifyPayment: async (reference: string, receiptData?: any) => {
    try {
      const response = await api.post(`/payments/verify/${reference}`, { receiptData })
      return response.data
    } catch (error) {
      console.error("Verify payment error:", error)
      throw error
    }
  },

  // Cancel payment
  cancelPayment: async (reference: string) => {
    try {
      const response = await api.post(`/payments/cancel/${reference}`)
      return response.data
    } catch (error) {
      console.error("Cancel payment error:", error)
      throw error
    }
  },

  // Get payment methods
  getPaymentMethods: () => {
    return [
      {
        id: "gopay",
        name: "GoPay",
        icon: "/icons/gopay.png",
        description: "Pay with GoPay",
        fee: 0.02, // 2% fee
      },
      {
        id: "ovo",
        name: "OVO",
        icon: "/icons/ovo.png",
        description: "Pay with OVO",
        fee: 0.02, // 2% fee
      },
      {
        id: "dana",
        name: "DANA",
        icon: "/icons/dana.png",
        description: "Pay with DANA",
        fee: 0.02, // 2% fee
      },
      {
        id: "bank_transfer",
        name: "Bank Transfer",
        icon: "/icons/bank.png",
        description: "Pay with Bank Transfer",
        fee: 0.01, // 1% fee
      },
    ]
  },

  // Calculate payment fee
  calculateFee: (amount: number, paymentMethod: string) => {
    const methods = PaymentService.getPaymentMethods()
    const method = methods.find((m) => m.id === paymentMethod)

    if (!method) return 0

    return Math.ceil(amount * method.fee)
  },

  // Calculate total amount with fee
  calculateTotal: (amount: number, paymentMethod: string) => {
    const fee = PaymentService.calculateFee(amount, paymentMethod)
    return amount + fee
  },
}
