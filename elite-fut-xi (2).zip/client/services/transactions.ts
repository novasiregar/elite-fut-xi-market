import { api } from "./auth"

export enum TransactionStatus {
  PENDING = "pending",
  PAYMENT_PROCESSING = "payment_processing",
  PAYMENT_COMPLETED = "payment_completed",
  ESCROW_FUNDED = "escrow_funded",
  ACCOUNT_DELIVERED = "account_delivered",
  COMPLETED = "completed",
  DISPUTED = "disputed",
  REFUNDED = "refunded",
  CANCELLED = "cancelled",
}

export interface Transaction {
  id: string
  listingId: string
  listingTitle: string
  buyerId: string
  sellerId: string
  amount: number
  escrowId: string
  paymentMethod: string
  paymentReference?: string
  status: TransactionStatus
  timeline: Array<{
    status: TransactionStatus
    timestamp: string
    note: string
  }>
  rating?: number
  review?: string
  deliveryDetails?: string
  deliveryMethod?: string
  deliveredAt?: string
  disputeId?: string
  createdAt: string
  updatedAt: string
}

export const TransactionService = {
  // Create a new transaction
  createTransaction: async (listingId: string, paymentMethod: string) => {
    try {
      const response = await api.post("/transactions", {
        listingId,
        paymentMethod,
      })
      return response.data
    } catch (error) {
      console.error("Create transaction error:", error)
      throw error
    }
  },

  // Get all transactions for current user
  getTransactions: async (status?: string, role?: "buyer" | "seller" | "all") => {
    try {
      const queryParams = new URLSearchParams()
      if (status) queryParams.append("status", status)
      if (role) queryParams.append("role", role)

      const response = await api.get(`/transactions?${queryParams.toString()}`)
      return response.data
    } catch (error) {
      console.error("Get transactions error:", error)
      throw error
    }
  },

  // Get a single transaction
  getTransaction: async (id: string) => {
    try {
      const response = await api.get(`/transactions/${id}`)
      return response.data
    } catch (error) {
      console.error("Get transaction error:", error)
      throw error
    }
  },

  // Confirm delivery (for buyer)
  confirmDelivery: async (id: string, rating?: number, review?: string) => {
    try {
      const response = await api.post(`/transactions/${id}/confirm-delivery`, {
        rating,
        review,
      })
      return response.data
    } catch (error) {
      console.error("Confirm delivery error:", error)
      throw error
    }
  },

  // Mark as delivered (for seller)
  markAsDelivered: async (id: string, deliveryDetails: string, deliveryMethod: string) => {
    try {
      const response = await api.post(`/transactions/${id}/deliver`, {
        deliveryDetails,
        deliveryMethod,
      })
      return response.data
    } catch (error) {
      console.error("Mark as delivered error:", error)
      throw error
    }
  },

  // Open a dispute
  openDispute: async (id: string, reason: string, details: string) => {
    try {
      const response = await api.post(`/transactions/${id}/dispute`, {
        reason,
        details,
      })
      return response.data
    } catch (error) {
      console.error("Open dispute error:", error)
      throw error
    }
  },

  // Cancel a transaction
  cancelTransaction: async (id: string, reason?: string) => {
    try {
      const response = await api.post(`/transactions/${id}/cancel`, {
        reason,
      })
      return response.data
    } catch (error) {
      console.error("Cancel transaction error:", error)
      throw error
    }
  },
}
