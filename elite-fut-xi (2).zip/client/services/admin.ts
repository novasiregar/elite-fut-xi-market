export const AdminService = {
  // Get admin dashboard stats
  getStats: async () => {
    try {
      // In a real implementation, this would fetch from the server
      // For now, returning mock data
      return {
        totalUsers: 1250,
        totalListings: 3456,
        totalTransactions: 789,
        totalRevenue: 123456789,
        pendingVerifications: 15,
        reportedListings: 8,
        disputedTransactions: 5,
        salesData: [
          { name: "Jan", transactions: 45, revenue: 22500000 },
          { name: "Feb", transactions: 58, revenue: 29000000 },
          { name: "Mar", transactions: 72, revenue: 36000000 },
          { name: "Apr", transactions: 80, revenue: 40000000 },
          { name: "May", transactions: 95, revenue: 47500000 },
          { name: "Jun", transactions: 110, revenue: 55000000 },
        ],
      }
    } catch (error) {
      console.error("Error fetching admin stats:", error)
      throw error
    }
  },

  // Get users with pagination
  getUsers: async ({ page = 1, limit: pageLimit = 10, filter = "" }) => {
    try {
      // In a real implementation, this would fetch from Firestore with pagination
      // For now, returning mock data
      return {
        data: [
          {
            id: "user1",
            displayName: "John Doe",
            email: "john@example.com",
            avatar: null,
            isVerified: true,
            isBanned: false,
            createdAt: new Date().toISOString(),
          },
          {
            id: "user2",
            displayName: "Jane Smith",
            email: "jane@example.com",
            avatar: null,
            isVerified: false,
            isBanned: false,
            createdAt: new Date().toISOString(),
          },
        ],
        pagination: {
          total: 1250,
          page,
          pageSize: pageLimit,
          totalPages: Math.ceil(1250 / pageLimit),
        },
      }
    } catch (error) {
      console.error("Error fetching users:", error)
      throw error
    }
  },

  // Get listings with pagination
  getListings: async ({ page = 1, limit: pageLimit = 10, filter = "" } = {}) => {
    try {
      // In a real implementation, this would fetch from Firestore with pagination
      // For now, returning mock data
      return {
        data: [
          {
            id: "listing1",
            title: "FIFA 25 Ultimate Team Account",
            price: 1500000,
            image: null,
            status: "active",
            sellerName: "John Doe",
            createdAt: new Date().toISOString(),
          },
          {
            id: "listing2",
            title: "eFootball 2025 Legend Account",
            price: 2200000,
            image: null,
            status: "pending",
            sellerName: "Jane Smith",
            createdAt: new Date().toISOString(),
          },
        ],
        pagination: {
          total: 3456,
          page,
          pageSize: pageLimit,
          totalPages: Math.ceil(3456 / pageLimit),
        },
      }
    } catch (error) {
      console.error("Error fetching listings:", error)
      throw error
    }
  },

  // Get transactions with pagination
  getTransactions: async ({ page = 1, limit: pageLimit = 10, filter = "" } = {}) => {
    try {
      // In a real implementation, this would fetch from Firestore with pagination
      // For now, returning mock data
      return {
        data: [
          {
            id: "transaction1",
            title: "FIFA 25 Ultimate Team Account",
            amount: 1500000,
            status: "completed",
            createdAt: new Date().toISOString(),
          },
          {
            id: "transaction2",
            title: "eFootball 2025 Legend Account",
            amount: 2200000,
            status: "pending",
            createdAt: new Date().toISOString(),
          },
        ],
        pagination: {
          total: 789,
          page,
          pageSize: pageLimit,
          totalPages: Math.ceil(789 / pageLimit),
        },
      }
    } catch (error) {
      console.error("Error fetching transactions:", error)
      throw error
    }
  },

  // Get reports with pagination
  getReports: async ({ page = 1, limit: pageLimit = 10, filter = "" } = {}) => {
    try {
      // In a real implementation, this would fetch from Firestore with pagination
      // For now, returning mock data
      return {
        data: [
          {
            id: "report1",
            reason: "Fraudulent listing",
            status: "pending",
            createdAt: new Date().toISOString(),
          },
          {
            id: "report2",
            reason: "Inappropriate content",
            status: "resolved",
            createdAt: new Date().toISOString(),
          },
        ],
        pagination: {
          total: 45,
          page,
          pageSize: pageLimit,
          totalPages: Math.ceil(45 / pageLimit),
        },
      }
    } catch (error) {
      console.error("Error fetching reports:", error)
      throw error
    }
  },

  // Update user status (verify, ban, etc.)
  updateUserStatus: async (userId, updates) => {
    try {
      // In a real implementation, this would update the user in Firestore
      console.log(`Updating user ${userId} with:`, updates)
      return { success: true }
    } catch (error) {
      console.error("Error updating user status:", error)
      throw error
    }
  },

  // Update listing status
  updateListingStatus: async (listingId, status) => {
    try {
      // In a real implementation, this would update the listing in Firestore
      console.log(`Updating listing ${listingId} to status: ${status}`)
      return { success: true }
    } catch (error) {
      console.error("Error updating listing status:", error)
      throw error
    }
  },

  // Resolve a report
  resolveReport: async (reportId, resolution) => {
    try {
      // In a real implementation, this would update the report in Firestore
      console.log(`Resolving report ${reportId} with:`, resolution)
      return { success: true }
    } catch (error) {
      console.error("Error resolving report:", error)
      throw error
    }
  },

  // Get platform settings
  getPlatformSettings: async () => {
    try {
      // In a real implementation, this would fetch from Firestore
      return {
        maintenanceMode: false,
        allowNewRegistrations: true,
        allowNewListings: true,
        platformFee: 5, // percentage
        minimumWithdrawal: 100000,
        maximumListingPrice: 10000000,
      }
    } catch (error) {
      console.error("Error fetching platform settings:", error)
      throw error
    }
  },

  // Update platform settings
  updatePlatformSettings: async (settings) => {
    try {
      // In a real implementation, this would update settings in Firestore
      console.log("Updating platform settings:", settings)
      return { success: true }
    } catch (error) {
      console.error("Error updating platform settings:", error)
      throw error
    }
  },
}
